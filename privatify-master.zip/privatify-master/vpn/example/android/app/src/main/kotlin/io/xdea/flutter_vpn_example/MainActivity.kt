package io.xdea.flutter_vpn_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
