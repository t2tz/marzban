import 'dart:developer';

import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:get/get.dart';
import 'package:privatify/models/loginResponse.dart' as LoginModel;
import 'package:privatify/models/profile.dart' as ProfileModel;
import 'package:privatify/models/update.dart' as UpdateModel;
import 'package:privatify/models/usage.dart' as UsageModel;

import 'package:privatify/models/user.dart';
import 'package:privatify/providers/app.dart';
import 'package:privatify/providers/user.dart';
import 'package:dio/dio.dart';
//import 'package:flutter_secure'

class User extends GetxController {
  //var data = Rx.obs;
  final data = Data().obs;
  final loginData = LoginModel.Data().obs;
  final profile = ProfileModel.Data().obs;
  final usage = UsageModel.Data().obs;
  final updateApp = UpdateModel.Data().obs;
  final url = "".obs;

  final userAction = {"email": "", "password": "", "action": "login"}.obs;

  userLogin(String email, String password) async {
    try {
      var response = await UserProvider().login(email, password);
      if (response.statusCode == 201) {
        var body = LoginModel.LoginResponse.fromJson(response.data);
        loginData.value = body.data!;
      }
    } catch (e) {
      rethrow;
    }
  }

  register(String email, String password) async {
    try {
      var response = await UserProvider().register(email, password);

      if (response.statusCode == 201) {
        var body = LoginModel.LoginResponse.fromJson(response.data);
        loginData.value = body.data!;
      }
    } catch (e) {
      rethrow;
    }
  }

  verifyCode(num code, String email) async {
    try {
      var response = await UserProvider().verifyCode(code, email);
      if (response.statusCode == 201) {
        var body = UserModel.fromJson(response.data);
        final storage = new FlutterSecureStorage();
        await storage.write(key: "jwt-token", value: body.data!.token);
        data.value = body.data!;
      }
    } catch (e) {
      rethrow;
      //log("$e");
    }
  }

  resendCode(String email) async {
    try {
      var response = await UserProvider().resendCode(email);
      if (response.statusCode == 201) {
        return true;
      }
    } catch (e) {
      rethrow;
      //log("$e");
    }
  }

  verifyPayment(String email, String recieptData) async {
    try {
      var response = await UserProvider().verifyPayment(email, recieptData);
      if (response.statusCode == 201) {
        return true;
      }
    } catch (e) {
      print(e);
      rethrow;
      //log("$e");
    }
  }

  getProfile() async {
    try {
      var response = await UserProvider().profile();

      // var body = User().
      if (response.statusCode == 200) {
        var body = ProfileModel.Profile.fromJson(response.data);

        profile.value = body.data!;
      }
    } catch (e) {
      log("$e");
    }
  }

  getUserUsage() async {
    try {
      var resposne = await UserProvider().getUsage();
      print(resposne);
      if (resposne.statusCode == 200) {
        var body = UsageModel.UsageModel.fromJson(resposne.data);
        usage.value = body.data!;
      }
    } catch (e) {
      log("$e");
    }
  }

  getUpdate() async {
    try {
      var response = await AppProvider().checkUpdate();

      if (response.statusCode == 201) {
        var body = UpdateModel.UpdateModel.fromJson(response.data);
        updateApp.value = body.data!;
      }
    } catch (e) {
      rethrow;
    }
  }

  setAction(action) {
    userAction["action"] = action;
  }

  setEmail(email) {
    userAction["email"] = email;
  }

  setPassword(password) {
    userAction["password"] = password;
  }

  setUrl(_url) {
    url.value = _url;
  }
}
