import 'dart:developer';
import 'package:get/get.dart';
import 'package:privatify/models/refrence.dart' as RefrenceModel;
import 'package:privatify/providers/refrences.dart';

import '../models/category.dart' as CategoryModel;
//import 'package:flutter_secure'

class Refrence extends GetxController {
  //var data = Rx.obs;
   final categories = CategoryModel.Category.fromJson(
    {
  "data": [
    {
      "id": 9,
      "title": "Privacy & security tools",
      "description": "Privacy & security tools",
      "slug": "privacy-security-tools"
    },
    {
      "id": 10,
      "title": "Help & Support",
      "description": "Help & Support",
      "slug": "help-support"
    }
  ],
  "statusCode": 200
}
   ).obs;

  final refrences = <RefrenceModel.Data>[].obs;


  getCategories() async {
    try {
      var response = await RefrenceProvider().categories();

      if (response.statusCode == 200) {
        var body = CategoryModel.Category.fromJson(response.data);
     //   categories.value = body.data!;
      }
    } catch (e) {
      log("$e");
    }
  }

  getRefrences(int categoryId) async {
    try {
      refrences.value = <RefrenceModel.Data>[];
      var response = await RefrenceProvider().refrences(categoryId);

      if (response.statusCode == 200) {
        var body = RefrenceModel.Refrences.fromJson(response.data);
        refrences.value = body.data!;
      }
    } catch (e) {
      log("$e");
    }
  }
}
