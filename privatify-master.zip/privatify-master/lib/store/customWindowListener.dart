import 'dart:developer';

import 'package:get/get.dart';
import 'package:privatify/store/server.dart';
import 'package:privatify/store/vpn.dart';
import 'package:tray_manager/tray_manager.dart';
import 'package:window_manager/window_manager.dart';

class CustomWindowListener extends GetxController
    with WindowListener, TrayListener {
  var vpn = Get.find<VPN>();
  var server = Get.find<Server>();
  CustomWindowListener() {
    windowManager.addListener(this);
    trayManager.addListener(this);

    vpn.status.listen((value) async {
      if (value == Status.connected || value == Status.connecting) {
        await createTrayMenu(connected: true);
      } else {
        await createTrayMenu();
      }
    });
  }

  var count = 0.obs;

  Future<void> _showApp() async {
    await windowManager.show();
    await windowManager.focus();
    await server.refreshServer();
  }

  Future<void> _closeApp(bool isClosable) async {
    // TODO: implement onWindowClose

    await windowManager.setPreventClose(!isClosable);
    if (!isClosable) {
      windowManager.hide();
    } else {
      windowManager.close();
    }
  }

  @override
  void onWindowClose() async {
    await _closeApp(false);
  }

  @override
  void onTrayIconMouseDown() {
    _showApp();
  }

  @override
  void onTrayIconRightMouseDown() {
    trayManager.popUpContextMenu();
  }

  void onTrayMenuItemClick(MenuItem menuItem) async {
    if (menuItem.key == 'show_window') {
      await _showApp();
    } else if (menuItem.key == 'exit_app') {
      await _closeApp(true);
    }

    if (menuItem.key == 'connect') {
      await vpn.connect();
    }

    if (menuItem.key == 'disconnect') {
      await vpn.disconnect();
    }
  }

  createTrayMenu({connected: false}) async {
    var menu = Menu(items: [
      connected == true
          ? MenuItem(
              key: 'disconnect',
              label: 'Disconnect VPN',
            )
          : MenuItem(
              key: 'connect',
              label: 'Connect VPN',
            ),
      MenuItem(
        key: 'show_window',
        label: 'Show Privatify',
      ),
      MenuItem.separator(),
      MenuItem(
        key: 'exit_app',
        label: 'Exit Privatify',
      )
    ]);

    await trayManager.setContextMenu(menu);
  }
}
