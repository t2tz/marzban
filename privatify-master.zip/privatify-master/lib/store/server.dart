import 'dart:developer';

import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:get/get.dart';
import 'package:privatify/models/config.dart' as Config;
import 'package:privatify/models/country.dart' as Country;
import 'package:privatify/models/servers.dart' as Servers;
import 'package:privatify/providers/server.dart';
import 'package:privatify/store/vpn.dart';
//import 'package:flutter_secure'

class Server extends GetxController {
  //var data = Rx.obs;
  final countries = <Country.Data>[].obs;
  final servers = <Servers.Data>[].obs;
  final id = 0.obs;
  final server = Servers.Data().obs;
  final config = Config.Data().obs;

  final favServerIds = [].obs;

  //final vpn = Get.find<VPN>();

  getCountries() async {
    try {
      var response = await ServerProvider().countries();

      if (response.statusCode == 200) {
        var body = Country.CountryModel.fromJson(response.data);
        countries.value = body.data!;
      }
    } catch (e) {
      log("$e");
    }
  }

  getServers() async {
    try {
      final storage = new FlutterSecureStorage();
      var proto = (await storage.read(key: 'protocol')) ?? "auto";

      var response = await ServerProvider().servers(proto: proto.toString());
      if (response.statusCode == 200) {
        var body = Servers.ServersModel.fromJson(response.data);
        servers.value = body.data!;
        storage.write(key: "cached_servers", value: proto);
      }
    } catch (e) {
      log("$e");
    }
  }

  selectServer(Servers.Data serverData) async {
    id.value = (serverData != null ? serverData.id : servers[0].id)!;
    server.value =
        servers.singleWhere((element) => element.id == serverData.id);
    await _serverInit();
  }

  refreshServer() async {
    var _server = server.value;
    server.value = Servers.Data();
    server.value = _server;
  }

  _serverInit() async {
    try {
      final storage = new FlutterSecureStorage();
      var proto = await storage.read(key: 'protocol');

      var response = await ServerProvider()
          .init(serverId: id.value, proto: proto ?? 'auto');

      if (response.statusCode == 201) {
        var body = Config.ConfigModel.fromJson(response.data);
        config.value = body.data!;
      }
    } catch (e) {
      log("$e");
    }
  }

  void toggleFavorite(int serverId) async {
    final storage = new FlutterSecureStorage();

    List<int> favServersList = await getFavorites();

    favServersList.contains(serverId)
        ? favServersList.remove(serverId)
        : favServersList.add(serverId);

    favServerIds.value = favServersList;

    await storage.write(key: "servers", value: favServersList.join(","));
    //favServers = ServerModel.ServersModel.fromJson(favServers);
  }

  Future<List<int>> getFavorites() async {
    final storage = new FlutterSecureStorage();

    String favServers = (await storage.read(key: "servers")) ?? "";

    List<int> favServersList = favServers
        .split(',')
        .map((e) => e.isNotEmpty ? int.parse(e) : 0)
        .toList();

    favServerIds.value = favServersList;

    return favServersList;
  }
}
