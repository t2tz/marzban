import 'dart:async';
import 'dart:convert';
import 'dart:developer';

import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:flutter_vpn/flutter_vpn.dart';
import 'package:flutter_vpn/state.dart';
import 'package:get/get.dart';
import 'package:openvpn_flutter/openvpn_flutter.dart';
import 'package:path_provider/path_provider.dart';
import 'package:privatify/store/server.dart';
import 'package:tray_manager/tray_manager.dart';
import 'dart:io';
import 'package:web_socket_channel/io.dart';

enum Status { notConnected, connecting, connected, disconnecting, reconnecting }

enum Protocol { auto, udp, tcp, ikev2 }

class VPN extends GetxController {
  final storage = new FlutterSecureStorage();
  // final streamController = StreamController.broadcast();
  final server = Get.find<Server>();

  var status = Status.notConnected.obs;
  var protocol = Protocol.auto.obs;
  var autoConnect = false.obs;
  late final channel;

  late OpenVPN openvpn;

  VPN() {
    if (Platform.isWindows) {
      channel = IOWebSocketChannel.connect("ws://localhost:9452");
    } else {
      openvpn = OpenVPN(
          onVpnStatusChanged: _onVpnStatusChanged,
          onVpnStageChanged: _onVpnStageChanged);
      openvpn.initialize(
          groupIdentifier: "net.privatify.vpn.ios",

          ///Example 'group.com.laskarmedia.vpn'
          providerBundleIdentifier: "net.privatify.vpn.ios.VPNExtension",

          ///Example 'id.laskarmedia.openvpnFlutterExample.VPNExtension'
          localizedDescription: "Privatify VPN"

          ///Example 'Laskarmedia VPN'
          );
    }
  }

  dynamic _onVpnStatusChanged(VpnStatus? vpnStatus) {
    // log('$vpnStatus');
  }

  dynamic _onVpnStageChanged(VPNStage stage, name) {
    //log("$stage");
    if (stage == VPNStage.connecting) status.value = Status.connecting;
    if (stage == VPNStage.connected) status.value = Status.connected;
    if (stage == VPNStage.disconnected) status.value = Status.notConnected;
    if (stage == VPNStage.disconnecting) status.value = Status.disconnecting;
  }

  checkOpenvpnConnection() async {
    if (Platform.isWindows) {
    } else {
      bool isConnected = false;
      if (protocol.value == Protocol.ikev2) {
        // FlutterVpn.prepare();
        isConnected = FlutterVpn.currentState == FlutterVpnState.connected;
        //if (FlutterVpn.prepared == false) {
      } else {
        isConnected = await openvpn.isConnected();
      }

      status.value =
          isConnected == true ? Status.connected : Status.notConnected;
    }
  }

  initialListener() async {
    checkWindowsConnected();
    autoConnect.value = (await storage.read(key: "auto_connect")) == "true";

    channel.stream.listen((message) {
      //  print(message);
      //  log(message);
      var connected = message.contains("Sequence Completed");
      var disconnected = message.contains("has been terminated.") ||
          message.contains("Exiting due to fatal error");

      var reconnecting = message.contains("restarting");

      var isConnected = message.contains("openvpn.exe");

      if (isConnected || connected) status.value = Status.connected;
      if (disconnected) status.value = Status.notConnected;
      if (reconnecting) status.value = Status.reconnecting;

      // if (connected)
    });
  }

  changeProtocol(Protocol proto) async {
    print(proto);
    protocol.value = proto;
    await storage.write(key: "protocol", value: proto.name);

    await server.getServers();

    var optimizedServer = server.servers[0];
    await server.selectServer(optimizedServer);
  }

  setAutoConnect(bool value) async {
    autoConnect.value = value;
    await storage.write(key: "auto_connect", value: value.toString());
  }

  connect() async {
    if (status.value == Status.notConnected) {
      await storage.write(
          key: "last_server_id", value: server.server.value.id.toString());
      //
      if (protocol.value == Protocol.ikev2) {
        _ikev2();
      } else {
        _openvpn();
      }
    }

    if (status.value == Status.connected) {
      // channel.sink.add(json.encode({
      //   "execute": "taskkill.exe",
      //   "args": ["/F", "/IM", "openvpn.exe"]
      // }));
    }

    status.value = status.value == Status.notConnected
        ? Status.connecting
        : Status.notConnected;
  }

  disconnect() {
    if (Platform.isWindows) {
      channel.sink.add(json.encode({
        "execute": "taskkill.exe",
        "args": ["/F", "/IM", "openvpn.exe"]
      }));

      return;
    }
    if (protocol.value == Protocol.ikev2) {
      FlutterVpn.disconnect();
    } else {
      openvpn.disconnect();
    }
  }

  Future<String> appDataPath() async {
    final directory = await getApplicationSupportDirectory();
    return directory.path;
  }

  _ikev2() async {
    //if (FlutterVpn.prepared == false) {
    FlutterVpn.prepare();
    FlutterVpn.onStateChanged.listen((event) {
      if (event == FlutterVpnState.connecting) {
        status.value = Status.connecting;
      }
      if (event == FlutterVpnState.connected) status.value = Status.connected;
      if (event == FlutterVpnState.disconnected) {
        status.value = Status.notConnected;
      }
      if (event == FlutterVpnState.disconnecting) {
        status.value = Status.disconnecting;
      }
    });
    //  }

    var configString = Platform.isIOS == true
        ? server.config.value.certificate!.p12
        : server.config.value.certificate!.pem;

    FlutterVpn.connectIkev2EAP(
        certificate: configString ?? "",
        server: server.server.value.dns ?? "",
        username: server.config.value.username ?? "",
        password: server.config.value.password ?? "");
  }

  _openvpn() async {
    if (Platform.isWindows) {
      await openvpnForWindows();
    } else {
      var configString = server.config.value.config;

      var accountPassword = server.config.value.account;

      log("vpn !");

      openvpn.connect(configString.toString(), "Privatify",
          username: accountPassword,
          password: accountPassword,
          bypassPackages: [],
          certIsRequired: true);
    }

    // channel.sink.add(json.encode({
    //   "execute": openvpnPath,
    //   "args": ["--config", configFile, "--auth-user-pass", authFile]
    // }));
  }

  openvpnForWindows() async {
    var configString = server.config.value.config;
    var accountPassword = server.config.value.account;

    String path = await appDataPath();
    final authFile = "$path/auth.txt";
    final configFile = "$path/config.ovpn";

    await File(configFile).writeAsString(configString!);
    await File(authFile).writeAsString("$accountPassword\n$accountPassword");

    final localDirectory = Directory.current.path;
    final openvpnPath = "$localDirectory/bin/openvpn.exe";

    channel.sink.add(json.encode({
      "execute": openvpnPath,
      "args": ["--config", configFile, "--auth-user-pass", authFile]
    }));
  }

  checkWindowsConnected() {
    channel.sink.add(json.encode({"execute": "tasklist", "args": []}));
  }

 
}
