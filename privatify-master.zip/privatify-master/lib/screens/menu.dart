import 'dart:developer';
import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:get/get.dart';
import 'package:privatify/components/backgroud.dart';
import 'package:privatify/components/button.dart';
import 'package:privatify/components/menu/header.dart';
import 'package:privatify/components/menu/options.dart';
import 'package:privatify/components/menu/progress.dart';
import 'package:privatify/helpers/helpers.dart';
import 'dart:math' as Math;

import '../store/refrences.dart';
import '../store/user.dart';

class Menu extends StatefulWidget {
  const Menu({super.key});

  @override
  State<Menu> createState() => _MenuState();
}

class _MenuState extends State<Menu> with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  var refrence = Get.put(Refrence());
  var user = Get.find<User>();

  var remain;

  void initState() {
    var remain =
        user.profile.value.user!.customer!.accounts![0].days?.remain ?? 0;
    var all = user.profile.value.user!.customer!.accounts![0].days?.all ?? 0;

    var lowerBound = all == 0 ? 0 : remain / all;

    super.initState();
    _controller = AnimationController(
        vsync: this, // the SingleTickerProviderStateMixin
        duration: const Duration(milliseconds: 500),
        lowerBound: 0,
        upperBound: lowerBound.toDouble())
      ..addListener(() {
        setState(() {});
      });

    if (remain != 0) {
      _controller.forward();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Background(
        child: Column(
      children: [
        const HeaderMenu(
          right: true,
        ),
        user.profile.value.isPremium == true
            ? Stack(
                alignment: Alignment.center,
                children: [
                  Transform.rotate(
                      angle: -((90 * Math.pi) / 180),
                      child: DayProgress(
                        value: _controller.value,
                      )),
                  Positioned(
                      child: Image.asset(
                    'assets/inner_progress.png',
                    width: 129,
                  )),
                  Positioned(
                      child: Column(
                    children: [
                      Text("Expire",
                          style: Theme.of(context).textTheme.titleSmall),
                      Text(
                        (user.profile.value.user!.customer!.accounts![0].days
                                    ?.remain ??
                                0)
                            .toString(),
                        style: Theme.of(context).textTheme.titleLarge,
                      ),
                      Text(
                        "Days",
                        style: Theme.of(context).textTheme.titleSmall,
                      )
                    ],
                  ))
                ],
              )
            : Container(
                padding:
                    EdgeInsets.only(top: 50, bottom: 25, left: 35, right: 35),
                child: PButton(
                    onPress: () => Platform.isIOS
                        ? Get.toNamed("/purchase")
                        : Get.toNamed('/dashboard'),
                    title: "Become Premium"),
              ),
        Text(user.profile.value.user!.email ?? ""),
        Expanded(child: const Options())
      ],
    ));
  }
}
