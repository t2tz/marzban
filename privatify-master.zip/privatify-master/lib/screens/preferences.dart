import 'dart:developer';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:modal_bottom_sheet/modal_bottom_sheet.dart';
import 'package:privatify/components/backgroud.dart';
import 'package:privatify/components/checkbox.dart';
import 'package:privatify/components/menu/header.dart';
import 'package:privatify/helpers/helpers.dart';
import 'package:privatify/store/user.dart';
import 'package:privatify/store/vpn.dart';

import '../components/menu/prefItem.dart';

class Preferences extends StatefulWidget {
  const Preferences({Key? key}) : super(key: key);

  @override
  State<Preferences> createState() => _PreferencesState();
}

class _PreferencesState extends State<Preferences> {
  var status = false;
  var vpn = Get.find<VPN>();
  var user = Get.find<User>();

  changeProtocol(Protocol proto) {
    // log(proto.name);
    // showDialog(context: context, builder: (context) => Container(child: Text("Hello"),));

    if (vpn.status.value == Status.connected && vpn.protocol.value != proto) {
      Helpers.dialogPrompt(context, "Change Protocol",
          "VPN will disconnect to make these change.", () {
        disconnectAndChangeProtocol(proto);
      }, () {
        log("cancel vpn reset.");
      });
    } else {
      disconnectAndChangeProtocol(proto);
    }
  }

  resetProfile() {
    Helpers.dialogPrompt(
        context, "Reset VPN profile", "by this all of preferences will reset.",
        () {
      vpn.changeProtocol(Protocol.auto);
      vpn.setAutoConnect(false);
    }, () {
      log("cancel vpn reset.");
    });
  }

  disconnectAndChangeProtocol(proto) {
    if (vpn.status.value == Status.connected) vpn.disconnect();
    vpn.changeProtocol(proto);
    Navigator.of(context).pop();
  }

  showProtocols() {
    showMaterialModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
          height: 550,
          decoration: const BoxDecoration(
              color: Color(0xff3a3a47),
              borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(25), topRight: Radius.circular(10))),
          child: Padding(
              padding: EdgeInsets.only(top: 30, bottom: 30),
              child: Obx(() => SingleChildScrollView(
                    child: Column(
                      children: [
                        Container(
                          width: 32,
                          height: 4,
                          decoration: const BoxDecoration(
                              borderRadius:
                                  BorderRadius.all(Radius.circular(10)),
                              color: Color(0xff727289)),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              vertical: 12, horizontal: 10),
                        ),
                        PrefItem(
                            title: "Automatic",
                            description:
                                "We will automatically pick the protocol most appropriate for your network.",
                            icon: "icon",
                            leftSide: PCheckbox(
                              onChanged: (value) =>
                                  changeProtocol(Protocol.auto),
                              value: vpn.protocol.value == Protocol.auto,
                            ),
                            url: ""),
                        PrefItem(
                            title: "UDP",
                            locked: user.profile.value.isPremium == false,
                            description:
                                "Best combination of speed and security, but may not work on all networks.",
                            icon: "icon",
                            leftSide: PCheckbox(
                              locked: user.profile.value.isPremium != true,
                              onChanged: (value) =>
                                  changeProtocol(Protocol.udp),
                              value: vpn.protocol.value == Protocol.udp,
                              // activeColor: Colors.black
                            ),
                            url: ""),
                        PrefItem(
                          title: "TCP",
                          locked: user.profile.value.isPremium == false,
                          description:
                              "Likely to function on all types of network, but might be slower than UDP.",
                          icon: "icon",
                          leftSide: PCheckbox(
                            locked: user.profile.value.isPremium != true,
                            onChanged: (value) => changeProtocol(Protocol.tcp),
                            value: vpn.protocol.value == Protocol.tcp,
                          ),
                          url: "",
                        ),
                        Platform.isWindows ? Container() :
                        PrefItem(
                          title: "IKEv2",
                          locked: user.profile.value.isPremium == false,
                          description:
                              "it’s one of the fastest and most secure VPN protocols that are available to online users.",
                          icon: "icon",
                          leftSide: PCheckbox(
                            locked: user.profile.value.isPremium != true,
                            onChanged: (value) =>
                                changeProtocol(Protocol.ikev2),
                            value: vpn.protocol.value == Protocol.ikev2,
                          ),
                          url: "",
                          hasBorder: false,
                        )
                      ],
                    ),
                  )))),
    );
  }

  Color thumbState(Set<MaterialState> states) {
    return Colors.white;
  }

  @override
  Widget build(BuildContext context) {
    return Background(
        child: Column(
      children: [
        const HeaderMenu(title: "Preferences"),
        Container(
          padding: EdgeInsets.only(top: 50),
          child: Column(children: [
            Obx(() => PrefItem(
                  title: "VPN Protocols",
                  description: vpn.protocol.value.name,
                  icon: "assets/shield.png",
                  url: "",
                  isClickable: true,
                  onItem: () => showProtocols(),
                )),
            PrefItem(
                title: "Auto connect",
                description: "when connection is interruped",
                icon: "assets/power_2.png",
                url: "",
                isClickable: true,
                hasBorder: true,
                rightSide: Obx(
                  () => Switch(
                    value: vpn.autoConnect.value,
                    onChanged: (value) => vpn.setAutoConnect(value),
                    activeColor: const Color(0xff0ef62c),
                    thumbColor: MaterialStateColor.resolveWith(thumbState),
                  ),
                )),
            PrefItem(
              title: "Reset Vpn Profile",
              description: "by this all of preferences will reset.",
              icon: "assets/refresh.png",
              url: "",
              isClickable: true,
              hasBorder: false,
              onItem: () => resetProfile(),
            ),
          ]),
        )
      ],
    ));
  }
}
