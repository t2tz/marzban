import 'dart:async';
import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:openvpn_flutter/openvpn_flutter.dart';
import 'package:privatify/components/backgroud.dart';
import 'package:privatify/components/button.dart';
import 'package:privatify/components/circleImage.dart';
import 'package:privatify/components/connectionBg.dart';
import 'package:privatify/components/locationButton.dart';
import 'package:privatify/components/volume.dart';
import 'package:privatify/store/user.dart';
import 'package:privatify/store/vpn.dart';

import '../components/switch/switch.dart';
import '../helpers/helpers.dart';
import '../store/server.dart';

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  final vpn = Get.find<VPN>();
  final server = Get.find<Server>();
  final user = Get.find<User>();

  late Timer timer;

  @override
  void initState() {
    vpn.checkOpenvpnConnection();
    Future.delayed(Duration.zero, () async {
      //AppProvider().checkUpdate()
      if (user.updateApp.value.isVersionExist == true) {
        Helpers.showUpdate(context, user.updateApp.value);
      }
    });
    // TODO: implement initState
    if (user.profile.value.isPremium != true) {
      timer = Timer.periodic(new Duration(seconds: 60), (timer) {
        user.getUserUsage();

        if (double.parse(user.usage.value.leftUsage ?? "0") <= 0) {
          if (vpn.status.value == Status.connected) {
            vpn.disconnect();
            Helpers.errorToast(
                context, "The allocated VPN volume has been exhausted.");
          }
        }
      });
    }
    super.initState();
  }

  @override
  void dispose() {
    timer.cancel();
    // TODO: implement dispose
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Obx(() => Background(
        color: vpn.status.value == Status.connected ? "green" : "gray",
        hasBackground: true,
        child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Padding(
                  padding:
                      const EdgeInsets.only( left: 25, right: 25, bottom: 55),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      GestureDetector(
                        onTap: () => Get.toNamed("/menu"),
                        child: Image.asset(
                          "assets/menu.png",
                          width: 48,
                        ),
                      ),
                      Volume(
                        leftUsage:
                            double.parse(user.usage.value.leftUsage ?? "0"),
                        totalUsage: (user.usage.value.limit ?? 0).toDouble(),
                        isPremium: user.profile.value.isPremium ?? false,
                      ),
                    ],
                  )),
              // SizedBox(width: 250, height: 60, child: PButton(title: "Become Premium",),)
              Expanded(
                child: Column(children: [
                  Padding(
                      padding: EdgeInsets.symmetric(
                          vertical: MediaQuery.of(context).size.height > 720
                              ? 10
                              : 0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          CircleImage(
                              url:
                                  "https://api.privatify.net/flags/${server.server.value.country?.shortName}.png"),
                          Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 15),
                              child: Text(
                                server.server.value.city?.name ?? "",
                                style: Theme.of(context).textTheme.titleMedium,
                              ))
                        ],
                      )),
                  Text(
                    vpn.status.value == Status.notConnected
                        ? "UNPRIVATIFY !"
                        : vpn.status.value == Status.connecting
                            ? "PRIVATIFYING..."
                            : vpn.status.value == Status.disconnecting
                                ? "UNPRIVATIFYING..."
                                : "PRIVATIFY !",
                    style: GoogleFonts.baloo2(
                        fontSize: 32,
                        fontWeight: FontWeight.bold,
                        color: vpn.status.value == Status.connecting
                            ? const Color(0xffffc500)
                            : vpn.status.value == Status.disconnecting
                                ? const Color(0xffffc500)
                                : Colors.white),
                  ),
                  LocationButton(),
                ]),
              ),
              Expanded(
               flex: MediaQuery.of(context).size.height > 720 ? 1 : 2,
                child: PSwitch(
                  status: vpn.status.value,
                  onConnect: (connectionStatus) {
                    connectionStatus == true ? vpn.connect() : vpn.disconnect();
                  },
                ),
              ),
              ConnectionBackground()
            ])));
  }
}
