import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:privatify/components/backgroud.dart';
import 'package:privatify/components/menu/header.dart';
import 'package:privatify/components/menu/prefItem.dart';
import 'package:privatify/store/user.dart';
import 'package:share_plus/share_plus.dart';

class Referer extends StatefulWidget {
  const Referer({Key? key}) : super(key: key);

  @override
  State<Referer> createState() => _RefererState();
}

var user = Get.find<User>();

var id = user.profile.value.user != null ? user.profile.value.user!.id : 0;
var url = "https://privatify.net?referer=$id";

void _showToast(BuildContext context) {
  final scaffold = ScaffoldMessenger.of(context);
  scaffold.showSnackBar(
    const SnackBar(
      content: Text('Copied to clipboard.'),
      //  action: SnackBarAction(label: 'UNDO', onPressed: scaffold.hideCurrentSnackBar),
    ),
  );
}

class _RefererState extends State<Referer> {
  @override
  Widget build(BuildContext context) {
    return Background(
      child: Column(children: [
        const HeaderMenu(title: "Referer Friends"),

        Padding(padding: EdgeInsets.only(top: 35), child: Image.asset("assets/referer.png", width: 280,),),
        Container(
          padding: const EdgeInsets.only(top: 50),
          child: Text(
            "Get a friend to Subscribe",
            style:
                GoogleFonts.baloo2(fontSize: 20, fontWeight: FontWeight.w500),
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(top: 50),
          child: Column(children: [
            PrefItem(
              icon: "assets/share.png",
              title: "Share It!",
              description: "Share referer link with email",
              isClickable: true,
              url: "",
              onItem: () => Share.share("Get 1 Month Premium VPN $url ",
                  subject: "Get 1 Month Premium VPN"),
            ),
            PrefItem(
                icon: "assets/link.png",
                title: "Copy Link",
                description: "Copy referer link to clipboard",
                isClickable: true,
                url: "",
                hasBorder: false,
                onItem: () => Clipboard.setData(
                        ClipboardData(text: "Get 1 Month Premium VPN $url"))
                    .then((value) => _showToast(context))),
          ]),
        )
      ]),
    );
  }
}
