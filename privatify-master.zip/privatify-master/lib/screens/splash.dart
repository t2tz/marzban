import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:privatify/helpers/helpers.dart';
import 'package:privatify/providers/app.dart';
import 'package:privatify/utils/appInit.dart';

import '../components/loading.dart';
import '../store/user.dart';

class Splash extends StatefulWidget {
  const Splash({super.key});

  @override
  State<Splash> createState() => _SplashState();
}

class _SplashState extends State<Splash> {
  final user = Get.find<User>();
  initialApplication() async {
    Application().AppInit().then((value) {
      if (value == true && user.profile.value.user != null) {
       Get.toNamed('/home');
      } else if (value == false) {
        Helpers.dialogPrompt(
            context,
            "You're offline!",
            "Check your connection and try again",
            () => initialApplication(),
            null);
      }
    });
  }

  @override
  void initState() {
   initialApplication();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
          image: DecorationImage(
              image: AssetImage("assets/map.png"),
              fit: BoxFit.none,
              alignment: Alignment.topCenter),
          gradient: LinearGradient(
            colors: [Color(0xff0f1018), Color(0xff15161f), Color(0xff3a3a47)],
            stops: [0, 0.1478630006313324, 1],
            begin: Alignment(-0.78, 0.63),
            end: Alignment(0.78, -0.63),
            // angle: 51,
            // scale: undefined,
          )),
      child:
          Column(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Expanded(child: Container()),
        Expanded(
            child: Container(
          child: Stack(alignment: Alignment.topCenter, children: [
            SvgPicture.asset("assets/logo.svg"),
            Loading(),
          ]),
        )),
        Container(
          padding: const EdgeInsets.only(bottom: 20),
          child: Text(
            "Ver 1.0.1",
            style: Theme.of(context).textTheme.titleSmall,
          ),
        )
      ]),
    );
  }
}
