import 'dart:async';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:privatify/components/backgroud.dart';
import 'package:privatify/components/inputText.dart';

import '../components/button.dart';
import '../helpers/helpers.dart';
import '../store/user.dart';
import '../utils/appInit.dart';

class WelcomeCode extends StatefulWidget {
  const WelcomeCode({super.key});

  @override
  State<WelcomeCode> createState() => _WelcomeCodeState();
}

class _WelcomeCodeState extends State<WelcomeCode> {
  num code = 0;
  String loading = "";

  num timeRemain = 0;

  startTimer() {
    timeRemain = 60;
    Timer.periodic(Duration(seconds: 1), (timer) {
      if (timeRemain <= 0) {
        timer.cancel();
        return;
      }
      setState(() {
        timeRemain = timeRemain - 1;
      });
    });
  }

  @override
  void initState() {
    startTimer();
    // TODO: implement initState
    super.initState();
  }

  final User user = Get.find<User>();

  void setLoading(String state) {
    setState(() {
      loading = state;
    });
  }

  void resendCode() async {
    try {
      setLoading("...");
      await user.resendCode(user.userAction['email'] ?? "");
      startTimer();
      setLoading("");
    } catch (e) {
      setLoading("");
      Helpers.errorToast(context, e.toString());
    }
  }

  void verifyCode() async {
    // await user.setEmail(email);
    //   Get.toNamed('/password');
    try {
      setLoading("Verifying...");
      await user.verifyCode(code, user.userAction['email'] ?? "");

      Application().AppInit().then((value) {
        if (value == true) Get.toNamed('/home');
      });
    } catch (e) {
      setLoading("");
      Helpers.errorToast(context, e.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    return Background(
      scrollView: true,
      child: Column(mainAxisSize: MainAxisSize.max, children: [
        Image.asset(
          "assets/login.png",
          width: 268,
        ),
        Container(
          padding: const EdgeInsets.only(top: 25, bottom: 15),
          child: Column(children: [
            Text("Verify Code", style: Theme.of(context).textTheme.titleLarge),
            Text("Enter the Verification Code",
                style: Theme.of(context).textTheme.titleMedium)
          ]),
        ),
        Container(
          margin: const EdgeInsets.only(top: 30),
          padding: const EdgeInsets.symmetric(horizontal: 35),
          child: Column(
            children: [
              InputText(
                icon: Icons.password_outlined,
                placeholder: "Code",
                type: TextInputType.number,
                onType: (value) => code = num.tryParse(value) ?? 0,
              ),
              Container(
                  margin: const EdgeInsets.symmetric(vertical: 30),
                  child: PButton(
                    onPress: verifyCode,
                    title: "Verify Code",
                    color: ButtonColors.yellow,
                    loading: loading,
                  )),
              Container(
                  padding: EdgeInsets.only(top: 10),
                  alignment: Alignment.center,
                  child: timeRemain <= 0
                      ? InkWell(
                          onTap: () => resendCode(),
                          child: Text(
                            "Resend Code",
                            style: Theme.of(context).textTheme.titleMedium,
                          ),
                        )
                      : Text(
                          timeRemain.toString(),
                          style: Theme.of(context).textTheme.titleLarge,
                          textAlign: TextAlign.center,
                        ))
            ],
          ),
        )
      ]),
    );
  }
}
