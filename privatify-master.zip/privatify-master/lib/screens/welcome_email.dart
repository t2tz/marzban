import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:privatify/components/backgroud.dart';
import 'package:privatify/components/button.dart';
import 'package:privatify/components/inputText.dart';

import '../helpers/helpers.dart';
import '../store/user.dart';

class WelcomeEmail extends StatefulWidget {
  const WelcomeEmail({super.key});

  @override
  State<WelcomeEmail> createState() => _WelcomeEmailState();
}

class _WelcomeEmailState extends State<WelcomeEmail> {
  String email = "";
  String error = "";

  final User user = Get.find<User>();

  String? validateEmail(String? value) {
    String pattern =
        r"^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]"
        r"{0,253}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]"
        r"{0,253}[a-zA-Z0-9])?)*$";
    RegExp regex = RegExp(pattern);
    if (value == null || value.isEmpty || !regex.hasMatch(value))
      return 'Enter a valid email address';
    else
      return null;
  }

  void nextAction() async {
    var emailValidation = validateEmail(email);
    if (emailValidation == null) {
      await user.setEmail(email);
      Get.toNamed('/welcome-password');
    } else {
      Helpers.errorToast(context, emailValidation);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Background(
      scrollView: true,
      child: Column(mainAxisSize: MainAxisSize.max, children: [
        Image.asset(
          "assets/login.png",
          width: 268,
        ),
        Container(
          padding: const EdgeInsets.only(top: 25, bottom: 15),
          child: Column(children: [
            Text(
                user.userAction["action"] == "login"
                    ? "Login to PRIVATIFY"
                    : "Become PRIVATIFY !",
                style: Theme.of(context).textTheme.titleLarge),
            Text("Enter Email Address",
                style: Theme.of(context).textTheme.titleMedium)
          ]),
        ),
        Container(
          margin: const EdgeInsets.only(top: 30),
          padding: const EdgeInsets.symmetric(horizontal: 35),
          child: Column(
            children: [
              InputText(
                  onType: (value) => email = value,
                  icon: Icons.email_outlined,
                  placeholder: "Email",
                  type: TextInputType.emailAddress),
              Container(
                  margin: const EdgeInsets.symmetric(vertical: 30),
                  child: PButton(
                    onPress: () => nextAction(),
                    title: "Next",
                    color: user.userAction["action"] == "login"
                        ? ButtonColors.yellow
                        : ButtonColors.gray,
                  )),
              Container(
                  child: InkWell(
                onTap: () => Navigator.of(context).pop(),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.arrow_back_ios_rounded,
                      color: Colors.white,
                    ),
                    Padding(
                      padding: EdgeInsets.only(left: 5, right: 20),
                      child: Text(
                        "Back",
                        style: GoogleFonts.baloo2(
                            fontSize: 20, fontWeight: FontWeight.bold),
                      ),
                    )
                  ],
                ),
              ))
            ],
          ),
        )
      ]),
    );
  }
}
