// Copyright 2013 The Flutter Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

import 'dart:async';
import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:in_app_purchase/in_app_purchase.dart';
import 'package:in_app_purchase_storekit/in_app_purchase_storekit.dart';
import 'package:in_app_purchase_storekit/store_kit_wrappers.dart';
import 'package:privatify/components/backgroud.dart';
import 'package:privatify/components/button.dart';
import 'package:privatify/components/menu/header.dart';
import '../store/user.dart';
import 'consumable_store.dart';

// Auto-consume must be true on iOS.
// To try without auto-consume on another platform, change `true` to `false` here.
final bool _kAutoConsume = Platform.isIOS || true;

const String _kConsumableId = 'consumable';
const String _kUpgradeId = 'upgrade';
const String _onMonthSubscription = 'net.privatify.vpn.oneMonth';
const String _oneYearSubscription = 'net.privatify.vpn.oneYear';
const List<String> _kProductIds = <String>[
  _kConsumableId,
  _kUpgradeId,
  _onMonthSubscription,
  _oneYearSubscription,
];

class MyAppPurchase extends StatefulWidget {
  @override
  State<MyAppPurchase> createState() => MyAppPurchaseState();
}

class MyAppPurchaseState extends State<MyAppPurchase> {
  final InAppPurchase _inAppPurchase = InAppPurchase.instance;
  late StreamSubscription<List<PurchaseDetails>> _subscription;
  List<String> _notFoundIds = <String>[];
  List<ProductDetails> _products = <ProductDetails>[];
  List<PurchaseDetails> _purchases = <PurchaseDetails>[];
  List<String> _consumables = <String>[];
  bool _isAvailable = false;
  bool _purchasePending = false;
  bool _loading = true;
  String? _queryProductError;

  var user = Get.find<User>();

  @override
  void initState() {
    final Stream<List<PurchaseDetails>> purchaseUpdated =
        _inAppPurchase.purchaseStream;
    _subscription =
        purchaseUpdated.listen((List<PurchaseDetails> purchaseDetailsList) {
      _listenToPurchaseUpdated(purchaseDetailsList);
    }, onDone: () {
      _subscription.cancel();
    }, onError: (Object error) {
      // handle error here.
    });
    initStoreInfo();
    super.initState();
  }

  Future<void> initStoreInfo() async {
    final bool isAvailable = await _inAppPurchase.isAvailable();
    if (!isAvailable) {
      setState(() {
        _isAvailable = isAvailable;
        _products = <ProductDetails>[];
        _purchases = <PurchaseDetails>[];
        _notFoundIds = <String>[];
        _consumables = <String>[];
        _purchasePending = false;
        _loading = false;
      });
      return;
    }

    if (Platform.isIOS) {
      final InAppPurchaseStoreKitPlatformAddition iosPlatformAddition =
          _inAppPurchase
              .getPlatformAddition<InAppPurchaseStoreKitPlatformAddition>();
      await iosPlatformAddition.setDelegate(ExamplePaymentQueueDelegate());
    }

    final ProductDetailsResponse productDetailResponse =
        await _inAppPurchase.queryProductDetails(_kProductIds.toSet());
    if (productDetailResponse.error != null) {
      setState(() {
        _queryProductError = productDetailResponse.error!.message;
        _isAvailable = isAvailable;
        _products = productDetailResponse.productDetails;
        _purchases = <PurchaseDetails>[];
        _notFoundIds = productDetailResponse.notFoundIDs;
        _consumables = <String>[];
        _purchasePending = false;
        _loading = false;
      });
      return;
    }

    if (productDetailResponse.productDetails.isEmpty) {
      setState(() {
        _queryProductError = null;
        _isAvailable = isAvailable;
        _products = productDetailResponse.productDetails;
        _purchases = <PurchaseDetails>[];
        _notFoundIds = productDetailResponse.notFoundIDs;
        _consumables = <String>[];
        _purchasePending = false;
        _loading = false;
      });
      return;
    }

    final List<String> consumables = await ConsumableStore.load();
    setState(() {
      _isAvailable = isAvailable;
      _products = productDetailResponse.productDetails;
      _notFoundIds = productDetailResponse.notFoundIDs;
      _consumables = consumables;
      _purchasePending = false;
      _loading = false;
    });
  }

  @override
  void dispose() {
    if (Platform.isIOS) {
      final InAppPurchaseStoreKitPlatformAddition iosPlatformAddition =
          _inAppPurchase
              .getPlatformAddition<InAppPurchaseStoreKitPlatformAddition>();
      iosPlatformAddition.setDelegate(null);
    }
    _subscription.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Background(
      child: Column(children: [
        HeaderMenu(
          title: "Privatify Plans",
        ),
        Expanded(child: _buildProductList())
      ]),
    );
  }

  _buildProductList() {
    if (_loading) {
      return Text('Fetching Privatify Plans...');
    }

    _premiumItem(String title) {
      return Container(
        padding: EdgeInsets.symmetric(horizontal: 40),
        child: Row(
          children: [
            Padding(
              padding: EdgeInsets.only(right: 10),
              child: Icon(
                Icons.check,
                color: Colors.white,
                size: 20,
              ),
            ),
            Text(
              title,
              style: Theme.of(context).textTheme.bodySmall,
            )
          ],
        ),
      );
    }

    return Column(children: [
      Padding(
        padding: EdgeInsets.symmetric(vertical: 15),
        child: Center(
          child: Text(
            "Privatify Premium Subscription",
            style: Theme.of(context).textTheme.titleMedium,
          ),
        ),
      ),
      Column(
        children: [
          _premiumItem("Unlimited Data Usage"),
          _premiumItem("Fast Premium Servers"),
          _premiumItem("All VPN Protocols"),
          _premiumItem("Manual VPN Configuration"),
        ],
      ),
      Expanded(
          child: ListView.builder(
              itemCount: _products.length,
              itemBuilder: (context, index) {
                return Container(
                    margin: EdgeInsets.symmetric(vertical: 20, horizontal: 20),
                    child: PButton(
                        onPress: () async {
                          try {
                            var paymentWrapper = SKPaymentQueueWrapper();
                            var transactions =
                                await paymentWrapper.transactions();
                            transactions.forEach((transaction) async {
                              await paymentWrapper
                                  .finishTransaction(transaction);
                            });
                            log("1");
                            late PurchaseParam purchaseParam;
                            purchaseParam = PurchaseParam(
                              productDetails: _products[index],
                            );

                            if (_products[index].id == _kConsumableId) {
                              _inAppPurchase.buyConsumable(
                                  purchaseParam: purchaseParam,
                                  autoConsume: _kAutoConsume);
                            } else {
                              log("2");
                              _inAppPurchase.buyNonConsumable(
                                  purchaseParam: purchaseParam);
                            }
                          } catch (e) {
                            print(e);
                          }
                        },
                        title:
                            " ${_products[index].price} / ${index == 0 ? 'Month' : 'Year'}"));
              })),
      _purchasePending
          ? Center(
              child: Text(
                "Loading Plan...",
                style: Theme.of(context).textTheme.bodySmall,
              ),
            )
          : Container()
    ]);
  }

  Future<void> consume(String id) async {
    await ConsumableStore.consume(id);
    final List<String> consumables = await ConsumableStore.load();
    setState(() {
      _consumables = consumables;
    });
  }

  void showPendingUI() {
    setState(() {
      _purchasePending = true;
    });
  }

  Future<void> deliverProduct(PurchaseDetails purchaseDetails) async {
    // IMPORTANT!! Always verify purchase details before delivering the product.

    await this.user.getProfile();
    Get.toNamed('/menu');

    setState(() {
      _purchases.add(purchaseDetails);
      _purchasePending = false;
    });
  }

  void handleError(IAPError error) {
    setState(() {
      _purchasePending = false;
    });
  }

  Future<bool> _verifyPurchase(PurchaseDetails purchaseDetails) async {
    // IMPORTANT!! Always verify a purchase before delivering the product.
    // For the purpose of an example, we directly return true.

    await user.verifyPayment(user.profile.value.user!.email ?? "",
        purchaseDetails.verificationData.localVerificationData);
    return Future<bool>.value(true);
  }

  void _handleInvalidPurchase(PurchaseDetails purchaseDetails) {
    // handle invalid purchase here if  _verifyPurchase` failed.
  }

  Future<void> _listenToPurchaseUpdated(
      List<PurchaseDetails> purchaseDetailsList) async {
    for (final PurchaseDetails purchaseDetails in purchaseDetailsList) {
      log("3");
      if (purchaseDetails.status == PurchaseStatus.pending) {
        // await user.verifyPayment(user.profile.value.user!.email ?? "",
        //     purchaseDetails.verificationData.localVerificationData);
        showPendingUI();
      } else {
        if (purchaseDetails.status == PurchaseStatus.error) {
          handleError(purchaseDetails.error!);
        } else if (purchaseDetails.status == PurchaseStatus.purchased ||
            purchaseDetails.status == PurchaseStatus.restored) {
          final bool valid = await _verifyPurchase(purchaseDetails);
          if (valid) {
            deliverProduct(purchaseDetails);
          } else {
            _handleInvalidPurchase(purchaseDetails);
            return;
          }
        }

        if (purchaseDetails.pendingCompletePurchase) {
          await _inAppPurchase.completePurchase(purchaseDetails);
        }
      }
    }
  }

  Future<void> confirmPriceChange(BuildContext context) async {
    if (Platform.isIOS) {
      final InAppPurchaseStoreKitPlatformAddition iapStoreKitPlatformAddition =
          _inAppPurchase
              .getPlatformAddition<InAppPurchaseStoreKitPlatformAddition>();
      await iapStoreKitPlatformAddition.showPriceConsentIfNeeded();
    }
  }
}

/// Example implementation of the
/// [`SKPaymentQueueDelegate`](https://developer.apple.com/documentation/storekit/skpaymentqueuedelegate?language=objc).
///
/// The payment queue delegate can be implementated to provide information
/// needed to complete transactions.
class ExamplePaymentQueueDelegate implements SKPaymentQueueDelegateWrapper {
  @override
  bool shouldContinueTransaction(
      SKPaymentTransactionWrapper transaction, SKStorefrontWrapper storefront) {
    return true;
  }

  @override
  bool shouldShowPriceConsent() {
    return false;
  }
}
