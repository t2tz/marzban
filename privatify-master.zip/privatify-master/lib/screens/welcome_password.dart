import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:privatify/components/backgroud.dart';
import 'package:privatify/components/button.dart';
import 'package:privatify/components/inputText.dart';

import '../helpers/helpers.dart';
import '../store/user.dart';

class WelcomePassword extends StatefulWidget {
  const WelcomePassword({super.key});

  @override
  State<WelcomePassword> createState() => _WelcomePasswordState();
}

class _WelcomePasswordState extends State<WelcomePassword> {
  String password = "";
  String loading = "";

  final User user = Get.find<User>();

  void setLoading(String state) {
    setState(() {
      loading = state;
    });
  }

  void login() async {
    try {
      setLoading("Logging In...");
      await user.userLogin(user.userAction['email'] ?? "", password);
      setLoading("");
      Get.toNamed("/welcome-code");
    } catch (e) {
      setLoading("");
      Helpers.errorToast(context, e.toString());
    }
  }

  void register() async {
    try {
      setLoading("Creating Account...");
      await user.register(user.userAction['email'] ?? "", password);
      setLoading("");
      Get.toNamed("/welcome-code");
    } catch (e) {
      setLoading("");
      Helpers.errorToast(context, e.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    return Background(
      scrollView: true,
      child: Column(mainAxisSize: MainAxisSize.max, children: [
        Image.asset(
          "assets/login.png",
          width: 268,
        ),
        Container(
          padding: const EdgeInsets.only(top: 25, bottom: 15),
          child: Column(children: [
            Text(
                user.userAction["action"] == "login"
                    ? "Login to PRIVATIFY"
                    : "Become PRIVATIFY !",
                style: Theme.of(context).textTheme.titleLarge),
            Text("Enter your password",
                style: Theme.of(context).textTheme.titleMedium)
          ]),
        ),
        Container(
          margin: const EdgeInsets.only(top: 30),
          padding: const EdgeInsets.symmetric(horizontal: 35),
          child: Column(
            children: [
              InputText(
                onType: (value) => password = value,
                icon: Icons.password_outlined,
                placeholder: "Password",
                password: true,
              ),
              Container(
                  margin: const EdgeInsets.symmetric(vertical: 30),
                  child: user.userAction["action"] == "login"
                      ? PButton(
                          onPress: () => login(),
                          title: "Login",
                          color: ButtonColors.yellow,
                          loading: loading,
                        )
                      : PButton(
                          onPress: () => register(),
                          loading: loading,
                          title: "Register",
                          color: ButtonColors.gray,
                        )),
              Container(
                  child: InkWell(
                onTap: () => Navigator.of(context).pop(),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.arrow_back_ios_rounded,
                      color: Colors.white,
                    ),
                    Padding(
                      padding: EdgeInsets.only(left: 5, right: 20),
                      child: Text(
                        "Back",
                        style: GoogleFonts.baloo2(
                            fontSize: 20, fontWeight: FontWeight.bold),
                      ),
                    )
                  ],
                ),
              ))
            ],
          ),
        )
      ]),
    );
  }
}
