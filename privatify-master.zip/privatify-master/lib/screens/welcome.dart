import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:privatify/components/backgroud.dart';
import 'package:privatify/components/button.dart';

import '../store/user.dart';

class Welcome extends StatefulWidget {
  const Welcome({super.key});

  @override
  State<Welcome> createState() => _WelcomeState();
}

class _WelcomeState extends State<Welcome> {
  final User user = Get.find<User>();

  void goAction(action) async {
    user.setAction(action);
    Get.toNamed('/welcome-email');
  }

  @override
  Widget build(BuildContext context) {
    return Background(
      scrollView: true,
      child: Column(children: [
        Image.asset(
          "assets/login.png",
          width: 268,
        ),
        Container(
          padding: const EdgeInsets.only(top: 25, bottom: 15),
          child: Column(children: [
            Text("Welcome to",
                style: GoogleFonts.baloo2(
                    fontSize: 20,
                    fontWeight: FontWeight.w500,
                    color: Colors.white,
                    height: .5)),
            Text("PRIVATIFY",
                style: GoogleFonts.baloo2(
                    fontSize: 40,
                    fontWeight: FontWeight.bold,
                    color: Colors.white))
          ]),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 30),
          child: Column(
            children: [
              Container(
                  margin: const EdgeInsets.symmetric(vertical: 30),
                  child:  PButton(
                    onPress: () => goAction("login"),
                    title: "Login",
                    color: ButtonColors.yellow,
                  )),
               PButton(
                onPress: () => goAction("resgister"),
                title: "Register",
                color: ButtonColors.gray,
              )
            ],
          ),
        )
      ]),
    );
  }
}
