import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:get/get.dart';
import 'package:privatify/components/backgroud.dart';
import 'package:privatify/components/menu/header.dart';
import 'package:privatify/models/category.dart';
import 'package:privatify/store/refrences.dart';
import 'package:url_launcher/url_launcher.dart';

import '../components/menu/prefItem.dart';

class Contents extends StatefulWidget {
  const Contents({Key? key}) : super(key: key);

  @override
  State<Contents> createState() => _ContentsState();
}

class _ContentsState extends State<Contents> {
  var refrence = Get.put(Refrence());
  var id;
  var title = "";

  Future<void> _launchUrl(url) async {
    if (!await launchUrl(url)) {
      throw 'Could not launch $url';
    }
  }

  @override
  void initState() {
    dynamic categories = refrence.categories.value.data;
    title = categories[Get.arguments].title;

    refrence.getRefrences(categories[Get.arguments].id);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Background(
        child: Container(
            child: Column(children: [
      HeaderMenu(title: title),
    title.contains("security") ?  Image.asset('assets/security.png', width: 288,) : Container(),
      Expanded(
          child: Padding(
        padding: const EdgeInsets.only(top: 20),
        child: Obx(() =>
        refrence.refrences.isNotEmpty ? Column(
              children: [
                //for(var ref in refrence.refrences)

                Expanded(
                    child: SizedBox(
                  height: 300,
                  child: ListView.builder(
                      itemCount: refrence.refrences.length,
                      itemBuilder: (context, index) {
                        var ref = refrence.refrences[index];

                        return PrefItem(
                          key: Key(ref.id.toString()),
                          title: ref.title ?? "",
                          description: ref.description ?? "",
                          icon: "",
                          leftSide: null,
                          url: "",
                          onItem: () => _launchUrl(Uri.parse(ref.url ?? "")),
                          isClickable: true,
                          hasBorder: refrence
                                  .refrences[refrence.refrences.length - 1]
                                  .id !=
                              ref.id,
                          rightSide: Image.asset('assets/arrow.png'),
                        );
                      }),
                ))
              ],
            ) : SizedBox(child: Text("Fetching..."),)),
      ))
    ])));
  }
}
