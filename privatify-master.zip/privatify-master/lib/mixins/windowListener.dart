//import 'package:window_manager/window_manager.dart';

//abstract class CustomWindowsListener {
  // CustomWindowsListener() {
  //   windowManager.addListener(this);
  // }

  // @override
  // void dispose() {
  //   print("from listener .....");
  // }

  // @override
  // void onWindowFocus() {
  //   // TODO: implement onWindowFocus
  //   super.onWindowFocus();
  //   print("windows focused");
  // }
//}
