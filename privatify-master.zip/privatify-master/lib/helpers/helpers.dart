import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:modal_bottom_sheet/modal_bottom_sheet.dart';
import 'package:privatify/models/update.dart' as UpdateModel;
import 'package:privatify/components/button.dart';
import 'package:top_snackbar_flutter/custom_snack_bar.dart';
import 'package:top_snackbar_flutter/top_snack_bar.dart';
import 'package:url_launcher/url_launcher.dart';

class Helpers {
  static Future<void> openUrl(url) async {
    if (!await launchUrl(url, mode: LaunchMode.inAppWebView, webViewConfiguration: WebViewConfiguration(headers: {"inapp": "yes"}) )) {
      throw 'Could not launch $url';
    }
  }

  static openPaymentDashboardUrl() async {
    final storage = new FlutterSecureStorage();
    var token = await storage.read(key: 'jwt-token');
    var url =
        "https://privatify.net/dashboard/auth/login-with-token?token=$token&redirect=/plans?in_app=true";

    openUrl(Uri.parse(url));
  }

  static void errorToast(BuildContext context, String? title) {
    // final scaffold = ScaffoldMessenger.of(context);
    // scaffold.showSnackBar(
    //   SnackBar(
    //       backgroundColor: Colors.white70,
    //       content: Text(
    //         title ?? "",
    //         style: GoogleFonts.baloo2(
    //             color: Colors.red, fontWeight: FontWeight.bold, fontSize: 16),
    //       )
    //       //  action: SnackBarAction(label: 'UNDO', onPressed: scaffold.hideCurrentSnackBar),
    //       ),
    // );

    showTopSnackBar(
      context,
      CustomSnackBar.error(
        message: title ?? "",
      ),
    );
  }

  static void showUpdate(BuildContext context, UpdateModel.Data update) {
    showMaterialModalBottomSheet(
        context: context,
        isDismissible: update.forceUpdate == true ? false : true,
        enableDrag: update.forceUpdate == true ? false : true,
        builder: (context) => SizedBox(
              height: 200,
              width: double.infinity,
              child: Container(
                  color: Color(0xff15161f),
                  padding: const EdgeInsets.only(
                      top: 25, left: 25, right: 25, bottom: 35),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                "Update Privatify",
                                style: GoogleFonts.baloo2(
                                    fontSize: 20, fontWeight: FontWeight.bold),
                              )
                            ],
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                "Version ${update.version}",
                                style: GoogleFonts.baloo2(
                                    fontSize: 14,
                                    fontWeight: FontWeight.normal),
                              )
                            ],
                          ),
                        ],
                      ),
                      PButton(
                          onPress: () => openUrl(Uri.parse(update.url ?? "")),
                          title: "Update")
                    ],
                  )),
            ));
  }

  static void dialogPrompt(context, String title, String description,
      Function accept, Function? cancel) {
    showDialog(
        context: context,
        builder: (context) => AlertDialog(
            backgroundColor: Colors.transparent,
            content: Container(
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: Color(0xff15161f)),
                alignment: Alignment.center,
                padding: EdgeInsets.all(10),
                height: 180,
                child: Column(
                  children: [
                    Text(
                      title,
                      style: GoogleFonts.baloo2(
                          fontSize: 16, fontWeight: FontWeight.bold),
                    ),
                    Text(
                      description,
                      style: Theme.of(context).textTheme.titleSmall,
                      textAlign: TextAlign.center,
                    ),
                    Container(
                      padding: EdgeInsets.only(top: 25),
                      child: Row(
                          mainAxisAlignment: cancel == null
                              ? MainAxisAlignment.center
                              : MainAxisAlignment.spaceAround,
                          children: [
                            InkWell(
                              onTap: () {
                                accept();
                                Navigator.pop(context);
                              },
                              child: Container(
                                padding: EdgeInsets.symmetric(
                                    vertical: 5, horizontal: 5),
                                child: Text(
                                  "Continue",
                                  style: Theme.of(context).textTheme.titleSmall,
                                ),
                              ),
                            ),
                            cancel == null
                                ? Container()
                                : InkWell(
                                    onTap: () {
                                      cancel();
                                      Navigator.pop(context);
                                    },
                                    child: Container(
                                      padding: const EdgeInsets.symmetric(
                                          vertical: 5, horizontal: 5),
                                      child: Text(
                                        "Cancel",
                                        style: Theme.of(context)
                                            .textTheme
                                            .titleSmall,
                                      ),
                                    ),
                                  ),
                          ]),
                    )
                  ],
                ))));
  }
}
