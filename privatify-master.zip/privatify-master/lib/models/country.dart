class CountryModel {
  List<Data>? data;

  CountryModel({this.data});

  CountryModel.fromJson(Map<String, dynamic> json) {
    if (json['data'] != null) {
      data = [];
      json['data'].forEach((v) {
        data!.add(new Data.fromJson(v));
      });
    }
    //   statusCode = json['statusCode'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.data != null) {
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    //   data['statusCode'] = this.statusCode;
    return data;
  }
}

class Data {
  int? id;
  String? name;
  String? shortName;
  String? flag;
  List<Servers>? servers;

  Data({this.id, this.name, this.shortName, this.flag, this.servers});

  Data.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    shortName = json['short_name'];
    flag = json['flag'];
    if (json['servers'] != null) {
      servers = [];
      json['servers'].forEach((v) {
        servers!.add(new Servers.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['short_name'] = this.shortName;
    data['flag'] = this.flag;
    if (this.servers != null) {
      data['servers'] = this.servers!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Servers {
  int? id;
  String? name;
  String? ip;
  num? distance;
  String? date;
  String? lat;
  String? lon;
  List<Protocols>? protocols;
  String? dns;
  City? city;
  num? connections;
  num? level;
  num? maxLevel;

  Servers(
      {this.id,
      this.name,
      this.ip,
      this.distance,
      this.date,
      this.lat,
      this.lon,
      this.protocols,
      this.dns,
      this.city,
      this.connections,
      this.level,
      this.maxLevel});

  Servers.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    ip = json['ip'];
    distance = json['distance'];
    date = json['date'];
    lat = json['lat'];
    lon = json['lon'];
    if (json['protocols'] != null) {
      protocols = [];
      json['protocols'].forEach((v) {
        protocols!.add(new Protocols.fromJson(v));
      });
    }
    dns = json['dns'];
    city = json['city'] != null ? new City.fromJson(json['city']) : null;
    connections = json['connections'];
    level = json['level'];
    maxLevel = json['max_level'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['ip'] = this.ip;
    data['distance'] = this.distance;
    data['date'] = this.date;
    data['lat'] = this.lat;
    data['lon'] = this.lon;
    if (this.protocols != null) {
      data['protocols'] = this.protocols!.map((v) => v.toJson()).toList();
    }
    data['dns'] = this.dns;
    if (this.city != null) {
      data['city'] = this.city!.toJson();
    }
    data['connections'] = this.connections;
    data['level'] = this.level;
    data['max_level'] = this.maxLevel;
    return data;
  }
}

class Protocols {
  int? id;
  String? name;
  int? portNumber;
  String? os;

  Protocols({this.id, this.name, this.portNumber, this.os});

  Protocols.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    portNumber = json['port_number'];
    os = json['os'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['port_number'] = this.portNumber;
    data['os'] = this.os;
    return data;
  }
}

class City {
  int? id;
  String? name;
  String? shortName;
  num? countryId;

  City({this.id, this.name, this.shortName, this.countryId});

  City.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    shortName = json['short_name'];
    countryId = json['country_id'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['short_name'] = this.shortName;
    data['country_id'] = this.countryId;
    return data;
  }
}
