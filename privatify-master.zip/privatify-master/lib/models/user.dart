// ignore_for_file: non_constant_identifier_names

class UserModel {
  Data? data;

  UserModel({this.data});

  UserModel.fromJson(Map<String, dynamic> json) {
    data = json['data'] != null ? new Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class Data {
  int? id;
  String? email;
  String? token;

  Data({this.id, this.email});

  Data.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    email = json['email'];
    token = json['token'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = id;
    data['email'] = email;
    data['token'] = token;
    return data;
  }
}

class Account {
  int? id;
  int? customer_id;
  String? token;
  String? vpn_password;
  String? vpn_username;
  Days? days;

  Account(
      {this.id,
      this.customer_id,
      this.token,
      this.vpn_password,
      this.vpn_username,
      this.days});

  Account.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    customer_id = json['customer_id'];
    token = json['token'];
    vpn_password = json['vpn_password'];
    vpn_username = json['vpn_username'];
    days = json['days'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = id;
    data['customer_id'] = customer_id;
    data['token'] = token;
    data['vpn_password'] = vpn_password;
    data['vpn_username'] = vpn_username;
    data['days'] = days;

    return data;
  }
}

class Days {
  int? all;
  int? remain;

  Days({this.all, this.remain});

  Days.fromJson(Map<String, dynamic> json) {
    all = json['all'];
    remain = json['remain'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['all'] = all;
    data['remain'] = remain;

    return data;
  }
}
