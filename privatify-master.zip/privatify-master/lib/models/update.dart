class UpdateModel {
  Data? data;
  int? statusCode;

  UpdateModel({this.data, this.statusCode});

  UpdateModel.fromJson(Map<String, dynamic> json) {
    data = json['data'] != null ? new Data.fromJson(json['data']) : null;
    statusCode = json['statusCode'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    data['statusCode'] = this.statusCode;
    return data;
  }
}

class Data {
  bool? isVersionExist;
  bool? forceUpdate;
  String? url;
  String? os;
  String? version;
  String? message;

  Data(
      {this.isVersionExist,
      this.forceUpdate,
      this.url,
      this.os,
      this.version,
      this.message});

  Data.fromJson(Map<String, dynamic> json) {
    isVersionExist = json['isVersionExist'];
    forceUpdate = json['forceUpdate'];
    url = json['url'];
    os = json['os'];
    version = json['version'];
    message = json['message'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['isVersionExist'] = this.isVersionExist;
    data['forceUpdate'] = this.forceUpdate;
    data['url'] = this.url;
    data['os'] = this.os;
    data['version'] = this.version;
    data['message'] = this.message;
    return data;
  }
}
