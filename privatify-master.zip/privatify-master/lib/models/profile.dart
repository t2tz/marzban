class Profile {
  Data? data;
  int? statusCode;

  Profile({this.data, this.statusCode});

  Profile.fromJson(Map<String, dynamic> json) {
    data = json['data'] != null ? new Data.fromJson(json['data']) : null;
    statusCode = json['statusCode'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    data['statusCode'] = this.statusCode;
    return data;
  }
}

class Data {
  String? protocol;
  String? language;
  bool? autoConnect;
  int? serverId;
  int? countryId;
  User? user;
  bool? isPremium;
  List<int>? favorites;

  Data(
      {this.protocol,
      this.language,
      this.autoConnect,
      this.serverId,
      this.countryId,
      this.user,
      this.isPremium,
      this.favorites});

  Data.fromJson(Map<String, dynamic> json) {
    protocol = json['protocol'];
    language = json['language'];
    autoConnect = json['auto_connect'];
    serverId = json['server_id'];
    isPremium = json['isPremium'];
    countryId = json['country_id'];
    user = json['user'] != null ? new User.fromJson(json['user']) : null;
    favorites = json['favorites'].cast<int>();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['protocol'] = this.protocol;
    data['language'] = this.language;
    data['auto_connect'] = this.autoConnect;
    data['server_id'] = this.serverId;
    data['country_id'] = this.countryId;
    if (this.user != null) {
      data['user'] = this.user!.toJson();
    }
    data['favorites'] = this.favorites;
    return data;
  }
}

class User {
  int? id;
  String? email;
  Customer? customer;

  User({this.id, this.email, this.customer});

  User.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    email = json['email'];
    customer = json['customer'] != null
        ? new Customer.fromJson(json['customer'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['email'] = this.email;
    if (this.customer != null) {
      data['customer'] = this.customer!.toJson();
    }
    return data;
  }
}

class Customer {
  int? id;
  List<Accounts>? accounts;

  Customer({this.id, this.accounts});

  Customer.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    if (json['accounts'] != null) {
      accounts = <Accounts>[];
      json['accounts'].forEach((v) {
        accounts!.add(new Accounts.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    if (this.accounts != null) {
      data['accounts'] = this.accounts!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Accounts {
  int? id;
  String? expiredAt;
  String? updatedAt;
  Days? days;

  Accounts({this.id, this.expiredAt, this.updatedAt, this.days});

  Accounts.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    expiredAt = json['expired_at'];
    updatedAt = json['updated_at'];
    days = json['days'] != null ? new Days.fromJson(json['days']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['expired_at'] = this.expiredAt;
    data['updated_at'] = this.updatedAt;
    if (this.days != null) {
      data['days'] = this.days!.toJson();
    }
    return data;
  }
}

class Days {
  int? all;
  int? remain;

  Days({this.all, this.remain});

  Days.fromJson(Map<String, dynamic> json) {
    all = json['all'];
    remain = json['remain'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['all'] = this.all;
    data['remain'] = this.remain;
    return data;
  }
}