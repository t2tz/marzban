class ConfigModel {
  Data? data;

  ConfigModel({this.data});

  ConfigModel.fromJson(Map<String, dynamic> json) {
    data = json['data'] != null ? new Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class Data {
  String? account;
  String? config;
  String? protocol;
  String? username;
  String? password;
  Certificate? certificate;

  Data({this.account, this.config, this.protocol, this.certificate, this.password, this.username});

  Data.fromJson(Map<String, dynamic> json) {
    account = json['account'];
    config = json['config'];
    protocol = json['protocol'];
    username = json['username'];
    password = json['password'];
    certificate = json['certificate'] != null
        ? new Certificate.fromJson(json['certificate'])
        : null;
  }
//certificate
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['account'] = account;
    data['config'] = config;
    data['protocol'] = protocol;
    data['username'] = username;
    data['password'] = password;
    if (this.certificate != null) {
      data['certificate'] = this.certificate!.toJson();
    }

    
    return data;
  }
}

class Certificate {
  String? pem;
  String? p12;

  Certificate({this.pem, this.p12});

  Certificate.fromJson(Map<String, dynamic> json) {
    pem = json['pem'];
    p12 = json['p12'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['pem'] = this.pem;
    data['p12'] = this.p12;
    return data;
  }
}