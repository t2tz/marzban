class LoginResponse {
  Data? data;
  int? statusCode;

  LoginResponse({this.data, this.statusCode});

  LoginResponse.fromJson(Map<String, dynamic> json) {
    data = json['data'] != null ? new Data.fromJson(json['data']) : null;
    statusCode = json['statusCode'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    data['statusCode'] = this.statusCode;
    return data;
  }
}

class Data {
  bool? isTwoStep;
  String? message;
  String? refererUrl;

  Data({this.isTwoStep, this.message, this.refererUrl});

  Data.fromJson(Map<String, dynamic> json) {
    isTwoStep = json['is_two_step'];
    message = json['message'];
    refererUrl = json['referer_url'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['is_two_step'] = isTwoStep;
    data['message'] = message;
    data['referer_url'] = refererUrl;
    return data;
  }
}