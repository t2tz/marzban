class ServersModel {
  List<Data>? data;
  int? statusCode;

  ServersModel({this.data, this.statusCode});

  ServersModel.fromJson(Map<String, dynamic> json) {
    if (json['data'] != null) {
      data = <Data>[];
      json['data'].forEach((v) {
        data!.add(new Data.fromJson(v));
      });
    }
    statusCode = json['statusCode'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.data != null) {
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    data['statusCode'] = this.statusCode;
    return data;
  }
}

class Data {
  int? id;
  String? name;
  num? distance;
  String? date;
  Country? country;
  City? city;
  String? lat;
  String? lon;
  String? ip;
  Resources? resources;
  List<Protocols>? protocols;
  num? countryId;
  String? dns;
  num? connections;
  num? level;
  num? maxLevel;
  bool? premium;

  Data(
      {this.id,
      this.name,
      this.distance,
      this.date,
      this.country,
      this.city,
      this.lat,
      this.lon,
      this.ip,
      this.resources,
      this.protocols,
      this.countryId,
      this.dns,
      this.connections,
      this.level,
      this.maxLevel,
      this.premium
      });

  Data.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    distance = json['distance'];
    date = json['date'];
    country =
        json['country'] != null ? new Country.fromJson(json['country']) : null;
    city = json['city'] != null ? new City.fromJson(json['city']) : null;
    lat = json['lat'];
    lon = json['lon'];
    ip = json['ip'];
    resources = json['resources'] != null
        ? new Resources.fromJson(json['resources'])
        : null;
    if (json['protocols'] != null) {
      protocols = <Protocols>[];
      json['protocols'].forEach((v) {
        protocols!.add(new Protocols.fromJson(v));
      });
    }
    countryId = json['countryId'];
    dns = json['dns'];
    connections = json['connections'];
    level = json['level'];
    maxLevel = json['max_level'];
    premium = json['premium'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['distance'] = this.distance;
    data['date'] = this.date;
    if (this.country != null) {
      data['country'] = this.country!.toJson();
    }
    if (this.city != null) {
      data['city'] = this.city!.toJson();
    }
    data['lat'] = this.lat;
    data['lon'] = this.lon;
    data['ip'] = this.ip;
    if (this.resources != null) {
      data['resources'] = this.resources!.toJson();
    }
    if (this.protocols != null) {
      data['protocols'] = this.protocols!.map((v) => v.toJson()).toList();
    }
    data['countryId'] = this.countryId;
    data['dns'] = this.dns;
    data['connections'] = this.connections;
    data['level'] = this.level;
    data['max_level'] = this.maxLevel;
    data['premium'] = premium;
    return data;
  }
}

class Country {
  int? id;
  String? name;
  String? shortName;
  String? flag;

  Country({this.id, this.name, this.shortName, this.flag});

  Country.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    shortName = json['short_name'];
    flag = json['flag'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['short_name'] = this.shortName;
    data['flag'] = this.flag;
    return data;
  }
}

class City {
  int? id;
  String? name;
  String? shortName;
  num? countryId;

  City({this.id, this.name, this.shortName, this.countryId});

  City.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    shortName = json['short_name'];
    countryId = json['country_id'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['short_name'] = this.shortName;
    data['country_id'] = this.countryId;
    return data;
  }
}

class Resources {
  int? id;
  num? cpuUsage;
  num? memoryUsage;
  String? networkIn;
  String? networkOut;
  bool? isUp;
  String? updateAt;

  Resources(
      {this.id,
      this.cpuUsage,
      this.memoryUsage,
      this.networkIn,
      this.networkOut,
      this.isUp,
      this.updateAt});

  Resources.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    cpuUsage = json['cpu_usage'];
    memoryUsage = json['memory_usage'];
    networkIn = json['network_in'];
    networkOut = json['network_out'];
    isUp = json['is_up'];
    updateAt = json['update_at'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['cpu_usage'] = this.cpuUsage;
    data['memory_usage'] = this.memoryUsage;
    data['network_in'] = this.networkIn;
    data['network_out'] = this.networkOut;
    data['is_up'] = this.isUp;
    data['update_at'] = this.updateAt;
    return data;
  }
}

class Protocols {
  int? id;
  String? name;
  num? portNumber;
  Null? os;

  Protocols({this.id, this.name, this.portNumber, this.os});

  Protocols.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    portNumber = json['port_number'];
    os = json['os'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['port_number'] = this.portNumber;
    data['os'] = this.os;
    return data;
  }
}
