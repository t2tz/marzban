class UsageModel {
  Data? data;

  UsageModel({this.data});

  UsageModel.fromJson(Map<String, dynamic> json) {
    data = json['data'] != null ? new Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class Data {
  String? leftUsage;
  num? usage;
  num? limit;

  Data({this.leftUsage, this.usage, this.limit});

  Data.fromJson(Map<String, dynamic> json) {
    usage = json['usage'];
    leftUsage = json['leftUsage'];
    limit = json['limit'];
  }
//certificate
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['leftUsage'] = leftUsage;
    data['usage'] = usage;
    data['limit'] = limit;
 

    return data;
  }
}

