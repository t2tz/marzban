import 'dart:io';

import 'package:flutter/material.dart' hide MenuItem;
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:privatify/screens/contents.dart';
import 'package:privatify/screens/dashboard.dart';
import 'package:privatify/screens/home.dart';
import 'package:privatify/screens/menu.dart' as MenuSettings;
import 'package:privatify/screens/preferences.dart';
import 'package:privatify/screens/referer.dart';
import 'package:privatify/screens/splash.dart';
import 'package:privatify/screens/purchase.dart';
import 'package:privatify/screens/welcome.dart';
import 'package:privatify/screens/welcome_code.dart';
import 'package:privatify/screens/welcome_email.dart';
import 'package:privatify/screens/welcome_password.dart';
import 'package:privatify/store/customWindowListener.dart';
import 'package:privatify/store/server.dart';
import 'package:privatify/store/user.dart';
import 'package:privatify/store/vpn.dart';
import 'package:tray_manager/tray_manager.dart';
import 'package:window_manager/window_manager.dart';
import 'package:window_size/window_size.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  Get.put(User());
  Get.put(Server());
  final vpn = Get.put(VPN());

  if (Platform.isWindows) {
    await trayManager.setIcon('assets/icon/icon.ico');

    await CustomWindowListener().createTrayMenu();

    //double minWidth = 375;
    //double minHeight = 680;
    //setWindowMaxSize(Size(minWidth, minHeight));
    //setWindowMinSize(Size(minWidth, minHeight));

    await windowManager.ensureInitialized();
    await windowManager.setTitle("PRIVATIFY");
    await windowManager.setAlignment(Alignment.bottomRight);
    await windowManager.setPreventClose(true);

    windowManager.setResizable(false);

    WindowOptions windowOptions = const WindowOptions(
        // minimumSize: Size(375, 680),
        //maximumSize: Size(375, 680),
        // titleBarStyle: TitleBarStyle.hidden,
        );

    windowManager.waitUntilReadyToShow(windowOptions, () async {
      await windowManager.show();
      await windowManager.focus();
      Get.put(CustomWindowListener());
    });

    vpn.initialListener();
  }

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);
    // return MaterialApp(
    //   title: 'Flutter Demo',
    //   theme: ThemeData(
    //     // This is the theme of your application.
    //     //
    //     // Try running your application with "flutter run". You'll see the
    //     // application has a blue toolbar. Then, without quitting the app, try
    //     // changing the primarySwatch below to Colors.green and then invoke
    //     // "hot reload" (press "r" in the console where you ran "flutter run",
    //     // or simply save your changes to "hot reload" in a Flutter IDE).
    //     // Notice that the counter didn't reset back to zero; the application
    //     // is not restarted.
    //     primarySwatch: Colors.blue,
    //   ),
    //   home: const MyHomePage(title: 'Flutter Demo Home Page'),
    // );
    return GetMaterialApp(
      title: 'Privatify',
      initialRoute: "splash",
      defaultTransition: Transition.cupertino,
      getPages: [
        GetPage(name: "/home", page: () => const Home()),
        GetPage(name: "/splash", page: () => const Splash()),
        GetPage(name: "/welcome", page: () => const Welcome()),
        GetPage(name: "/welcome-email", page: () => const WelcomeEmail()),
        GetPage(name: '/welcome-password', page: () => const WelcomePassword()),
        GetPage(name: '/welcome-code', page: () => const WelcomeCode()),
        GetPage(name: '/menu', page: () => const MenuSettings.Menu()),
        GetPage(name: '/contents', page: () => const Contents()),
        GetPage(name: '/referer', page: () => const Referer()),
        GetPage(name: '/pref', page: () => const Preferences()),
        GetPage(name: '/purchase', page: () => MyAppPurchase()),
        GetPage(name: '/dashboard', page: () => InAppWebViewExampleScreen())
      ],
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
          // This is the theme of your application.
          //
          // Try running your application with "flutter run". You'll see the
          // application has a blue toolbar. Then, without quitting the app, try
          // changing the primarySwatch below to Colors.green and then invoke
          // "hot reload" (press "r" in the console where you ran "flutter run",
          // or simply save your changes to "hot reload" in a Flutter IDE).
          // Notice that the counter didn't reset back to zero; the application
          // is not restarted.
          primarySwatch: Colors.green,
          errorColor: const Color(0x00ff5c5c),
          highlightColor: const Color(0x00ffc500),
          backgroundColor: const Color(0x005a5d78),
          textTheme: TextTheme(
              titleLarge: GoogleFonts.baloo2(
                  fontSize: 32,
                  fontWeight: FontWeight.bold,
                  color: Colors.white),
              titleMedium: GoogleFonts.baloo2(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: Colors.white),
              titleSmall: GoogleFonts.baloo2(
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                  color: Colors.white60),
              bodySmall: GoogleFonts.baloo2(
                  fontSize: 18,
                  fontWeight: FontWeight.w500,
                  color: Colors.white),
              bodyMedium: GoogleFonts.baloo2(
                  fontSize: 18,
                  fontWeight: FontWeight.w500,
                  color: Colors.white))),
      home: const Splash(),
    );
  }
}
