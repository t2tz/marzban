import 'dart:developer';

import 'package:dio/dio.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:get/utils.dart';
import 'package:package_info_plus/package_info_plus.dart';

class Service {
  dynamic requestInterceptor(
      RequestOptions options, RequestInterceptorHandler handler) async {
    final storage = new FlutterSecureStorage();
    var token = await storage.read(key: 'jwt-token');

    PackageInfo packageInfo = await PackageInfo.fromPlatform();
    String appName = packageInfo.appName;
    String version = packageInfo.version;
    String buildNumber = packageInfo.buildNumber;
    String platformName = GetPlatform.isIOS
        ? "ios"
        : GetPlatform.isAndroid
            ? "android"
            : GetPlatform.isWindows
                ? "windows"
                : "osx";

    String appInfo = "${appName}_${version}_${buildNumber}_$platformName";
    // var options = BaseOptions(
    //     baseUrl: "https://api.privatify.net/", headers: {'jwt-token': token});
    options.headers.addAll({'jwt-token': token, "app-info": appInfo});
    //log(token ?? "");
    options.baseUrl = "https://api.privatify.net/";

    options.connectTimeout = 5000;
    options.receiveTimeout = 5000;
    // SharedPreferences prefs = await SharedPreferences.getInstance();
    // var token = prefs.get("token");

    // options.headers.addAll({"Token": "$token${DateTime.now()}"});

    handler.next(options);
  }

  Dio request() {
    Dio dio = Dio();
    dio.interceptors.add(InterceptorsWrapper(
      onRequest: (RequestOptions options, RequestInterceptorHandler handler) =>
          requestInterceptor(options, handler),
          
      onError: (e, h) {
        // throw e.response!.data["message"];
        h.next(e);
      },
      // onResponse: (resp, handler) => print(resp)
    ));

    return dio;
  }
}
