import 'dart:developer';

import 'package:dio/dio.dart';
import 'package:privatify/providers/service.dart';

//const String BASE_URL = "https://api.privatify.net/";

class UserProvider extends Service {
  Future<Response> login(String email, String password) =>
      request().post("users/login?two_step=1", data: {
        "email": email,
        "password": password
      }).onError((DioError error, stackTrace) {
        //   print(error.response);
         if (error.response == null) {
          throw "Internet/Server Connection error.";
        }
        throw error.response?.data["message"];
      });
  Future<Response> register(String email, String password) =>
      request().post("customers/subscription", data: {
        "email": email,
        "password": password
      }).onError((DioError error, stackTrace) {
        if (error.response == null) {
          throw "Internet/Server Connection error.";
        }
        //   print(error.response);
        throw error.response?.data["message"];
      });

  Future<Response> verifyCode(num code, String email) =>
      request().post("users/verify-code/$code", data: {"email": email}).onError(
          (DioError error, stackTrace) {
        //   print(error.response);
        if (error.response == null) {
          throw "Internet/Server Connection error.";
        }
        //   print(error.response);
        throw error.response?.data["message"];
      });

  Future<Response> resendCode(String email) =>
      request().post("users/resend-code", data: {"email": email}).onError(
          (DioError error, stackTrace) {
        //   print(error.response);
        if (error.response == null) {
          throw "Internet/Server Connection error.";
        }
        //   print(error.response);
        throw error.response?.data["message"];
      });

  Future<Response> verifyPayment(String email, String receiptData) =>
      request().post("payment/apple-pay/verify", data: {
        "email": email,
        "receiptData": receiptData
      }).onError((DioError error, stackTrace) {
        //   print(error.response);
        if (error.response == null) {
          throw "Internet/Server Connection error.";
        }
        //   print(error.response);
        throw error.response?.data["message"];
      });

  Future<Response> profile() => request().get("customers/profile");

  Future<Response> getUsage() => request().get("/accounts/usage");
}
