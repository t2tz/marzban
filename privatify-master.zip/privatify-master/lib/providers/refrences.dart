import 'dart:developer';

import 'package:dio/src/response.dart';
import 'package:privatify/providers/service.dart';

class RefrenceProvider extends Service {
  Future<Response> refrences(id) =>
      request().get("contents/refrences?category_id=$id");

  Future<Response> categories() =>
      request().get("contents/refrences/categories");
}
