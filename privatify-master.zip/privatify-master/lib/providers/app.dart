import 'dart:developer';

import 'package:dio/dio.dart';
import 'package:privatify/providers/service.dart';

//const String BASE_URL = "https://api.privatify.net/";

class AppProvider extends Service {

  Future<Response> checkUpdate() => request().post("/update");

}
