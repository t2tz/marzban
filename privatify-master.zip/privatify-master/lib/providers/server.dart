import 'dart:developer';

import 'package:dio/dio.dart';
import 'package:dio/src/response.dart';
import 'package:privatify/providers/service.dart';

class ServerProvider extends Service {
  Future<Response> countries({String proto = "udp"}) =>
      request().get("servers/countries?protocol=$proto");

  Future<Response> servers({String proto = "udp"}) =>
      request().get("servers?protocol=$proto&resources=true").onError(
          (DioError error, stackTrace) {
          print(error.requestOptions.uri);
        if (error.response == null) {
          print(error.error);
           print("Internet/Server Connection error.");
        }
        //   print(error.response);
         print(error.response?.data["message"]);
         throw error.response?.data["message"];
      });


  Future<Response> init({String proto = "openvpn", required int serverId}) =>
      request().post("servers/init",
          data: {"server_id": serverId, "protocol": proto}).onError((DioError error, stackTrace) {
        throw error.response?.data["message"];
      });
}
