import 'dart:developer';
import 'dart:io';

import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:get/get.dart';
//import 'package:privatify/helpers/helpers.dart';
import 'package:privatify/store/user.dart';
import 'package:privatify/store/vpn.dart';

import '../store/server.dart';

class Application {

  final server = Get.find<Server>();
  final user = Get.find<User>();
  final vpn = Get.find<VPN>();

 Future<bool> AppInit() async {
    // check internent connection
    ConnectivityResult connectivityResult =
        await (Connectivity().checkConnectivity());



    if (connectivityResult == ConnectivityResult.none) return false;

    // check jwt token
    var storage = new FlutterSecureStorage();
    var token = await storage.read(key: 'jwt-token');

    if (token == null) {
      Get.toNamed('/welcome');
      return true;
    }

    user.setUrl(
        "https://privatify.net/dashboard/auth/login-with-token?token=$token&redirect=/plans?in_app=true");

    // fetch user profile

    var proto = await storage.read(key: 'protocol');
    await addPrototoStore(proto);

    // fetch countries

    //await server.getServers();
    await user.getProfile();

    if (user.profile.value.isPremium == false) {
      await user.getUserUsage();
    }

    await server.getFavorites();

    var lastServerId = await storage.read(key: "last_server_id");

    if (lastServerId == null || lastServerId.isEmpty) {
      var optimizedServer = server.servers.firstWhere((item) =>
          user.profile.value.isPremium == true ? true : item.premium == false);
      await server.selectServer(optimizedServer);
    } else {
      var lastServer = server.servers
          .firstWhere((item) => item.id == num.parse(lastServerId));
      await server.selectServer(lastServer);
    }

    if (vpn.autoConnect == true && vpn.status.value == Status.notConnected) {
      await vpn.connect();
    }


    return true;
  }

  addPrototoStore(String? proto) async {
    if (proto == null) {
      return await vpn.changeProtocol(Protocol.auto);
    } else {
      Protocol protocol =
          Protocol.values.firstWhere((element) => element.name == proto);
      await vpn.changeProtocol(protocol);
    }
  }
}
