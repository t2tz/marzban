import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:privatify/components/servers/servers.dart';

class LocationButton extends StatelessWidget {
  const LocationButton({super.key});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () => ServersWidget().show(context),
      child: Container(
        margin: EdgeInsets.symmetric(
            vertical: MediaQuery.of(context).size.height > 720 ? 20 : 10),
        width: 144,
        height: 44,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          color: const Color(0xe52e2e38),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Image.asset(
              "assets/globe.png",
              width: 24,
            ),
            Text(
              "Location",
              style: Theme.of(context).textTheme.titleSmall,
            ),
            Image.asset(
              "assets/arrow.png",
              width: 24,
            )
          ],
        ),
      ),
    );
  }
}
