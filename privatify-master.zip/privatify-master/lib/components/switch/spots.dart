import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter_svg/flutter_svg.dart';

class Spots extends StatefulWidget {
  const Spots({super.key, this.color1 = "yellow", this.color2 = "yellow", this.color3 = "yellow"});

 final String color1;
 final String color2;
 final String color3;

  @override
  State<Spots> createState() => _SpotsState();
}

class _SpotsState extends State<Spots> {

  var red = "yellow";
  @override
  Widget build(BuildContext context) {
    return SvgPicture.string('''
    <svg xmlns="http://www.w3.org/2000/svg" width="493" height="368" viewBox="0 0 493 368">
    <defs>
        <clipPath id="clip-path">
            <path id="Rectangle_2517" d="M0 0H493V368H0z" class="cls-1" transform="translate(.046 .297)"/>
        </clipPath>

    </defs>
    <g id="Group_10623" transform="translate(.795 .088)">
        <g id="Group_10576" transform="translate(-.841 -.385)">
            <g id="Group_10575" clip-path="url(#clip-path)">
                <g id="Group_10574" transform="translate(-3.627 -.756)">
                    <path id="Path_48247" d="M21.453 14.645a1.646 1.646 0 1 1-1.646 1.646 1.643 1.643 0 0 1 1.646-1.646z" class="cls-1" transform="translate(228.167 171.476)"/>
                    <path id="Path_48248" d="M22.376 14.627a1.867 1.867 0 1 1-1.867 1.867 1.863 1.863 0 0 1 1.867-1.867z" class="cls-1" transform="translate(236.086 171.273)"/>
                    <path id="Path_48249" d="M22.037 15.2a1.793 1.793 0 1 1-1.793 1.793 1.793 1.793 0 0 1 1.793-1.793z" class="cls-1" transform="translate(233.097 163.863)"/>
                    <path id="Path_48250" d="M21.371 15.339a1.744 1.744 0 1 1-1.732 1.744 1.743 1.743 0 0 1 1.732-1.744z" class="cls-1" transform="translate(226.271 162.062)"/>
                    <path id="Path_48251" d="M20.623 14.974a1.443 1.443 0 1 1-1.449 1.449 1.452 1.452 0 0 1 1.449-1.449z" class="cls-1" transform="translate(221.025 167.512)"/>
                    <path id="Path_48252" d="M20.578 14.353a1.394 1.394 0 1 1-1.4 1.388 1.4 1.4 0 0 1 1.4-1.388z" class="cls-1" transform="translate(221.07 175.858)"/>
                    <path id="Path_48253" d="M21.168 13.953a1.523 1.523 0 1 1-1.511 1.523 1.523 1.523 0 0 1 1.511-1.523z" class="cls-1" transform="translate(226.474 180.913)"/>
                    <path id="Path_48254" d="M21.969 14.076A1.719 1.719 0 1 1 20.25 15.8a1.714 1.714 0 0 1 1.719-1.724z" class="cls-1" transform="translate(233.164 178.886)"/>
                    <path id="Path_48255" d="M23.118 14.625a1.891 1.891 0 1 1-1.891 1.891 1.882 1.882 0 0 1 1.891-1.891z" class="cls-1" transform="translate(244.187 171.25)"/>
                    <path id="Path_48256" d="M22.93 15.254a1.836 1.836 0 1 1-1.842 1.83 1.837 1.837 0 0 1 1.842-1.83z" class="cls-1" transform="translate(242.619 163.007)"/>
                    <circle id="Ellipse_10532" cx="1.471" cy="1.471" r="1.471" class="cls-1" transform="translate(259.171 172.469)"/>
                    <path id="Path_48257" d="M21.412 16.081a1.253 1.253 0 1 1-1.253 1.253 1.258 1.258 0 0 1 1.253-1.253z" class="cls-1" transform="translate(232.138 153.189)"/>
                    <path id="Path_48258" d="M20.771 16.081a1.253 1.253 0 1 1-1.253 1.253 1.258 1.258 0 0 1 1.253-1.253z" class="cls-1" transform="translate(224.906 153.189)"/>
                    <circle id="Ellipse_10533" cx="1.422" cy="1.422" r="1.422" class="cls-1" transform="translate(237.166 172.518)"/>
                    <path id="Path_48259" d="M19.884 15.294a1.351 1.351 0 1 1-1.351 1.351 1.355 1.355 0 0 1 1.351-1.351z" class="cls-1" transform="translate(213.794 163.446)"/>
                    <path id="Path_48260" d="M19.7 14.673a1.3 1.3 0 1 1-1.3 1.3 1.3 1.3 0 0 1 1.3-1.3z" class="cls-1" transform="translate(212.237 171.792)"/>
                    <path id="Path_48261" d="M19.907 14.042a1.376 1.376 0 1 1-1.376 1.376 1.373 1.373 0 0 1 1.376-1.376z" class="cls-1" transform="translate(213.771 180.025)"/>
                    <circle id="Ellipse_10534" cx="1.398" cy="1.398" r="1.398" class="cls-1" transform="translate(237.19 200.197)"/>
                    <path id="Path_48262" d="M20.929 13.259a1.425 1.425 0 1 1-1.429 1.425 1.426 1.426 0 0 1 1.429-1.425z" class="cls-1" transform="translate(224.748 190.327)"/>
                    <path id="Path_48263" d="M21.728 13.245a1.6 1.6 0 1 1-1.6 1.6 1.593 1.593 0 0 1 1.6-1.6z" class="cls-1" transform="translate(231.822 190.169)"/>
                    <path id="Path_48264" d="M22.429 13.511a1.744 1.744 0 1 1-1.729 1.744 1.743 1.743 0 0 1 1.729-1.744z" class="cls-1" transform="translate(238.207 186.341)"/>
                    <path id="Path_48265" d="M22.84 14.012a1.744 1.744 0 1 1-1.74 1.744 1.751 1.751 0 0 1 1.74-1.744z" class="cls-1" transform="translate(242.709 179.687)"/>
                    <path id="Path_48266" d="M23.748 14.633a1.793 1.793 0 1 1-1.793 1.793 1.793 1.793 0 0 1 1.793-1.793z" class="cls-1" transform="translate(252.4 171.341)"/>
                    <path id="Path_48267" d="M23.472 15.286a1.591 1.591 0 1 1-1.6 1.584 1.588 1.588 0 0 1 1.6-1.584z" class="cls-1" transform="translate(251.497 163.073)"/>
                    <path id="Path_48268" d="M22.876 15.894a1.253 1.253 0 1 1-1.253 1.253 1.25 1.25 0 0 1 1.253-1.253z" class="cls-1" transform="translate(248.654 155.673)"/>
                    <path id="Path_48269" d="M22.3 16.378a1.105 1.105 0 1 1-1.1 1.105 1.109 1.109 0 0 1 1.1-1.105z" class="cls-1" transform="translate(243.848 149.539)"/>
                    <path id="Path_48270" d="M21.678 16.706a1.026 1.026 0 1 1-1.032 1.019 1.027 1.027 0 0 1 1.032-1.019z" class="cls-1" transform="translate(237.632 145.343)"/>
                    <path id="Path_48271" d="M21.117 16.843a1.105 1.105 0 1 1-1.105 1.105 1.109 1.109 0 0 1 1.105-1.105z" class="cls-1" transform="translate(230.479 143.363)"/>
                    <circle id="Ellipse_10535" cx="1.152" cy="1.152" r="1.152" class="cls-1" transform="translate(242.56 160.752)"/>
                    <path id="Path_48272" d="M19.944 16.554a1.173 1.173 0 0 1 0 2.346 1.173 1.173 0 1 1 0-2.346z" class="cls-1" transform="translate(216.411 147.067)"/>
                    <path id="Path_48273" d="M19.508 16.146a1.253 1.253 0 1 1-1.253 1.254 1.258 1.258 0 0 1 1.253-1.254z" class="cls-1" transform="translate(210.657 152.326)"/>
                    <path id="Path_48274" d="M19.146 15.614a1.253 1.253 0 1 1-1.253 1.253 1.248 1.248 0 0 1 1.253-1.253z" class="cls-1" transform="translate(206.573 159.392)"/>
                    <circle id="Ellipse_10536" cx="1.299" cy="1.299" r="1.299" class="cls-1" transform="translate(222.084 182.514)"/>
                    <circle id="Ellipse_10537" cx="1.324" cy="1.324" r="1.324" class="cls-1" transform="translate(222.059 190.398)"/>
                    <path id="Path_48275" d="M19.191 13.736a1.3 1.3 0 1 1-1.3 1.3 1.3 1.3 0 0 1 1.3-1.3z" class="cls-1" transform="translate(206.528 184.237)"/>
                    <path id="Path_48276" d="M19.6 13.2a1.351 1.351 0 1 1-1.351 1.351A1.355 1.355 0 0 1 19.6 13.2z" class="cls-1" transform="translate(210.567 191.258)"/>
                    <path id="Path_48277" d="M20.147 12.794a1.4 1.4 0 1 1-1.4 1.4 1.4 1.4 0 0 1 1.4-1.4z" class="cls-1" transform="translate(216.208 196.552)"/>
                    <circle id="Ellipse_10538" cx="1.496" cy="1.496" r="1.496" class="cls-1" transform="translate(242.216 212.135)"/>
                    <path id="Path_48278" d="M21.614 12.491a1.646 1.646 0 1 1-1.646 1.646 1.646 1.646 0 0 1 1.646-1.646z" class="cls-1" transform="translate(229.983 200.085)"/>
                    <path id="Path_48279" d="M22.309 12.628a1.719 1.719 0 1 1-1.719 1.719 1.714 1.714 0 0 1 1.719-1.719z" class="cls-1" transform="translate(237 198.118)"/>
                    <path id="Path_48280" d="M22.9 12.947a1.762 1.762 0 1 1-1.756 1.769 1.761 1.761 0 0 1 1.756-1.769z" class="cls-1" transform="translate(243.25 193.795)"/>
                    <path id="Path_48281" d="M23.406 13.412a1.842 1.842 0 1 1-1.83 1.842 1.84 1.84 0 0 1 1.83-1.842z" class="cls-1" transform="translate(248.124 187.46)"/>
                    <path id="Path_48282" d="M23.72 13.991a1.861 1.861 0 1 1-1.867 1.867 1.863 1.863 0 0 1 1.867-1.867z" class="cls-1" transform="translate(251.249 179.733)"/>
                    <path id="Path_48283" d="M24.513 14.629a1.842 1.842 0 1 1-1.842 1.842 1.837 1.837 0 0 1 1.842-1.842z" class="cls-1" transform="translate(260.478 171.296)"/>
                    <path id="Path_48284" d="M24.158 15.294a1.548 1.548 0 1 1-1.535 1.548 1.549 1.549 0 0 1 1.535-1.548z" class="cls-1" transform="translate(259.936 163.053)"/>
                    <path id="Path_48285" d="M23.674 15.927a1.247 1.247 0 1 1-1.24 1.253 1.242 1.242 0 0 1 1.24-1.253z" class="cls-1" transform="translate(257.804 155.247)"/>
                    <path id="Path_48286" d="M23.185 16.487a1.075 1.075 0 1 1-1.085 1.069 1.072 1.072 0 0 1 1.085-1.069z" class="cls-1" transform="translate(254.081 148.153)"/>
                    <path id="Path_48287" d="M22.684 16.947a1.032 1.032 0 1 1-1.032 1.032 1.03 1.03 0 0 1 1.032-1.032z" class="cls-1" transform="translate(248.982 142.13)"/>
                    <path id="Path_48288" d="M22.047 17.3a.933.933 0 1 1-.933.933.933.933 0 0 1 .933-.933z" class="cls-1" transform="translate(242.912 137.664)"/>
                    <path id="Path_48289" d="M21.45 17.509a.958.958 0 1 1 0 1.916.958.958 0 0 1 0-1.916z" class="cls-1" transform="translate(236.03 134.813)"/>
                    <path id="Path_48290" d="M20.844 17.579a.983.983 0 1 1-.983.983.975.975 0 0 1 .983-.983z" class="cls-1" transform="translate(228.776 133.834)"/>
                    <path id="Path_48291" d="M20.248 17.5a1.032 1.032 0 1 1 0 2.063 1.032 1.032 0 1 1 0-2.063z" class="cls-1" transform="translate(221.499 134.745)"/>
                    <path id="Path_48292" d="M19.661 17.288a1.056 1.056 0 1 1-1.061 1.056 1.064 1.064 0 0 1 1.061-1.056z" class="cls-1" transform="translate(214.606 137.551)"/>
                    <path id="Path_48293" d="M19.16 16.941a1.1 1.1 0 1 1-1.105 1.093 1.1 1.1 0 0 1 1.105-1.093z" class="cls-1" transform="translate(208.401 142.074)"/>
                    <circle id="Ellipse_10539" cx="1.25" cy="1.25" r="1.25" class="cls-1" transform="translate(220.71 164.463)"/>
                    <path id="Path_48294" d="M18.542 15.923a1.3 1.3 0 1 1-1.3 1.3 1.3 1.3 0 0 1 1.3-1.3z" class="cls-1" transform="translate(199.206 155.202)"/>
                    <path id="Path_48295" d="M18.351 15.312a1.326 1.326 0 0 1 0 2.653 1.326 1.326 0 1 1 0-2.653z" class="cls-1" transform="translate(196.781 163.256)"/>
                    <path id="Path_48296" d="M18.325 14.667a1.376 1.376 0 1 1-1.376 1.376 1.371 1.371 0 0 1 1.376-1.376z" class="cls-1" transform="translate(195.923 171.724)"/>
                    <path id="Path_48297" d="M18.329 14.032a1.3 1.3 0 1 1-1.3 1.3 1.3 1.3 0 0 1 1.3-1.3z" class="cls-1" transform="translate(196.803 180.306)"/>
                    <path id="Path_48298" d="M18.564 13.422a1.32 1.32 0 1 1-1.326 1.326 1.329 1.329 0 0 1 1.326-1.326z" class="cls-1" transform="translate(199.184 188.371)"/>
                    <circle id="Ellipse_10540" cx="1.398" cy="1.398" r="1.398" class="cls-1" transform="translate(220.563 208.424)"/>
                    <circle id="Ellipse_10541" cx="1.422" cy="1.422" r="1.422" class="cls-1" transform="translate(226.139 214)"/>
                    <circle id="Ellipse_10542" cx="1.496" cy="1.496" r="1.496" class="cls-1" transform="translate(232.772 218.14)"/>
                    <circle id="Ellipse_10543" cx="1.52" cy="1.52" r="1.52" class="cls-1" transform="translate(240.224 220.731)"/>
                    <path id="Path_48299" d="M21.453 11.765a1.646 1.646 0 1 1-1.646 1.646 1.643 1.643 0 0 1 1.646-1.646z" class="cls-1" transform="translate(228.167 209.728)"/>
                    <path id="Path_48300" d="M22.194 11.827a1.769 1.769 0 1 1-1.756 1.773 1.761 1.761 0 0 1 1.756-1.773z" class="cls-1" transform="translate(235.285 208.659)"/>
                    <path id="Path_48301" d="M22.769 12.044a1.719 1.719 0 1 1-1.719 1.719 1.725 1.725 0 0 1 1.719-1.719z" class="cls-1" transform="translate(242.19 205.875)"/>
                    <path id="Path_48302" d="M23.361 12.383a1.769 1.769 0 1 1-1.769 1.769 1.761 1.761 0 0 1 1.769-1.769z" class="cls-1" transform="translate(248.305 201.274)"/>
                    <path id="Path_48303" d="M23.941 12.828a1.91 1.91 0 1 1 0 3.82 1.91 1.91 0 0 1 0-3.82z" class="cls-1" transform="translate(253.325 195.081)"/>
                    <path id="Path_48304" d="M24.261 13.376a1.885 1.885 0 1 1 0 3.771 1.885 1.885 0 0 1 0-3.771z" class="cls-1" transform="translate(257.217 187.852)"/>
                    <path id="Path_48305" d="M24.474 13.984a1.891 1.891 0 1 1-1.874 1.891 1.892 1.892 0 0 1 1.874-1.891z" class="cls-1" transform="translate(259.62 179.764)"/>
                    <path id="Path_48306" d="M25.188 14.633a1.793 1.793 0 1 1-1.793 1.793 1.793 1.793 0 0 1 1.793-1.793z" class="cls-1" transform="translate(268.646 171.341)"/>
                    <circle id="Ellipse_10544" cx="1.324" cy="1.324" r="1.324" class="cls-1" transform="translate(291.795 178.548)"/>
                    <circle id="Ellipse_10545" cx="1.226" cy="1.226" r="1.226" class="cls-1" transform="translate(289.785 171.006)"/>
                    <path id="Path_48307" d="M24.091 16.532a1.148 1.148 0 1 1-1.154 1.154 1.153 1.153 0 0 1 1.154-1.154z" class="cls-1" transform="translate(263.479 147.408)"/>
                    <path id="Path_48308" d="M23.6 17.064a1.026 1.026 0 1 1-1.032 1.019 1.027 1.027 0 0 1 1.032-1.019z" class="cls-1" transform="translate(259.316 140.588)"/>
                    <path id="Path_48309" d="M23.042 17.518a.927.927 0 1 1-.933.921.93.93 0 0 1 .933-.921z" class="cls-1" transform="translate(254.137 134.754)"/>
                    <path id="Path_48310" d="M22.482 17.875a.909.909 0 1 1-.909.909.9.9 0 0 1 .909-.909z" class="cls-1" transform="translate(248.09 130.05)"/>
                    <path id="Path_48311" d="M21.865 18.131a.884.884 0 1 1-.884.884.888.888 0 0 1 .884-.884z" class="cls-1" transform="translate(241.411 126.699)"/>
                    <circle id="Ellipse_10546" cx=".908" cy=".908" r=".908" class="cls-1" transform="translate(254.643 143.045)"/>
                    <path id="Path_48312" d="M20.614 18.3a.909.909 0 1 1-.909.909.907.907 0 0 1 .909-.909z" class="cls-1" transform="translate(227.016 124.392)"/>
                    <path id="Path_48313" d="M19.975 18.215a.909.909 0 1 1-.909.909.912.912 0 0 1 .909-.909z" class="cls-1" transform="translate(219.807 125.534)"/>
                    <path id="Path_48314" d="M19.406 18.011a.958.958 0 1 1-.958.958.959.959 0 0 1 .958-.958z" class="cls-1" transform="translate(212.835 128.145)"/>
                    <path id="Path_48315" d="M18.871 17.7a1 1 0 1 1-.995 1.007 1 1 0 0 1 .995-1.007z" class="cls-1" transform="translate(206.381 132.163)"/>
                    <path id="Path_48316" d="M18.423 17.295a1.056 1.056 0 1 1-1.056 1.056 1.064 1.064 0 0 1 1.056-1.056z" class="cls-1" transform="translate(200.639 137.458)"/>
                    <path id="Path_48317" d="M18.066 16.8a1.13 1.13 0 1 1-1.13 1.13 1.127 1.127 0 0 1 1.13-1.13z" class="cls-1" transform="translate(195.777 143.846)"/>
                    <path id="Path_48318" d="M17.8 16.243a1.2 1.2 0 1 1-1.2 1.2 1.206 1.206 0 0 1 1.2-1.2z" class="cls-1" transform="translate(191.975 151.136)"/>
                    <path id="Path_48319" d="M17.677 15.629a1.326 1.326 0 1 1-1.314 1.326 1.329 1.329 0 0 1 1.314-1.326z" class="cls-1" transform="translate(189.312 159.045)"/>
                    <path id="Path_48320" d="M17.573 14.994a1.32 1.32 0 1 1-1.326 1.314 1.318 1.318 0 0 1 1.326-1.314z" class="cls-1" transform="translate(188.003 167.492)"/>
                    <circle id="Ellipse_10547" cx="1.398" cy="1.398" r="1.398" class="cls-1" transform="translate(204.18 190.333)"/>
                    <path id="Path_48321" d="M17.7 13.711a1.351 1.351 0 1 1-1.339 1.351 1.347 1.347 0 0 1 1.339-1.351z" class="cls-1" transform="translate(189.289 184.471)"/>
                    <path id="Path_48322" d="M17.961 13.1a1.376 1.376 0 1 1-1.376 1.376 1.373 1.373 0 0 1 1.376-1.376z" class="cls-1" transform="translate(191.817 192.471)"/>
                    <path id="Path_48323" d="M18.359 12.545a1.449 1.449 0 1 1-1.449 1.449 1.452 1.452 0 0 1 1.449-1.449z" class="cls-1" transform="translate(195.483 199.761)"/>
                    <circle id="Ellipse_10548" cx="1.471" cy="1.471" r="1.471" class="cls-1" transform="translate(217.588 218.254)"/>
                    <path id="Path_48324" d="M19.322 11.653a1.492 1.492 0 1 1-1.486 1.5 1.489 1.489 0 0 1 1.486-1.5z" class="cls-1" transform="translate(205.93 211.522)"/>
                    <path id="Path_48325" d="M19.947 11.343a1.541 1.541 0 1 1-1.547 1.535 1.536 1.536 0 0 1 1.547-1.535z" class="cls-1" transform="translate(212.293 215.541)"/>
                    <path id="Path_48326" d="M20.516 11.147a1.5 1.5 0 1 1-1.5 1.5 1.494 1.494 0 0 1 1.5-1.5z" class="cls-1" transform="translate(219.265 218.231)"/>
                    <path id="Path_48327" d="M21.291 11.049a1.64 1.64 0 1 1-1.646 1.633 1.643 1.643 0 0 1 1.646-1.633z" class="cls-1" transform="translate(226.339 219.25)"/>
                    <path id="Path_48328" d="M22.026 11.07a1.738 1.738 0 1 1-1.744 1.744 1.743 1.743 0 0 1 1.744-1.744z" class="cls-1" transform="translate(233.525 218.774)"/>
                    <path id="Path_48329" d="M22.678 11.211a1.769 1.769 0 1 1-1.769 1.769 1.777 1.777 0 0 1 1.769-1.769z" class="cls-1" transform="translate(240.599 216.84)"/>
                    <path id="Path_48330" d="M23.294 11.463a1.793 1.793 0 1 1-1.794 1.793 1.793 1.793 0 0 1 1.794-1.793z" class="cls-1" transform="translate(247.278 213.444)"/>
                    <path id="Path_48331" d="M23.606 11.839a1.541 1.541 0 1 1-1.548 1.548 1.541 1.541 0 0 1 1.548-1.548z" class="cls-1" transform="translate(253.573 208.954)"/>
                    <path id="Path_48332" d="M24.389 12.257a1.885 1.885 0 1 1-1.889 1.891 1.882 1.882 0 0 1 1.889-1.891z" class="cls-1" transform="translate(258.526 202.714)"/>
                    <path id="Path_48333" d="M24.836 12.773a1.959 1.959 0 1 1-1.965 1.965 1.963 1.963 0 0 1 1.965-1.965z" class="cls-1" transform="translate(262.734 195.713)"/>
                    <path id="Path_48334" d="M25.094 13.356a1.941 1.941 0 1 1-1.941 1.944 1.945 1.945 0 0 1 1.941-1.944z" class="cls-1" transform="translate(265.916 188.007)"/>
                    <path id="Path_48335" d="M25.175 13.986a1.842 1.842 0 1 1-1.842 1.842 1.837 1.837 0 0 1 1.842-1.842z" class="cls-1" transform="translate(267.946 179.836)"/>
                    <path id="Path_48336" d="M25.908 14.633a1.793 1.793 0 1 1-1.793 1.793 1.793 1.793 0 0 1 1.793-1.793z" class="cls-1" transform="translate(276.769 171.341)"/>
                    <path id="Path_48337" d="M25.4 15.317a1.3 1.3 0 1 1-1.29 1.3 1.3 1.3 0 0 1 1.29-1.3z" class="cls-1" transform="translate(276.678 163.238)"/>
                    <path id="Path_48338" d="M25.129 15.958a1.154 1.154 0 1 1-1.154 1.154 1.161 1.161 0 0 1 1.154-1.154z" class="cls-1" transform="translate(275.189 155.02)"/>
                    <path id="Path_48339" d="M24.893 16.56a1.148 1.148 0 1 1-1.154 1.154 1.153 1.153 0 0 1 1.154-1.154z" class="cls-1" transform="translate(272.527 147.036)"/>
                    <circle id="Ellipse_10549" cx="1.078" cy="1.078" r="1.078" class="cls-1" transform="translate(292.375 156.801)"/>
                    <path id="Path_48340" d="M24.021 17.635a1.007 1.007 0 1 1-.995 1.007 1 1 0 0 1 .995-1.007z" class="cls-1" transform="translate(264.483 133.041)"/>
                    <path id="Path_48341" d="M23.469 18.083a.9.9 0 1 1-.909.9.9.9 0 0 1 .909-.9z" class="cls-1" transform="translate(259.225 127.299)"/>
                    <path id="Path_48342" d="M22.913 18.448a.884.884 0 1 1-.884.884.878.878 0 0 1 .884-.884z" class="cls-1" transform="translate(253.235 122.488)"/>
                    <path id="Path_48343" d="M22.376 18.724a.933.933 0 1 1-.933.933.933.933 0 0 1 .933-.933z" class="cls-1" transform="translate(246.624 118.724)"/>
                    <path id="Path_48344" d="M21.692 18.921a.86.86 0 0 1 0 1.719.86.86 0 0 1 0-1.719z" class="cls-1" transform="translate(239.73 116.255)"/>
                    <path id="Path_48345" d="M21.019 19.019a.835.835 0 0 1 0 1.67.835.835 0 0 1 0-1.67z" class="cls-1" transform="translate(232.555 115.003)"/>
                    <circle id="Ellipse_10550" cx=".858" cy=".858" r=".858" class="cls-1" transform="translate(244.791 134)"/>
                    <path id="Path_48346" d="M19.791 18.919a.878.878 0 1 1 0 1.756.878.878 0 1 1 0-1.756z" class="cls-1" transform="translate(218.013 116.245)"/>
                    <path id="Path_48347" d="M19.2 18.726a.909.909 0 1 1-.909.909.907.907 0 0 1 .909-.909z" class="cls-1" transform="translate(211.03 118.747)"/>
                    <path id="Path_48348" d="M18.638 18.444a.934.934 0 0 1 0 1.867.933.933 0 0 1 0-1.867z" class="cls-1" transform="translate(204.452 122.443)"/>
                    <path id="Path_48349" d="M18.172 18.075a1 1 0 1 1-1.007.995 1 1 0 0 1 1.007-.995z" class="cls-1" transform="translate(198.36 127.209)"/>
                    <path id="Path_48350" d="M17.767 17.63a1.075 1.075 0 1 1-1.081 1.081 1.082 1.082 0 0 1 1.081-1.081z" class="cls-1" transform="translate(192.956 132.972)"/>
                    <circle id="Ellipse_10551" cx="1.103" cy="1.103" r="1.103" class="cls-1" transform="translate(204.674 156.776)"/>
                    <path id="Path_48351" d="M17.1 16.56a1.148 1.148 0 1 1 0 2.3 1.148 1.148 0 0 1 0-2.3z" class="cls-1" transform="translate(184.709 147.036)"/>
                    <path id="Path_48352" d="M16.986 15.948a1.277 1.277 0 1 1-1.277 1.277 1.266 1.266 0 0 1 1.277-1.277z" class="cls-1" transform="translate(181.934 154.907)"/>
                    <circle id="Ellipse_10552" cx="1.398" cy="1.398" r="1.398" class="cls-1" transform="translate(195.753 178.462)"/>
                    <path id="Path_48353" d="M16.862 14.669a1.351 1.351 0 1 1-1.351 1.351 1.344 1.344 0 0 1 1.351-1.351z" class="cls-1" transform="translate(179.7 171.747)"/>
                    <circle id="Ellipse_10553" cx="1.373" cy="1.373" r="1.373" class="cls-1" transform="translate(195.777 194.302)"/>
                    <path id="Path_48354" d="M17.1 13.392a1.394 1.394 0 1 1-1.4 1.388 1.394 1.394 0 0 1 1.4-1.388z" class="cls-1" transform="translate(181.821 188.622)"/>
                    <circle id="Ellipse_10554" cx="1.471" cy="1.471" r="1.471" class="cls-1" transform="translate(200.341 209.317)"/>
                    <circle id="Ellipse_10555" cx="1.496" cy="1.496" r="1.496" class="cls-1" transform="translate(204.281 216.16)"/>
                    <circle id="Ellipse_10556" cx="1.471" cy="1.471" r="1.471" class="cls-1" transform="translate(209.25 222.384)"/>
                    <path id="Path_48355" d="M18.668 11.276a1.541 1.541 0 1 1-1.548 1.548 1.541 1.541 0 0 1 1.548-1.548z" class="cls-1" transform="translate(197.864 216.431)"/>
                    <path id="Path_48356" d="M19.2 10.912a1.541 1.541 0 1 1-1.548 1.535 1.536 1.536 0 0 1 1.548-1.535z" class="cls-1" transform="translate(203.888 221.266)"/>
                    <path id="Path_48357" d="M19.75 10.634a1.517 1.517 0 1 1-1.511 1.511 1.512 1.512 0 0 1 1.511-1.511z" class="cls-1" transform="translate(210.477 225.007)"/>
                    <path id="Path_48358" d="M20.457 10.435a1.621 1.621 0 1 1-1.609 1.621 1.62 1.62 0 0 1 1.609-1.621z" class="cls-1" transform="translate(217.347 227.442)"/>
                    <path id="Path_48359" d="M21.288 10.323a1.818 1.818 0 1 1-1.818 1.818 1.821 1.821 0 0 1 1.818-1.818z" class="cls-1" transform="translate(224.365 228.536)"/>
                    <path id="Path_48360" d="M21.967 10.319a1.867 1.867 0 1 1-1.855 1.867 1.866 1.866 0 0 1 1.855-1.867z" class="cls-1" transform="translate(231.608 228.491)"/>
                    <path id="Path_48361" d="M22.639 10.413a1.891 1.891 0 1 1-1.891 1.887 1.892 1.892 0 0 1 1.891-1.887z" class="cls-1" transform="translate(238.783 227.193)"/>
                    <circle id="Ellipse_10557" cx="1.937" cy="1.937" r="1.937" class="cls-1" transform="translate(267.062 235.22)"/>
                    <path id="Path_48362" d="M23.884 10.88a1.934 1.934 0 1 1-1.941 1.928 1.924 1.924 0 0 1 1.941-1.928z" class="cls-1" transform="translate(252.265 220.905)"/>
                    <path id="Path_48363" d="M24.349 11.25a1.861 1.861 0 1 1-1.867 1.867 1.866 1.866 0 0 1 1.867-1.867z" class="cls-1" transform="translate(258.345 216.138)"/>
                    <path id="Path_48364" d="M24.7 11.7a1.738 1.738 0 1 1-1.732 1.732A1.732 1.732 0 0 1 24.7 11.7z" class="cls-1" transform="translate(263.806 210.42)"/>
                    <circle id="Ellipse_10558" cx="1.937" cy="1.937" r="1.937" class="cls-1" transform="translate(291.516 215.719)"/>
                    <path id="Path_48365" d="M25.638 12.745a1.959 1.959 0 1 1-1.965 1.955 1.96 1.96 0 0 1 1.965-1.955z" class="cls-1" transform="translate(271.782 196.085)"/>
                    <path id="Path_48366" d="M25.852 13.348a1.934 1.934 0 1 1-1.941 1.928 1.924 1.924 0 0 1 1.941-1.928z" class="cls-1" transform="translate(274.467 188.125)"/>
                    <path id="Path_48367" d="M25.825 13.991a1.769 1.769 0 1 1-1.756 1.769 1.761 1.761 0 0 1 1.756-1.769z" class="cls-1" transform="translate(276.25 179.917)"/>
                    <path id="Path_48368" d="M26.515 14.643a1.67 1.67 0 1 1-1.67 1.67 1.662 1.662 0 0 1 1.67-1.67z" class="cls-1" transform="translate(285.004 171.454)"/>
                    <circle id="Ellipse_10559" cx="1.373" cy="1.373" r="1.373" class="cls-1" transform="translate(309.634 178.478)"/>
                    <path id="Path_48369" d="M25.922 15.959a1.2 1.2 0 1 1-1.2 1.2 1.206 1.206 0 0 1 1.2-1.2z" class="cls-1" transform="translate(283.572 154.908)"/>
                    <path id="Path_48370" d="M25.6 16.582a1.081 1.081 0 1 1 0 2.162 1.081 1.081 0 1 1 0-2.162z" class="cls-1" transform="translate(281.383 146.879)"/>
                    <path id="Path_48371" d="M25.257 17.17a1.007 1.007 0 1 1-1.007 1.007 1.012 1.012 0 0 1 1.007-1.007z" class="cls-1" transform="translate(278.292 139.217)"/>
                    <path id="Path_48372" d="M24.905 17.712a1 1 0 1 1-1.005 1.007 1 1 0 0 1 1.005-1.007z" class="cls-1" transform="translate(274.321 132.03)"/>
                    <path id="Path_48373" d="M24.441 18.207a.958.958 0 1 1-.958.958.959.959 0 0 1 .958-.958z" class="cls-1" transform="translate(269.639 125.542)"/>
                    <path id="Path_48374" d="M23.918 18.645a.909.909 0 1 1-.909.909.907.907 0 0 1 .909-.909z" class="cls-1" transform="translate(264.291 119.823)"/>
                    <path id="Path_48375" d="M23.365 19.017a.884.884 0 1 1-.884.884.881.881 0 0 1 .884-.884z" class="cls-1" transform="translate(258.334 114.931)"/>
                    <path id="Path_48376" d="M22.793 19.316a.878.878 0 1 1-.884.872.886.886 0 0 1 .884-.872z" class="cls-1" transform="translate(251.881 110.972)"/>
                    <path id="Path_48377" d="M22.165 19.541a.854.854 0 1 1-.86.847.849.849 0 0 1 .86-.847z" class="cls-1" transform="translate(245.067 108.033)"/>
                    <path id="Path_48378" d="M21.444 19.693a.765.765 0 0 1 .761.761.762.762 0 0 1-1.523 0 .765.765 0 0 1 .762-.761z" class="cls-1" transform="translate(238.049 106.21)"/>
                    <circle id="Ellipse_10560" cx=".76" cy=".76" r=".76" class="cls-1" transform="translate(250.839 125.138)"/>
                    <circle id="Ellipse_10561" cx=".76" cy=".76" r=".76" class="cls-1" transform="translate(242.911 125.392)"/>
                    <path id="Path_48379" d="M19.564 19.627a.8.8 0 1 1-.811.8.807.807 0 0 1 .811-.8z" class="cls-1" transform="translate(216.276 106.989)"/>
                    <path id="Path_48380" d="M19.012 19.437a.884.884 0 1 1-.884.884.888.888 0 0 1 .884-.884z" class="cls-1" transform="translate(209.224 109.353)"/>
                    <path id="Path_48381" d="M18.365 19.179a.835.835 0 1 1-.823.835.828.828 0 0 1 .823-.835z" class="cls-1" transform="translate(202.613 112.878)"/>
                    <path id="Path_48382" d="M17.892 18.839a.9.9 0 1 1-.909.9.9.9 0 0 1 .909-.9z" class="cls-1" transform="translate(196.307 117.258)"/>
                    <path id="Path_48383" d="M17.364 18.438a.884.884 0 1 1-.884.884.881.881 0 0 1 .884-.884z" class="cls-1" transform="translate(190.632 122.621)"/>
                    <path id="Path_48384" d="M17.006 17.966a.983.983 0 1 1-.983.983.985.985 0 0 1 .983-.983z" class="cls-1" transform="translate(185.476 128.694)"/>
                    <path id="Path_48385" d="M16.732 17.439a1.1 1.1 0 1 1-1.105 1.105 1.1 1.1 0 0 1 1.105-1.105z" class="cls-1" transform="translate(181.009 135.46)"/>
                    <path id="Path_48386" d="M16.438 16.874a1.13 1.13 0 1 1 0 2.26 1.13 1.13 0 0 1 0-2.26z" class="cls-1" transform="translate(177.41 142.903)"/>
                    <path id="Path_48387" d="M16.206 16.273a1.155 1.155 0 1 1-1.142 1.154 1.153 1.153 0 0 1 1.142-1.154z" class="cls-1" transform="translate(174.657 150.836)"/>
                    <path id="Path_48388" d="M16.28 15.629a1.394 1.394 0 1 1-1.4 1.4 1.4 1.4 0 0 1 1.4-1.4z" class="cls-1" transform="translate(172.581 158.91)"/>
                    <circle id="Ellipse_10562" cx="1.422" cy="1.422" r="1.422" class="cls-1" transform="translate(186.42 182.379)"/>
                    <path id="Path_48389" d="M16.152 14.346A1.351 1.351 0 1 1 14.8 15.7a1.347 1.347 0 0 1 1.352-1.354z" class="cls-1" transform="translate(171.69 176.037)"/>
                    <path id="Path_48390" d="M16.235 13.706a1.345 1.345 0 1 1-1.351 1.351 1.345 1.345 0 0 1 1.351-1.351z" class="cls-1" transform="translate(172.626 184.55)"/>
                    <path id="Path_48391" d="M16.432 13.077a1.4 1.4 0 1 1-1.388 1.4 1.4 1.4 0 0 1 1.388-1.4z" class="cls-1" transform="translate(174.431 192.793)"/>
                    <circle id="Ellipse_10563" cx="1.471" cy="1.471" r="1.471" class="cls-1" transform="translate(192.374 213.153)"/>
                    <path id="Path_48392" d="M17.116 11.906a1.517 1.517 0 1 1-1.523 1.523 1.512 1.512 0 0 1 1.523-1.523z" class="cls-1" transform="translate(180.625 208.113)"/>
                    <path id="Path_48393" d="M17.524 11.386a1.548 1.548 0 0 1 0 3.1 1.548 1.548 0 0 1 0-3.1z" class="cls-1" transform="translate(184.957 214.958)"/>
                    <path id="Path_48394" d="M17.973 10.922a1.548 1.548 0 1 1-1.548 1.548 1.549 1.549 0 0 1 1.548-1.548z" class="cls-1" transform="translate(190.023 221.121)"/>
                    <path id="Path_48395" d="M18.569 10.511a1.646 1.646 0 1 1-1.646 1.646 1.646 1.646 0 0 1 1.646-1.646z" class="cls-1" transform="translate(195.63 226.383)"/>
                    <path id="Path_48396" d="M19.267 10.163a1.812 1.812 0 1 1-1.805 1.818 1.814 1.814 0 0 1 1.805-1.818z" class="cls-1" transform="translate(201.711 230.674)"/>
                    <circle id="Ellipse_10564" cx="2.011" cy="2.011" r="2.011" class="cls-1" transform="translate(226.226 243.848)"/>
                    <path id="Path_48397" d="M20.782 9.692a2.131 2.131 0 1 1-2.137 2.137 2.139 2.139 0 0 1 2.137-2.137z" class="cls-1" transform="translate(215.057 236.291)"/>
                    <path id="Path_48398" d="M21.465 9.585a2.18 2.18 0 1 1-2.186 2.186 2.181 2.181 0 0 1 2.186-2.186z" class="cls-1" transform="translate(222.21 237.614)"/>
                    <path id="Path_48399" d="M22.11 9.564a2.18 2.18 0 1 1-2.186 2.186 2.183 2.183 0 0 1 2.186-2.186z" class="cls-1" transform="translate(229.487 237.893)"/>
                    <circle id="Ellipse_10565" cx="2.133" cy="2.133" r="2.133" class="cls-1" transform="translate(257.361 246.74)"/>
                    <path id="Path_48400" d="M23.406 9.768a2.2 2.2 0 1 1-2.211 2.211 2.207 2.207 0 0 1 2.211-2.211z" class="cls-1" transform="translate(243.826 235.134)"/>
                    <circle id="Ellipse_10566" cx="2.158" cy="2.158" r="2.158" class="cls-1" transform="translate(272.514 242.212)"/>
                    <circle id="Ellipse_10567" cx="2.133" cy="2.133" r="2.133" class="cls-1" transform="translate(279.57 238.568)"/>
                    <circle id="Ellipse_10568" cx="2.109" cy="2.109" r="2.109" class="cls-1" transform="translate(286.1 234.055)"/>
                    <path id="Path_48401" d="M25.344 11.115a1.934 1.934 0 1 1-1.944 1.928 1.934 1.934 0 0 1 1.944-1.928z" class="cls-1" transform="translate(268.736 217.784)"/>
                    <path id="Path_48402" d="M25.6 11.621a1.762 1.762 0 1 1-1.769 1.769 1.759 1.759 0 0 1 1.769-1.769z" class="cls-1" transform="translate(273.621 211.407)"/>
                    <path id="Path_48403" d="M26.137 12.146a1.959 1.959 0 1 1-1.965 1.954 1.96 1.96 0 0 1 1.965-1.954z" class="cls-1" transform="translate(277.412 204.041)"/>
                    <circle id="Ellipse_10569" cx="1.961" cy="1.961" r="1.961" class="cls-1" transform="translate(305.03 209.035)"/>
                    <path id="Path_48404" d="M26.621 13.341a1.959 1.959 0 1 1-1.965 1.965 1.953 1.953 0 0 1 1.965-1.965z" class="cls-1" transform="translate(282.872 188.169)"/>
                    <path id="Path_48405" d="M26.654 13.983a1.861 1.861 0 1 1-1.867 1.867 1.866 1.866 0 0 1 1.867-1.867z" class="cls-1" transform="translate(284.35 179.839)"/>
                    <path id="Path_48406" d="M27.213 14.645a1.646 1.646 0 1 1-1.646 1.646 1.643 1.643 0 0 1 1.646-1.646z" class="cls-1" transform="translate(293.15 171.476)"/>
                    <path id="Path_48407" d="M27.007 15.3a1.474 1.474 0 1 1-1.462 1.474 1.47 1.47 0 0 1 1.462-1.474z" class="cls-1" transform="translate(292.902 163.067)"/>
                    <path id="Path_48408" d="M26.8 15.951a1.345 1.345 0 1 1-1.351 1.339 1.344 1.344 0 0 1 1.351-1.339z" class="cls-1" transform="translate(291.785 154.732)"/>
                    <path id="Path_48409" d="M26.449 16.586a1.173 1.173 0 1 1 0 2.346 1.173 1.173 0 0 1 0-2.346z" class="cls-1" transform="translate(289.935 146.642)"/>
                    <path id="Path_48410" d="M26.055 17.2a1.007 1.007 0 1 1-1.007 1 1.012 1.012 0 0 1 1.007-1z" class="cls-1" transform="translate(287.295 138.871)"/>
                    <path id="Path_48411" d="M25.675 17.768a.927.927 0 1 1-.933.933.933.933 0 0 1 .933-.933z" class="cls-1" transform="translate(283.842 131.434)"/>
                    <path id="Path_48412" d="M25.189 18.3a.811.811 0 1 1-.811.811.81.81 0 0 1 .811-.811z" class="cls-1" transform="translate(279.736 124.548)"/>
                    <circle id="Ellipse_10570" cx=".834" cy=".834" r=".834" class="cls-1" transform="translate(298.804 136.91)"/>
                    <path id="Path_48413" d="M24.231 19.22a.761.761 0 1 1-.761.761.765.765 0 0 1 .761-.761z" class="cls-1" transform="translate(269.492 112.48)"/>
                    <path id="Path_48414" d="M23.772 19.588a.835.835 0 0 1 0 1.67.835.835 0 0 1 0-1.67z" class="cls-1" transform="translate(263.479 107.445)"/>
                    <path id="Path_48415" d="M23.207 19.9a.829.829 0 1 1 0 1.658.829.829 0 1 1 0-1.658z" class="cls-1" transform="translate(257.104 103.3)"/>
                    <path id="Path_48416" d="M22.565 20.152a.792.792 0 0 1 .786.786.786.786 0 1 1-1.572 0 .792.792 0 0 1 .786-.786z" class="cls-1" transform="translate(250.414 100.053)"/>
                    <path id="Path_48417" d="M21.854 20.339a.682.682 0 1 1-.688.688.687.687 0 0 1 .688-.688z" class="cls-1" transform="translate(243.499 97.778)"/>
                    <circle id="Ellipse_10571" cx=".662" cy=".662" r=".662" class="cls-1" transform="translate(256.874 116.807)"/>
                    <path id="Path_48418" d="M20.573 20.483a.688.688 0 0 1 0 1.376.688.688 0 1 1 0-1.376z" class="cls-1" transform="translate(229.047 95.853)"/>
                    <circle id="Ellipse_10572" cx=".687" cy=".687" r=".687" class="cls-1" transform="translate(241.007 116.783)"/>
                    <circle id="Ellipse_10573" cx=".736" cy=".736" r=".736" class="cls-1" transform="translate(233.137 118.063)"/>
                    <circle id="Ellipse_10574" cx=".76" cy=".76" r=".76" class="cls-1" transform="translate(225.489 120.234)"/>
                    <path id="Path_48419" d="M18.129 19.907a.755.755 0 1 1-.749.761.75.75 0 0 1 .749-.761z" class="cls-1" transform="translate(200.786 103.368)"/>
                    <path id="Path_48420" d="M17.621 19.59a.811.811 0 1 1-.811.811.81.81 0 0 1 .811-.811z" class="cls-1" transform="translate(194.355 107.468)"/>
                    <path id="Path_48421" d="M17.161 19.21a.884.884 0 0 1 0 1.769.884.884 0 1 1 0-1.769z" class="cls-1" transform="translate(188.342 112.368)"/>
                    <circle id="Ellipse_10575" cx=".932" cy=".932" r=".932" class="cls-1" transform="translate(198.66 136.812)"/>
                    <path id="Path_48422" d="M16.34 18.29a.983.983 0 1 1-.983.983.985.985 0 0 1 .983-.983z" class="cls-1" transform="translate(177.963 124.39)"/>
                    <path id="Path_48423" d="M16 17.76a1.026 1.026 0 1 1-1.019 1.032A1.022 1.022 0 0 1 16 17.76z" class="cls-1" transform="translate(173.709 131.344)"/>
                    <path id="Path_48424" d="M15.744 17.19a1.081 1.081 0 0 1 0 2.162 1.081 1.081 0 1 1 0-2.162z" class="cls-1" transform="translate(170.133 138.804)"/>
                    <path id="Path_48425" d="M15.519 16.591a1.105 1.105 0 1 1-1.105 1.109 1.109 1.109 0 0 1 1.105-1.109z" class="cls-1" transform="translate(167.324 146.711)"/>
                    <path id="Path_48426" d="M15.5 15.957a1.271 1.271 0 1 1-1.277 1.265 1.274 1.274 0 0 1 1.277-1.265z" class="cls-1" transform="translate(165.146 154.8)"/>
                    <circle id="Ellipse_10576" cx="1.52" cy="1.52" r="1.52" class="cls-1" transform="translate(177.797 178.326)"/>
                    <path id="Path_48427" d="M15.625 14.651a1.572 1.572 0 1 1-1.572 1.572 1.573 1.573 0 0 1 1.572-1.572z" class="cls-1" transform="translate(163.251 171.544)"/>
                    <path id="Path_48428" d="M15.458 14.024a1.351 1.351 0 1 1-1.351 1.351 1.355 1.355 0 0 1 1.351-1.351z" class="cls-1" transform="translate(163.86 180.314)"/>
                    <circle id="Ellipse_10577" cx="1.349" cy="1.349" r="1.349" class="cls-1" transform="translate(179.297 202.161)"/>
                    <circle id="Ellipse_10578" cx="1.422" cy="1.422" r="1.422" class="cls-1" transform="translate(181.42 209.71)"/>
                    <circle id="Ellipse_10579" cx="1.52" cy="1.52" r="1.52" class="cls-1" transform="translate(184.357 216.941)"/>
                    <path id="Path_48429" d="M16.473 11.589a1.541 1.541 0 1 1-1.535 1.535 1.538 1.538 0 0 1 1.535-1.535z" class="cls-1" transform="translate(173.235 212.274)"/>
                    <path id="Path_48430" d="M16.858 11.062a1.541 1.541 0 1 1-1.547 1.538 1.538 1.538 0 0 1 1.547-1.538z" class="cls-1" transform="translate(177.444 219.274)"/>
                    <path id="Path_48431" d="M17.357 10.574a1.621 1.621 0 1 1-1.621 1.626 1.617 1.617 0 0 1 1.621-1.626z" class="cls-1" transform="translate(182.238 225.596)"/>
                    <path id="Path_48432" d="M17.872 10.14a1.664 1.664 0 1 1-1.658 1.66 1.662 1.662 0 0 1 1.658-1.66z" class="cls-1" transform="translate(187.631 231.274)"/>
                    <path id="Path_48433" d="M18.455 9.762a1.719 1.719 0 1 1-1.719 1.719 1.725 1.725 0 0 1 1.719-1.719z" class="cls-1" transform="translate(193.52 236.184)"/>
                    <circle id="Ellipse_10580" cx="1.937" cy="1.937" r="1.937" class="cls-1" transform="translate(216.984 249.568)"/>
                    <circle id="Ellipse_10581" cx="2.109" cy="2.109" r="2.109" class="cls-1" transform="translate(224.141 252.432)"/>
                    <circle id="Ellipse_10582" cx="2.182" cy="2.182" r="2.182" class="cls-1" transform="translate(231.69 254.554)"/>
                    <path id="Path_48434" d="M21.349 8.873a2.235 2.235 0 1 1-2.235 2.235 2.233 2.233 0 0 1 2.235-2.235z" class="cls-1" transform="translate(220.348 246.96)"/>
                    <path id="Path_48435" d="M22.107 8.827a2.358 2.358 0 1 1-2.358 2.358 2.356 2.356 0 0 1 2.358-2.358z" class="cls-1" transform="translate(227.512 247.325)"/>
                    <path id="Path_48436" d="M22.662 8.871a2.26 2.26 0 1 1-2.26 2.26 2.251 2.251 0 0 1 2.26-2.26z" class="cls-1" transform="translate(234.879 246.937)"/>
                    <path id="Path_48437" d="M23.241 8.984a2.2 2.2 0 1 1-2.2 2.211 2.2 2.2 0 0 1 2.2-2.211z" class="cls-1" transform="translate(242.111 245.547)"/>
                    <path id="Path_48438" d="M23.851 9.164a2.186 2.186 0 1 1-2.186 2.186 2.191 2.191 0 0 1 2.186-2.186z" class="cls-1" transform="translate(249.128 243.193)"/>
                    <circle id="Ellipse_10583" cx="2.06" cy="2.06" r="2.06" class="cls-1" transform="translate(278.249 249.445)"/>
                    <circle id="Ellipse_10584" cx="2.109" cy="2.109" r="2.109" class="cls-1" transform="translate(285.145 245.559)"/>
                    <path id="Path_48439" d="M25.472 10.1a2.106 2.106 0 1 1-2.112 2.1 2.11 2.11 0 0 1 2.112-2.1z" class="cls-1" transform="translate(268.251 230.868)"/>
                    <circle id="Ellipse_10585" cx="2.011" cy="2.011" r="2.011" class="cls-1" transform="translate(297.628 235.78)"/>
                    <path id="Path_48440" d="M26.249 11.028a1.959 1.959 0 1 1-1.965 1.953 1.96 1.96 0 0 1 1.965-1.953z" class="cls-1" transform="translate(278.675 218.89)"/>
                    <path id="Path_48441" d="M26.533 11.563a1.861 1.861 0 1 1-1.867 1.855 1.853 1.853 0 0 1 1.867-1.855z" class="cls-1" transform="translate(282.985 211.981)"/>
                    <circle id="Ellipse_10586" cx="1.986" cy="1.986" r="1.986" class="cls-1" transform="translate(311.366 216.476)"/>
                    <path id="Path_48442" d="M27.148 12.719a1.934 1.934 0 1 1-1.928 1.928 1.934 1.934 0 0 1 1.928-1.928z" class="cls-1" transform="translate(289.235 196.48)"/>
                    <path id="Path_48443" d="M27.316 13.341a1.916 1.916 0 1 1-1.916 1.916 1.918 1.918 0 0 1 1.916-1.916z" class="cls-1" transform="translate(291.266 188.255)"/>
                    <path id="Path_48444" d="M27.39 13.98a1.891 1.891 0 1 1-1.879 1.891 1.892 1.892 0 0 1 1.879-1.891z" class="cls-1" transform="translate(292.518 179.817)"/>
                    <path id="Path_48445" d="M27.91 14.647a1.621 1.621 0 1 1-1.621 1.621 1.617 1.617 0 0 1 1.621-1.621z" class="cls-1" transform="translate(301.295 171.499)"/>
                    <path id="Path_48446" d="M27.776 15.3a1.523 1.523 0 1 1-1.511 1.523 1.523 1.523 0 0 1 1.511-1.523z" class="cls-1" transform="translate(301.025 163.022)"/>
                    <path id="Path_48447" d="M27.533 15.953a1.351 1.351 0 1 1-1.351 1.347 1.347 1.347 0 0 1 1.351-1.347z" class="cls-1" transform="translate(300.088 154.693)"/>
                    <path id="Path_48448" d="M27.306 16.585a1.277 1.277 0 1 1-1.277 1.277 1.284 1.284 0 0 1 1.277-1.277z" class="cls-1" transform="translate(298.362 146.446)"/>
                    <path id="Path_48449" d="M26.927 17.206a1.105 1.105 0 1 1-1.105 1.105 1.109 1.109 0 0 1 1.105-1.105z" class="cls-1" transform="translate(296.027 138.542)"/>
                    <path id="Path_48450" d="M26.522 17.8a.983.983 0 1 1-.97.983.978.978 0 0 1 .97-.983z" class="cls-1" transform="translate(292.981 130.925)"/>
                    <path id="Path_48451" d="M26.107 18.357a.884.884 0 1 1-.884.884.888.888 0 0 1 .884-.884z" class="cls-1" transform="translate(289.269 123.697)"/>
                    <circle id="Ellipse_10587" cx=".834" cy=".834" r=".834" class="cls-1" transform="translate(309.747 135.777)"/>
                    <circle id="Ellipse_10588" cx=".711" cy=".711" r=".711" class="cls-1" transform="translate(304.474 130.083)"/>
                    <circle id="Ellipse_10589" cx=".662" cy=".662" r=".662" class="cls-1" transform="translate(298.575 124.883)"/>
                    <path id="Path_48452" d="M24.11 20.164a.712.712 0 1 1-.712.712.713.713 0 0 1 .712-.712z" class="cls-1" transform="translate(268.68 100.041)"/>
                    <circle id="Ellipse_10590" cx=".687" cy=".687" r=".687" class="cls-1" transform="translate(285.237 116.26)"/>
                    <circle id="Ellipse_10591" cx=".736" cy=".736" r=".736" class="cls-1" transform="translate(277.956 112.947)"/>
                    <circle id="Ellipse_10592" cx=".662" cy=".662" r=".662" class="cls-1" transform="translate(270.508 110.493)"/>
                    <circle id="Ellipse_10593" cx=".637" cy=".637" r=".637" class="cls-1" transform="translate(262.798 108.753)"/>
                    <circle id="Ellipse_10594" cx=".662" cy=".662" r=".662" class="cls-1" transform="translate(254.901 107.742)"/>
                    <path id="Path_48453" d="M20.388 21.2a.663.663 0 1 1-.663.663.66.66 0 0 1 .663-.663z" class="cls-1" transform="translate(227.242 86.339)"/>
                    <circle id="Ellipse_10595" cx=".613" cy=".613" r=".613" class="cls-1" transform="translate(239.106 108.186)"/>
                    <circle id="Ellipse_10596" cx=".662" cy=".662" r=".662" class="cls-1" transform="translate(231.243 109.514)"/>
                    <path id="Path_48454" d="M18.576 20.86a.755.755 0 1 1-.761.761.757.757 0 0 1 .761-.761z" class="cls-1" transform="translate(205.693 90.71)"/>
                    <path id="Path_48455" d="M17.941 20.626a.731.731 0 1 1-.725.725.721.721 0 0 1 .725-.725z" class="cls-1" transform="translate(198.935 93.868)"/>
                    <path id="Path_48456" d="M17.4 20.329a.761.761 0 1 1-.761.761.755.755 0 0 1 .761-.761z" class="cls-1" transform="translate(192.426 97.751)"/>
                    <circle id="Ellipse_10597" cx=".785" cy=".785" r=".785" class="cls-1" transform="translate(202.372 122.364)"/>
                    <path id="Path_48457" d="M16.42 19.57a.829.829 0 1 1 0 1.658.829.829 0 1 1 0-1.658z" class="cls-1" transform="translate(180.535 107.697)"/>
                    <path id="Path_48458" d="M16.014 19.113a.9.9 0 1 1-.9.909.907.907 0 0 1 .9-.909z" class="cls-1" transform="translate(175.255 113.619)"/>
                    <path id="Path_48459" d="M15.61 18.618a.909.909 0 1 1-.909.909.915.915 0 0 1 .909-.909z" class="cls-1" transform="translate(170.562 120.181)"/>
                    <path id="Path_48460" d="M15.291 18.08a.958.958 0 1 1-.958.958.959.959 0 0 1 .958-.958z" class="cls-1" transform="translate(166.41 127.229)"/>
                    <path id="Path_48461" d="M15.072 17.505a1.05 1.05 0 1 1-1.056 1.056 1.048 1.048 0 0 1 1.056-1.056z" class="cls-1" transform="translate(162.834 134.681)"/>
                    <path id="Path_48462" d="M14.833 16.907a1.081 1.081 0 1 1-1.069 1.081 1.075 1.075 0 0 1 1.069-1.081z" class="cls-1" transform="translate(159.991 142.563)"/>
                    <path id="Path_48463" d="M14.721 16.284a1.154 1.154 0 1 1-1.154 1.154 1.153 1.153 0 0 1 1.154-1.154z" class="cls-1" transform="translate(157.768 150.69)"/>
                    <path id="Path_48464" d="M14.751 15.637a1.326 1.326 0 1 1-1.326 1.326 1.329 1.329 0 0 1 1.326-1.326z" class="cls-1" transform="translate(156.166 158.939)"/>
                    <path id="Path_48465" d="M14.845 14.98a1.5 1.5 0 1 1-1.5 1.5 1.494 1.494 0 0 1 1.5-1.5z" class="cls-1" transform="translate(155.286 167.321)"/>
                    <circle id="Ellipse_10598" cx="1.471" cy="1.471" r="1.471" class="cls-1" transform="translate(168.656 190.263)"/>
                    <path id="Path_48466" d="M14.729 13.707a1.3 1.3 0 1 1-1.3 1.3 1.3 1.3 0 0 1 1.3-1.3z" class="cls-1" transform="translate(156.189 184.622)"/>
                    <circle id="Ellipse_10599" cx="1.299" cy="1.299" r="1.299" class="cls-1" transform="translate(171.19 206.106)"/>
                    <path id="Path_48467" d="M15.216 12.441a1.492 1.492 0 1 1-1.486 1.486 1.486 1.486 0 0 1 1.486-1.486z" class="cls-1" transform="translate(159.607 201.056)"/>
                    <path id="Path_48468" d="M15.467 11.846a1.492 1.492 0 1 1-1.486 1.5 1.489 1.489 0 0 1 1.486-1.5z" class="cls-1" transform="translate(162.439 208.959)"/>
                    <path id="Path_48469" d="M15.787 11.278a1.5 1.5 0 1 1-1.5 1.5 1.5 1.5 0 0 1 1.5-1.5z" class="cls-1" transform="translate(165.914 216.491)"/>
                    <path id="Path_48470" d="M16.264 10.734a1.621 1.621 0 1 1-1.621 1.621 1.62 1.62 0 0 1 1.621-1.621z" class="cls-1" transform="translate(169.907 223.47)"/>
                    <path id="Path_48471" d="M16.645 10.242a1.591 1.591 0 1 1-1.584 1.6 1.593 1.593 0 0 1 1.584-1.6z" class="cls-1" transform="translate(174.623 230.066)"/>
                    <path id="Path_48472" d="M17.187 9.785a1.664 1.664 0 1 1-1.67 1.67 1.672 1.672 0 0 1 1.67-1.67z" class="cls-1" transform="translate(179.768 235.989)"/>
                    <path id="Path_48473" d="M17.805 9.372a1.787 1.787 0 1 1-1.793 1.781 1.793 1.793 0 0 1 1.793-1.781z" class="cls-1" transform="translate(185.352 241.229)"/>
                    <path id="Path_48474" d="M18.529 9a1.99 1.99 0 1 1-1.99 1.99A1.987 1.987 0 0 1 18.529 9z" class="cls-1" transform="translate(191.298 245.698)"/>
                    <circle id="Ellipse_10600" cx="2.133" cy="2.133" r="2.133" class="cls-1" transform="translate(214.749 258.177)"/>
                    <path id="Path_48475" d="M19.975 8.451a2.278 2.278 0 1 1-2.284 2.284 2.277 2.277 0 0 1 2.284-2.284z" class="cls-1" transform="translate(204.294 252.479)"/>
                    <path id="Path_48476" d="M20.53 8.282a2.2 2.2 0 1 1-2.211 2.211 2.2 2.2 0 0 1 2.211-2.211z" class="cls-1" transform="translate(211.379 254.871)"/>
                    <path id="Path_48477" d="M21.346 8.154a2.4 2.4 0 1 1-2.407 2.407 2.411 2.411 0 0 1 2.407-2.407z" class="cls-1" transform="translate(218.374 256.178)"/>
                    <path id="Path_48478" d="M22.1 8.095a2.53 2.53 0 1 1-2.53 2.53 2.534 2.534 0 0 1 2.53-2.53z" class="cls-1" transform="translate(225.527 256.703)"/>
                    <path id="Path_48479" d="M22.7 8.115a2.481 2.481 0 1 1-2.477 2.485A2.49 2.49 0 0 1 22.7 8.115z" class="cls-1" transform="translate(232.86 256.536)"/>
                    <circle id="Ellipse_10601" cx="2.33" cy="2.33" r="2.33" class="cls-1" transform="translate(261.105 263.815)"/>
                    <path id="Path_48480" d="M23.682 8.365a2.162 2.162 0 1 1-2.162 2.162 2.154 2.154 0 0 1 2.162-2.162z" class="cls-1" transform="translate(247.492 253.854)"/>
                    <path id="Path_48481" d="M24.248 8.575a2.112 2.112 0 1 1-2.112 2.112 2.112 2.112 0 0 1 2.112-2.112z" class="cls-1" transform="translate(254.442 251.163)"/>
                    <circle id="Ellipse_10602" cx="2.133" cy="2.133" r="2.133" class="cls-1" transform="translate(283.79 256.455)"/>
                    <path id="Path_48482" d="M25.363 9.166a2.082 2.082 0 1 1-2.076 2.076 2.084 2.084 0 0 1 2.076-2.076z" class="cls-1" transform="translate(267.427 243.375)"/>
                    <circle id="Ellipse_10603" cx="2.109" cy="2.109" r="2.109" class="cls-1" transform="translate(297.128 247.881)"/>
                    <circle id="Ellipse_10604" cx="2.109" cy="2.109" r="2.109" class="cls-1" transform="translate(303.076 242.632)"/>
                    <circle id="Ellipse_10605" cx="2.109" cy="2.109" r="2.109" class="cls-1" transform="translate(308.473 236.816)"/>
                    <path id="Path_48483" d="M27.078 10.971a1.934 1.934 0 1 1-1.941 1.929 1.924 1.924 0 0 1 1.941-1.929z" class="cls-1" transform="translate(288.299 219.696)"/>
                    <path id="Path_48484" d="M27.4 11.522a1.941 1.941 0 1 1-1.928 1.941 1.937 1.937 0 0 1 1.928-1.941z" class="cls-1" transform="translate(292.101 212.366)"/>
                    <circle id="Ellipse_10606" cx="1.986" cy="1.986" r="1.986" class="cls-1" transform="translate(320.966 216.695)"/>
                    <path id="Path_48485" d="M27.916 12.711a1.941 1.941 0 1 1-1.941 1.941 1.934 1.934 0 0 1 1.941-1.941z" class="cls-1" transform="translate(297.753 196.574)"/>
                    <path id="Path_48486" d="M28.075 13.337a1.941 1.941 0 1 1-1.941 1.941 1.945 1.945 0 0 1 1.941-1.941z" class="cls-1" transform="translate(299.547 188.259)"/>
                    <path id="Path_48487" d="M28.092 13.982a1.861 1.861 0 1 1-1.855 1.855 1.856 1.856 0 0 1 1.855-1.855z" class="cls-1" transform="translate(300.709 179.852)"/>
                    <path id="Path_48488" d="M28.608 14.649a1.6 1.6 0 1 1-1.6 1.6 1.591 1.591 0 0 1 1.6-1.6z" class="cls-1" transform="translate(309.441 171.521)"/>
                    <circle id="Ellipse_10607" cx="1.496" cy="1.496" r="1.496" class="cls-1" transform="translate(336.193 178.344)"/>
                    <circle id="Ellipse_10608" cx="1.422" cy="1.422" r="1.422" class="cls-1" transform="translate(335.2 170.555)"/>
                    <path id="Path_48489" d="M28.032 16.593a1.247 1.247 0 1 1-1.253 1.253 1.25 1.25 0 0 1 1.253-1.253z" class="cls-1" transform="translate(306.823 146.401)"/>
                    <path id="Path_48490" d="M27.73 17.215a1.155 1.155 0 1 1-1.142 1.154 1.153 1.153 0 0 1 1.142-1.154z" class="cls-1" transform="translate(304.669 138.324)"/>
                    <path id="Path_48491" d="M27.376 17.819a1.032 1.032 0 1 1-1.032 1.032 1.027 1.027 0 0 1 1.032-1.032z" class="cls-1" transform="translate(301.916 130.548)"/>
                    <path id="Path_48492" d="M26.967 18.4a.933.933 0 1 1-.921.933.933.933 0 0 1 .921-.933z" class="cls-1" transform="translate(298.554 123.081)"/>
                    <circle id="Ellipse_10609" cx=".809" cy=".809" r=".809" class="cls-1" transform="translate(320.347 134.981)"/>
                    <circle id="Ellipse_10610" cx=".662" cy=".662" r=".662" class="cls-1" transform="translate(315.547 128.925)"/>
                    <path id="Path_48493" d="M25.525 19.929a.663.663 0 1 1-.663.663.66.66 0 0 1 .663-.663z" class="cls-1" transform="translate(285.196 103.26)"/>
                    <path id="Path_48494" d="M25.039 20.354a.663.663 0 0 1 0 1.326.663.663 0 0 1 0-1.326z" class="cls-1" transform="translate(279.713 97.615)"/>
                    <circle id="Ellipse_10611" cx=".613" cy=".613" r=".613" class="cls-1" transform="translate(297.717 113.354)"/>
                    <path id="Path_48495" d="M23.882 21.071a.582.582 0 0 1 .59.59.583.583 0 1 1-1.167 0 .579.579 0 0 1 .577-.59z" class="cls-1" transform="translate(267.63 88.24)"/>
                    <path id="Path_48496" d="M23.4 21.344a.682.682 0 1 1 0 1.363.682.682 0 1 1 0-1.363z" class="cls-1" transform="translate(260.963 84.429)"/>
                    <circle id="Ellipse_10612" cx=".711" cy=".711" r=".711" class="cls-1" transform="translate(276.23 102.955)"/>
                    <circle id="Ellipse_10613" cx=".662" cy=".662" r=".662" class="cls-1" transform="translate(268.63 100.894)"/>
                    <circle id="Ellipse_10614" cx=".662" cy=".662" r=".662" class="cls-1" transform="translate(260.823 99.477)"/>
                    <circle id="Ellipse_10615" cx=".662" cy=".662" r=".662" class="cls-1" transform="translate(252.921 98.765)"/>
                    <circle id="Ellipse_10616" cx=".687" cy=".687" r=".687" class="cls-1" transform="translate(244.961 98.741)"/>
                    <circle id="Ellipse_10617" cx=".662" cy=".662" r=".662" class="cls-1" transform="translate(237.083 99.477)"/>
                    <path id="Path_48497" d="M18.981 21.74a.712.712 0 1 1 0 1.425.712.712 0 0 1 0-1.425z" class="cls-1" transform="translate(210.951 79.108)"/>
                    <circle id="Ellipse_10618" cx=".711" cy=".711" r=".711" class="cls-1" transform="translate(221.577 102.955)"/>
                    <circle id="Ellipse_10619" cx=".687" cy=".687" r=".687" class="cls-1" transform="translate(214.174 105.767)"/>
                    <path id="Path_48498" d="M17.206 21.059a.737.737 0 1 1-.737.737.739.739 0 0 1 .737-.737z" class="cls-1" transform="translate(190.508 88.104)"/>
                    <circle id="Ellipse_10620" cx=".785" cy=".785" r=".785" class="cls-1" transform="translate(200.115 113.182)"/>
                    <path id="Path_48499" d="M16.184 20.342a.811.811 0 1 1-.8.811.81.81 0 0 1 .8-.811z" class="cls-1" transform="translate(178.29 97.48)"/>
                    <circle id="Ellipse_10621" cx=".76" cy=".76" r=".76" class="cls-1" transform="translate(187.745 123.091)"/>
                    <path id="Path_48500" d="M15.251 19.45a.811.811 0 1 1-.8.811.81.81 0 0 1 .8-.811z" class="cls-1" transform="translate(167.764 109.327)"/>
                    <path id="Path_48501" d="M14.928 18.939a.884.884 0 1 1-.884.884.888.888 0 0 1 .884-.884z" class="cls-1" transform="translate(163.149 115.967)"/>
                    <path id="Path_48502" d="M14.595 18.4a.909.909 0 1 1-.909.909.907.907 0 0 1 .909-.909z" class="cls-1" transform="translate(159.111 123.103)"/>
                    <path id="Path_48503" d="M14.357 17.823a.983.983 0 0 1 0 1.965.983.983 0 1 1 0-1.965z" class="cls-1" transform="translate(155.591 130.593)"/>
                    <path id="Path_48504" d="M14.148 17.225a1.032 1.032 0 1 1 0 2.063 1.032 1.032 0 0 1 0-2.063z" class="cls-1" transform="translate(152.68 138.437)"/>
                    <path id="Path_48505" d="M14.015 16.6a1.1 1.1 0 1 1-1.105 1.11 1.1 1.1 0 0 1 1.105-1.11z" class="cls-1" transform="translate(150.356 146.537)"/>
                    <path id="Path_48506" d="M13.984 15.965a1.222 1.222 0 1 1-1.228 1.216 1.221 1.221 0 0 1 1.228-1.216z" class="cls-1" transform="translate(148.619 154.792)"/>
                    <path id="Path_48507" d="M14.011 15.315a1.345 1.345 0 1 1-1.351 1.351 1.345 1.345 0 0 1 1.351-1.351z" class="cls-1" transform="translate(147.535 163.179)"/>
                    <path id="Path_48508" d="M14.14 14.655a1.523 1.523 0 1 1-1.523 1.523 1.52 1.52 0 0 1 1.523-1.523z" class="cls-1" transform="translate(147.05 171.589)"/>
                    <path id="Path_48509" d="M13.988 14.026a1.32 1.32 0 1 1-1.326 1.314 1.316 1.316 0 0 1 1.326-1.314z" class="cls-1" transform="translate(147.558 180.348)"/>
                    <path id="Path_48510" d="M14.074 13.385a1.326 1.326 0 1 1 0 2.653 1.326 1.326 0 1 1 0-2.653z" class="cls-1" transform="translate(148.528 188.85)"/>
                    <circle id="Ellipse_10622" cx="1.422" cy="1.422" r="1.422" class="cls-1" transform="translate(162.95 209.87)"/>
                    <circle id="Ellipse_10623" cx="1.447" cy="1.447" r="1.447" class="cls-1" transform="translate(165.378 217.392)"/>
                    <circle id="Ellipse_10624" cx="1.471" cy="1.471" r="1.471" class="cls-1" transform="translate(168.472 224.664)"/>
                    <circle id="Ellipse_10625" cx="1.52" cy="1.52" r="1.52" class="cls-1" transform="translate(172.182 231.602)"/>
                    <path id="Path_48511" d="M15.605 10.415a1.621 1.621 0 1 1-1.621 1.621 1.617 1.617 0 0 1 1.621-1.621z" class="cls-1" transform="translate(162.473 227.707)"/>
                    <path id="Path_48512" d="M16.018 9.908a1.646 1.646 0 1 1-1.633 1.646 1.646 1.646 0 0 1 1.633-1.646z" class="cls-1" transform="translate(166.997 234.392)"/>
                    <path id="Path_48513" d="M16.612 9.429a1.793 1.793 0 1 1-1.793 1.793 1.8 1.8 0 0 1 1.793-1.793z" class="cls-1" transform="translate(171.893 240.459)"/>
                    <path id="Path_48514" d="M17.177 9a1.885 1.885 0 1 1-1.877 1.875A1.882 1.882 0 0 1 17.177 9z" class="cls-1" transform="translate(177.297 246.026)"/>
                    <path id="Path_48515" d="M17.8 8.608a1.99 1.99 0 1 1-1.99 1.99 2 2 0 0 1 1.99-1.99z" class="cls-1" transform="translate(183.096 250.971)"/>
                    <circle id="Ellipse_10626" cx="1.986" cy="1.986" r="1.986" class="cls-1" transform="translate(205.725 263.651)"/>
                    <circle id="Ellipse_10627" cx="2.158" cy="2.158" r="2.158" class="cls-1" transform="translate(212.703 266.922)"/>
                    <path id="Path_48516" d="M19.724 7.754a2.18 2.18 0 1 1-2.186 2.186 2.181 2.181 0 0 1 2.186-2.186z" class="cls-1" transform="translate(202.568 261.933)"/>
                    <circle id="Ellipse_10628" cx="2.182" cy="2.182" r="2.182" class="cls-1" transform="translate(227.755 271.797)"/>
                    <path id="Path_48517" d="M21.343 7.434a2.579 2.579 0 1 1-2.579 2.579 2.579 2.579 0 0 1 2.579-2.579z" class="cls-1" transform="translate(216.4 265.384)"/>
                    <path id="Path_48518" d="M22.01 7.375a2.6 2.6 0 1 1-2.6 2.6 2.6 2.6 0 0 1 2.6-2.6z" class="cls-1" transform="translate(223.643 266.131)"/>
                    <path id="Path_48519" d="M22.633 7.377a2.573 2.573 0 1 1-2.579 2.579 2.576 2.576 0 0 1 2.579-2.579z" class="cls-1" transform="translate(230.953 266.154)"/>
                    <path id="Path_48520" d="M23.141 7.447a2.426 2.426 0 1 1-2.432 2.432 2.437 2.437 0 0 1 2.432-2.432z" class="cls-1" transform="translate(238.343 265.519)"/>
                    <path id="Path_48521" d="M23.709 7.568a2.352 2.352 0 1 1-2.358 2.358 2.348 2.348 0 0 1 2.358-2.358z" class="cls-1" transform="translate(245.586 264.059)"/>
                    <path id="Path_48522" d="M24.287 7.744a2.3 2.3 0 1 1-2.309 2.309 2.3 2.3 0 0 1 2.309-2.309z" class="cls-1" transform="translate(252.659 261.82)"/>
                    <path id="Path_48523" d="M24.812 7.977a2.229 2.229 0 1 1-2.223 2.235 2.228 2.228 0 0 1 2.223-2.235z" class="cls-1" transform="translate(259.553 258.872)"/>
                    <circle id="Ellipse_10629" cx="2.133" cy="2.133" r="2.133" class="cls-1" transform="translate(289.385 263.504)"/>
                    <path id="Path_48524" d="M25.847 8.6a2.112 2.112 0 1 1-2.112 2.112A2.112 2.112 0 0 1 25.847 8.6z" class="cls-1" transform="translate(272.482 250.858)"/>
                    <circle id="Ellipse_10630" cx="2.109" cy="2.109" r="2.109" class="cls-1" transform="translate(302.641 254.795)"/>
                    <circle id="Ellipse_10631" cx="2.084" cy="2.084" r="2.084" class="cls-1" transform="translate(308.641 249.6)"/>
                    <circle id="Ellipse_10632" cx="2.158" cy="2.158" r="2.158" class="cls-1" transform="translate(314.051 243.79)"/>
                    <circle id="Ellipse_10633" cx="2.084" cy="2.084" r="2.084" class="cls-1" transform="translate(319.072 237.661)"/>
                    <circle id="Ellipse_10634" cx="1.937" cy="1.937" r="1.937" class="cls-1" transform="translate(323.59 231.186)"/>
                    <path id="Path_48525" d="M28.143 11.5a1.867 1.867 0 1 1-1.867 1.867 1.863 1.863 0 0 1 1.867-1.867z" class="cls-1" transform="translate(301.149 212.765)"/>
                    <path id="Path_48526" d="M28.452 12.091a1.941 1.941 0 1 1-1.928 1.941 1.937 1.937 0 0 1 1.928-1.941z" class="cls-1" transform="translate(303.947 204.808)"/>
                    <circle id="Ellipse_10635" cx="1.961" cy="1.961" r="1.961" class="cls-1" transform="translate(332.896 209.331)"/>
                    <path id="Path_48527" d="M28.807 13.336a1.934 1.934 0 1 1-1.94 1.941 1.937 1.937 0 0 1 1.94-1.941z" class="cls-1" transform="translate(307.816 188.285)"/>
                    <path id="Path_48528" d="M28.782 13.986a1.812 1.812 0 1 1-1.818 1.805 1.808 1.808 0 0 1 1.818-1.805z" class="cls-1" transform="translate(308.911 179.897)"/>
                    <path id="Path_48529" d="M29.305 14.651a1.572 1.572 0 1 1-1.572 1.572 1.573 1.573 0 0 1 1.572-1.572z" class="cls-1" fill="${widget.color1}" transform="translate(317.586 171.544)"/>
                    <circle id="Ellipse_10636" cx="1.447" cy="1.447" r="1.447" class="cls-1" fill="${widget.color1}" transform="translate(345.117 178.392)"/>
                    <path id="Path_48530" d="M29.03 15.952a1.4 1.4 0 1 1-1.388 1.4 1.4 1.4 0 0 1 1.388-1.4z" fill="${widget.color1}" class="cls-1" transform="translate(316.56 154.608)"/>
                    <circle id="Ellipse_10637" fill="${widget.color1}" cx="1.324" cy="1.324" r="1.324" class="cls-1" transform="translate(342.663 162.868)"/>
                    <circle id="Ellipse_10638" cx="1.25" cy="1.25" r="1.25" class="cls-1" fill="${widget.color1}" transform="translate(340.501 155.328)"/>
                    <path id="Path_48531" d="M28.192 17.834a1.075 1.075 0 1 1-1.069 1.081 1.075 1.075 0 0 1 1.069-1.081z" class="cls-1" transform="translate(310.704 130.263)"/>
                    <path id="Path_48532" d="M27.787 18.428a.927.927 0 1 1-.933.933.933.933 0 0 1 .933-.933z" class="cls-1" transform="translate(307.67 122.668)"/>
                    <path id="Path_48533" d="M27.3 19a.761.761 0 1 1 0 1.523.761.761 0 1 1 0-1.523z" class="cls-1" transform="translate(304.138 115.416)"/>
                    <circle id="Ellipse_10639" cx=".637" cy=".637" r=".637" class="cls-1" transform="translate(326.249 128.045)"/>
                    <circle id="Ellipse_10640" cx=".662" cy=".662" r=".662" class="cls-1" transform="translate(321.151 121.919)"/>
                    <circle id="Ellipse_10641" cx=".637" cy=".637" r=".637" class="cls-1" transform="translate(315.623 116.276)"/>
                    <circle id="Ellipse_10642" cx=".637" cy=".637" r=".637" class="cls-1" transform="translate(309.626 111.079)"/>
                    <path id="Path_48534" d="M24.91 21.3a.614.614 0 1 1-.6.614.608.608 0 0 1 .6-.614z" class="cls-1" transform="translate(278.946 85.109)"/>
                    <circle id="Ellipse_10643" cx=".588" cy=".588" r=".588" class="cls-1" transform="translate(296.513 102.285)"/>
                    <path id="Path_48535" d="M23.818 21.931a.642.642 0 0 1 .639.639.65.65 0 0 1-.639.639.642.642 0 0 1-.639-.639.634.634 0 0 1 .639-.639z" class="cls-1" transform="translate(266.209 76.719)"/>
                    <path id="Path_48536" d="M23.22 22.176a.633.633 0 1 1-.639.639.632.632 0 0 1 .639-.639z" class="cls-1" transform="translate(259.462 73.477)"/>
                    <path id="Path_48537" d="M22.591 22.37a.639.639 0 1 1-.626.639.634.634 0 0 1 .626-.639z" class="cls-1" transform="translate(252.513 70.888)"/>
                    <path id="Path_48538" d="M22 22.512a.663.663 0 1 1-.663.663.658.658 0 0 1 .663-.663z" class="cls-1" transform="translate(245.383 68.953)"/>
                    <circle id="Ellipse_10644" cx=".637" cy=".637" r=".637" class="cls-1" transform="translate(258.882 90.363)"/>
                    <circle id="Ellipse_10645" cx=".662" cy=".662" r=".662" class="cls-1" transform="translate(250.937 89.854)"/>
                    <path id="Path_48539" d="M20.043 22.632a.639.639 0 0 1 0 1.277.639.639 0 0 1 0-1.277z" class="cls-1" transform="translate(223.62 67.408)"/>
                    <path id="Path_48540" d="M19.411 22.564a.66.66 0 0 1 .663.663.657.657 0 1 1-1.314 0 .658.658 0 0 1 .651-.663z" class="cls-1" transform="translate(216.355 68.262)"/>
                    <path id="Path_48541" d="M18.832 22.443a.713.713 0 0 1 .712.712.712.712 0 0 1-1.425 0 .713.713 0 0 1 .713-.712z" class="cls-1" transform="translate(209.134 69.784)"/>
                    <path id="Path_48542" d="M18.254 22.269a.761.761 0 1 1-.761.761.765.765 0 0 1 .761-.761z" class="cls-1" transform="translate(202.06 71.984)"/>
                    <circle id="Ellipse_10646" cx=".711" cy=".711" r=".711" class="cls-1" transform="translate(212.139 97.001)"/>
                    <path id="Path_48543" d="M17.013 21.785a.712.712 0 1 1-.712.712.713.713 0 0 1 .712-.712z" class="cls-1" transform="translate(188.613 78.511)"/>
                    <circle id="Ellipse_10647" cx=".736" cy=".736" r=".736" class="cls-1" transform="translate(197.971 104.146)"/>
                    <path id="Path_48544" d="M16.026 21.1a.835.835 0 1 1 0 1.67.835.835 0 1 1 0-1.67z" class="cls-1" transform="translate(176.09 87.376)"/>
                    <path id="Path_48545" d="M15.589 20.691a.9.9 0 1 1-.909.9.9.9 0 0 1 .909-.9z" class="cls-1" transform="translate(170.325 92.66)"/>
                    <path id="Path_48546" d="M15.016 20.256a.811.811 0 0 1 0 1.621.811.811 0 0 1 0-1.621z" class="cls-1" transform="translate(165.113 98.622)"/>
                    <path id="Path_48547" d="M14.618 19.774a.835.835 0 0 1 0 1.67.835.835 0 1 1 0-1.67z" class="cls-1" transform="translate(160.205 104.975)"/>
                    <path id="Path_48548" d="M14.27 19.257a.884.884 0 1 1-.884.884.881.881 0 0 1 .884-.884z" class="cls-1" transform="translate(155.726 111.743)"/>
                    <circle id="Ellipse_10648" cx=".908" cy=".908" r=".908" class="cls-1" transform="translate(164.8 137.652)"/>
                    <path id="Path_48549" d="M13.685 18.137a.958.958 0 1 1-.958.958.959.959 0 0 1 .958-.958z" class="cls-1" transform="translate(148.291 126.472)"/>
                    <path id="Path_48550" d="M13.452 17.542a.983.983 0 1 1-.983.983.975.975 0 0 1 .983-.983z" class="cls-1" transform="translate(145.381 134.325)"/>
                    <path id="Path_48551" fill="${widget.color1}" d="M13.3 16.924a1.056 1.056 0 1 1-1.044 1.056 1.048 1.048 0 0 1 1.044-1.056z" class="cls-1" transform="translate(142.978 142.386)"/>
                    <path id="Path_48552" fill="${widget.color1}" d="M13.268 16.288a1.173 1.173 0 1 1-1.179 1.179 1.179 1.179 0 0 1 1.179-1.179z" class="cls-1" transform="translate(141.094 150.6)"/>
                    <path id="Path_48553" fill="${widget.color1}" d="M13.186 15.648a1.2 1.2 0 1 1-1.2 1.2 1.206 1.206 0 0 1 1.2-1.2z" class="cls-1" transform="translate(139.886 159.039)"/>
                    <path id="Path_48554" fill="${widget.color1}" d="M13.336 14.986a1.425 1.425 0 1 1-1.425 1.425 1.426 1.426 0 0 1 1.425-1.425z" class="cls-1" transform="translate(139.085 167.389)"/>
                    <path id="Path_48555" fill="${widget.color1}" d="M13.4 14.334a1.5 1.5 0 1 1-1.5 1.5 1.5 1.5 0 0 1 1.5-1.5z" class="cls-1" transform="translate(139.018 175.902)"/>
                    <circle id="Ellipse_10649" fill="${widget.color1}" cx="1.349" cy="1.349" r="1.349" class="cls-1" transform="translate(151.722 198.295)"/>
                    <circle id="Ellipse_10650" fill="${widget.color1}" cx="1.373" cy="1.373" r="1.373" class="cls-1" transform="translate(152.987 206.1)"/>
                    <circle id="Ellipse_10651" fill="${widget.color1}" cx="1.447" cy="1.447" r="1.447" class="cls-1" transform="translate(154.837 213.726)"/>
                    <path id="Path_48556" fill="${widget.color1}" d="M13.9 11.816a1.468 1.468 0 1 1-1.474 1.462 1.457 1.457 0 0 1 1.474-1.462z" class="cls-1" transform="translate(144.929 209.407)"/>
                    <circle id="Ellipse_10652" fill="${widget.color1}" cx="1.496" cy="1.496" r="1.496" class="cls-1" transform="translate(160.48 228.476)"/>
                    <circle id="Ellipse_10653" fill="${widget.color1}" cx="1.545" cy="1.545" r="1.545" class="cls-1" transform="translate(164.162 235.43)"/>
                    <circle id="Ellipse_10654" cx="1.619" cy="1.619" fill="${widget.color1}" r="1.619" class="cls-1" transform="translate(168.379 242.032)"/>
                    <path id="Path_48557" fill="${widget.color1}" d="M15.363 9.582a1.64 1.64 0 1 1-1.646 1.633 1.641 1.641 0 0 1 1.646-1.633z" class="cls-1" transform="translate(159.46 238.734)"/>
                    <path id="Path_48558" fill="${widget.color1}" d="M15.919 9.09a1.793 1.793 0 1 1-1.781 1.793 1.787 1.787 0 0 1 1.781-1.793z" class="cls-1" transform="translate(164.21 244.962)"/>
                    <path id="Path_48559" fill="${widget.color1}" d="M16.649 8.626a2.057 2.057 0 1 1-2.063 2.063 2.06 2.06 0 0 1 2.063-2.063z" class="cls-1" transform="translate(169.264 250.596)"/>
                    <circle id="Ellipse_10655" fill="${widget.color1}" cx="1.986" cy="1.986" r="1.986" class="cls-1" transform="translate(190.134 264.242)"/>
                    <circle id="Ellipse_10656" cx="2.207" cy="2.207" fill="${widget.color1}" r="2.207" class="cls-1" transform="translate(196.499 268.446)"/>
                    <path id="Path_48560" fill="${widget.color1}" d="M18.491 7.525a2.327 2.327 0 1 1-2.321 2.321 2.322 2.322 0 0 1 2.321-2.321z" class="cls-1" transform="translate(187.135 264.679)"/>
                    <path id="Path_48561" fill="${widget.color1}" d="M19.136 7.253a2.377 2.377 0 1 1-2.383 2.37 2.382 2.382 0 0 1 2.383-2.37z" class="cls-1" transform="translate(193.712 268.194)"/>
                    <path id="Path_48562" fill="${widget.color1}" d="M19.744 7.033A2.377 2.377 0 1 1 17.361 9.4a2.364 2.364 0 0 1 2.383-2.367z" class="cls-1" transform="translate(200.571 271.116)"/>
                    <path id="Path_48563" fill="${widget.color1}" d="M20.536 6.848a2.573 2.573 0 1 1-2.567 2.579 2.579 2.579 0 0 1 2.567-2.579z" class="cls-1" transform="translate(207.431 273.18)"/>
                    <path id="Path_48564" fill="${widget.color1}" d="M21.239 6.724A2.647 2.647 0 1 1 18.6 9.365a2.639 2.639 0 0 1 2.639-2.641z" class="cls-1" transform="translate(214.527 274.679)"/>
                    <path id="Path_48565" fill="${widget.color1}" d="M21.949 6.652a2.72 2.72 0 1 1-2.714 2.714 2.718 2.718 0 0 1 2.714-2.714z" class="cls-1" transform="translate(221.713 275.488)"/>
                    <circle id="Ellipse_10657" fill="${widget.color1}" cx="2.673" cy="2.673" r="2.673" class="cls-1" transform="translate(248.927 282.347)"/>
                    <path id="Path_48566" fill="${widget.color1}" d="M23.116 6.69a2.579 2.579 0 1 1-2.579 2.579 2.579 2.579 0 0 1 2.579-2.579z" class="cls-1" transform="translate(236.402 275.266)"/>
                    <path id="Path_48567" fill="${widget.color1}" d="M23.734 6.784a2.555 2.555 0 1 1-2.555 2.555 2.55 2.55 0 0 1 2.555-2.555z" class="cls-1" transform="translate(243.645 274.067)"/>
                    <path id="Path_48568" fill="${widget.color1}" d="M24.284 6.934A2.475 2.475 0 1 1 21.815 9.4a2.471 2.471 0 0 1 2.469-2.466z" class="cls-1" transform="translate(250.821 272.234)"/>
                    <path id="Path_48569" fill="${widget.color1}" d="M24.889 7.131a2.45 2.45 0 1 1-2.456 2.444 2.443 2.443 0 0 1 2.456-2.444z" class="cls-1" transform="translate(257.793 269.667)"/>
                    <path id="Path_48570" fill="${widget.color1}" d="M25.329 7.389a2.278 2.278 0 1 1-2.284 2.272 2.275 2.275 0 0 1 2.284-2.272z" class="cls-1" transform="translate(264.697 266.584)"/>
                    <circle id="Ellipse_10658" cx="2.158" fill="${widget.color1}" cy="2.158" r="2.158" class="cls-1" transform="translate(294.943 270.503)"/>
                    <path id="Path_48571" fill="${widget.color1}" d="M26.354 8.027a2.186 2.186 0 1 1-2.174 2.186 2.183 2.183 0 0 1 2.174-2.186z" class="cls-1" transform="translate(277.502 258.294)"/>
                    <path id="Path_48572" fill="${widget.color1}" d="M26.842 8.413A2.137 2.137 0 1 1 24.7 10.55a2.128 2.128 0 0 1 2.142-2.137z" class="cls-1" transform="translate(283.425 253.266)"/>
                    <path id="Path_48573" fill="${widget.color1}" d="M27.24 8.844a2.039 2.039 0 1 1-2.04 2.039 2.05 2.05 0 0 1 2.04-2.039z" class="cls-1" transform="translate(289.021 247.738)"/>
                    <path id="Path_48574" fill="${widget.color1}" d="M27.624 9.312a1.959 1.959 0 1 1-1.965 1.965 1.963 1.963 0 0 1 1.965-1.965z" class="cls-1" transform="translate(294.188 241.682)"/>
                    <path id="Path_48575" fill="${widget.color1}" d="M28.082 9.8a2.014 2.014 0 1 1-2.014 2.014A2.008 2.008 0 0 1 28.082 9.8z" class="cls-1" transform="translate(298.802 235.036)"/>
                    <path id="Path_48576" fill="${widget.color1}" d="M28.51 10.327a2.088 2.088 0 1 1-2.076 2.088 2.086 2.086 0 0 1 2.076-2.088z" class="cls-1" transform="translate(302.931 227.943)"/>
                    <circle id="Ellipse_10659" fill="${widget.color1}" cx="1.937" cy="1.937" r="1.937" class="cls-1" transform="translate(333.523 231.575)"/>
                    <path id="Path_48577" fill="${widget.color1}" d="M28.981 11.479a1.934 1.934 0 1 1-1.928 1.941 1.929 1.929 0 0 1 1.928-1.941z" class="cls-1" transform="translate(309.915 212.949)"/>
                    <path id="Path_48578" fill="${widget.color1}" d="M29.213 12.082a1.934 1.934 0 1 1-1.928 1.941 1.929 1.929 0 0 1 1.928-1.941z" class="cls-1" transform="translate(312.532 204.94)"/>
                    <path id="Path_48579" fill="${widget.color1}" d="M29.4 12.7a1.934 1.934 0 1 1-1.928 1.941A1.929 1.929 0 0 1 29.4 12.7z" class="cls-1" transform="translate(314.585 196.705)"/>
                    <path id="Path_48580" fill="${widget.color1}" d="M29.459 13.34a1.867 1.867 0 1 1-1.859 1.867 1.866 1.866 0 0 1 1.859-1.867z" class="cls-1" transform="translate(316.131 188.367)"/>
                    <circle id="Ellipse_10660" fill="${widget.color1}" cx="1.692" cy="1.692" r="1.692" class="cls-1" transform="translate(344.871 194.004)"/>
                    <path id="Path_48581" d="M30.025 14.651a1.572 1.572 0 1 1-1.572 1.572 1.573 1.573 0 0 1 1.572-1.572z" class="cls-1" transform="translate(325.709 171.544)"/>
                    <circle id="Ellipse_10661" cx="1.496" cy="1.496" r="1.496" class="cls-1" transform="translate(353.937 178.342)"/>
                    <path id="Path_48582" d="M29.77 15.953a1.394 1.394 0 1 1-1.4 1.388 1.389 1.389 0 0 1 1.4-1.388z" class="cls-1" transform="translate(324.773 154.607)"/>
                    <circle id="Ellipse_10662" cx="1.349" cy="1.349" r="1.349" class="cls-1" transform="translate(351.721 162.807)"/>
                    <path id="Path_48583" d="M29.37 17.222a1.271 1.271 0 1 1-1.277 1.265 1.274 1.274 0 0 1 1.277-1.265z" class="cls-1" transform="translate(321.648 137.998)"/>
                    <path id="Path_48584" d="M29.055 17.84a1.173 1.173 0 1 1-1.167 1.167 1.177 1.177 0 0 1 1.167-1.167z" class="cls-1" transform="translate(319.335 129.986)"/>
                    <path id="Path_48585" d="M28.7 18.442a1.056 1.056 0 1 1-1.061 1.058 1.064 1.064 0 0 1 1.061-1.058z" class="cls-1" transform="translate(316.526 122.224)"/>
                    <path id="Path_48586" d="M28.258 19.025a.909.909 0 1 1-.909.909.907.907 0 0 1 .909-.909z" class="cls-1" transform="translate(313.254 114.776)"/>
                    <path id="Path_48587" d="M27.688 19.592a.663.663 0 0 1 0 1.326.663.663 0 1 1 0-1.326z" class="cls-1" transform="translate(309.599 107.736)"/>
                    <circle id="Ellipse_10663" cx=".613" cy=".613" r=".613" class="cls-1" transform="translate(331.966 120.993)"/>
                    <path id="Path_48588" d="M26.883 20.6a.668.668 0 0 1 .663.663.663.663 0 1 1-1.326 0 .668.668 0 0 1 .663-.663z" class="cls-1" transform="translate(300.517 94.321)"/>
                    <path id="Path_48589" d="M26.4 21.061a.633.633 0 1 1 0 1.265.633.633 0 1 1 0-1.265z" class="cls-1" transform="translate(295.384 88.286)"/>
                    <circle id="Ellipse_10664" cx=".588" cy=".588" r=".588" class="cls-1" transform="translate(315.188 104.215)"/>
                    <circle id="Ellipse_10665" cx=".662" cy=".662" r=".662" class="cls-1" transform="translate(308.729 99.429)"/>
                    <path id="Path_48590" d="M24.87 22.207a.668.668 0 0 1 .663.663.677.677 0 0 1-.663.663.668.668 0 0 1-.663-.663.66.66 0 0 1 .663-.663z" class="cls-1" transform="translate(277.807 73.004)"/>
                    <path id="Path_48591" d="M24.276 22.511a.634.634 0 0 1 .639.639.642.642 0 0 1-.639.639.65.65 0 0 1-.639-.639.642.642 0 0 1 .639-.639z" class="cls-1" transform="translate(271.376 69.016)"/>
                    <circle id="Ellipse_10666" cx=".637" cy=".637" r=".637" class="cls-1" transform="translate(287.746 88.35)"/>
                    <path id="Path_48592" d="M23.074 22.983a.639.639 0 1 1 0 1.277.639.639 0 1 1 0-1.277z" class="cls-1" transform="translate(257.815 62.747)"/>
                    <circle id="Ellipse_10667" cx=".637" cy=".637" r=".637" class="cls-1" transform="translate(272.59 83.676)"/>
                    <path id="Path_48593" d="M21.815 23.27a.634.634 0 0 1 .639.639.642.642 0 0 1-.639.639.65.65 0 0 1-.639-.639.642.642 0 0 1 .639-.639z" class="cls-1" transform="translate(243.611 58.935)"/>
                    <path id="Path_48594" d="M21.173 23.343a.642.642 0 0 1 .639.639.634.634 0 0 1-.639.639.642.642 0 0 1-.639-.639.65.65 0 0 1 .639-.639z" class="cls-1" transform="translate(236.368 57.965)"/>
                    <path id="Path_48595" d="M20.528 23.367a.639.639 0 0 1 0 1.277.639.639 0 0 1 0-1.277z" class="cls-1" transform="translate(229.092 57.646)"/>
                    <circle id="Ellipse_10668" cx=".662" cy=".662" r=".662" class="cls-1" transform="translate(241.023 81.287)"/>
                    <path id="Path_48596" d="M19.24 23.27a.634.634 0 0 1 .639.639.639.639 0 1 1-1.277 0 .634.634 0 0 1 .638-.639z" class="cls-1" transform="translate(214.561 58.935)"/>
                    <circle id="Ellipse_10669" cx=".613" cy=".613" r=".613" class="cls-1" transform="translate(225.39 83.701)"/>
                    <circle id="Ellipse_10670" cx=".662" cy=".662" r=".662" class="cls-1" transform="translate(217.676 85.705)"/>
                    <circle id="Ellipse_10671" cx=".687" cy=".687" r=".687" class="cls-1" transform="translate(210.16 88.301)"/>
                    <circle id="Ellipse_10672" cx=".662" cy=".662" r=".662" class="cls-1" transform="translate(202.912 91.5)"/>
                    <path id="Path_48597" d="M16.23 22.207a.668.668 0 0 1 .663.663.677.677 0 0 1-.663.663.668.668 0 0 1-.663-.663.66.66 0 0 1 .663-.663z" class="cls-1" transform="translate(180.332 73.004)"/>
                    <circle id="Ellipse_10673" cx=".711" cy=".711" r=".711" class="cls-1" transform="translate(189.128 99.38)"/>
                    <circle id="Ellipse_10674" cx=".834" cy=".834" r=".834" class="cls-1" transform="translate(182.62 103.969)"/>
                    <path id="Path_48598" d="M14.831 21.045a.829.829 0 1 1-.835.823.833.833 0 0 1 .835-.823z" class="cls-1" transform="translate(162.608 88.106)"/>
                    <path id="Path_48599" d="M14.352 20.59a.811.811 0 1 1-.811.811.818.818 0 0 1 .811-.811z" class="cls-1" transform="translate(157.475 94.186)"/>
                    <circle id="Ellipse_10675" cx=".858" cy=".858" r=".858" class="cls-1" transform="translate(165.792 120.747)"/>
                    <path id="Path_48600" d="M13.614 19.574a.884.884 0 1 1-.884.884.881.881 0 0 1 .884-.884z" class="cls-1" transform="translate(148.325 107.533)"/>
                    <path id="Path_48601" d="M13.293 19.025a.909.909 0 1 1-.909.909.907.907 0 0 1 .909-.909z" class="cls-1" transform="translate(144.422 114.776)"/>
                    <path id="Path_48602" d="M13.036 18.45a.958.958 0 1 1-.958.958.959.959 0 0 1 .958-.958z" class="cls-1" transform="translate(140.969 122.314)"/>
                    <circle id="Ellipse_10676" cx="1.006" cy="1.006" r="1.006" class="cls-1" transform="translate(149.83 147.993)"/>
                    <path id="Path_48603" d="M12.666 17.238a1.075 1.075 0 1 1-1.066 1.069 1.072 1.072 0 0 1 1.066-1.069z" class="cls-1" transform="translate(135.543 138.179)"/>
                    <path id="Path_48604" d="M12.6 16.606a1.173 1.173 0 1 1-1.179 1.167 1.169 1.169 0 0 1 1.179-1.167z" class="cls-1" transform="translate(133.557 146.376)"/>
                    <path id="Path_48605" d="M12.525 15.967A1.228 1.228 0 1 1 11.3 17.2a1.232 1.232 0 0 1 1.225-1.233z" class="cls-1" transform="translate(132.158 154.753)"/>
                    <circle id="Ellipse_10677" cx="1.299" cy="1.299" r="1.299" class="cls-1" transform="translate(142.497 178.538)"/>
                    <path id="Path_48606" d="M12.5 14.673a1.3 1.3 0 1 1-1.3 1.3 1.3 1.3 0 0 1 1.3-1.3z" class="cls-1" transform="translate(131.008 171.792)"/>
                    <circle id="Ellipse_10678" cx="1.299" cy="1.299" r="1.299" class="cls-1" transform="translate(142.497 194.398)"/>
                    <path id="Path_48607" d="M12.638 13.381a1.351 1.351 0 1 1-1.351 1.351 1.347 1.347 0 0 1 1.351-1.351z" class="cls-1" transform="translate(132.046 188.854)"/>
                    <circle id="Ellipse_10679" cx="1.422" cy="1.422" r="1.422" class="cls-1" transform="translate(144.739 209.958)"/>
                    <circle id="Ellipse_10680" cx="1.545" cy="1.545" r="1.545" class="cls-1" transform="translate(146.669 217.5)"/>
                    <circle id="Ellipse_10681" cx="1.619" cy="1.619" r="1.619" class="cls-1" transform="translate(149.217 224.917)"/>
                    <circle id="Ellipse_10682" cx="1.52" cy="1.52" r="1.52" class="cls-1" transform="translate(152.489 232.288)"/>
                    <path id="Path_48608" d="M13.88 10.333a1.548 1.548 0 1 1-1.548 1.548 1.549 1.549 0 0 1 1.548-1.548z" class="cls-1" transform="translate(143.835 228.944)"/>
                    <path id="Path_48609" d="M14.224 9.786a1.548 1.548 0 1 1 0 3.1 1.548 1.548 0 1 1 0-3.1z" class="cls-1" transform="translate(147.716 236.209)"/>
                    <path id="Path_48610" d="M14.788 9.25a1.744 1.744 0 1 1-1.744 1.744 1.74 1.74 0 0 1 1.744-1.744z" class="cls-1" transform="translate(151.868 242.935)"/>
                    <path id="Path_48611" d="M15.367 8.746a1.916 1.916 0 1 1-1.916 1.916 1.918 1.918 0 0 1 1.916-1.916z" class="cls-1" transform="translate(156.459 249.285)"/>
                    <path id="Path_48612" d="M15.914 8.282A2.008 2.008 0 1 1 13.9 10.3a2.015 2.015 0 0 1 2.014-2.018z" class="cls-1" transform="translate(161.525 255.264)"/>
                    <path id="Path_48613" d="M16.359 7.864a1.965 1.965 0 1 1-1.965 1.965 1.96 1.96 0 0 1 1.965-1.965z" class="cls-1" transform="translate(167.098 260.901)"/>
                    <circle id="Ellipse_10683" cx="2.133" cy="2.133" r="2.133" class="cls-1" transform="translate(187.705 273.31)"/>
                    <path id="Path_48614" d="M17.674 7.115a2.229 2.229 0 1 1-2.235 2.235 2.225 2.225 0 0 1 2.235-2.235z" class="cls-1" transform="translate(178.888 270.321)"/>
                    <circle id="Ellipse_10684" cx="2.084" cy="2.084" r="2.084" class="cls-1" transform="translate(201.489 281.289)"/>
                    <path id="Path_48615" d="M18.928 6.546a2.334 2.334 0 1 1-2.334 2.334 2.333 2.333 0 0 1 2.334-2.334z" class="cls-1" transform="translate(191.918 277.67)"/>
                    <path id="Path_48616" d="M19.808 6.309a2.622 2.622 0 1 1-2.628 2.616 2.621 2.621 0 0 1 2.628-2.616z" class="cls-1" transform="translate(198.529 280.241)"/>
                    <path id="Path_48617" d="M20.5 6.136a2.7 2.7 0 1 1-2.7 2.69 2.7 2.7 0 0 1 2.7-2.69z" class="cls-1" transform="translate(205.501 282.391)"/>
                    <path id="Path_48618" d="M21.18 6.012a2.745 2.745 0 1 1-2.751 2.751 2.744 2.744 0 0 1 2.751-2.751z" class="cls-1" transform="translate(212.62 283.94)"/>
                    <path id="Path_48619" d="M21.912 5.931a2.849 2.849 0 1 1-2.849 2.849 2.851 2.851 0 0 1 2.849-2.849z" class="cls-1" transform="translate(219.773 284.807)"/>
                    <path id="Path_48620" d="M22.513 5.911a2.8 2.8 0 1 1-2.8 2.8 2.8 2.8 0 0 1 2.8-2.8z" class="cls-1" transform="translate(227.106 285.171)"/>
                    <circle id="Ellipse_10685" cx="2.722" cy="2.722" r="2.722" class="cls-1" transform="translate(254.823 290.864)"/>
                    <path id="Path_48621" d="M23.608 6.024a2.6 2.6 0 1 1-2.591 2.6 2.605 2.605 0 0 1 2.591-2.6z" class="cls-1" transform="translate(241.818 284.075)"/>
                    <path id="Path_48622" d="M24.153 6.152a2.5 2.5 0 1 1-2.493 2.493 2.5 2.5 0 0 1 2.493-2.493z" class="cls-1" transform="translate(249.072 282.571)"/>
                    <path id="Path_48623" d="M24.687 6.327a2.4 2.4 0 1 1-2.395 2.395 2.4 2.4 0 0 1 2.395-2.395z" class="cls-1" transform="translate(256.202 280.444)"/>
                    <circle id="Ellipse_10686" cx="2.232" cy="2.232" r="2.232" class="cls-1" transform="translate(286.152 284.315)"/>
                    <path id="Path_48624" d="M25.731 6.813a2.229 2.229 0 1 1-2.223 2.223 2.225 2.225 0 0 1 2.223-2.223z" class="cls-1" transform="translate(269.921 274.333)"/>
                    <path id="Path_48625" d="M26.292 7.117a2.2 2.2 0 1 1-2.211 2.211 2.2 2.2 0 0 1 2.211-2.211z" class="cls-1" transform="translate(276.385 270.344)"/>
                    <path id="Path_48626" d="M26.771 7.467A2.131 2.131 0 1 1 24.634 9.6a2.128 2.128 0 0 1 2.137-2.133z" class="cls-1" transform="translate(282.624 265.843)"/>
                    <circle id="Ellipse_10687" cx="2.109" cy="2.109" r="2.109" class="cls-1" transform="translate(313.668 268.623)"/>
                    <path id="Path_48627" d="M27.678 8.28a2.033 2.033 0 1 1-2.027 2.039 2.034 2.034 0 0 1 2.027-2.039z" class="cls-1" transform="translate(294.109 255.241)"/>
                    <circle id="Ellipse_10688" cx="2.011" cy="2.011" r="2.011" class="cls-1" transform="translate(325.392 257.933)"/>
                    <path id="Path_48628" d="M28.456 9.236a1.916 1.916 0 1 1-1.916 1.916 1.908 1.908 0 0 1 1.916-1.916z" class="cls-1" transform="translate(304.127 242.777)"/>
                    <path id="Path_48629" d="M28.941 9.746a2.039 2.039 0 1 1-2.027 2.039 2.042 2.042 0 0 1 2.027-2.039z" class="cls-1" transform="translate(308.346 235.758)"/>
                    <path id="Path_48630" d="M29.228 10.3a1.965 1.965 0 1 1-1.965 1.965 1.971 1.971 0 0 1 1.965-1.965z" class="cls-1" transform="translate(312.284 228.56)"/>
                    <circle id="Ellipse_10689" cx="1.986" cy="1.986" r="1.986" class="cls-1" transform="translate(343.235 231.823)"/>
                    <path id="Path_48631" d="M29.709 11.469a1.885 1.885 0 1 1 0 3.771 1.885 1.885 0 0 1 0-3.771z" class="cls-1" transform="translate(318.681 213.18)"/>
                    <path id="Path_48632" d="M29.934 12.078a1.891 1.891 0 1 1-1.891 1.891 1.882 1.882 0 0 1 1.891-1.891z" class="cls-1" transform="translate(321.084 205.079)"/>
                    <path id="Path_48633" d="M30.056 12.707a1.836 1.836 0 1 1-1.842 1.842 1.84 1.84 0 0 1 1.842-1.842z" class="cls-1" transform="translate(323.013 196.836)"/>
                    <path id="Path_48634" d="M30.154 13.343a1.818 1.818 0 1 1-1.818 1.818 1.814 1.814 0 0 1 1.818-1.818z" class="cls-1" transform="translate(324.389 188.425)"/>
                    <circle id="Ellipse_10690" cx="1.668" cy="1.668" r="1.668" class="cls-1" transform="translate(353.765 194.029)"/>
                    <path id="Path_48635" fill="${widget.color2}" d="M30.79 14.647a1.621 1.621 0 1 1-1.621 1.621 1.617 1.617 0 0 1 1.621-1.621z" class="cls-1" transform="translate(333.787 171.499)"/>
                    <path id="Path_48636" fill="${widget.color2}" d="M30.711 15.3a1.566 1.566 0 1 1-1.56 1.56 1.565 1.565 0 0 1 1.56-1.56z" class="cls-1" transform="translate(333.584 162.976)"/>
                    <path id="Path_48637" fill="${widget.color2}" d="M30.554 15.948a1.468 1.468 0 1 1-1.462 1.474 1.463 1.463 0 0 1 1.462-1.474z" class="cls-1" transform="translate(332.918 154.526)"/>
                    <path id="Path_48638" fill="${widget.color2}" d="M30.342 16.594a1.351 1.351 0 1 1-1.351 1.351 1.345 1.345 0 0 1 1.351-1.351z" class="cls-1" transform="translate(331.779 146.179)"/>
                    <path id="Path_48639" fill="${widget.color2}" d="M30.1 17.23a1.247 1.247 0 1 1-1.253 1.253A1.258 1.258 0 0 1 30.1 17.23z" class="cls-1" transform="translate(330.12 137.941)"/>
                    <path id="Path_48640" fill="${widget.color2}" d="M29.842 17.849a1.2 1.2 0 1 1 0 2.395 1.2 1.2 0 0 1 0-2.395z" class="cls-1" transform="translate(327.943 129.818)"/>
                    <path id="Path_48641"  d="M29.524 18.457a1.1 1.1 0 1 1-1.105 1.093 1.106 1.106 0 0 1 1.105-1.093z" class="cls-1" transform="translate(325.326 121.939)"/>
                    <path id="Path_48642" d="M29.119 19.049a.983.983 0 1 1-.97.983.978.978 0 0 1 .97-.983z" class="cls-1" transform="translate(322.28 114.309)"/>
                    <circle id="Ellipse_10691" cx=".809" cy=".809" r=".809" class="cls-1" transform="translate(346.668 126.639)"/>
                    <path id="Path_48643" d="M28.16 20.174a.663.663 0 1 1-.663.663.66.66 0 0 1 .663-.663z" class="cls-1" transform="translate(314.924 100.006)"/>
                    <circle id="Ellipse_10692" cx=".637" cy=".637" r=".637" class="cls-1" transform="translate(337.605 113.914)"/>
                    <path id="Path_48644" d="M27.315 21.172a.639.639 0 1 1 0 1.277.639.639 0 1 1 0-1.277z" class="cls-1" transform="translate(305.661 86.8)"/>
                    <path id="Path_48645" d="M26.842 21.625a.642.642 0 0 1 .639.639.633.633 0 1 1-.639-.639z" class="cls-1" transform="translate(300.472 80.783)"/>
                    <path id="Path_48646" d="M26.329 22.047a.616.616 0 0 1 .614.614.608.608 0 1 1-.614-.614z" class="cls-1" transform="translate(294.955 75.227)"/>
                    <circle id="Ellipse_10693" cx=".662" cy=".662" r=".662" class="cls-1" transform="translate(314.256 92.497)"/>
                    <circle id="Ellipse_10694" cx=".637" cy=".637" r=".637" class="cls-1" transform="translate(307.598 88.241)"/>
                    <path id="Path_48647" d="M24.711 23.091a.624.624 0 0 1 .614.614.616.616 0 0 1-.614.614.608.608 0 0 1-.614-.614.616.616 0 0 1 .614-.614z" class="cls-1" transform="translate(276.566 61.361)"/>
                    <path id="Path_48648" d="M24.1 23.363a.6.6 0 0 1 .59.59.59.59 0 0 1-.59.59.582.582 0 0 1-.59-.59.59.59 0 0 1 .59-.59z" class="cls-1" transform="translate(269.966 57.798)"/>
                    <path id="Path_48649" d="M23.5 23.592a.59.59 0 0 1 .59.59.6.6 0 0 1-.59.59.59.59 0 0 1-.59-.59.582.582 0 0 1 .59-.59z" class="cls-1" transform="translate(263.152 54.756)"/>
                    <path id="Path_48650" d="M22.879 23.779a.59.59 0 1 1 0 1.179.59.59 0 1 1 0-1.179z" class="cls-1" transform="translate(256.168 52.272)"/>
                    <path id="Path_48651" d="M22.249 23.923a.59.59 0 0 1 .59.59.582.582 0 0 1-.59.59.59.59 0 0 1-.59-.59.6.6 0 0 1 .59-.59z" class="cls-1" transform="translate(249.061 50.36)"/>
                    <circle id="Ellipse_10695" cx=".564" cy=".564" r=".564" class="cls-1" transform="translate(262.908 73.084)"/>
                    <path id="Path_48652" d="M20.967 24.079a.583.583 0 1 1-.59.59.59.59 0 0 1 .59-.59z" class="cls-1" transform="translate(234.597 48.3)"/>
                    <path id="Path_48653" d="M20.321 24.09a.59.59 0 0 1 .59.59.582.582 0 0 1-.59.59.59.59 0 0 1-.59-.59.6.6 0 0 1 .59-.59z" class="cls-1" transform="translate(227.309 48.142)"/>
                    <circle id="Ellipse_10696" cx=".613" cy=".613" r=".613" class="cls-1" transform="translate(239.093 72.625)"/>
                    <path id="Path_48654" d="M19.034 23.978a.582.582 0 0 1 .59.59.59.59 0 0 1-.59.59.6.6 0 0 1-.59-.59.59.59 0 0 1 .59-.59z" class="cls-1" transform="translate(212.789 49.629)"/>
                    <path id="Path_48655" d="M18.354 23.86a.54.54 0 1 1-.54.54.545.545 0 0 1 .54-.54z" class="cls-1" transform="translate(205.682 51.295)"/>
                    <path id="Path_48656" d="M17.752 23.693a.563.563 0 0 1 .565.565.556.556 0 0 1-.565.565.563.563 0 0 1-.565-.565.571.571 0 0 1 .565-.565z" class="cls-1" transform="translate(198.608 53.464)"/>
                    <path id="Path_48657" d="M17.2 23.479a.642.642 0 0 1 .639.639.633.633 0 1 1-.639-.639z" class="cls-1" transform="translate(191.647 56.159)"/>
                    <circle id="Ellipse_10697" cx=".637" cy=".637" r=".637" class="cls-1" transform="translate(200.895 82.711)"/>
                    <path id="Path_48658" d="M16.012 22.941a.608.608 0 1 1-.614.614.616.616 0 0 1 .614-.614z" class="cls-1" transform="translate(178.425 63.366)"/>
                    <circle id="Ellipse_10698" cx=".637" cy=".637" r=".637" class="cls-1" transform="translate(186.978 90.324)"/>
                    <path id="Path_48659" d="M14.993 22.238a.688.688 0 1 1-.688.688.687.687 0 0 1 .688-.688z" class="cls-1" transform="translate(166.094 72.543)"/>
                    <circle id="Ellipse_10699" cx=".736" cy=".736" r=".736" class="cls-1" transform="translate(174.145 99.682)"/>
                    <path id="Path_48660" d="M14.067 21.392a.75.75 0 0 1 .761.761.755.755 0 1 1-1.511 0 .747.747 0 0 1 .75-.761z" class="cls-1" transform="translate(154.959 83.632)"/>
                    <circle id="Ellipse_10700" cx=".809" cy=".809" r=".809" class="cls-1" transform="translate(162.759 110.727)"/>
                    <path id="Path_48661" d="M13.335 20.416a.884.884 0 1 1-.884.884.888.888 0 0 1 .884-.884z" class="cls-1" transform="translate(145.178 96.35)"/>
                    <circle id="Ellipse_10701" cx=".908" cy=".908" r=".908" class="cls-1" transform="translate(152.986 123.199)"/>
                    <path id="Path_48662" d="M12.643 19.338a.909.909 0 1 1-.909.909.907.907 0 0 1 .909-.909z" class="cls-1" transform="translate(137.089 110.618)"/>
                    <path id="Path_48663" d="M12.388 18.762a.958.958 0 0 1 0 1.916.958.958 0 0 1 0-1.916z" class="cls-1" transform="translate(133.659 118.17)"/>
                    <path id="Path_48664" d="M12.161 18.167a1 1 0 1 1-.995.995.993.993 0 0 1 .995-.995z" class="cls-1" transform="translate(130.68 125.987)"/>
                    <path id="Path_48665" fill="${widget.color2}" d="M12.022 17.553a1.081 1.081 0 0 1 0 2.162 1.081 1.081 0 1 1 0-2.162z" class="cls-1" transform="translate(128.142 133.983)"/>
                    <path id="Path_48666" fill="${widget.color2}" d="M11.913 16.925a1.155 1.155 0 1 1-1.154 1.155 1.151 1.151 0 0 1 1.154-1.155z" class="cls-1" transform="translate(126.089 142.176)"/>
                    <path id="Path_48667" fill="${widget.color2}" d="M11.848 16.287A1.222 1.222 0 1 1 10.62 17.5a1.221 1.221 0 0 1 1.228-1.213z" class="cls-1" transform="translate(124.521 150.515)"/>
                    <path id="Path_48668" fill="${widget.color2}" d="M11.782 15.645a1.247 1.247 0 1 1-1.253 1.24 1.248 1.248 0 0 1 1.253-1.24z" class="cls-1" transform="translate(123.494 158.993)"/>
                    <path id="Path_48669" fill="${widget.color2}" d="M11.759 15a1.277 1.277 0 1 1-1.277 1.277A1.276 1.276 0 0 1 11.759 15z" class="cls-1" transform="translate(122.964 167.525)"/>
                    <path id="Path_48670" fill="${widget.color2}" d="M11.759 14.352a1.277 1.277 0 1 1-1.277 1.277 1.276 1.276 0 0 1 1.277-1.277z" class="cls-1" transform="translate(122.964 176.105)"/>
                    <circle id="Ellipse_10702" fill="${widget.color2}" cx="1.299" cy="1.299" r="1.299" class="cls-1" transform="translate(133.974 198.353)"/>
                    <circle id="Ellipse_10703" fill="${widget.color2}" cx="1.422" cy="1.422" r="1.422" class="cls-1" transform="translate(134.943 206.09)"/>
                    <path id="Path_48671" fill="${widget.color2}" d="M12.139 12.425a1.4 1.4 0 1 1-1.4 1.4 1.4 1.4 0 0 1 1.4-1.4z" class="cls-1" transform="translate(125.863 201.453)"/>
                    <circle id="Ellipse_10704" fill="${widget.color2}" cx="1.52" cy="1.52" r="1.52" class="cls-1" transform="translate(138.641 221.393)"/>
                    <circle id="Ellipse_10705" fill="${widget.color2}" cx="1.643" cy="1.643" r="1.643" class="cls-1" transform="translate(141.204 228.738)"/>
                    <path id="Path_48672" fill="${widget.color2}" d="M12.952 10.59a1.572 1.572 0 1 1-1.572 1.572 1.573 1.573 0 0 1 1.572-1.572z" class="cls-1" transform="translate(133.095 225.481)"/>
                    <path id="Path_48673" fill="${widget.color2}" d="M13.229 10.02a1.541 1.541 0 1 1-1.548 1.535 1.546 1.546 0 0 1 1.548-1.535z" class="cls-1" transform="translate(136.502 233.113)"/>
                    <circle id="Ellipse_10706" cx="1.57" fill="${widget.color2}" cy="1.57" r="1.57" class="cls-1" transform="translate(152.324 249.859)"/>
                    <path fill="${widget.color2}" id="Path_48674" d="M14.26 8.916a1.891 1.891 0 1 1-1.891 1.891 1.892 1.892 0 0 1 1.891-1.891z" class="cls-1" transform="translate(144.252 247.076)"/>
                    <circle id="Ellipse_10707" fill="${widget.color2}" cx="2.011" cy="2.011" r="2.011" class="cls-1" transform="translate(161.558 261.988)"/>
                    <circle id="Ellipse_10708" fill="${widget.color2}" cx="2.158" cy="2.158" r="2.158" class="cls-1" transform="translate(166.874 267.595)"/>
                    <path id="Path_48675" fill="${widget.color2}" d="M15.8 7.495a2.106 2.106 0 1 1-2.112 2.1 2.1 2.1 0 0 1 2.112-2.1z" class="cls-1" transform="translate(159.088 265.52)"/>
                    <path id="Path_48676" fill="${widget.color2}" d="M16.234 7.1a2.039 2.039 0 1 1-2.039 2.039A2.05 2.05 0 0 1 16.234 7.1z" class="cls-1" transform="translate(164.853 270.928)"/>
                    <path id="Path_48677" fill="${widget.color2}" d="M16.585 6.747a1.842 1.842 0 1 1-1.842 1.842 1.837 1.837 0 0 1 1.842-1.842z" class="cls-1" transform="translate(171.035 275.983)"/>
                    <path id="Path_48678" fill="${widget.color2}" d="M17.174 6.414a1.885 1.885 0 1 1 0 3.771 1.885 1.885 0 0 1 0-3.771z" class="cls-1" transform="translate(177.263 280.32)"/>
                    <path id="Path_48679" fill="${widget.color2}" d="M18.012 6.1a2.162 2.162 0 1 1-2.162 2.163A2.154 2.154 0 0 1 18.012 6.1z" class="cls-1" transform="translate(183.524 283.924)"/>
                    <path id="Path_48680" fill="${widget.color2}" d="M18.934 5.822a2.524 2.524 0 1 1-2.518 2.53 2.526 2.526 0 0 1 2.518-2.53z" class="cls-1" transform="translate(189.91 286.905)"/>
                    <path id="Path_48681" fill="${widget.color2}" d="M19.749 5.595a2.751 2.751 0 1 1-2.739 2.751 2.747 2.747 0 0 1 2.739-2.751z" class="cls-1" transform="translate(196.611 289.466)"/>
                    <path id="Path_48682" fill="${widget.color2}" d="M20.408 5.428a2.77 2.77 0 1 1-2.776 2.763 2.768 2.768 0 0 1 2.776-2.763z" class="cls-1" transform="translate(203.629 291.647)"/>
                    <path id="Path_48683" fill="${widget.color2}" d="M21.1 5.3a2.843 2.843 0 1 1-2.837 2.837A2.841 2.841 0 0 1 21.1 5.3z" class="cls-1" transform="translate(210.725 293.2)"/>
                    <path id="Path_48684" fill="${widget.color2}" d="M21.684 5.228a2.77 2.77 0 1 1-2.776 2.763 2.768 2.768 0 0 1 2.776-2.763z" class="cls-1" transform="translate(218.024 294.303)"/>
                    <path id="Path_48685" fill="${widget.color2}" d="M22.284 5.2a2.72 2.72 0 1 1-2.727 2.727A2.728 2.728 0 0 1 22.284 5.2z" class="cls-1" transform="translate(225.346 294.787)"/>
                    <path id="Path_48686" fill="${widget.color2}" d="M22.862 5.216a2.647 2.647 0 1 1-2.653 2.653 2.65 2.65 0 0 1 2.653-2.653z" class="cls-1" transform="translate(232.702 294.708)"/>
                    <path id="Path_48687" fill="${widget.color2}" d="M23.483 5.274A2.622 2.622 0 1 1 20.855 7.9a2.621 2.621 0 0 1 2.628-2.626z" class="cls-1" transform="translate(239.99 293.987)"/>
                    <path id="Path_48688" fill="${widget.color2}" d="M24.02 5.381a2.53 2.53 0 1 1-2.52 2.53 2.526 2.526 0 0 1 2.52-2.53z" class="cls-1" transform="translate(247.289 292.75)"/>
                    <path id="Path_48689" fill="${widget.color2}" d="M24.661 5.525a2.53 2.53 0 1 1-2.53 2.53 2.534 2.534 0 0 1 2.53-2.53z" class="cls-1" transform="translate(254.386 290.838)"/>
                    <path id="Path_48690" fill="${widget.color2}" d="M25.145 5.724a2.377 2.377 0 1 1-2.383 2.37 2.364 2.364 0 0 1 2.383-2.37z" class="cls-1" transform="translate(261.504 288.502)"/>
                    <path id="Path_48691" fill="${widget.color2}" d="M25.681 5.959a2.309 2.309 0 1 1-2.309 2.309 2.3 2.3 0 0 1 2.309-2.309z" class="cls-1" transform="translate(268.386 285.516)"/>
                    <path id="Path_48692" fill="${widget.color2}" d="M26.155 6.24a2.18 2.18 0 1 1-2.186 2.186 2.18 2.18 0 0 1 2.186-2.186z" class="cls-1" transform="translate(275.122 282.041)"/>
                    <path id="Path_48693" fill="${widget.color2}" d="M26.722 6.55a2.18 2.18 0 1 1-2.186 2.186 2.181 2.181 0 0 1 2.186-2.186z" class="cls-1" transform="translate(281.518 277.924)"/>
                    <path id="Path_48694" fill="${widget.color2}" d="M27.221 6.9a2.131 2.131 0 1 1-2.137 2.125A2.118 2.118 0 0 1 27.221 6.9z" class="cls-1" transform="translate(287.701 273.347)"/>
                    <circle id="Ellipse_10709" fill="${widget.color2}" cx="2.109" cy="2.109" r="2.109" class="cls-1" transform="translate(319.181 275.536)"/>
                    <circle id="Ellipse_10710" fill="${widget.color2}" cx="2.011" cy="2.011" r="2.011" class="cls-1" transform="translate(325.31 270.475)"/>
                    <circle id="Ellipse_10711" fill="${widget.color2}" cx="1.937" cy="1.937" r="1.937" class="cls-1" transform="translate(331.043 264.986)"/>
                    <path id="Path_48695" fill="${widget.color2}" d="M28.985 8.656a1.984 1.984 0 1 1-1.99 1.977 1.976 1.976 0 0 1 1.99-1.977z" class="cls-1" transform="translate(309.26 250.345)"/>
                    <path id="Path_48696" fill="${widget.color2}" d="M29.4 9.166a2.008 2.008 0 1 1-2.014 2 2.013 2.013 0 0 1 2.014-2z" class="cls-1" transform="translate(313.683 243.523)"/>
                    <path id="Path_48697" fill="${widget.color2}" d="M29.759 9.7a2.008 2.008 0 1 1-2.014 2 2 2 0 0 1 2.014-2z" class="cls-1" transform="translate(317.722 236.377)"/>
                    <path id="Path_48698" fill="${widget.color2}" d="M29.932 10.277a1.867 1.867 0 1 1-1.855 1.867 1.866 1.866 0 0 1 1.855-1.867z" class="cls-1" transform="translate(321.467 229.049)"/>
                    <path id="Path_48699" fill="${widget.color2}" d="M30.224 10.86a1.861 1.861 0 1 1-1.867 1.867 1.866 1.866 0 0 1 1.867-1.867z" class="cls-1" transform="translate(324.626 221.318)"/>
                    <path id="Path_48700" fill="${widget.color2}" d="M30.384 11.466a1.787 1.787 0 1 1-1.784 1.793 1.787 1.787 0 0 1 1.784-1.793z" class="cls-1" transform="translate(327.401 213.417)"/>
                    <path id="Path_48701" fill="${widget.color2}" d="M30.616 12.079a1.812 1.812 0 1 1-1.816 1.805 1.819 1.819 0 0 1 1.816-1.805z" class="cls-1" transform="translate(329.601 205.226)"/>
                    <path id="Path_48702" fill="${widget.color2}" d="M30.816 12.7a1.867 1.867 0 1 1-1.867 1.867 1.863 1.863 0 0 1 1.867-1.867z" class="cls-1" transform="translate(331.305 196.841)"/>
                    <path id="Path_48703" fill="${widget.color2}" d="M30.847 13.345a1.787 1.787 0 1 1-1.781 1.793 1.787 1.787 0 0 1 1.781-1.793z" class="cls-1" transform="translate(332.625 188.46)"/>
                    <path id="Path_48704" fill="${widget.color2}" d="M30.891 13.989a1.769 1.769 0 1 1-1.756 1.769 1.761 1.761 0 0 1 1.756-1.769z" class="cls-1" transform="translate(333.403 179.943)"/>
                    <path id="Path_48705" d="M31.578 14.641a1.695 1.695 0 1 1-1.695 1.695 1.688 1.688 0 0 1 1.695-1.695z" class="cls-1" transform="translate(341.842 171.431)"/>
                    <path id="Path_48706" d="M31.467 15.295a1.6 1.6 0 1 1-1.6 1.6 1.6 1.6 0 0 1 1.6-1.6z" class="cls-1" transform="translate(341.696 162.941)"/>
                    <circle id="Ellipse_10712" cx="1.471" cy="1.471" r="1.471" class="cls-1" transform="translate(370.928 170.464)"/>
                    <circle id="Ellipse_10713" cx="1.349" cy="1.349" r="1.349" class="cls-1" transform="translate(369.785 162.754)"/>
                    <circle id="Ellipse_10714" cx="1.275" cy="1.275" r="1.275" class="cls-1" transform="translate(368.092 155.09)"/>
                    <path id="Path_48707" d="M30.59 17.859a1.179 1.179 0 1 1-1.179 1.179 1.179 1.179 0 0 1 1.179-1.179z" class="cls-1" transform="translate(336.517 129.722)"/>
                    <path id="Path_48708" d="M30.3 18.472a1.1 1.1 0 1 1-1.105 1.093 1.1 1.1 0 0 1 1.105-1.093z" class="cls-1" transform="translate(334.069 121.74)"/>
                    <path id="Path_48709" d="M29.936 19.071a1 1 0 1 1-.995 1.007 1 1 0 0 1 .995-1.007z" class="cls-1" transform="translate(331.215 113.98)"/>
                    <path id="Path_48710" d="M29.5 19.655a.86.86 0 1 1-.847.86.854.854 0 0 1 .847-.86z" class="cls-1" transform="translate(327.977 106.506)"/>
                    <path id="Path_48711" d="M29.179 20.208a.86.86 0 1 1-.86.86.86.86 0 0 1 .86-.86z" class="cls-1" transform="translate(324.197 99.161)"/>
                    <circle id="Ellipse_10715" cx=".711" cy=".711" r=".711" class="cls-1" transform="translate(348.12 113.01)"/>
                    <circle id="Ellipse_10716" cx=".687" cy=".687" r=".687" class="cls-1" transform="translate(343.196 106.83)"/>
                    <circle id="Ellipse_10717" cx=".662" cy=".662" r=".662" class="cls-1" transform="translate(337.885 100.98)"/>
                    <path id="Path_48712" d="M27.3 22.189a.639.639 0 1 1 0 1.277.639.639 0 0 1 0-1.277z" class="cls-1" transform="translate(305.537 73.292)"/>
                    <path id="Path_48713" d="M26.857 22.6a.688.688 0 1 1 0 1.376.688.688 0 1 1 0-1.376z" class="cls-1" transform="translate(299.942 67.682)"/>
                    <circle id="Ellipse_10718" cx=".637" cy=".637" r=".637" class="cls-1" transform="translate(319.806 85.592)"/>
                    <path id="Path_48714" d="M25.73 23.349a.616.616 0 0 1 .614.614.614.614 0 0 1-1.228 0 .616.616 0 0 1 .614-.614z" class="cls-1" transform="translate(288.062 57.935)"/>
                    <circle id="Ellipse_10719" cx=".613" cy=".613" r=".613" class="cls-1" transform="translate(306.264 77.393)"/>
                    <path id="Path_48715" d="M24.54 23.95a.563.563 0 0 1 .565.565.571.571 0 0 1-.565.565.563.563 0 0 1-.565-.565.556.556 0 0 1 .565-.565z" class="cls-1" transform="translate(275.189 50.05)"/>
                    <path id="Path_48716" d="M23.918 24.195a.545.545 0 0 1 .54.54.54.54 0 1 1-1.081 0 .545.545 0 0 1 .541-.54z" class="cls-1" transform="translate(268.454 46.845)"/>
                    <path id="Path_48717" d="M23.305 24.4a.537.537 0 0 1 .54.54.545.545 0 0 1-.54.54.537.537 0 0 1-.54-.54.53.53 0 0 1 .54-.54z" class="cls-1" transform="translate(261.538 44.149)"/>
                    <path id="Path_48718" d="M22.658 24.564a.516.516 0 0 1 0 1.032.516.516 0 0 1 0-1.032z" class="cls-1" transform="translate(254.51 41.994)"/>
                    <path id="Path_48719" d="M22 24.69a.491.491 0 1 1-.491.491.493.493 0 0 1 .491-.491z" class="cls-1" transform="translate(247.368 40.369)"/>
                    <path id="Path_48720" d="M21.383 24.77a.5.5 0 0 1 .5.516.51.51 0 1 1-.5-.516z" class="cls-1" transform="translate(240.125 39.258)"/>
                    <path id="Path_48721" d="M20.76 24.81a.545.545 0 0 1 .54.54.537.537 0 0 1-.54.54.53.53 0 0 1-.54-.54.537.537 0 0 1 .54-.54z" class="cls-1" transform="translate(232.826 38.677)"/>
                    <path id="Path_48722" d="M20.092 24.812a.516.516 0 1 1-.516.516.508.508 0 0 1 .516-.516z" class="cls-1" transform="translate(225.561 38.7)"/>
                    <path id="Path_48723" d="M19.492 24.766a.563.563 0 0 1 .565.565.571.571 0 0 1-.565.565.563.563 0 0 1-.565-.565.556.556 0 0 1 .565-.565z" class="cls-1" transform="translate(218.239 39.212)"/>
                    <path id="Path_48724" d="M18.851 24.684a.571.571 0 0 1 .565.565.563.563 0 0 1-.565.565.556.556 0 0 1-.565-.565.563.563 0 0 1 .565-.565z" class="cls-1" transform="translate(211.007 40.302)"/>
                    <path id="Path_48725" d="M18.172 24.564a.516.516 0 0 1 0 1.032.516.516 0 0 1 0-1.032z" class="cls-1" transform="translate(203.899 41.994)"/>
                    <path id="Path_48726" d="M17.547 24.4a.516.516 0 1 1-.516.516.509.509 0 0 1 .516-.516z" class="cls-1" transform="translate(196.848 44.172)"/>
                    <path id="Path_48727" d="M16.978 24.193a.563.563 0 0 1 .565.565.556.556 0 0 1-.565.565.563.563 0 0 1-.565-.565.571.571 0 0 1 .565-.565z" class="cls-1" transform="translate(189.876 46.823)"/>
                    <path id="Path_48728" d="M16.379 23.95a.556.556 0 0 1 .565.565.563.563 0 0 1-.565.565.571.571 0 0 1-.565-.565.563.563 0 0 1 .565-.565z" class="cls-1" transform="translate(183.118 50.05)"/>
                    <path id="Path_48729" d="M15.82 23.668a.59.59 0 0 1 .59.59.582.582 0 0 1-.59.59.59.59 0 0 1-.59-.59.6.6 0 0 1 .59-.59z" class="cls-1" transform="translate(176.53 53.747)"/>
                    <path id="Path_48730" d="M15.279 23.349a.616.616 0 0 1 .614.614.608.608 0 0 1-.614.614.616.616 0 0 1-.614-.614.624.624 0 0 1 .614-.614z" class="cls-1" transform="translate(170.155 57.935)"/>
                    <circle id="Ellipse_10720" cx=".637" cy=".637" r=".637" class="cls-1" transform="translate(178.149 85.592)"/>
                    <circle id="Ellipse_10721" cx=".662" cy=".662" r=".662" class="cls-1" transform="translate(171.765 90.314)"/>
                    <circle id="Ellipse_10722" cx=".736" cy=".736" r=".736" class="cls-1" transform="translate(165.649 95.384)"/>
                    <circle id="Ellipse_10723" cx=".76" cy=".76" r=".76" class="cls-1" transform="translate(159.923 100.882)"/>
                    <path id="Path_48731" d="M13.01 21.247a.811.811 0 1 1-.811.811.81.81 0 0 1 .811-.811z" class="cls-1" transform="translate(142.335 85.46)"/>
                    <path id="Path_48732" d="M12.652 20.738a.86.86 0 1 1-.86.86.854.854 0 0 1 .86-.86z" class="cls-1" transform="translate(137.743 92.122)"/>
                    <path id="Path_48733" d="M12.328 20.2a.909.909 0 1 1-.909.909.915.915 0 0 1 .909-.909z" class="cls-1" transform="translate(133.535 99.116)"/>
                    <path id="Path_48734" d="M12.015 19.65a.927.927 0 1 1-.933.933.933.933 0 0 1 .933-.933z" class="cls-1" transform="translate(129.733 106.438)"/>
                    <path id="Path_48735" d="M11.762 19.073a.976.976 0 1 1-.983.983.978.978 0 0 1 .983-.983z" class="cls-1" transform="translate(126.314 114.003)"/>
                    <path id="Path_48736" d="M11.522 18.48a1 1 0 1 1-1.007.995 1 1 0 0 1 1.007-.995z" class="cls-1" transform="translate(123.336 121.83)"/>
                    <path id="Path_48737" d="M11.344 17.869a1.056 1.056 0 0 1 0 2.112 1.056 1.056 0 0 1 0-2.112z" class="cls-1" transform="translate(120.775 129.835)"/>
                    <path id="Path_48738" d="M11.25 17.242A1.154 1.154 0 1 1 10.1 18.4a1.153 1.153 0 0 1 1.15-1.158z" class="cls-1" transform="translate(118.609 137.966)"/>
                    <path id="Path_48739" d="M11.14 16.608a1.2 1.2 0 1 1-1.191 1.2 1.2 1.2 0 0 1 1.191-1.2z" class="cls-1" transform="translate(116.95 146.288)"/>
                    <path id="Path_48740" d="M11.037 15.97a1.2 1.2 0 1 1-1.191 1.2 1.206 1.206 0 0 1 1.191-1.2z" class="cls-1" transform="translate(115.788 154.762)"/>
                    <path id="Path_48741" d="M11.054 15.321A1.277 1.277 0 1 1 9.777 16.6a1.276 1.276 0 0 1 1.277-1.279z" class="cls-1" transform="translate(115.01 163.235)"/>
                    <path id="Path_48742" d="M11.057 14.673a1.3 1.3 0 1 1-1.3 1.3 1.3 1.3 0 0 1 1.3-1.3z" class="cls-1" transform="translate(114.762 171.792)"/>
                    <path id="Path_48743" d="M11.111 14.023a1.351 1.351 0 1 1-1.339 1.351 1.347 1.347 0 0 1 1.339-1.351z" class="cls-1" transform="translate(114.954 180.327)"/>
                    <path id="Path_48744" d="M11.24 13.374A1.425 1.425 0 1 1 9.828 14.8a1.426 1.426 0 0 1 1.412-1.426z" class="cls-1" transform="translate(115.585 188.799)"/>
                    <circle id="Ellipse_10724" cx="1.471" cy="1.471" r="1.471" class="cls-1" transform="translate(126.626 209.961)"/>
                    <circle id="Ellipse_10725" cx="1.496" cy="1.496" r="1.496" class="cls-1" transform="translate(128.367 217.674)"/>
                    <path id="Path_48745" d="M11.841 11.473a1.591 1.591 0 1 1-1.6 1.584 1.591 1.591 0 0 1 1.6-1.584z" class="cls-1" transform="translate(120.279 213.717)"/>
                    <path id="Path_48746" d="M12.1 10.862a1.646 1.646 0 1 1-1.633 1.646 1.646 1.646 0 0 1 1.633-1.646z" class="cls-1" transform="translate(122.761 221.721)"/>
                    <circle id="Ellipse_10726" cx="1.52" cy="1.52" r="1.52" class="cls-1" transform="translate(136.554 239.962)"/>
                    <path id="Path_48747" d="M12.692 9.7a1.664 1.664 0 1 1-1.67 1.67 1.662 1.662 0 0 1 1.67-1.67z" class="cls-1" transform="translate(129.056 237.158)"/>
                    <path id="Path_48748" d="M13.118 9.136a1.769 1.769 0 1 1-1.769 1.764 1.766 1.766 0 0 1 1.769-1.764z" class="cls-1" transform="translate(132.745 244.4)"/>
                    <path id="Path_48749" d="M13.611 8.594a1.916 1.916 0 1 1-1.9 1.916 1.918 1.918 0 0 1 1.9-1.916z" class="cls-1" transform="translate(136.784 251.304)"/>
                    <circle id="Ellipse_10727" cx="2.06" cy="2.06" r="2.06" class="cls-1" transform="translate(153.288 265.959)"/>
                    <path id="Path_48750" d="M14.528 7.6a1.984 1.984 0 1 1-1.99 1.99 1.979 1.979 0 0 1 1.99-1.99z" class="cls-1" transform="translate(146.159 264.305)"/>
                    <path id="Path_48751" d="M14.9 7.163a1.891 1.891 0 1 1-1.89 1.891 1.892 1.892 0 0 1 1.89-1.891z" class="cls-1" transform="translate(151.484 270.359)"/>
                    <path id="Path_48752" d="M15.235 6.758a1.719 1.719 0 1 1-1.719 1.719 1.725 1.725 0 0 1 1.719-1.719z" class="cls-1" transform="translate(157.193 276.082)"/>
                    <path id="Path_48753" d="M15.753 6.372a1.713 1.713 0 1 1-1.719 1.707 1.7 1.7 0 0 1 1.719-1.707z" class="cls-1" transform="translate(163.037 281.221)"/>
                    <path id="Path_48754" d="M16.407 6.009a1.842 1.842 0 1 1-1.842 1.842 1.84 1.84 0 0 1 1.842-1.842z" class="cls-1" transform="translate(169.027 285.785)"/>
                    <circle id="Ellipse_10728" cx="2.182" cy="2.182" r="2.182" class="cls-1" transform="translate(190.17 295.347)"/>
                    <path id="Path_48755" d="M18.128 5.36a2.475 2.475 0 1 1-2.469 2.469 2.471 2.471 0 0 1 2.469-2.469z" class="cls-1" transform="translate(181.37 293.14)"/>
                    <path id="Path_48756" d="M19 5.094a2.77 2.77 0 1 1-2.766 2.776A2.773 2.773 0 0 1 19 5.094z" class="cls-1" transform="translate(187.857 296.083)"/>
                    <circle id="Ellipse_10729" cx="2.771" cy="2.771" r="2.771" class="cls-1" transform="translate(211.619 303.68)"/>
                    <path id="Path_48757" d="M20.18 4.732a2.7 2.7 0 1 1-2.7 2.69 2.689 2.689 0 0 1 2.7-2.69z" class="cls-1" transform="translate(201.891 301.039)"/>
                    <path id="Path_48758" d="M20.814 4.608a2.7 2.7 0 1 1-2.7 2.7 2.7 2.7 0 0 1 2.7-2.7z" class="cls-1" transform="translate(209.044 302.673)"/>
                    <circle id="Ellipse_10730" cx="2.771" cy="2.771" r="2.771" class="cls-1" transform="translate(234.956 308.226)"/>
                    <path id="Path_48759" d="M22.123 4.482A2.727 2.727 0 1 1 19.4 7.209a2.726 2.726 0 0 1 2.723-2.727z" class="cls-1" transform="translate(223.53 304.298)"/>
                    <circle id="Ellipse_10731" cx="2.795" cy="2.795" r="2.795" class="cls-1" transform="translate(250.787 308.71)"/>
                    <circle id="Ellipse_10732" cx="2.795" cy="2.795" r="2.795" class="cls-1" transform="translate(258.708 308.201)"/>
                    <path id="Path_48760" d="M24.065 4.6a2.745 2.745 0 1 1-2.739 2.751A2.747 2.747 0 0 1 24.065 4.6z" class="cls-1" transform="translate(245.304 302.627)"/>
                    <path id="Path_48761" d="M24.576 4.74a2.6 2.6 0 1 1-2.6 2.591 2.592 2.592 0 0 1 2.6-2.591z" class="cls-1" transform="translate(252.592 301.129)"/>
                    <circle id="Ellipse_10733" cx="2.574" cy="2.574" r="2.574" class="cls-1" transform="translate(282.266 303.877)"/>
                    <path id="Path_48762" d="M25.746 5.114a2.524 2.524 0 1 1-2.53 2.53 2.534 2.534 0 0 1 2.53-2.53z" class="cls-1" transform="translate(266.626 296.309)"/>
                    <path id="Path_48763" d="M26.3 5.36a2.475 2.475 0 1 1-2.481 2.469A2.469 2.469 0 0 1 26.3 5.36z" class="cls-1" transform="translate(273.429 293.14)"/>
                    <path id="Path_48764" d="M26.747 5.652a2.334 2.334 0 1 1-2.334 2.334 2.332 2.332 0 0 1 2.334-2.334z" class="cls-1" transform="translate(280.131 289.544)"/>
                    <path id="Path_48765" d="M27.264 5.973a2.284 2.284 0 1 1-2.284 2.284 2.28 2.28 0 0 1 2.284-2.284z" class="cls-1" transform="translate(286.527 285.379)"/>
                    <circle id="Ellipse_10734" cx="2.207" cy="2.207" r="2.207" class="cls-1" transform="translate(318.237 287.099)"/>
                    <path id="Path_48766" d="M28.177 6.724a2.137 2.137 0 1 1-2.125 2.137 2.139 2.139 0 0 1 2.125-2.137z" class="cls-1" transform="translate(298.622 275.699)"/>
                    <path id="Path_48767" d="M28.646 7.145a2.113 2.113 0 1 1-2.1 2.112 2.112 2.112 0 0 1 2.1-2.112z" class="cls-1" transform="translate(304.195 270.156)"/>
                    <circle id="Ellipse_10735" cx="1.986" cy="1.986" r="1.986" class="cls-1" transform="translate(336.561 271.907)"/>
                    <path id="Path_48768" d="M29.4 8.087a1.934 1.934 0 1 1-1.941 1.928A1.934 1.934 0 0 1 29.4 8.087z" class="cls-1" transform="translate(314.484 258.001)"/>
                    <circle id="Ellipse_10736" cx="1.961" cy="1.961" r="1.961" class="cls-1" transform="translate(346.869 259.853)"/>
                    <circle id="Ellipse_10737" cx="2.011" cy="2.011" r="2.011" class="cls-1" transform="translate(351.361 253.294)"/>
                    <path id="Path_48769" d="M30.584 9.667a2.033 2.033 0 1 1-2.026 2.039 2.034 2.034 0 0 1 2.026-2.039z" class="cls-1" transform="translate(326.894 236.819)"/>
                    <path id="Path_48770" d="M30.748 10.252a1.885 1.885 0 1 1 0 3.771 1.885 1.885 0 0 1 0-3.771z" class="cls-1" transform="translate(330.402 229.344)"/>
                    <path id="Path_48771" d="M30.976 10.846a1.842 1.842 0 1 1-1.842 1.842 1.84 1.84 0 0 1 1.842-1.842z" class="cls-1" transform="translate(333.392 221.541)"/>
                    <path id="Path_48772" d="M31.2 11.453a1.836 1.836 0 1 1-1.842 1.83 1.837 1.837 0 0 1 1.842-1.83z" class="cls-1" transform="translate(335.908 213.491)"/>
                    <path id="Path_48773" d="M31.406 12.07a1.867 1.867 0 1 1-1.867 1.867 1.866 1.866 0 0 1 1.867-1.867z" class="cls-1" transform="translate(337.961 205.235)"/>
                    <path id="Path_48774" d="M31.55 12.7a1.867 1.867 0 1 1-1.867 1.867A1.856 1.856 0 0 1 31.55 12.7z" class="cls-1" transform="translate(339.586 196.867)"/>
                    <path id="Path_48775" d="M31.608 13.342a1.818 1.818 0 1 1-1.818 1.818 1.821 1.821 0 0 1 1.818-1.818z" class="cls-1" transform="translate(340.793 188.438)"/>
                    <path id="Path_48776" d="M31.647 13.987a1.793 1.793 0 1 1-1.793 1.793 1.8 1.8 0 0 1 1.793-1.793z" class="cls-1" transform="translate(341.515 179.921)"/>
                    <path id="Path_48777" fill="${widget.color3}" d="M32.163 14.653a1.548 1.548 0 1 1-1.548 1.547 1.546 1.546 0 0 1 1.548-1.547z" class="cls-1" transform="translate(350.1 171.566)"/>
                    <path id="Path_48778" fill="${widget.color3}" d="M32.075 15.3a1.474 1.474 0 1 1-1.475 1.479 1.478 1.478 0 0 1 1.475-1.479z" class="cls-1" transform="translate(349.943 163.054)"/>
                    <path id="Path_48779" fill="${widget.color3}" d="M31.96 15.953a1.419 1.419 0 1 1-1.412 1.425 1.426 1.426 0 0 1 1.412-1.425z" class="cls-1" transform="translate(349.345 154.558)"/>
                    <circle id="Ellipse_10738" fill="${widget.color3}" cx="1.422" cy="1.422" r="1.422" class="cls-1" transform="translate(378.705 162.66)"/>
                    <path id="Path_48780" fill="${widget.color3}" d="M31.606 17.236a1.271 1.271 0 1 1-1.277 1.277 1.276 1.276 0 0 1 1.277-1.277z" class="cls-1" transform="translate(346.874 137.812)"/>
                    <path id="Path_48781" fill="${widget.color3}" d="M31.321 17.868a1.154 1.154 0 1 1-1.154 1.154 1.153 1.153 0 0 1 1.154-1.154z" class="cls-1" transform="translate(345.046 129.651)"/>
                    <path id="Path_48782" fill="${widget.color3}" d="M31.067 18.484a1.105 1.105 0 1 1-1.105 1.105 1.109 1.109 0 0 1 1.105-1.105z" class="cls-1" transform="translate(342.733 121.568)"/>
                    <path id="Path_48783" fill="${widget.color3}" d="M30.71 19.092a.983.983 0 1 1-.983.983.985.985 0 0 1 .983-.983z" class="cls-1" transform="translate(340.082 113.738)"/>
                    <circle id="Ellipse_10739" cx=".858" cy=".858" r=".858" class="cls-1" transform="translate(366.489 125.808)"/>
                    <circle id="Ellipse_10740" cx=".834" cy=".834" r=".834" class="cls-1" transform="translate(362.649 118.9)"/>
                    <circle id="Ellipse_10741" cx=".785" cy=".785" r=".785" class="cls-1" transform="translate(358.425 112.262)"/>
                    <circle id="Ellipse_10742" cx=".736" cy=".736" r=".736" class="cls-1" transform="translate(353.81 105.89)"/>
                    <circle id="Ellipse_10743" cx=".662" cy=".662" r=".662" class="cls-1" transform="translate(348.843 99.834)"/>
                    <path id="Path_48784" d="M28.243 22.3a.66.66 0 0 1 .663.663.663.663 0 0 1-1.326 0 .66.66 0 0 1 .663-.663z" class="cls-1" transform="translate(315.86 71.716)"/>
                    <path id="Path_48785" d="M27.776 22.751a.663.663 0 1 1-.663.663.66.66 0 0 1 .663-.663z" class="cls-1" transform="translate(310.592 65.779)"/>
                    <path id="Path_48786" d="M27.216 23.175a.59.59 0 0 1 .59.59.582.582 0 0 1-.59.59.59.59 0 0 1-.59-.59.6.6 0 0 1 .59-.59z" class="cls-1" transform="translate(305.097 60.295)"/>
                    <path id="Path_48787" d="M26.721 23.56a.608.608 0 0 1 .614.614.616.616 0 0 1-.614.614.624.624 0 0 1-.614-.614.616.616 0 0 1 .614-.614z" class="cls-1" transform="translate(299.242 55.132)"/>
                    <path id="Path_48788" d="M26.137 23.92a.563.563 0 0 1 .565.565.565.565 0 1 1-1.13 0 .563.563 0 0 1 .565-.565z" class="cls-1" transform="translate(293.206 50.449)"/>
                    <path id="Path_48789" d="M25.577 24.243a.556.556 0 0 1 .565.565.563.563 0 0 1-.565.565.571.571 0 0 1-.565-.565.563.563 0 0 1 .565-.565z" class="cls-1" transform="translate(286.888 46.159)"/>
                    <path id="Path_48790" d="M24.943 24.536a.5.5 0 0 1 .516.516.51.51 0 1 1-1.019 0 .5.5 0 0 1 .503-.516z" class="cls-1" transform="translate(280.424 42.365)"/>
                    <path id="Path_48791" d="M24.315 24.794a.467.467 0 1 1-.467.467.467.467 0 0 1 .467-.467z" class="cls-1" transform="translate(273.756 39.037)"/>
                    <path id="Path_48792" d="M23.752 25.008a.516.516 0 1 1-.516.516.519.519 0 0 1 .516-.516z" class="cls-1" transform="translate(266.852 36.096)"/>
                    <path id="Path_48793" d="M23.109 25.192a.485.485 0 1 1-.491.479.482.482 0 0 1 .491-.479z" class="cls-1" transform="translate(259.88 33.714)"/>
                    <path id="Path_48794" d="M22.479 25.335a.491.491 0 1 1-.491.491.493.493 0 0 1 .491-.491z" class="cls-1" transform="translate(252.772 31.802)"/>
                    <path id="Path_48795" d="M21.841 25.441a.491.491 0 1 1-.491.491.493.493 0 0 1 .491-.491z" class="cls-1" transform="translate(245.574 30.395)"/>
                    <path id="Path_48796" d="M21.177 25.511a.467.467 0 1 1-.467.467.467.467 0 0 1 .467-.467z" class="cls-1" transform="translate(238.354 29.514)"/>
                    <path id="Path_48797" d="M20.553 25.538a.491.491 0 1 1-.491.491.493.493 0 0 1 .491-.491z" class="cls-1" transform="translate(231.043 29.106)"/>
                    <circle id="Ellipse_10744" cx=".515" cy=".515" r=".515" class="cls-1" transform="translate(243.149 54.742)"/>
                    <path id="Path_48798" d="M19.308 25.476a.545.545 0 0 1 .54.54.537.537 0 0 1-.54.54.53.53 0 0 1-.54-.54.537.537 0 0 1 .54-.54z" class="cls-1" transform="translate(216.445 29.831)"/>
                    <path id="Path_48799" d="M18.6 25.395a.467.467 0 1 1-.467.467.467.467 0 0 1 .467-.467z" class="cls-1" transform="translate(209.281 31.055)"/>
                    <path id="Path_48800" d="M17.943 25.272a.442.442 0 0 1 0 .884.442.442 0 1 1 0-.884z" class="cls-1" transform="translate(202.151 32.737)"/>
                    <path id="Path_48801" d="M17.318 25.11a.43.43 0 0 1 .442.43.442.442 0 1 1-.884 0 .43.43 0 0 1 .442-.43z" class="cls-1" transform="translate(195.1 34.901)"/>
                    <path id="Path_48802" d="M16.7 24.91a.442.442 0 0 1 0 .884.442.442 0 1 1 0-.884z" class="cls-1" transform="translate(188.161 37.545)"/>
                    <path id="Path_48803" d="M16.147 24.67a.491.491 0 1 1-.491.491.493.493 0 0 1 .491-.491z" class="cls-1" transform="translate(181.336 40.635)"/>
                    <path id="Path_48804" d="M15.561 24.4a.491.491 0 1 1-.491.491.493.493 0 0 1 .491-.491z" class="cls-1" transform="translate(174.725 44.248)"/>
                    <path id="Path_48805" d="M15.037 24.088a.54.54 0 0 1 0 1.081.54.54 0 0 1 0-1.081z" class="cls-1" transform="translate(168.26 48.267)"/>
                    <path id="Path_48806" d="M14.533 23.744a.59.59 0 0 1 .59.59.6.6 0 0 1-.59.59.59.59 0 0 1-.59-.59.582.582 0 0 1 .59-.59z" class="cls-1" transform="translate(162.01 52.737)"/>
                    <circle id="Ellipse_10745" cx=".613" cy=".613" r=".613" class="cls-1" transform="translate(169.44 81.022)"/>
                    <path id="Path_48807" d="M13.566 22.964a.657.657 0 1 1-.663.663.668.668 0 0 1 .663-.663z" class="cls-1" transform="translate(150.277 62.962)"/>
                    <circle id="Ellipse_10746" cx=".711" cy=".711" r=".711" class="cls-1" transform="translate(157.239 91.183)"/>
                    <circle id="Ellipse_10747" cx=".76" cy=".76" r=".76" class="cls-1" transform="translate(151.62 96.787)"/>
                    <path id="Path_48808" d="M12.309 21.574a.786.786 0 1 1-.774.786.784.784 0 0 1 .774-.786z" class="cls-1" transform="translate(134.843 81.166)"/>
                    <path id="Path_48809" d="M11.97 21.059a.835.835 0 1 1-.835.835.836.836 0 0 1 .835-.835z" class="cls-1" transform="translate(130.331 87.908)"/>
                    <path id="Path_48810" d="M11.674 20.519a.909.909 0 1 1-.909.909.907.907 0 0 1 .909-.909z" class="cls-1" transform="translate(126.156 94.933)"/>
                    <path id="Path_48811" d="M11.365 19.963a.927.927 0 1 1-.933.933.933.933 0 0 1 .933-.933z" class="cls-1" transform="translate(122.4 102.28)"/>
                    <path id="Path_48812" d="M11.113 19.385a.983.983 0 1 1-.983.983.985.985 0 0 1 .983-.983z" class="cls-1" transform="translate(118.992 109.847)"/>
                    <path id="Path_48813" fill="${widget.color3}" d="M10.895 18.791a1.026 1.026 0 1 1 0 2.051 1.026 1.026 0 1 1 0-2.051z" class="cls-1" transform="translate(115.98 117.65)"/>
                    <path id="Path_48814" fill="${widget.color3}" d="M10.735 18.18a1.1 1.1 0 1 1-1.105 1.093 1.1 1.1 0 0 1 1.105-1.093z" class="cls-1" transform="translate(113.352 125.618)"/>
                    <path id="Path_48815" fill="${widget.color3}" d="M10.568 17.56a1.13 1.13 0 1 1-1.13 1.13 1.127 1.127 0 0 1 1.13-1.13z" class="cls-1" transform="translate(111.185 133.791)"/>
                    <path id="Path_48816" fill="${widget.color3}" d="M10.46 16.929a1.173 1.173 0 1 1-1.179 1.179 1.169 1.169 0 0 1 1.179-1.179z" class="cls-1" transform="translate(109.414 142.086)"/>
                    <path id="Path_48817" fill="${widget.color3}" d="M10.367 16.291a1.2 1.2 0 1 1-1.2 1.191 1.2 1.2 0 0 1 1.2-1.191z" class="cls-1" transform="translate(108.083 150.511)"/>
                    <path id="Path_48818" fill="${widget.color3}" d="M10.357 15.643A1.277 1.277 0 1 1 9.08 16.92a1.284 1.284 0 0 1 1.277-1.277z" class="cls-1" transform="translate(107.147 158.958)"/>
                    <path id="Path_48819" fill="${widget.color3}" d="M10.33 15a1.3 1.3 0 1 1-1.29 1.3 1.3 1.3 0 0 1 1.29-1.3z" class="cls-1" transform="translate(106.695 167.502)"/>
                    <circle id="Ellipse_10748" cx="1.324" cy="1.324" fill="${widget.color3}" r="1.324" class="cls-1" transform="translate(115.707 190.411)"/>
                    <circle id="Ellipse_10749" cx="1.398" cy="1.398" fill="${widget.color3}" r="1.398" class="cls-1" transform="translate(116.107 198.259)"/>
                    <circle id="Ellipse_10750" cx="1.422" cy="1.422" fill="${widget.color3}" r="1.422" class="cls-1" transform="translate(117.031 206.115)"/>
                    <path id="Path_48820" fill="${widget.color3}" d="M10.753 12.412a1.492 1.492 0 1 1-1.5 1.5 1.486 1.486 0 0 1 1.5-1.5z" class="cls-1" transform="translate(109.121 201.441)"/>
                    <path id="Path_48821" fill="${widget.color3}" d="M10.929 11.782a1.517 1.517 0 1 1-1.523 1.511 1.52 1.52 0 0 1 1.523-1.511z" class="cls-1" transform="translate(110.824 209.76)"/>
                    <circle id="Ellipse_10751" fill="${widget.color3}" cx="1.643" cy="1.643" r="1.643" class="cls-1" transform="translate(122.447 228.996)"/>
                    <path id="Path_48822" fill="${widget.color3}" d="M11.4 10.553a1.6 1.6 0 1 1-1.584 1.6 1.593 1.593 0 0 1 1.584-1.6z" class="cls-1" transform="translate(115.473 225.924)"/>
                    <path id="Path_48823" fill="${widget.color3}" d="M11.564 9.973a1.474 1.474 0 1 1-1.474 1.474 1.478 1.478 0 0 1 1.474-1.474z" class="cls-1" transform="translate(118.541 233.873)"/>
                    <path id="Path_48824" fill="${widget.color3}" d="M11.975 9.39a1.591 1.591 0 1 1-1.6 1.6 1.6 1.6 0 0 1 1.6-1.6z" class="cls-1" transform="translate(121.79 241.383)"/>
                    <path id="Path_48825" fill="${widget.color3}" d="M12.441 8.823a1.738 1.738 0 1 1-1.741 1.732 1.732 1.732 0 0 1 1.741-1.732z" class="cls-1" transform="translate(125.389 248.619)"/>
                    <path id="Path_48826" fill="${widget.color3}" d="M12.963 8.275a1.916 1.916 0 1 1-1.916 1.916 1.918 1.918 0 0 1 1.916-1.916z" class="cls-1" transform="translate(129.338 255.541)"/>
                    <path id="Path_48827" fill="${widget.color3}" d="M13.369 7.762a1.934 1.934 0 1 1-1.928 1.928 1.926 1.926 0 0 1 1.928-1.928z" class="cls-1" transform="translate(133.783 262.318)"/>
                    <path id="Path_48828" fill="${widget.color3}" d="M13.694 7.285A1.818 1.818 0 1 1 11.876 9.1a1.811 1.811 0 0 1 1.818-1.815z" class="cls-1" transform="translate(138.691 268.886)"/>
                    <path id="Path_48829" fill="${widget.color3}" d="M14.079 6.831a1.738 1.738 0 1 1-1.744 1.732 1.74 1.74 0 0 1 1.744-1.732z" class="cls-1" transform="translate(143.869 275.076)"/>
                    <path id="Path_48830" fill="${widget.color3}" d="M14.525 6.4a1.713 1.713 0 1 1-1.707 1.72 1.709 1.709 0 0 1 1.707-1.72z" class="cls-1" transform="translate(149.318 280.836)"/>
                    <path id="Path_48831" fill="${widget.color3}" d="M15.11 5.992a1.787 1.787 0 1 1-1.793 1.793 1.785 1.785 0 0 1 1.793-1.793z" class="cls-1" transform="translate(154.948 286.121)"/>
                    <path id="Path_48832" fill="${widget.color3}" d="M15.728 5.612a1.885 1.885 0 1 1-1.891 1.879 1.89 1.89 0 0 1 1.891-1.879z" class="cls-1" transform="translate(160.814 290.972)"/>
                    <path id="Path_48833" fill="${widget.color3}" d="M16.391 5.262a2.014 2.014 0 1 1-2.014 2.014 2.013 2.013 0 0 1 2.014-2.014z" class="cls-1" transform="translate(166.906 295.362)"/>
                    <path id="Path_48834" fill="${widget.color3}" d="M17.254 4.93a2.327 2.327 0 1 1-2.334 2.321 2.327 2.327 0 0 1 2.334-2.321z" class="cls-1" transform="translate(173.032 299.146)"/>
                    <path id="Path_48835" fill="${widget.color3}" d="M18.223 4.624a2.751 2.751 0 1 1-2.751 2.751 2.754 2.754 0 0 1 2.751-2.751z" class="cls-1" transform="translate(179.26 302.363)"/>
                    <circle id="Ellipse_10752" fill="${widget.color3}"  cx="2.746" cy="2.746" r="2.746" class="cls-1" transform="translate(202.124 309.89)"/>
                    <path id="Path_48836" fill="${widget.color3}" d="M19.462 4.187a2.77 2.77 0 1 1-2.776 2.776 2.773 2.773 0 0 1 2.776-2.776z" class="cls-1" transform="translate(192.956 308.13)"/>
                    <path id="Path_48837" fill="${widget.color3}" d="M20.1 4.022a2.794 2.794 0 1 1-2.79 2.788 2.8 2.8 0 0 1 2.79-2.788z" class="cls-1" transform="translate(199.996 310.272)"/>
                    <path id="Path_48838" fill="${widget.color3}" d="M20.732 3.9a2.794 2.794 0 1 1-2.788 2.788A2.789 2.789 0 0 1 20.732 3.9z" class="cls-1" transform="translate(207.149 311.932)"/>
                    <path id="Path_48839" fill="${widget.color3}" d="M21.475 3.8a2.9 2.9 0 1 1-2.9 2.9 2.893 2.893 0 0 1 2.9-2.9z" class="cls-1" transform="translate(214.279 312.985)"/>
                    <circle id="Ellipse_10753" fill="${widget.color3}" cx="2.844" cy="2.844" r="2.844" class="cls-1" transform="translate(240.819 317.433)"/>
                    <circle id="Ellipse_10754" fill="${widget.color3}" cx="2.894" cy="2.894" r="2.894" class="cls-1" transform="translate(248.706 317.502)"/>
                    <path id="Path_48840" fill="${widget.color3}" d="M23.456 3.77a2.942 2.942 0 1 1-2.948 2.948 2.946 2.946 0 0 1 2.948-2.948z" class="cls-1" transform="translate(236.075 313.324)"/>
                    <path id="Path_48841" fill="${widget.color3}" d="M24.131 3.833a2.991 2.991 0 1 1-2.984 2.984 2.99 2.99 0 0 1 2.984-2.984z" class="cls-1" transform="translate(243.284 312.389)"/>
                    <path id="Path_48842" fill="${widget.color3}" d="M24.6 3.955a2.794 2.794 0 1 1-2.8 2.788 2.794 2.794 0 0 1 2.8-2.788z" class="cls-1" transform="translate(250.651 311.162)"/>
                    <path id="Path_48843" fill="${widget.color3}" d="M25.185 4.1a2.745 2.745 0 1 1-2.751 2.751A2.744 2.744 0 0 1 25.185 4.1z" class="cls-1" transform="translate(257.804 309.295)"/>
                    <path id="Path_48844" fill="${widget.color3}" d="M25.737 4.29a2.671 2.671 0 1 1-2.677 2.677 2.676 2.676 0 0 1 2.677-2.677z" class="cls-1" transform="translate(264.866 306.958)"/>
                    <path id="Path_48845" fill="${widget.color3}" d="M26.244 4.516A2.573 2.573 0 1 1 23.677 7.1a2.579 2.579 0 0 1 2.567-2.584z" class="cls-1" transform="translate(271.827 304.153)"/>
                    <path id="Path_48846" fill="${widget.color3}" d="M26.77 4.776a2.5 2.5 0 1 1-2.493 2.505 2.5 2.5 0 0 1 2.493-2.505z" class="cls-1" transform="translate(278.596 300.847)"/>
                    <path id="Path_48847" fill="${widget.color3}" d="M27.371 5.063a2.524 2.524 0 1 1-2.518 2.53 2.526 2.526 0 0 1 2.518-2.53z" class="cls-1" transform="translate(285.095 296.986)"/>
                    <path id="Path_48848" fill="${widget.color3}" d="M27.9 5.39a2.475 2.475 0 1 1-2.481 2.469A2.479 2.479 0 0 1 27.9 5.39z" class="cls-1" transform="translate(291.446 292.741)"/>
                    <circle id="Ellipse_10755" fill="${widget.color3}" cx="2.354" cy="2.354" r="2.354" class="cls-1" transform="translate(323.612 293.878)"/>
                    <circle id="Ellipse_10756" fill="${widget.color3}" cx="2.182" cy="2.182" r="2.182" class="cls-1" transform="translate(330.134 289.29)"/>
                    <circle id="Ellipse_10757" fill="${widget.color3}" cx="2.084" cy="2.084" r="2.084" class="cls-1" transform="translate(336.287 284.257)"/>
                    <circle id="Ellipse_10758" fill="${widget.color3}" cx="2.133" cy="2.133" r="2.133" class="cls-1" transform="translate(341.974 278.724)"/>
                    <circle id="Ellipse_10759" fill="${widget.color3}" cx="2.084" cy="2.084" r="2.084" class="cls-1" transform="translate(347.421 272.955)"/>
                    <path id="Path_48849" fill="${widget.color3}" d="M30.334 8.009a2.008 2.008 0 1 1-2.014 2.014 2.008 2.008 0 0 1 2.014-2.014z" class="cls-1" transform="translate(324.209 258.89)"/>
                    <path id="Path_48850" fill="${widget.color3}" d="M30.624 8.539a1.916 1.916 0 1 1-1.916 1.916 1.918 1.918 0 0 1 1.916-1.916z" class="cls-1" transform="translate(328.586 252.035)"/>
                    <path id="Path_48851" fill="${widget.color3}" d="M31.13 9.07a2.082 2.082 0 1 1-2.088 2.076A2.084 2.084 0 0 1 31.13 9.07z" class="cls-1" transform="translate(332.354 244.65)"/>
                    <path id="Path_48852" fill="${widget.color3}" d="M31.287 9.648a1.916 1.916 0 1 1-1.916 1.916 1.908 1.908 0 0 1 1.916-1.916z" class="cls-1" transform="translate(336.066 237.305)"/>
                    <path id="Path_48853" fill="${widget.color3}" d="M31.5 10.236a1.842 1.842 0 1 1-1.842 1.842 1.84 1.84 0 0 1 1.842-1.842z" class="cls-1" transform="translate(339.293 229.643)"/>
                    <circle id="Ellipse_10760" fill="${widget.color3}" cx="1.937" cy="1.937" r="1.937" class="cls-1" transform="translate(371.864 232.438)"/>
                    <path id="Path_48854" fill="${widget.color3}" d="M32 11.442a1.885 1.885 0 1 1-1.891 1.879A1.89 1.89 0 0 1 32 11.442z" class="cls-1" transform="translate(344.369 213.539)"/>
                    <path id="Path_48855" fill="${widget.color3}" d="M32.1 12.071a1.812 1.812 0 1 1-1.818 1.818 1.811 1.811 0 0 1 1.818-1.818z" class="cls-1" transform="translate(346.378 205.332)"/>
                    <path id="Path_48856" fill="${widget.color3}" d="M32.214 12.7a1.787 1.787 0 1 1-1.793 1.8 1.787 1.787 0 0 1 1.793-1.8z" class="cls-1" transform="translate(347.912 196.96)"/>
                    <path id="Path_48857" fill="${widget.color3}" d="M32.209 13.352a1.689 1.689 0 1 1-1.683 1.695 1.69 1.69 0 0 1 1.683-1.695z" class="cls-1" transform="translate(349.096 188.564)"/>
                    <path id="Path_48858" fill="${widget.color3}" d="M32.188 14a1.6 1.6 0 1 1-1.6 1.6 1.593 1.593 0 0 1 1.6-1.6z" class="cls-1" transform="translate(349.83 180.101)"/>
                    <path id="Path_48859" d="M32.815 14.659a1.474 1.474 0 1 1-1.474 1.474 1.468 1.468 0 0 1 1.474-1.474z" class="cls-1" transform="translate(358.291 171.634)"/>
                    <circle id="Ellipse_10761" cx="1.398" cy="1.398" r="1.398" class="cls-1" transform="translate(389.481 178.436)"/>
                    <path id="Path_48860" d="M32.606 15.961a1.326 1.326 0 1 1-1.326 1.326 1.329 1.329 0 0 1 1.326-1.326z" class="cls-1" transform="translate(357.603 154.636)"/>
                    <circle id="Ellipse_10762" cx="1.299" cy="1.299" r="1.299" class="cls-1" transform="translate(387.803 162.768)"/>
                    <circle id="Ellipse_10763" cx="1.201" cy="1.201" r="1.201" class="cls-1" transform="translate(386.353 155.082)"/>
                    <path id="Path_48861" d="M32.059 17.874a1.155 1.155 0 1 1-1.142 1.154 1.153 1.153 0 0 1 1.142-1.154z" class="cls-1" transform="translate(353.508 129.572)"/>
                    <path id="Path_48862" d="M31.852 18.492a1.13 1.13 0 1 1-1.13 1.13 1.135 1.135 0 0 1 1.13-1.13z" class="cls-1" transform="translate(351.308 121.413)"/>
                    <path id="Path_48863" d="M31.532 19.1a1.026 1.026 0 1 1 0 2.051 1.026 1.026 0 1 1 0-2.051z" class="cls-1" transform="translate(348.803 113.493)"/>
                    <circle id="Ellipse_10764" cx=".883" cy=".883" r=".883" class="cls-1" transform="translate(376.207 125.496)"/>
                    <circle id="Ellipse_10765" cx=".785" cy=".785" r=".785" class="cls-1" transform="translate(372.662 118.543)"/>
                    <circle id="Ellipse_10766" cx=".785" cy=".785" r=".785" class="cls-1" transform="translate(368.63 111.707)"/>
                    <path id="Path_48864" d="M30.013 21.385a.737.737 0 1 1-.737.737.739.739 0 0 1 .737-.737z" class="cls-1" transform="translate(334.994 83.774)"/>
                    <path id="Path_48865" d="M29.534 21.91a.642.642 0 0 1 .639.639.634.634 0 0 1-.639.639.642.642 0 0 1-.639-.639.65.65 0 0 1 .639-.639z" class="cls-1" transform="translate(330.696 76.998)"/>
                    <path id="Path_48866" d="M29.072 22.407a.582.582 0 0 1 .59.59.59.59 0 0 1-.59.59.6.6 0 0 1-.59-.59.59.59 0 0 1 .59-.59z" class="cls-1" transform="translate(326.036 70.495)"/>
                    <path id="Path_48867" d="M28.661 22.873a.639.639 0 1 1-.626.639.634.634 0 0 1 .626-.639z" class="cls-1" transform="translate(320.993 64.208)"/>
                    <path id="Path_48868" d="M28.159 23.321a.6.6 0 0 1 .59.59.59.59 0 0 1-.59.59.582.582 0 0 1-.59-.59.59.59 0 0 1 .59-.59z" class="cls-1" transform="translate(315.736 58.356)"/>
                    <path id="Path_48869" d="M27.642 23.74a.563.563 0 0 1 .565.565.556.556 0 0 1-.565.565.563.563 0 0 1-.565-.565.571.571 0 0 1 .565-.565z" class="cls-1" transform="translate(310.185 52.84)"/>
                    <path id="Path_48870" d="M27.1 24.13a.54.54 0 1 1-.54.54.545.545 0 0 1 .54-.54z" class="cls-1" transform="translate(304.387 47.709)"/>
                    <path id="Path_48871" d="M26.544 24.491a.516.516 0 0 1 0 1.032.516.516 0 0 1 0-1.032z" class="cls-1" transform="translate(298.351 42.963)"/>
                    <path id="Path_48872" d="M25.987 24.82a.51.51 0 1 1-.516.516.511.511 0 0 1 .516-.516z" class="cls-1" transform="translate(292.067 38.606)"/>
                    <path id="Path_48873" d="M25.39 25.118a.491.491 0 1 1-.491.491.493.493 0 0 1 .491-.491z" class="cls-1" transform="translate(285.614 34.685)"/>
                    <path id="Path_48874" d="M24.8 25.382a.491.491 0 1 1-.491.491.493.493 0 0 1 .491-.491z" class="cls-1" transform="translate(278.957 31.178)"/>
                    <path id="Path_48875" d="M24.174 25.615a.461.461 0 1 1-.467.467.467.467 0 0 1 .467-.467z" class="cls-1" transform="translate(272.166 28.145)"/>
                    <path id="Path_48876" d="M23.559 25.811a.467.467 0 1 1-.467.467.467.467 0 0 1 .467-.467z" class="cls-1" transform="translate(265.227 25.529)"/>
                    <path id="Path_48877" d="M22.933 25.972a.467.467 0 1 1-.467.467.466.466 0 0 1 .467-.467z" class="cls-1" transform="translate(258.165 23.391)"/>
                    <path id="Path_48878" d="M22.3 26.1a.467.467 0 1 1-.467.467.467.467 0 0 1 .467-.467z" class="cls-1" transform="translate(251.012 21.718)"/>
                    <path id="Path_48879" d="M21.636 26.191a.436.436 0 1 1 0 .872.436.436 0 1 1 0-.872z" class="cls-1" transform="translate(243.814 20.544)"/>
                    <path id="Path_48880" d="M20.971 26.247a.418.418 0 1 1-.418.418.412.412 0 0 1 .418-.418z" class="cls-1" transform="translate(236.583 19.837)"/>
                    <path id="Path_48881" d="M20.3 26.267a.393.393 0 1 1 0 .786.393.393 0 1 1 0-.786z" class="cls-1" transform="translate(229.317 19.62)"/>
                    <path id="Path_48882" d="M19.679 26.247a.418.418 0 1 1 0 .835.418.418 0 0 1 0-.835z" class="cls-1" transform="translate(222.007 19.837)"/>
                    <path id="Path_48883" d="M19.035 26.193a.411.411 0 1 1-.418.418.414.414 0 0 1 .418-.418z" class="cls-1" transform="translate(214.741 20.566)"/>
                    <path id="Path_48884" d="M18.372 26.1a.388.388 0 0 1 .393.393.393.393 0 0 1-.786 0 .388.388 0 0 1 .393-.393z" class="cls-1" transform="translate(207.543 21.785)"/>
                    <path id="Path_48885" d="M17.715 25.98a.362.362 0 0 1 .368.368.37.37 0 0 1-.368.368.378.378 0 0 1-.368-.368.369.369 0 0 1 .368-.368z" class="cls-1" transform="translate(200.413 23.481)"/>
                    <path id="Path_48886" d="M17.1 25.817a.4.4 0 0 1 .393.393.387.387 0 1 1-.774 0 .393.393 0 0 1 .381-.393z" class="cls-1" transform="translate(193.34 25.597)"/>
                    <path id="Path_48887" d="M16.5 25.621a.387.387 0 1 1 0 .774.387.387 0 1 1 0-.774z" class="cls-1" transform="translate(186.39 28.213)"/>
                    <path id="Path_48888" d="M15.916 25.388a.418.418 0 1 1-.418.418.414.414 0 0 1 .418-.418z" class="cls-1" transform="translate(179.553 31.246)"/>
                    <path id="Path_48889" d="M15.371 25.12a.467.467 0 1 1-.467.467.466.466 0 0 1 .467-.467z" class="cls-1" transform="translate(172.852 34.707)"/>
                    <path id="Path_48890" d="M14.819 24.822a.485.485 0 1 1-.491.491.485.485 0 0 1 .491-.491z" class="cls-1" transform="translate(166.354 38.628)"/>
                    <path id="Path_48891" d="M14.286 24.491a.516.516 0 0 1 0 1.032.516.516 0 0 1 0-1.032z" class="cls-1" transform="translate(160.058 42.963)"/>
                    <path id="Path_48892" d="M13.793 24.128a.556.556 0 0 1 .565.565.563.563 0 0 1-.565.565.571.571 0 0 1-.565-.565.563.563 0 0 1 .565-.565z" class="cls-1" transform="translate(153.944 47.686)"/>
                    <path id="Path_48893" d="M13.3 23.738a.6.6 0 0 1 .59.59.59.59 0 0 1-1.179 0 .6.6 0 0 1 .589-.59z" class="cls-1" transform="translate(148.1 52.817)"/>
                    <path id="Path_48894" d="M12.851 23.317a.642.642 0 0 1 .639.639.634.634 0 0 1-.639.639.642.642 0 0 1-.639-.639.65.65 0 0 1 .639-.639z" class="cls-1" transform="translate(142.481 58.31)"/>
                    <circle id="Ellipse_10767" cx=".687" cy=".687" r=".687" class="cls-1" transform="translate(148.883 87.035)"/>
                    <path id="Path_48895" d="M12.05 22.393a.757.757 0 0 1 .761.761.761.761 0 1 1-1.523 0 .757.757 0 0 1 .762-.761z" class="cls-1" transform="translate(132.068 70.337)"/>
                    <path id="Path_48896" d="M11.656 21.9a.78.78 0 1 1-.786.774.781.781 0 0 1 .786-.774z" class="cls-1" transform="translate(127.341 76.875)"/>
                    <path id="Path_48897" d="M11.29 21.379a.811.811 0 1 1 0 1.621.811.811 0 1 1 0-1.621z" class="cls-1" transform="translate(122.93 83.707)"/>
                    <path id="Path_48898" d="M11 20.836a.884.884 0 1 1-.884.884.881.881 0 0 1 .884-.884z" class="cls-1" transform="translate(118.812 90.771)"/>
                    <path id="Path_48899" d="M10.715 20.275a.933.933 0 1 1-.933.933.933.933 0 0 1 .933-.933z" class="cls-1" transform="translate(115.066 98.124)"/>
                    <path id="Path_48900" d="M10.475 19.695A1.007 1.007 0 1 1 9.48 20.7a1 1 0 0 1 .995-1.005z" class="cls-1" transform="translate(111.659 105.68)"/>
                    <path id="Path_48901" d="M10.268 19.1a1.05 1.05 0 1 1-1.056 1.056 1.046 1.046 0 0 1 1.056-1.056z" class="cls-1" transform="translate(108.636 113.47)"/>
                    <path id="Path_48902" d="M10.082 18.494A1.105 1.105 0 1 1 8.977 19.6a1.109 1.109 0 0 1 1.105-1.106z" class="cls-1" transform="translate(105.985 121.435)"/>
                    <path id="Path_48903" d="M9.909 17.876a1.13 1.13 0 1 1-1.13 1.13 1.127 1.127 0 0 1 1.13-1.13z" class="cls-1" transform="translate(103.751 129.594)"/>
                    <path id="Path_48904" d="M9.781 17.247a1.173 1.173 0 1 1 0 2.346 1.173 1.173 0 0 1 0-2.346z" class="cls-1" transform="translate(101.889 137.863)"/>
                    <path id="Path_48905" d="M9.677 16.611A1.2 1.2 0 1 1 8.486 17.8a1.2 1.2 0 0 1 1.191-1.189z" class="cls-1" transform="translate(100.445 146.261)"/>
                    <circle id="Ellipse_10768" cx="1.25" cy="1.25" r="1.25" class="cls-1" transform="translate(107.768 170.675)"/>
                    <circle id="Ellipse_10769" cx="1.349" cy="1.349" r="1.349" class="cls-1" transform="translate(107.003 178.486)"/>
                    <path id="Path_48906" d="M9.662 14.669a1.351 1.351 0 1 1-1.351 1.351 1.345 1.345 0 0 1 1.351-1.351z" class="cls-1" transform="translate(98.471 171.747)"/>
                    <circle id="Ellipse_10770" cx="1.398" cy="1.398" r="1.398" class="cls-1" transform="translate(106.954 194.303)"/>
                    <circle id="Ellipse_10771" cx="1.447" cy="1.447" r="1.447" class="cls-1" transform="translate(107.572 202.162)"/>
                    <path id="Path_48907" d="M9.926 12.729A1.474 1.474 0 1 1 8.464 14.2a1.47 1.47 0 0 1 1.462-1.471z" class="cls-1" transform="translate(100.197 197.268)"/>
                    <circle id="Ellipse_10772" cx="1.545" cy="1.545" r="1.545" class="cls-1" transform="translate(110.131 217.706)"/>
                    <circle id="Ellipse_10773" cx="1.594" cy="1.594" r="1.594" class="cls-1" transform="translate(112.064 225.342)"/>
                    <path id="Path_48908" d="M10.534 10.844a1.6 1.6 0 1 1-1.6 1.6 1.593 1.593 0 0 1 1.6-1.6z" class="cls-1" transform="translate(105.533 222.059)"/>
                    <path id="Path_48909" d="M10.7 10.247a1.517 1.517 0 1 1-1.526 1.523 1.512 1.512 0 0 1 1.526-1.523z" class="cls-1" transform="translate(108.207 230.147)"/>
                    <circle id="Ellipse_10774" cx="1.496" cy="1.496" r="1.496" class="cls-1" transform="translate(120.644 247.66)"/>
                    <path id="Path_48910" d="M11.415 9.069a1.689 1.689 0 1 1-1.695 1.695 1.69 1.69 0 0 1 1.695-1.695z" class="cls-1" transform="translate(114.367 245.45)"/>
                    <path id="Path_48911" d="M11.777 8.508a1.744 1.744 0 1 1-1.732 1.744 1.743 1.743 0 0 1 1.732-1.744z" class="cls-1" transform="translate(118.033 252.79)"/>
                    <path id="Path_48912" d="M12.091 7.975a1.689 1.689 0 1 1-1.683 1.683 1.688 1.688 0 0 1 1.683-1.683z" class="cls-1" transform="translate(122.129 259.98)"/>
                    <path id="Path_48913" d="M12.491 7.459A1.689 1.689 0 1 1 10.8 9.154a1.7 1.7 0 0 1 1.691-1.695z" class="cls-1" transform="translate(126.506 266.833)"/>
                    <path id="Path_48914" d="M12.976 6.959a1.762 1.762 0 1 1-1.769 1.756 1.766 1.766 0 0 1 1.769-1.756z" class="cls-1" transform="translate(131.143 273.327)"/>
                    <path id="Path_48915" d="M13.42 6.489a1.769 1.769 0 1 1-1.769 1.769 1.766 1.766 0 0 1 1.769-1.769z" class="cls-1" transform="translate(136.152 279.557)"/>
                    <path id="Path_48916" d="M13.9 6.043a1.793 1.793 0 1 1-1.781 1.793A1.787 1.787 0 0 1 13.9 6.043z" class="cls-1" transform="translate(141.432 285.432)"/>
                    <path id="Path_48917" d="M14.473 5.62a1.867 1.867 0 1 1-1.867 1.867 1.866 1.866 0 0 1 1.867-1.867z" class="cls-1" transform="translate(146.926 290.902)"/>
                    <path id="Path_48918" d="M15.09 5.222A1.984 1.984 0 1 1 13.113 7.2a1.979 1.979 0 0 1 1.977-1.978z" class="cls-1" transform="translate(152.646 295.955)"/>
                    <circle id="Ellipse_10775" cx="2.158" cy="2.158" r="2.158" class="cls-1" transform="translate(172.181 305.41)"/>
                    <path id="Path_48919" d="M16.579 4.5a2.4 2.4 0 1 1-2.407 2.407A2.411 2.411 0 0 1 16.579 4.5z" class="cls-1" transform="translate(164.594 304.696)"/>
                    <circle id="Ellipse_10776" cx="2.673" cy="2.673" r="2.673" class="cls-1" transform="translate(185.554 312.57)"/>
                    <circle id="Ellipse_10777" cx="2.746" cy="2.746" r="2.746" class="cls-1" transform="translate(192.724 315.737)"/>
                    <path id="Path_48920" d="M18.618 3.686a2.7 2.7 0 1 1-2.7 2.7 2.692 2.692 0 0 1 2.7-2.7z" class="cls-1" transform="translate(184.269 314.931)"/>
                    <circle id="Ellipse_10778" cx="2.869" cy="2.869" r="2.869" class="cls-1" transform="translate(207.577 320.855)"/>
                    <circle id="Ellipse_10779" cx="2.967" cy="2.967" r="2.967" class="cls-1" transform="translate(215.164 322.739)"/>
                    <path id="Path_48921" d="M20.741 3.18a2.966 2.966 0 1 1-2.972 2.96 2.972 2.972 0 0 1 2.972-2.96z" class="cls-1" transform="translate(205.174 321.112)"/>
                    <path id="Path_48922" d="M21.4 3.088a2.991 2.991 0 1 1-3 3 2.99 2.99 0 0 1 3-3z" class="cls-1" transform="translate(212.372 322.284)"/>
                    <circle id="Ellipse_10780" cx="2.992" cy="2.992" r="2.992" class="cls-1" transform="translate(238.69 326.039)"/>
                    <path id="Path_48923" d="M22.761 3.009a3.064 3.064 0 1 1-3.07 3.058 3.058 3.058 0 0 1 3.07-3.058z" class="cls-1" transform="translate(226.858 323.186)"/>
                    <circle id="Ellipse_10781" cx="2.992" cy="2.992" r="2.992" class="cls-1" transform="translate(254.557 326.039)"/>
                    <path id="Path_48924" d="M24.039 3.082a3.064 3.064 0 1 1-3.058 3.07 3.072 3.072 0 0 1 3.058-3.07z" class="cls-1" transform="translate(241.411 322.217)"/>
                    <circle id="Ellipse_10782" cx="2.992" cy="2.992" r="2.992" class="cls-1" transform="translate(270.323 324.263)"/>
                    <circle id="Ellipse_10783" cx="2.894" cy="2.894" r="2.894" class="cls-1" transform="translate(278.205 322.813)"/>
                    <path id="Path_48925" d="M25.725 3.48A2.819 2.819 0 1 1 22.9 6.3a2.815 2.815 0 0 1 2.825-2.82z" class="cls-1" transform="translate(263.061 317.422)"/>
                    <path id="Path_48926" d="M26.171 3.69a2.647 2.647 0 1 1-2.641 2.653 2.65 2.65 0 0 1 2.641-2.653z" class="cls-1" transform="translate(270.169 314.977)"/>
                    <path id="Path_48927" d="M26.7 3.928a2.548 2.548 0 1 1-2.559 2.542A2.55 2.55 0 0 1 26.7 3.928z" class="cls-1" transform="translate(277.062 312.012)"/>
                    <path id="Path_48928" d="M27.263 4.194a2.524 2.524 0 1 1-2.53 2.518 2.524 2.524 0 0 1 2.53-2.518z" class="cls-1" transform="translate(283.741 308.528)"/>
                    <circle id="Ellipse_10784" cx="2.599" cy="2.599" r="2.599" class="cls-1" transform="translate(315.456 309.001)"/>
                    <path id="Path_48929" d="M28.349 4.823a2.475 2.475 0 1 1-2.481 2.469 2.469 2.469 0 0 1 2.481-2.469z" class="cls-1" transform="translate(296.546 300.272)"/>
                    <path id="Path_48930" d="M28.863 5.184a2.45 2.45 0 1 1-2.456 2.444 2.453 2.453 0 0 1 2.456-2.444z" class="cls-1" transform="translate(302.627 295.526)"/>
                    <path id="Path_48931" d="M29.345 5.575a2.426 2.426 0 1 1-2.419 2.432 2.437 2.437 0 0 1 2.419-2.432z" class="cls-1" transform="translate(308.482 290.382)"/>
                    <path id="Path_48932" d="M29.738 6a2.309 2.309 0 1 1-2.309 2.31A2.306 2.306 0 0 1 29.738 6z" class="cls-1" transform="translate(314.157 284.958)"/>
                    <circle id="Ellipse_10785" cx="2.109" cy="2.109" r="2.109" class="cls-1" transform="translate(347.552 285.705)"/>
                    <path id="Path_48933" d="M30.437 6.933a2.082 2.082 0 1 1-2.076 2.076 2.084 2.084 0 0 1 2.076-2.076z" class="cls-1" transform="translate(324.671 273.033)"/>
                    <path id="Path_48934" d="M30.831 7.429a2.057 2.057 0 1 1-2.051 2.063 2.06 2.06 0 0 1 2.051-2.063z" class="cls-1" transform="translate(329.398 266.495)"/>
                    <circle id="Ellipse_10786" cx="2.035" cy="2.035" r="2.035" class="cls-1" transform="translate(362.971 267.606)"/>
                    <path id="Path_48935" d="M31.568 8.484a2.039 2.039 0 1 1-2.039 2.039 2.05 2.05 0 0 1 2.039-2.039z" class="cls-1" transform="translate(337.848 252.519)"/>
                    <circle id="Ellipse_10787" cx="1.986" cy="1.986" r="1.986" class="cls-1" transform="translate(371.461 254.221)"/>
                    <path id="Path_48936" d="M31.967 9.635a1.787 1.787 0 1 1-1.793 1.781 1.793 1.793 0 0 1 1.793-1.781z" class="cls-1" transform="translate(345.125 237.736)"/>
                    <path id="Path_48937" d="M32.141 10.233a1.689 1.689 0 1 1-1.695 1.695 1.68 1.68 0 0 1 1.695-1.695z" class="cls-1" transform="translate(348.194 229.99)"/>
                    <path id="Path_48938" d="M32.371 10.836a1.695 1.695 0 1 1-1.695 1.695 1.7 1.7 0 0 1 1.695-1.695z" class="cls-1" transform="translate(350.789 221.968)"/>
                    <path id="Path_48939" d="M32.714 11.438a1.867 1.867 0 1 1-1.855 1.862 1.866 1.866 0 0 1 1.855-1.862z" class="cls-1" transform="translate(352.853 213.629)"/>
                    <path id="Path_48940" d="M32.684 12.082a1.64 1.64 0 1 1-1.646 1.646 1.646 1.646 0 0 1 1.646-1.646z" class="cls-1" transform="translate(354.873 205.53)"/>
                    <path id="Path_48941" d="M32.832 12.713a1.67 1.67 0 1 1-1.67 1.67 1.672 1.672 0 0 1 1.67-1.67z" class="cls-1" transform="translate(356.272 197.087)"/>
                    <path id="Path_48942" d="M32.832 13.361a1.572 1.572 0 1 1 0 3.144 1.572 1.572 0 1 1 0-3.144z" class="cls-1" transform="translate(357.377 188.677)"/>
                    <circle id="Ellipse_10788" cx="1.545" cy="1.545" r="1.545" class="cls-1" transform="translate(389.334 194.156)"/>
                    <path id="Path_48943" d="M33.467 14.665a1.4 1.4 0 1 1-1.4 1.4 1.4 1.4 0 0 1 1.4-1.4z" class="cls-1" transform="translate(366.482 171.702)"/>
                    <path id="Path_48944" d="M33.405 15.315a1.351 1.351 0 1 1-1.351 1.351 1.344 1.344 0 0 1 1.351-1.351z" class="cls-1" transform="translate(366.335 163.167)"/>
                    <path id="Path_48945" d="M33.251 15.967a1.253 1.253 0 1 1-1.24 1.253 1.25 1.25 0 0 1 1.24-1.253z" class="cls-1" transform="translate(365.85 154.704)"/>
                    <path id="Path_48946" d="M33.144 16.61a1.228 1.228 0 1 1 0 2.456 1.228 1.228 0 0 1 0-2.456z" class="cls-1" transform="translate(364.914 146.212)"/>
                    <path id="Path_48947" d="M32.947 17.253a1.13 1.13 0 1 1-1.13 1.13 1.124 1.124 0 0 1 1.13-1.13z" class="cls-1" transform="translate(363.661 137.869)"/>
                    <path id="Path_48948" d="M32.75 17.885a1.081 1.081 0 1 1-1.081 1.081 1.08 1.08 0 0 1 1.081-1.081z" class="cls-1" transform="translate(361.992 129.573)"/>
                    <path id="Path_48949" d="M32.565 18.5a1.081 1.081 0 1 1-1.081 1.081 1.072 1.072 0 0 1 1.081-1.081z" class="cls-1" transform="translate(359.904 121.351)"/>
                    <path id="Path_48950" d="M32.279 19.119a1 1 0 1 1-1.007.995 1 1 0 0 1 1.007-.995z" class="cls-1" transform="translate(357.513 113.343)"/>
                    <path id="Path_48951" d="M31.872 19.729a.835.835 0 0 1 0 1.67.835.835 0 0 1 0-1.67z" class="cls-1" transform="translate(354.861 105.573)"/>
                    <path id="Path_48952" d="M31.535 20.315a.786.786 0 1 1-.774.786.784.784 0 0 1 .774-.786z" class="cls-1" transform="translate(351.748 97.888)"/>
                    <circle id="Ellipse_10789" cx=".76" cy=".76" r=".76" class="cls-1" transform="translate(378.712 111.271)"/>
                    <circle id="Ellipse_10790" cx=".711" cy=".711" r=".711" class="cls-1" transform="translate(374.583 104.572)"/>
                    <circle id="Ellipse_10791" cx=".662" cy=".662" r=".662" class="cls-1" transform="translate(370.104 98.103)"/>
                    <circle id="Ellipse_10792" cx=".564" cy=".564" r=".564" class="cls-1" transform="translate(365.336 91.932)"/>
                    <circle id="Ellipse_10793" cx=".564" cy=".564" r=".564" class="cls-1" transform="translate(360.146 85.927)"/>
                    <path id="Path_48953" d="M29.034 23.447a.54.54 0 0 1 0 1.081.54.54 0 1 1 0-1.081z" class="cls-1" transform="translate(326.172 56.78)"/>
                    <path id="Path_48954" d="M28.563 23.889a.534.534 0 1 1-.54.54.527.527 0 0 1 .54-.54z" class="cls-1" transform="translate(320.858 50.922)"/>
                    <path id="Path_48955" d="M28.023 24.309a.491.491 0 1 1-.491.491.493.493 0 0 1 .491-.491z" class="cls-1" transform="translate(315.319 45.43)"/>
                    <path id="Path_48956" d="M27.473 24.7a.467.467 0 1 1 0 .933.467.467 0 0 1 0-.933z" class="cls-1" transform="translate(309.531 40.286)"/>
                    <path id="Path_48957" d="M26.95 25.062a.467.467 0 1 1-.467.467.467.467 0 0 1 .467-.467z" class="cls-1" transform="translate(303.484 35.478)"/>
                    <path id="Path_48958" d="M26.4 25.395a.467.467 0 1 1-.467.467.466.466 0 0 1 .467-.467z" class="cls-1" transform="translate(297.234 31.055)"/>
                    <path id="Path_48959" d="M25.836 25.7a.491.491 0 1 1 0 .983.491.491 0 0 1 0-.983z" class="cls-1" transform="translate(290.781 27.008)"/>
                    <path id="Path_48960" d="M25.24 25.971a.461.461 0 1 1-.467.467.467.467 0 0 1 .467-.467z" class="cls-1" transform="translate(284.192 23.417)"/>
                    <circle id="Ellipse_10794" cx=".465" cy=".465" r=".465" class="cls-1" transform="translate(301.6 46.419)"/>
                    <path id="Path_48961" d="M24.029 26.421a.467.467 0 1 1-.467.467.466.466 0 0 1 .467-.467z" class="cls-1" transform="translate(270.53 17.428)"/>
                    <path id="Path_48962" d="M23.384 26.6a.442.442 0 1 1-.442.442.44.44 0 0 1 .442-.442z" class="cls-1" transform="translate(263.535 15.099)"/>
                    <path id="Path_48963" d="M22.754 26.744a.442.442 0 1 1-.442.442.44.44 0 0 1 .442-.442z" class="cls-1" transform="translate(256.428 13.187)"/>
                    <path id="Path_48964" d="M22.073 26.858a.4.4 0 0 1 .393.393.4.4 0 0 1-.393.393.4.4 0 0 1-.393-.393.388.388 0 0 1 .393-.393z" class="cls-1" transform="translate(249.297 11.771)"/>
                    <path id="Path_48965" d="M21.408 26.937a.369.369 0 0 1 .368.368.368.368 0 0 1-.737 0 .369.369 0 0 1 .369-.368z" class="cls-1" transform="translate(242.077 10.771)"/>
                    <path id="Path_48966" d="M20.718 26.983a.31.31 0 0 1 .319.319.317.317 0 0 1-.319.319.325.325 0 0 1-.318-.321.317.317 0 0 1 .318-.317z" class="cls-1" transform="translate(234.845 10.258)"/>
                    <path id="Path_48967" d="M20.072 26.992a.319.319 0 1 1-.319.319.325.325 0 0 1 .319-.319z" class="cls-1" transform="translate(227.557 10.138)"/>
                    <path id="Path_48968" d="M19.426 26.966a.31.31 0 0 1 .319.319.317.317 0 0 1-.319.319.325.325 0 0 1-.319-.319.317.317 0 0 1 .319-.319z" class="cls-1" transform="translate(220.269 10.484)"/>
                    <path id="Path_48969" d="M18.806 26.9a.351.351 0 0 1 .344.344.343.343 0 0 1-.344.344.336.336 0 0 1-.344-.344.343.343 0 0 1 .344-.344z" class="cls-1" transform="translate(212.993 11.245)"/>
                    <path id="Path_48970" d="M18.144 26.813a.307.307 0 0 1 .307.319.313.313 0 1 1-.626 0 .31.31 0 0 1 .319-.319z" class="cls-1" transform="translate(205.806 12.516)"/>
                    <path id="Path_48971" d="M17.51 26.686a.319.319 0 1 1-.319.319.325.325 0 0 1 .319-.319z" class="cls-1" transform="translate(198.653 14.203)"/>
                    <path id="Path_48972" d="M16.884 26.526a.325.325 0 0 1 .319.319.319.319 0 1 1-.639 0 .325.325 0 0 1 .32-.319z" class="cls-1" transform="translate(191.591 16.328)"/>
                    <path id="Path_48973" d="M16.29 26.331a.338.338 0 1 1 0 .675.338.338 0 1 1 0-.675z" class="cls-1" transform="translate(184.608 18.881)"/>
                    <path id="Path_48974" d="M15.707 26.1a.368.368 0 1 1 0 .737.368.368 0 1 1 0-.737z" class="cls-1" transform="translate(177.759 21.848)"/>
                    <path id="Path_48975" d="M15.16 25.842a.418.418 0 1 1-.418.418.414.414 0 0 1 .418-.418z" class="cls-1" transform="translate(171.024 25.216)"/>
                    <path id="Path_48976" d="M14.6 25.552a.442.442 0 1 1 0 .884.442.442 0 0 1 0-.884z" class="cls-1" transform="translate(164.469 29.019)"/>
                    <path id="Path_48977" d="M14.064 25.232a.467.467 0 1 1-.467.467.466.466 0 0 1 .467-.467z" class="cls-1" transform="translate(158.107 33.22)"/>
                    <path id="Path_48978" d="M13.541 24.882a.491.491 0 1 1-.491.491.493.493 0 0 1 .491-.491z" class="cls-1" transform="translate(151.935 37.819)"/>
                    <path id="Path_48979" d="M13.06 24.5a.537.537 0 0 1 .54.54.53.53 0 0 1-.54.54.537.537 0 0 1-.54-.54.545.545 0 0 1 .54-.54z" class="cls-1" transform="translate(145.956 42.755)"/>
                    <circle id="Ellipse_10795" cx=".588" cy=".588" r=".588" class="cls-1" transform="translate(152.228 72.162)"/>
                    <circle id="Ellipse_10796" cx=".637" cy=".637" r=".637" class="cls-1" transform="translate(146.243 77.382)"/>
                    <circle id="Ellipse_10797" cx=".687" cy=".687" r=".687" class="cls-1" transform="translate(140.546 82.907)"/>
                    <path id="Path_48980" d="M11.358 22.723a.737.737 0 1 1-.737.737.739.739 0 0 1 .737-.737z" class="cls-1" transform="translate(124.532 66.003)"/>
                    <circle id="Ellipse_10798" cx=".785" cy=".785" r=".785" class="cls-1" transform="translate(130.071 94.813)"/>
                    <path id="Path_48981" d="M10.656 21.695a.835.835 0 1 1-.835.835.834.834 0 0 1 .835-.835z" class="cls-1" transform="translate(115.506 79.461)"/>
                    <circle id="Ellipse_10799" cx=".883" cy=".883" r=".883" class="cls-1" transform="translate(120.919 107.746)"/>
                    <path id="Path_48982" d="M10.077 20.586a.958.958 0 0 1 0 1.916.958.958 0 0 1 0-1.916z" class="cls-1" transform="translate(107.722 93.944)"/>
                    <path id="Path_48983" d="M9.838 20.008a1.007 1.007 0 1 1-1.007 1.007 1.012 1.012 0 0 1 1.007-1.007z" class="cls-1" transform="translate(104.337 101.523)"/>
                    <path id="Path_48984" d="M9.618 19.414a1.056 1.056 0 1 1-1.056 1.056 1.056 1.056 0 0 1 1.056-1.056z" class="cls-1" transform="translate(101.303 109.314)"/>
                    <path id="Path_48985" d="M9.418 18.808a1.105 1.105 0 1 1-1.093 1.105 1.109 1.109 0 0 1 1.093-1.105z" class="cls-1" transform="translate(98.629 117.265)"/>
                    <path id="Path_48986" d="M9.228 18.194a1.1 1.1 0 1 1-1.105 1.093 1.1 1.1 0 0 1 1.105-1.093z" class="cls-1" transform="translate(96.35 125.432)"/>
                    <path id="Path_48987" d="M9.093 17.566a1.155 1.155 0 1 1-1.142 1.154 1.153 1.153 0 0 1 1.142-1.154z" class="cls-1" transform="translate(94.409 133.662)"/>
                    <path id="Path_48988" d="M9.015 16.93a1.2 1.2 0 1 1-1.2 1.2 1.206 1.206 0 0 1 1.2-1.2z" class="cls-1" transform="translate(92.83 142.011)"/>
                    <path id="Path_48989" d="M8.98 16.286a1.277 1.277 0 1 1-1.28 1.277 1.284 1.284 0 0 1 1.28-1.277z" class="cls-1" transform="translate(91.611 150.418)"/>
                    <path id="Path_48990" d="M8.957 15.64a1.32 1.32 0 1 1-1.326 1.326 1.321 1.321 0 0 1 1.326-1.326z" class="cls-1" transform="translate(90.799 158.912)"/>
                    <path id="Path_48991" d="M8.946 14.992a1.351 1.351 0 1 1-1.351 1.351 1.347 1.347 0 0 1 1.351-1.351z" class="cls-1" transform="translate(90.393 167.457)"/>
                    <circle id="Ellipse_10800" cx="1.398" cy="1.398" r="1.398" class="cls-1" transform="translate(97.94 190.337)"/>
                    <circle id="Ellipse_10801" cx="1.447" cy="1.447" r="1.447" class="cls-1" transform="translate(98.31 198.214)"/>
                    <circle id="Ellipse_10802" cx="1.471" cy="1.471" r="1.471" class="cls-1" transform="translate(99.122 206.082)"/>
                    <path id="Path_48992" d="M9.308 12.406a1.523 1.523 0 1 1-1.523 1.523 1.531 1.531 0 0 1 1.523-1.523z" class="cls-1" transform="translate(92.537 201.46)"/>
                    <circle id="Ellipse_10803" cx="1.545" cy="1.545" r="1.545" class="cls-1" transform="translate(101.964 221.606)"/>
                    <path id="Path_48993" d="M9.657 11.146a1.572 1.572 0 0 1 0 3.144 1.572 1.572 0 1 1 0-3.144z" class="cls-1" transform="translate(95.921 218.097)"/>
                    <path id="Path_48994" d="M9.824 10.534a1.548 1.548 0 1 1-1.535 1.548 1.541 1.541 0 0 1 1.535-1.548z" class="cls-1" transform="translate(98.223 226.274)"/>
                    <circle id="Ellipse_10804" cx="1.594" cy="1.594" r="1.594" class="cls-1" transform="translate(109.325 244.16)"/>
                    <circle id="Ellipse_10805" cx="1.57" cy="1.57" r="1.57" class="cls-1" transform="translate(112.603 251.424)"/>
                    <path id="Path_48995" d="M10.731 8.758a1.664 1.664 0 1 1-1.658 1.658 1.662 1.662 0 0 1 1.658-1.658z" class="cls-1" transform="translate(107.068 249.629)"/>
                    <path id="Path_48996" d="M11.159 8.192A1.762 1.762 0 1 1 9.39 9.961a1.769 1.769 0 0 1 1.769-1.769z" class="cls-1" transform="translate(110.644 256.95)"/>
                    <path id="Path_48997" d="M11.6 7.643A1.867 1.867 0 1 1 9.737 9.51 1.863 1.863 0 0 1 11.6 7.643z" class="cls-1" transform="translate(114.559 264.033)"/>
                    <path id="Path_48998" d="M11.963 7.125a1.836 1.836 0 1 1-1.842 1.842 1.84 1.84 0 0 1 1.842-1.842z" class="cls-1" transform="translate(118.891 270.975)"/>
                    <path id="Path_48999" d="M12.351 6.627a1.812 1.812 0 1 1-1.818 1.805 1.808 1.808 0 0 1 1.818-1.805z" class="cls-1" transform="translate(123.539 277.638)"/>
                    <path id="Path_49000" d="M12.763 6.151a1.793 1.793 0 1 1-1.793 1.793 1.8 1.8 0 0 1 1.793-1.793z" class="cls-1" transform="translate(128.469 283.997)"/>
                    <path id="Path_49001" d="M13.336 5.687A1.916 1.916 0 1 1 11.42 7.6a1.918 1.918 0 0 1 1.916-1.913z" class="cls-1" transform="translate(133.546 289.914)"/>
                    <circle id="Ellipse_10806" cx="2.133" cy="2.133" r="2.133" class="cls-1" transform="translate(150.683 300.652)"/>
                    <path id="Path_49002" d="M14.629 4.827a2.26 2.26 0 1 1-2.248 2.26 2.254 2.254 0 0 1 2.248-2.26z" class="cls-1" transform="translate(144.388 300.649)"/>
                    <path id="Path_49003" d="M15.256 4.444A2.352 2.352 0 1 1 12.9 6.79a2.356 2.356 0 0 1 2.356-2.346z" class="cls-1" transform="translate(150.221 305.552)"/>
                    <path id="Path_49004" d="M15.869 4.09a2.432 2.432 0 1 1-2.432 2.432 2.437 2.437 0 0 1 2.432-2.432z" class="cls-1" transform="translate(156.301 310.094)"/>
                    <circle id="Ellipse_10807" cx="2.574" cy="2.574" r="2.574" class="cls-1" transform="translate(176.504 317.947)"/>
                    <circle id="Ellipse_10808" cx="2.795" cy="2.795" r="2.795" class="cls-1" transform="translate(183.387 321.263)"/>
                    <path id="Path_49005" d="M18.077 3.185a2.942 2.942 0 1 1-2.948 2.935 2.935 2.935 0 0 1 2.948-2.935z" class="cls-1" transform="translate(175.39 321.094)"/>
                    <path id="Path_49006" d="M18.715 2.956a2.991 2.991 0 1 1-2.984 3 2.993 2.993 0 0 1 2.984-3z" class="cls-1" transform="translate(182.182 324.038)"/>
                    <path id="Path_49007" d="M19.434 2.755a3.089 3.089 0 1 1-3.1 3.1 3.1 3.1 0 0 1 3.1-3.1z" class="cls-1" transform="translate(189.041 326.511)"/>
                    <path id="Path_49008" d="M19.97 2.6a2.991 2.991 0 1 1-3 2.984 3 3 0 0 1 3-2.984z" class="cls-1" transform="translate(196.194 328.739)"/>
                    <path id="Path_49009" d="M20.581 2.477a2.966 2.966 0 1 1-2.972 2.96 2.961 2.961 0 0 1 2.972-2.96z" class="cls-1" transform="translate(203.369 330.449)"/>
                    <path id="Path_49010" d="M21.13 2.392a2.868 2.868 0 1 1-2.874 2.874 2.878 2.878 0 0 1 2.874-2.874z" class="cls-1" transform="translate(210.669 331.774)"/>
                    <path id="Path_49011" d="M21.829 2.326a2.942 2.942 0 1 1-2.935 2.935 2.938 2.938 0 0 1 2.935-2.935z" class="cls-1" transform="translate(217.866 332.503)"/>
                    <path id="Path_49012" d="M22.6 2.291a3.064 3.064 0 1 1-3.07 3.07 3.072 3.072 0 0 1 3.07-3.07z" class="cls-1" transform="translate(225.03 332.723)"/>
                    <path id="Path_49013" d="M23.189 2.3a3.015 3.015 0 1 1-3.009 3.012A3.017 3.017 0 0 1 23.189 2.3z" class="cls-1" transform="translate(232.375 332.661)"/>
                    <path id="Path_49014" d="M23.62 2.366a2.77 2.77 0 1 1-2.776 2.776 2.773 2.773 0 0 1 2.776-2.776z" class="cls-1" transform="translate(239.866 332.316)"/>
                    <path id="Path_49015" d="M24.217 2.446A2.72 2.72 0 1 1 21.49 5.16a2.715 2.715 0 0 1 2.727-2.714z" class="cls-1" transform="translate(247.154 331.352)"/>
                    <path id="Path_49016" d="M24.932 2.548a2.825 2.825 0 1 1-2.813 2.825 2.825 2.825 0 0 1 2.813-2.825z" class="cls-1" transform="translate(254.25 329.788)"/>
                    <path id="Path_49017" d="M25.584 2.69a2.843 2.843 0 1 1-2.837 2.837 2.841 2.841 0 0 1 2.837-2.837z" class="cls-1" transform="translate(261.335 327.865)"/>
                    <circle id="Ellipse_10809" cx="2.869" cy="2.869" r="2.869" class="cls-1" transform="translate(291.688 328.353)"/>
                    <circle id="Ellipse_10810" cx="2.771" cy="2.771" r="2.771" class="cls-1" transform="translate(299.294 325.88)"/>
                    <path id="Path_49018" d="M27.225 3.336A2.622 2.622 0 1 1 24.6 5.952a2.618 2.618 0 0 1 2.625-2.616z" class="cls-1" transform="translate(282.207 319.727)"/>
                    <path id="Path_49019" d="M27.844 3.6a2.677 2.677 0 1 1-2.665 2.677A2.676 2.676 0 0 1 27.844 3.6z" class="cls-1" transform="translate(288.773 316.057)"/>
                    <path id="Path_49020" d="M28.359 3.914a2.6 2.6 0 1 1-2.6 2.6 2.605 2.605 0 0 1 2.6-2.6z" class="cls-1" transform="translate(295.271 312.1)"/>
                    <path id="Path_49021" d="M28.755 4.261a2.426 2.426 0 1 1-2.432 2.432 2.437 2.437 0 0 1 2.432-2.432z" class="cls-1" transform="translate(301.679 307.835)"/>
                    <circle id="Ellipse_10811" cx="2.232" cy="2.232" r="2.232" class="cls-1" transform="translate(334.779 307.851)"/>
                    <path id="Path_49022" d="M29.625 5.028a2.229 2.229 0 1 1-2.235 2.235 2.236 2.236 0 0 1 2.235-2.235z" class="cls-1" transform="translate(313.717 298.041)"/>
                    <path id="Path_49023" d="M30.188 5.438a2.3 2.3 0 1 1-2.309 2.309 2.3 2.3 0 0 1 2.309-2.309z" class="cls-1" transform="translate(319.233 292.448)"/>
                    <path id="Path_49024" d="M30.67 5.877a2.334 2.334 0 1 1-2.321 2.334 2.333 2.333 0 0 1 2.321-2.334z" class="cls-1" transform="translate(324.536 286.556)"/>
                    <path id="Path_49025" d="M31.039 6.351A2.235 2.235 0 1 1 28.8 8.586a2.243 2.243 0 0 1 2.239-2.235z" class="cls-1" transform="translate(329.669 280.456)"/>
                    <path id="Path_49026" d="M31.349 6.85a2.106 2.106 0 1 1-2.112 2.1 2.1 2.1 0 0 1 2.112-2.1z" class="cls-1" transform="translate(334.554 274.087)"/>
                    <circle id="Ellipse_10812" cx="2.035" cy="2.035" r="2.035" class="cls-1" transform="translate(368.731 274.734)"/>
                    <path id="Path_49027" d="M31.934 7.907a1.916 1.916 0 1 1-1.916 1.916 1.908 1.908 0 0 1 1.916-1.916z" class="cls-1" transform="translate(343.365 260.429)"/>
                    <path id="Path_49028" d="M32.251 8.459a1.885 1.885 0 1 1-1.891 1.891 1.882 1.882 0 0 1 1.891-1.891z" class="cls-1" transform="translate(347.224 253.158)"/>
                    <path id="Path_49029" d="M32.46 9.033a1.793 1.793 0 1 1-1.781 1.793 1.8 1.8 0 0 1 1.781-1.793z" class="cls-1" transform="translate(350.823 245.719)"/>
                    <path id="Path_49030" d="M32.707 9.619a1.744 1.744 0 1 1-1.744 1.744 1.743 1.743 0 0 1 1.744-1.744z" class="cls-1" transform="translate(354.027 238.034)"/>
                    <path id="Path_49031" d="M32.866 10.224a1.64 1.64 0 1 1-1.646 1.646 1.646 1.646 0 0 1 1.646-1.646z" class="cls-1" transform="translate(356.926 230.207)"/>
                    <path id="Path_49032" d="M33.061 10.834a1.621 1.621 0 1 1-1.621 1.621 1.617 1.617 0 0 1 1.621-1.621z" class="cls-1" transform="translate(359.408 222.142)"/>
                    <path id="Path_49033" d="M33.269 11.451a1.646 1.646 0 1 1-1.646 1.649 1.643 1.643 0 0 1 1.646-1.649z" class="cls-1" transform="translate(361.473 213.898)"/>
                    <path id="Path_49034" d="M33.4 12.081a1.621 1.621 0 1 1-1.623 1.619 1.617 1.617 0 0 1 1.623-1.619z" class="cls-1" transform="translate(363.21 205.58)"/>
                    <path id="Path_49035" d="M33.415 12.724a1.523 1.523 0 1 1-1.515 1.523 1.515 1.515 0 0 1 1.515-1.523z" class="cls-1" transform="translate(364.643 197.236)"/>
                    <circle id="Ellipse_10813" cx="1.422" cy="1.422" r="1.422" class="cls-1" transform="translate(397.685 202.191)"/>
                    <path id="Path_49036" d="M33.45 14.019a1.4 1.4 0 1 1-1.4 1.4 1.4 1.4 0 0 1 1.4-1.4z" class="cls-1" transform="translate(366.29 180.282)"/>
                    <path id="Path_49037" d="M34.119 14.671A1.326 1.326 0 1 1 32.793 16a1.326 1.326 0 0 1 1.326-1.329z" class="cls-1" transform="translate(374.672 171.769)"/>
                    <path id="Path_49038" d="M34.023 15.323a1.253 1.253 0 1 1-1.24 1.253 1.25 1.25 0 0 1 1.24-1.253z" class="cls-1" transform="translate(374.56 163.257)"/>
                    <path id="Path_49039" d="M33.942 15.972a1.2 1.2 0 1 1-1.2 1.2 1.206 1.206 0 0 1 1.2-1.2z" class="cls-1" transform="translate(374.052 154.748)"/>
                    <path id="Path_49040" d="M33.794 16.619a1.124 1.124 0 1 1-1.13 1.118 1.124 1.124 0 0 1 1.13-1.118z" class="cls-1" transform="translate(373.217 146.302)"/>
                    <path id="Path_49041" d="M33.637 17.259a1.081 1.081 0 1 1-1.081 1.081 1.08 1.08 0 0 1 1.081-1.081z" class="cls-1" transform="translate(371.999 137.887)"/>
                    <path id="Path_49042" d="M33.448 17.893a1.032 1.032 0 1 1-1.032 1.032 1.038 1.038 0 0 1 1.032-1.032z" class="cls-1" transform="translate(370.419 129.565)"/>
                    <path id="Path_49043" d="M33.228 18.519a.983.983 0 1 1-.983.983.985.985 0 0 1 .983-.983z" class="cls-1" transform="translate(368.49 121.349)"/>
                    <path id="Path_49044" d="M32.931 19.14a.878.878 0 1 1-.884.872.878.878 0 0 1 .884-.872z" class="cls-1" transform="translate(366.256 113.31)"/>
                    <circle id="Ellipse_10814" cx=".858" cy=".858" r=".858" class="cls-1" transform="translate(395.43 125.08)"/>
                    <circle id="Ellipse_10815" cx=".809" cy=".809" r=".809" class="cls-1" transform="translate(392.215 117.896)"/>
                    <path id="Path_49045" d="M32 20.917a.737.737 0 1 1-.737.737.739.739 0 0 1 .737-.737z" class="cls-1" transform="translate(357.4 89.99)"/>
                    <path id="Path_49046" d="M31.631 21.481a.688.688 0 1 1-.688.688.687.687 0 0 1 .688-.688z" class="cls-1" transform="translate(353.801 82.598)"/>
                    <circle id="Ellipse_10816" cx=".637" cy=".637" r=".637" class="cls-1" transform="translate(380.492 97.465)"/>
                    <path id="Path_49047" d="M30.756 22.56a.541.541 0 1 1-.528.54.537.537 0 0 1 .528-.54z" class="cls-1" transform="translate(345.734 68.561)"/>
                    <circle id="Ellipse_10817" cx=".49" cy=".49" r=".49" class="cls-1" transform="translate(371.058 84.963)"/>
                    <circle id="Ellipse_10818" cx=".49" cy=".49" r=".49" class="cls-1" transform="translate(365.807 79.013)"/>
                    <circle id="Ellipse_10819" cx=".465" cy=".465" r=".465" class="cls-1" transform="translate(360.29 73.356)"/>
                    <path id="Path_49048" d="M28.922 24.46a.442.442 0 1 1-.442.442.44.44 0 0 1 .442-.442z" class="cls-1" transform="translate(326.014 43.522)"/>
                    <path id="Path_49049" d="M28.382 24.88a.387.387 0 1 1-.393.393.388.388 0 0 1 .393-.393z" class="cls-1" transform="translate(320.474 38.054)"/>
                    <path id="Path_49050" d="M27.89 25.268a.422.422 0 0 1 .418.418.418.418 0 0 1-.835 0 .422.422 0 0 1 .417-.418z" class="cls-1" transform="translate(314.642 32.84)"/>
                    <path id="Path_49051" d="M27.31 25.636a.37.37 0 0 1 .368.368.368.368 0 0 1-.737 0 .369.369 0 0 1 .369-.368z" class="cls-1" transform="translate(308.662 28.05)"/>
                    <path id="Path_49052" d="M26.782 25.971a.4.4 0 0 1 .393.393.4.4 0 0 1-.393.393.388.388 0 0 1-.393-.393.4.4 0 0 1 .393-.393z" class="cls-1" transform="translate(302.424 23.552)"/>
                    <path id="Path_49053" d="M26.259 26.276a.448.448 0 0 1 .442.442.442.442 0 1 1-.884 0 .448.448 0 0 1 .442-.442z" class="cls-1" transform="translate(295.97 19.403)"/>
                    <path id="Path_49054" d="M25.7 26.554a.467.467 0 1 1-.467.467.467.467 0 0 1 .467-.467z" class="cls-1" transform="translate(289.382 15.661)"/>
                    <path id="Path_49055" d="M25.126 26.8a.491.491 0 1 1-.491.491.493.493 0 0 1 .491-.491z" class="cls-1" transform="translate(282.635 12.305)"/>
                    <path id="Path_49056" d="M24.5 27.026a.467.467 0 1 1-.467.467.467.467 0 0 1 .467-.467z" class="cls-1" transform="translate(275.81 9.392)"/>
                    <path id="Path_49057" d="M23.812 27.223a.387.387 0 1 1 0 .774.387.387 0 1 1 0-.774z" class="cls-1" transform="translate(268.917 6.935)"/>
                    <path id="Path_49058" d="M23.174 27.382a.393.393 0 1 1-.381.393.388.388 0 0 1 .381-.393z" class="cls-1" transform="translate(261.854 4.811)"/>
                    <path id="Path_49059" d="M22.529 27.512a.368.368 0 1 1 0 .737.368.368 0 0 1 0-.737z" class="cls-1" transform="translate(254.724 3.134)"/>
                    <path id="Path_49060" d="M21.823 27.614a.291.291 0 0 1 .295.295.295.295 0 0 1-.59 0 .291.291 0 0 1 .295-.295z" class="cls-1" transform="translate(247.583 1.926)"/>
                    <path id="Path_49061" d="M21.157 27.681a.27.27 0 1 1-.27.27.273.273 0 0 1 .27-.27z" class="cls-1" transform="translate(240.351 1.085)"/>
                    <path id="Path_49062" d="M20.49 27.715a.246.246 0 1 1-.246.246.246.246 0 0 1 .246-.246z" class="cls-1" transform="translate(233.097 .683)"/>
                    <path id="Path_49063" d="M19.854 27.713a.27.27 0 1 1-.258.27.265.265 0 0 1 .258-.27z" class="cls-1" transform="translate(225.786 .66)"/>
                    <path id="Path_49064" d="M19.22 27.681a.27.27 0 1 1-.27.27.273.273 0 0 1 .27-.27z" class="cls-1" transform="translate(218.498 1.085)"/>
                    <path id="Path_49065" d="M18.6 27.614a.291.291 0 0 1 .295.295.295.295 0 0 1-.59 0 .291.291 0 0 1 .295-.295z" class="cls-1" transform="translate(211.221 1.926)"/>
                    <path id="Path_49066" d="M17.938 27.52a.27.27 0 1 1-.27.27.273.273 0 0 1 .27-.27z" class="cls-1" transform="translate(204.035 3.224)"/>
                    <path id="Path_49067" d="M17.328 27.39a.295.295 0 0 1 0 .59.295.295 0 0 1 0-.59z" class="cls-1" transform="translate(196.871 4.901)"/>
                    <path id="Path_49068" d="M16.7 27.231a.278.278 0 0 1 .282.282.289.289 0 1 1-.282-.282z" class="cls-1" transform="translate(189.808 7.025)"/>
                    <path id="Path_49069" d="M16.106 27.038a.319.319 0 1 1-.319.319.325.325 0 0 1 .319-.319z" class="cls-1" transform="translate(182.814 9.527)"/>
                    <path id="Path_49070" d="M15.522 26.815a.344.344 0 0 1 0 .688.344.344 0 1 1 0-.688z" class="cls-1" transform="translate(175.943 12.44)"/>
                    <path id="Path_49071" d="M14.948 26.562a.368.368 0 1 1 0 .737.368.368 0 1 1 0-.737z" class="cls-1" transform="translate(169.197 15.751)"/>
                    <path id="Path_49072" d="M14.389 26.28a.4.4 0 0 1 .393.393.393.393 0 1 1-.786 0 .4.4 0 0 1 .393-.393z" class="cls-1" transform="translate(162.608 19.448)"/>
                    <path id="Path_49073" d="M13.845 25.969a.43.43 0 0 1 .418.418.422.422 0 0 1-.418.418.414.414 0 0 1-.418-.418.422.422 0 0 1 .418-.418z" class="cls-1" transform="translate(156.189 23.529)"/>
                    <path id="Path_49074" d="M13.338 25.628a.467.467 0 1 1-.467.467.466.466 0 0 1 .467-.467z" class="cls-1" transform="translate(149.916 27.96)"/>
                    <path id="Path_49075" d="M12.849 25.26a.519.519 0 0 1 .516.516.516.516 0 0 1-1.032 0 .519.519 0 0 1 .516-.516z" class="cls-1" transform="translate(143.846 32.749)"/>
                    <circle id="Ellipse_10820" cx=".515" cy=".515" r=".515" class="cls-1" transform="translate(149.858 62.807)"/>
                    <circle id="Ellipse_10821" cx=".564" cy=".564" r=".564" class="cls-1" transform="translate(143.729 67.859)"/>
                    <path id="Path_49076" d="M11.466 24a.633.633 0 1 1-.626.626.632.632 0 0 1 .626-.626z" class="cls-1" transform="translate(127.003 49.185)"/>
                    <path id="Path_49077" d="M11.072 23.538a.688.688 0 1 1-.688.688.687.687 0 0 1 .688-.688z" class="cls-1" transform="translate(121.858 55.277)"/>
                    <circle id="Ellipse_10822" cx=".736" cy=".736" r=".736" class="cls-1" transform="translate(126.946 84.717)"/>
                    <circle id="Ellipse_10823" cx=".809" cy=".809" r=".809" class="cls-1" transform="translate(121.924 90.849)"/>
                    <circle id="Ellipse_10824" cx=".858" cy=".858" r=".858" class="cls-1" transform="translate(117.242 97.244)"/>
                    <path id="Path_49078" d="M9.694 21.465a.884.884 0 1 1-.884.884.881.881 0 0 1 .884-.884z" class="cls-1" transform="translate(104.1 82.417)"/>
                    <path id="Path_49079" d="M9.394 20.9a.909.909 0 1 1-.909.909.907.907 0 0 1 .909-.909z" class="cls-1" transform="translate(100.434 89.832)"/>
                    <circle id="Ellipse_10825" cx=".981" cy=".981" r=".981" class="cls-1" transform="translate(105.224 117.724)"/>
                    <path id="Path_49080" d="M8.946 19.729a1.032 1.032 0 1 1-1.032 1.032 1.03 1.03 0 0 1 1.032-1.032z" class="cls-1" transform="translate(93.992 105.18)"/>
                    <path id="Path_49081" d="M8.777 19.122a1.1 1.1 0 1 1-1.105 1.093 1.1 1.1 0 0 1 1.105-1.093z" class="cls-1" transform="translate(91.262 113.106)"/>
                    <path id="Path_49082" d="M8.583 18.507a1.13 1.13 0 1 1-1.118 1.13 1.127 1.127 0 0 1 1.118-1.13z" class="cls-1" transform="translate(88.926 121.213)"/>
                    <path id="Path_49083" d="M8.475 17.879a1.2 1.2 0 1 1-1.191 1.2 1.206 1.206 0 0 1 1.191-1.2z" class="cls-1" transform="translate(86.884 129.407)"/>
                    <path id="Path_49084" d="M8.366 17.247a1.228 1.228 0 1 1-1.228 1.228 1.221 1.221 0 0 1 1.228-1.228z" class="cls-1" transform="translate(85.237 137.752)"/>
                    <path id="Path_49085" d="M8.287 16.607a1.271 1.271 0 1 1-1.265 1.265 1.266 1.266 0 0 1 1.265-1.265z" class="cls-1" transform="translate(83.929 146.166)"/>
                    <path id="Path_49086" d="M8.263 15.962a1.32 1.32 0 1 1-1.326 1.326 1.321 1.321 0 0 1 1.326-1.326z" class="cls-1" transform="translate(82.97 154.635)"/>
                    <circle id="Ellipse_10826" cx="1.373" cy="1.373" r="1.373" class="cls-1" transform="translate(89.268 178.46)"/>
                    <path id="Path_49087" d="M8.29 14.663a1.425 1.425 0 1 1-1.425 1.425 1.415 1.415 0 0 1 1.425-1.425z" class="cls-1" transform="translate(82.157 171.679)"/>
                    <path id="Path_49088" d="M8.351 14.013a1.474 1.474 0 1 1-1.474 1.474 1.478 1.478 0 0 1 1.474-1.474z" class="cls-1" transform="translate(82.293 180.214)"/>
                    <path id="Path_49089" d="M8.421 13.367a1.492 1.492 0 1 1-1.5 1.486 1.494 1.494 0 0 1 1.5-1.486z" class="cls-1" transform="translate(82.812 188.757)"/>
                    <path id="Path_49090" d="M8.513 12.724A1.517 1.517 0 1 1 7 14.247a1.515 1.515 0 0 1 1.513-1.523z" class="cls-1" transform="translate(83.703 197.248)"/>
                    <path id="Path_49091" d="M8.682 12.083a1.572 1.572 0 1 1-1.572 1.572 1.565 1.565 0 0 1 1.572-1.572z" class="cls-1" transform="translate(84.921 205.652)"/>
                    <path id="Path_49092" d="M8.836 11.451a1.6 1.6 0 1 1-1.584 1.6 1.593 1.593 0 0 1 1.584-1.6z" class="cls-1" transform="translate(86.523 213.996)"/>
                    <path id="Path_49093" d="M8.966 10.833a1.548 1.548 0 1 1-1.535 1.548 1.549 1.549 0 0 1 1.535-1.548z" class="cls-1" transform="translate(88.543 222.303)"/>
                    <path id="Path_49094" d="M9.206 10.219a1.566 1.566 0 1 1-1.572 1.572 1.567 1.567 0 0 1 1.572-1.572z" class="cls-1" transform="translate(90.833 230.421)"/>
                    <path id="Path_49095" d="M9.51 9.611a1.646 1.646 0 1 1-1.646 1.646A1.646 1.646 0 0 1 9.51 9.611z" class="cls-1" transform="translate(93.428 238.337)"/>
                    <path id="Path_49096" d="M9.821 9.018a1.695 1.695 0 1 1-1.695 1.695 1.7 1.7 0 0 1 1.695-1.695z" class="cls-1" transform="translate(96.384 246.115)"/>
                    <path id="Path_49097" d="M10.184 8.437a1.762 1.762 0 1 1-1.769 1.756 1.766 1.766 0 0 1 1.769-1.756z" class="cls-1" transform="translate(99.644 253.696)"/>
                    <path id="Path_49098" d="M10.552 7.873a1.818 1.818 0 1 1-1.818 1.818 1.814 1.814 0 0 1 1.818-1.818z" class="cls-1" transform="translate(103.243 261.077)"/>
                    <path id="Path_49099" d="M10.97 7.325a1.885 1.885 0 1 1-1.891 1.891 1.89 1.89 0 0 1 1.891-1.891z" class="cls-1" transform="translate(107.135 268.22)"/>
                    <path id="Path_49100" d="M11.325 6.8a1.861 1.861 0 1 1-1.867 1.857A1.853 1.853 0 0 1 11.325 6.8z" class="cls-1" transform="translate(111.411 275.216)"/>
                    <path id="Path_49101" d="M11.683 6.3a1.812 1.812 0 1 1-1.818 1.819A1.811 1.811 0 0 1 11.683 6.3z" class="cls-1" transform="translate(116.003 281.968)"/>
                    <path id="Path_49102" d="M12.189 5.808a1.916 1.916 0 1 1-1.9 1.916 1.918 1.918 0 0 1 1.9-1.916z" class="cls-1" transform="translate(120.741 288.307)"/>
                    <circle id="Ellipse_10827" cx="2.011" cy="2.011" r="2.011" class="cls-1" transform="translate(136.464 299.703)"/>
                    <circle id="Ellipse_10828" cx="2.256" cy="2.256" r="2.256" class="cls-1" transform="translate(142.037 304.856)"/>
                    <path id="Path_49103" d="M14.083 4.449a2.426 2.426 0 1 1-2.42 2.432 2.429 2.429 0 0 1 2.42-2.432z" class="cls-1" transform="translate(136.287 305.338)"/>
                    <path id="Path_49104" d="M14.552 4.063a2.377 2.377 0 1 1-2.37 2.383 2.385 2.385 0 0 1 2.37-2.383z" class="cls-1" transform="translate(142.143 310.563)"/>
                    <path id="Path_49105" d="M15.132 3.695a2.426 2.426 0 1 1-2.42 2.432 2.437 2.437 0 0 1 2.42-2.432z" class="cls-1" transform="translate(148.122 315.352)"/>
                    <path id="Path_49106" d="M15.808 3.348A2.548 2.548 0 1 1 13.253 5.9a2.55 2.55 0 0 1 2.555-2.552z" class="cls-1" transform="translate(154.226 319.715)"/>
                    <path id="Path_49107" d="M16.555 3.023A2.745 2.745 0 1 1 13.8 5.774a2.747 2.747 0 0 1 2.755-2.751z" class="cls-1" transform="translate(160.442 323.639)"/>
                    <path id="Path_49108" d="M17.1 2.744a2.727 2.727 0 1 1-2.714 2.727A2.728 2.728 0 0 1 17.1 2.744z" class="cls-1" transform="translate(167.042 327.381)"/>
                    <path id="Path_49109" d="M17.62 2.5a2.622 2.622 0 1 1-2.628 2.616A2.61 2.61 0 0 1 17.62 2.5z" class="cls-1" transform="translate(173.845 330.818)"/>
                    <circle id="Ellipse_10829" cx="2.894" cy="2.894" r="2.894" class="cls-1" transform="translate(196.028 335.758)"/>
                    <path id="Path_49110" d="M19.139 2.064a2.942 2.942 0 1 1-2.948 2.948 2.938 2.938 0 0 1 2.948-2.948z" class="cls-1" transform="translate(187.372 335.983)"/>
                    <path id="Path_49111" d="M19.72 1.908a2.9 2.9 0 1 1-2.9 2.9 2.893 2.893 0 0 1 2.9-2.9z" class="cls-1" transform="translate(194.479 338.141)"/>
                    <path id="Path_49112" d="M20.364 1.778a2.917 2.917 0 1 1-2.911 2.911 2.92 2.92 0 0 1 2.911-2.911z" class="cls-1" transform="translate(201.609 339.831)"/>
                    <path id="Path_49113" d="M21.048 1.678a2.966 2.966 0 1 1-2.96 2.972 2.967 2.967 0 0 1 2.96-2.972z" class="cls-1" transform="translate(208.773 341.061)"/>
                    <path id="Path_49114" d="M21.736 1.61a3.015 3.015 0 1 1-3.009 3.021 3.019 3.019 0 0 1 3.009-3.021z" class="cls-1" transform="translate(215.982 341.866)"/>
                    <path id="Path_49115" d="M22.471 1.569a3.113 3.113 0 1 1-3.107 3.107 3.106 3.106 0 0 1 3.107-3.107z" class="cls-1" transform="translate(223.169 342.214)"/>
                    <path id="Path_49116" d="M23.175 1.565a3.169 3.169 0 1 1-3.169 3.169 3.166 3.166 0 0 1 3.169-3.169z" class="cls-1" transform="translate(230.412 342.156)"/>
                    <path id="Path_49117" d="M23.808 1.6a3.163 3.163 0 1 1-3.156 3.169A3.176 3.176 0 0 1 23.808 1.6z" class="cls-1" transform="translate(237.7 341.73)"/>
                    <circle id="Ellipse_10830" cx="2.869" cy="2.869" r="2.869" class="cls-1" transform="translate(266.538 342.836)"/>
                    <path id="Path_49118" d="M24.718 1.792a2.745 2.745 0 1 1-2.751 2.739 2.744 2.744 0 0 1 2.751-2.739z" class="cls-1" transform="translate(252.535 339.989)"/>
                    <circle id="Ellipse_10831" cx="2.771" cy="2.771" r="2.771" class="cls-1" transform="translate(282.263 340.178)"/>
                    <path id="Path_49119" d="M26.113 2.068a2.892 2.892 0 1 1-2.9 2.9 2.886 2.886 0 0 1 2.9-2.9z" class="cls-1" transform="translate(266.615 336.028)"/>
                    <circle id="Ellipse_10832" cx="2.869" cy="2.869" r="2.869" class="cls-1" transform="translate(297.44 335.782)"/>
                    <path id="Path_49120" d="M27.146 2.495a2.7 2.7 0 1 1-2.69 2.69 2.692 2.692 0 0 1 2.69-2.69z" class="cls-1" transform="translate(280.616 330.75)"/>
                    <path id="Path_49121" d="M27.821 2.74a2.77 2.77 0 1 1-2.776 2.76 2.768 2.768 0 0 1 2.776-2.76z" class="cls-1" transform="translate(287.261 327.349)"/>
                    <circle id="Ellipse_10833" cx="2.795" cy="2.795" r="2.795" class="cls-1" transform="translate(319.435 326.615)"/>
                    <path id="Path_49122" d="M28.926 3.334A2.72 2.72 0 1 1 26.2 6.061a2.718 2.718 0 0 1 2.726-2.727z" class="cls-1" transform="translate(300.28 319.557)"/>
                    <path id="Path_49123" d="M29.273 3.689a2.5 2.5 0 1 1-2.506 2.505 2.508 2.508 0 0 1 2.506-2.505z" class="cls-1" transform="translate(306.699 315.285)"/>
                    <path id="Path_49124" d="M29.695 4.063a2.377 2.377 0 1 1-2.383 2.383 2.385 2.385 0 0 1 2.383-2.383z" class="cls-1" transform="translate(312.837 310.563)"/>
                    <path id="Path_49125" d="M30.074 4.465A2.229 2.229 0 1 1 27.839 6.7a2.236 2.236 0 0 1 2.235-2.235z" class="cls-1" transform="translate(318.782 305.518)"/>
                    <path id="Path_49126" d="M30.547 4.882a2.2 2.2 0 1 1-2.211 2.2 2.207 2.207 0 0 1 2.211-2.2z" class="cls-1" transform="translate(324.389 300.029)"/>
                    <circle id="Ellipse_10834" cx="2.182" cy="2.182" r="2.182" class="cls-1" transform="translate(358.573 299.531)"/>
                    <circle id="Ellipse_10835" cx="2.133" cy="2.133" r="2.133" class="cls-1" transform="translate(364.163 293.899)"/>
                    <circle id="Ellipse_10836" cx="2.084" cy="2.084" r="2.084" class="cls-1" transform="translate(369.464 287.998)"/>
                    <path id="Path_49127" d="M32.132 6.788a2.033 2.033 0 1 1-2.026 2.027 2.031 2.031 0 0 1 2.026-2.027z" class="cls-1" transform="translate(344.358 275.058)"/>
                    <path id="Path_49128" d="M32.5 7.315a2.008 2.008 0 1 1-2.014 2.014A2 2 0 0 1 32.5 7.315z" class="cls-1" transform="translate(348.634 268.107)"/>
                    <path id="Path_49129" d="M32.793 7.861a1.965 1.965 0 1 1-1.953 1.965 1.971 1.971 0 0 1 1.953-1.965z" class="cls-1" transform="translate(352.639 260.941)"/>
                    <path id="Path_49130" d="M33 8.431a1.836 1.836 0 1 1-1.83 1.83A1.837 1.837 0 0 1 33 8.431z" class="cls-1" transform="translate(356.396 253.629)"/>
                    <path id="Path_49131" d="M33.242 9.012a1.769 1.769 0 1 1-1.769 1.769 1.769 1.769 0 0 1 1.769-1.769z" class="cls-1" transform="translate(359.78 246.047)"/>
                    <path id="Path_49132" d="M33.462 9.6a1.719 1.719 0 1 1-1.719 1.719A1.724 1.724 0 0 1 33.462 9.6z" class="cls-1" transform="translate(362.826 238.269)"/>
                    <path id="Path_49133" d="M33.653 10.211a1.664 1.664 0 1 1-1.67 1.67 1.672 1.672 0 0 1 1.67-1.67z" class="cls-1" transform="translate(365.534 230.331)"/>
                    <path id="Path_49134" d="M33.792 10.829a1.6 1.6 0 1 1-1.6 1.6 1.6 1.6 0 0 1 1.6-1.6z" class="cls-1" transform="translate(367.926 222.258)"/>
                    <circle id="Ellipse_10837" cx="1.57" cy="1.57" r="1.57" class="cls-1" transform="translate(402.296 225.475)"/>
                    <circle id="Ellipse_10838" cx="1.52" cy="1.52" r="1.52" class="cls-1" transform="translate(404.111 217.786)"/>
                    <circle id="Ellipse_10839" cx="1.398" cy="1.398" r="1.398" class="cls-1" transform="translate(405.612 210.093)"/>
                    <path id="Path_49135" d="M34.1 13.377a1.369 1.369 0 1 1-1.376 1.363 1.371 1.371 0 0 1 1.376-1.363z" class="cls-1" transform="translate(373.894 188.87)"/>
                    <path id="Path_49136" d="M34.114 14.023a1.351 1.351 0 1 1-1.339 1.351 1.347 1.347 0 0 1 1.339-1.351z" class="cls-1" transform="translate(374.469 180.327)"/>
                    <path id="Path_49137" d="M34.772 14.677a1.253 1.253 0 1 1-1.253 1.253 1.248 1.248 0 0 1 1.253-1.253z" class="cls-1" transform="translate(382.863 171.837)"/>
                    <path id="Path_49138" d="M34.7 15.327a1.2 1.2 0 1 1-1.191 1.2 1.206 1.206 0 0 1 1.191-1.2z" class="cls-1" transform="translate(382.739 163.302)"/>
                    <path id="Path_49139" d="M34.6 15.978a1.124 1.124 0 1 1-1.13 1.118 1.122 1.122 0 0 1 1.13-1.118z" class="cls-1" transform="translate(382.288 154.815)"/>
                    <path id="Path_49140" d="M34.487 16.621a1.105 1.105 0 1 1-1.093 1.105 1.1 1.1 0 0 1 1.093-1.105z" class="cls-1" transform="translate(381.453 146.312)"/>
                    <path id="Path_49141" d="M34.325 17.265a1.026 1.026 0 1 1-1.032 1.019 1.027 1.027 0 0 1 1.032-1.019z" class="cls-1" transform="translate(380.313 137.918)"/>
                    <path id="Path_49142" d="M34.166 17.9a1 1 0 1 1-1.007 1.007 1 1 0 0 1 1.007-1.007z" class="cls-1" transform="translate(378.801 129.547)"/>
                    <path id="Path_49143" d="M33.955 18.527a.958.958 0 1 1-.958.958.959.959 0 0 1 .958-.958z" class="cls-1" transform="translate(376.974 121.292)"/>
                    <path id="Path_49144" d="M33.657 19.151a.86.86 0 1 1 0 1.719.86.86 0 0 1 0-1.719z" class="cls-1" transform="translate(374.864 113.2)"/>
                    <circle id="Ellipse_10840" cx=".834" cy=".834" r=".834" class="cls-1" transform="translate(404.939 124.936)"/>
                    <path id="Path_49145" d="M33.148 20.356a.811.811 0 1 1-.811.811.807.807 0 0 1 .811-.811z" class="cls-1" transform="translate(369.528 97.294)"/>
                    <path id="Path_49146" d="M32.776 20.946a.712.712 0 1 1-.712.712.713.713 0 0 1 .712-.712z" class="cls-1" transform="translate(366.448 89.654)"/>
                    <circle id="Ellipse_10841" cx=".687" cy=".687" r=".687" class="cls-1" transform="translate(394.763 103.646)"/>
                    <path id="Path_49147" d="M32.09 22.071a.668.668 0 0 1 .663.663.677.677 0 0 1-.663.663.668.668 0 0 1-.663-.663.66.66 0 0 1 .663-.663z" class="cls-1" transform="translate(359.261 74.81)"/>
                    <path id="Path_49148" d="M31.64 22.616a.563.563 0 0 1 .565.565.571.571 0 0 1-.565.565.563.563 0 0 1-.565-.565.556.556 0 0 1 .565-.565z" class="cls-1" transform="translate(355.29 67.768)"/>
                    <circle id="Ellipse_10842" cx=".49" cy=".49" r=".49" class="cls-1" transform="translate(381.713 84.08)"/>
                    <path id="Path_49149" d="M30.756 23.644a.467.467 0 1 1-.467.467.466.466 0 0 1 .467-.467z" class="cls-1" transform="translate(346.423 54.311)"/>
                    <path id="Path_49150" d="M30.3 24.126a.442.442 0 1 1-.442.442.44.44 0 0 1 .442-.442z" class="cls-1" transform="translate(341.571 47.958)"/>
                    <path id="Path_49151" d="M29.847 24.586a.442.442 0 1 1-.442.442.44.44 0 0 1 .442-.442z" class="cls-1" transform="translate(336.45 41.849)"/>
                    <path id="Path_49152" d="M29.327 25.028a.393.393 0 0 1 .381.393.387.387 0 1 1-.774 0 .4.4 0 0 1 .393-.393z" class="cls-1" transform="translate(331.136 36.077)"/>
                    <path id="Path_49153" d="M28.808 25.444a.369.369 0 0 1 .368.368.378.378 0 0 1-.368.368.369.369 0 0 1-.368-.368.362.362 0 0 1 .368-.368z" class="cls-1" transform="translate(325.563 30.6)"/>
                    <path id="Path_49154" d="M28.293 25.835a.362.362 0 0 1 .368.368.37.37 0 0 1-.368.368.378.378 0 0 1-.368-.368.37.37 0 0 1 .368-.368z" class="cls-1" transform="translate(319.752 25.407)"/>
                    <path id="Path_49155" d="M27.739 26.2a.343.343 0 0 1 .344.344.351.351 0 0 1-.344.344.343.343 0 0 1-.344-.344.336.336 0 0 1 .344-.344z" class="cls-1" transform="translate(313.773 20.569)"/>
                    <path id="Path_49156" d="M27.258 26.538a.418.418 0 0 1 0 .835.418.418 0 0 1 0-.835z" class="cls-1" transform="translate(307.512 15.972)"/>
                    <path id="Path_49157" d="M26.693 26.852a.418.418 0 1 1-.418.418.414.414 0 0 1 .418-.418z" class="cls-1" transform="translate(301.137 11.801)"/>
                    <path id="Path_49158" d="M26.114 27.14a.411.411 0 1 1-.418.418.414.414 0 0 1 .418-.418z" class="cls-1" transform="translate(294.605 7.988)"/>
                    <path id="Path_49159" d="M25.522 27.4a.418.418 0 1 1 0 .835.418.418 0 1 1 0-.835z" class="cls-1" transform="translate(287.926 4.536)"/>
                    <path id="Path_49160" d="M24.919 27.63a.414.414 0 0 1 .418.418.418.418 0 0 1-.835 0 .414.414 0 0 1 .417-.418z" class="cls-1" transform="translate(281.123 1.468)"/>
                    <path id="Path_49161" d="M24.259 27.837a.37.37 0 0 1 .368.368.362.362 0 0 1-.368.368.369.369 0 0 1-.368-.368.378.378 0 0 1 .368-.368z" class="cls-1" transform="translate(274.242 -1.183)"/>
                    <path id="Path_49162" d="M23.615 28.012a.343.343 0 0 1 .344.344.351.351 0 0 1-.344.344.343.343 0 0 1-.344-.344.336.336 0 0 1 .344-.344z" class="cls-1" transform="translate(267.247 -3.458)"/>
                    <path id="Path_49163" d="M22.962 28.158a.319.319 0 0 1 0 .639.319.319 0 1 1 0-.639z" class="cls-1" transform="translate(260.162 -5.348)"/>
                    <path id="Path_49164" d="M22.3 28.274a.295.295 0 1 1-.295.295.3.3 0 0 1 .295-.295z" class="cls-1" transform="translate(253.009 -6.84)"/>
                    <path id="Path_49165" d="M21.618 28.362a.246.246 0 1 1-.246.246.246.246 0 0 1 .246-.246z" class="cls-1" transform="translate(245.823 -7.91)"/>
                    <path id="Path_49166" d="M20.974 28.415a.246.246 0 1 1-.246.246.246.246 0 0 1 .246-.246z" class="cls-1" transform="translate(238.557 -8.614)"/>
                    <circle id="Ellipse_10843" cx=".221" cy=".221" r=".221" class="cls-1" transform="translate(251.378 19.543)"/>
                    <path id="Path_49167" d="M19.659 28.432a.221.221 0 1 1-.221.221.22.22 0 0 1 .221-.221z" class="cls-1" transform="translate(224.004 -8.791)"/>
                    <path id="Path_49168" d="M19.037 28.392a.246.246 0 1 1-.246.246.246.246 0 0 1 .246-.246z" class="cls-1" transform="translate(216.704 -8.309)"/>
                    <path id="Path_49169" d="M18.394 28.324a.246.246 0 1 1-.246.246.246.246 0 0 1 .246-.246z" class="cls-1" transform="translate(209.45 -7.406)"/>
                    <path id="Path_49170" d="M17.756 28.225a.246.246 0 1 1-.246.246.246.246 0 0 1 .246-.246z" class="cls-1" transform="translate(202.252 -6.091)"/>
                    <path id="Path_49171" d="M17.123 28.1a.246.246 0 0 1 0 .491.246.246 0 0 1 0-.491z" class="cls-1" transform="translate(195.111 -4.377)"/>
                    <path id="Path_49172" d="M16.518 27.935a.265.265 0 0 1 .27.27.27.27 0 0 1-.54 0 .265.265 0 0 1 .27-.27z" class="cls-1" transform="translate(188.015 -2.288)"/>
                    <path id="Path_49173" d="M15.923 27.745a.291.291 0 0 1 .295.295.295.295 0 0 1-.59 0 .291.291 0 0 1 .295-.295z" class="cls-1" transform="translate(181.02 .186)"/>
                    <path id="Path_49174" d="M15.314 27.528a.295.295 0 1 1-.295.295.3.3 0 0 1 .295-.295z" class="cls-1" transform="translate(174.149 3.068)"/>
                    <path id="Path_49175" d="M14.738 27.281a.317.317 0 0 1 .319.319.31.31 0 0 1-.319.319.317.317 0 0 1-.319-.319.325.325 0 0 1 .319-.319z" class="cls-1" transform="translate(167.38 6.3)"/>
                    <path id="Path_49176" d="M14.176 27a.343.343 0 0 1 .344.344.351.351 0 0 1-.344.344.343.343 0 0 1-.344-.344.336.336 0 0 1 .344-.344z" class="cls-1" transform="translate(160.758 9.917)"/>
                    <path id="Path_49177" d="M13.626 26.7a.362.362 0 1 1-.368.368.362.362 0 0 1 .368-.368z" class="cls-1" transform="translate(154.282 13.891)"/>
                    <path id="Path_49178" d="M13.092 26.373a.393.393 0 1 1-.393.393.388.388 0 0 1 .393-.393z" class="cls-1" transform="translate(147.975 18.212)"/>
                    <path id="Path_49179" d="M12.6 26.016a.436.436 0 1 1-.442.442.44.44 0 0 1 .442-.442z" class="cls-1" transform="translate(141.827 22.868)"/>
                    <path id="Path_49180" d="M12.095 25.635a.467.467 0 1 1-.467.467.467.467 0 0 1 .467-.467z" class="cls-1" transform="translate(135.893 27.867)"/>
                    <path id="Path_49181" d="M11.635 25.228a.516.516 0 1 1-.516.516.519.519 0 0 1 .516-.516z" class="cls-1" transform="translate(130.15 33.174)"/>
                    <path id="Path_49182" d="M11.194 24.8a.563.563 0 0 1 .565.565.556.556 0 0 1-.565.565.563.563 0 0 1-.565-.565.571.571 0 0 1 .565-.565z" class="cls-1" transform="translate(124.622 38.787)"/>
                    <path id="Path_49183" d="M10.808 24.341a.663.663 0 1 1-.651.663.66.66 0 0 1 .651-.663z" class="cls-1" transform="translate(119.297 44.661)"/>
                    <circle id="Ellipse_10844" cx=".687" cy=".687" r=".687" class="cls-1" transform="translate(123.98 74.755)"/>
                    <circle id="Ellipse_10845" cx=".76" cy=".76" r=".76" class="cls-1" transform="translate(118.742 80.707)"/>
                    <path id="Path_49184" d="M9.695 22.858a.811.811 0 1 1-.811.811.81.81 0 0 1 .811-.811z" class="cls-1" transform="translate(104.935 64.063)"/>
                    <path id="Path_49185" d="M9.389 22.324a.884.884 0 1 1-.884.884.881.881 0 0 1 .884-.884z" class="cls-1" transform="translate(100.659 71.008)"/>
                    <path id="Path_49186" d="M9.065 21.777a.909.909 0 1 1-.909.909.907.907 0 0 1 .909-.909z" class="cls-1" transform="translate(96.722 78.224)"/>
                    <path id="Path_49187" d="M8.755 21.214a.933.933 0 1 1 0 1.867.933.933 0 0 1 0-1.867z" class="cls-1" transform="translate(93.089 85.653)"/>
                    <path id="Path_49188" d="M8.518 20.635a.976.976 0 1 1-.983.983.978.978 0 0 1 .983-.983z" class="cls-1" transform="translate(89.716 93.257)"/>
                    <path id="Path_49189" d="M8.274 20.044a1.007 1.007 0 1 1-1.007 1.007 1.012 1.012 0 0 1 1.007-1.007z" class="cls-1" transform="translate(86.693 101.045)"/>
                    <path id="Path_49190" d="M8.08 19.439a1.056 1.056 0 0 1 0 2.112 1.056 1.056 0 0 1 0-2.112z" class="cls-1" transform="translate(83.951 108.982)"/>
                    <path id="Path_49191" d="M7.961 18.82a1.154 1.154 0 1 1-1.154 1.154 1.151 1.151 0 0 1 1.154-1.154z" class="cls-1" transform="translate(81.503 117.007)"/>
                    <path id="Path_49192" d="M7.826 18.2a1.2 1.2 0 1 1-1.2 1.191 1.2 1.2 0 0 1 1.2-1.191z" class="cls-1" transform="translate(79.416 125.209)"/>
                    <path id="Path_49193" d="M7.72 17.563a1.253 1.253 0 1 1-1.253 1.253 1.24 1.24 0 0 1 1.253-1.253z" class="cls-1" transform="translate(77.667 133.506)"/>
                    <path id="Path_49194" d="M7.62 16.927a1.271 1.271 0 1 1-1.277 1.265 1.266 1.266 0 0 1 1.277-1.265z" class="cls-1" transform="translate(76.268 141.916)"/>
                    <path id="Path_49195" d="M7.574 16.283a1.326 1.326 0 1 1 0 2.653 1.326 1.326 0 1 1 0-2.653z" class="cls-1" transform="translate(75.196 150.359)"/>
                    <path id="Path_49196" d="M7.559 15.636A1.369 1.369 0 1 1 6.183 17a1.371 1.371 0 0 1 1.376-1.364z" class="cls-1" transform="translate(74.463 158.867)"/>
                    <circle id="Ellipse_10846" cx="1.422" cy="1.422" r="1.422" class="cls-1" transform="translate(80.225 182.376)"/>
                    <circle id="Ellipse_10847" cx="1.422" cy="1.422" r="1.422" class="cls-1" transform="translate(80.225 190.313)"/>
                    <circle id="Ellipse_10848" cx="1.447" cy="1.447" r="1.447" class="cls-1" transform="translate(80.575 198.216)"/>
                    <path id="Path_49197" d="M7.732 13.045a1.5 1.5 0 1 1-1.5 1.5 1.5 1.5 0 0 1 1.5-1.5z" class="cls-1" transform="translate(75.038 193.022)"/>
                    <path id="Path_49198" d="M7.869 12.4a1.548 1.548 0 1 1 0 3.1 1.548 1.548 0 0 1 0-3.1z" class="cls-1" transform="translate(76.02 201.477)"/>
                    <path id="Path_49199" d="M8.036 11.763a1.591 1.591 0 1 1-1.6 1.584 1.588 1.588 0 0 1 1.6-1.584z" class="cls-1" transform="translate(77.351 209.865)"/>
                    <path id="Path_49200" d="M8.232 11.131a1.64 1.64 0 1 1-1.646 1.646 1.646 1.646 0 0 1 1.646-1.646z" class="cls-1" transform="translate(79.01 218.161)"/>
                    <path id="Path_49201" d="M8.323 10.518a1.548 1.548 0 1 1-1.548 1.548 1.546 1.546 0 0 1 1.548-1.548z" class="cls-1" transform="translate(81.142 226.487)"/>
                    <path id="Path_49202" d="M8.565 9.9a1.591 1.591 0 1 1-1.584 1.584A1.591 1.591 0 0 1 8.565 9.9z" class="cls-1" transform="translate(83.466 234.569)"/>
                    <path id="Path_49203" d="M8.951 9.29a1.744 1.744 0 1 1-1.744 1.744A1.751 1.751 0 0 1 8.951 9.29z" class="cls-1" transform="translate(86.016 242.404)"/>
                    <path id="Path_49204" d="M9.228 8.7a1.762 1.762 0 1 1-1.756 1.769A1.761 1.761 0 0 1 9.228 8.7z" class="cls-1" transform="translate(89.005 250.203)"/>
                    <path id="Path_49205" d="M9.567 8.12a1.818 1.818 0 1 1-1.805 1.818A1.814 1.814 0 0 1 9.567 8.12z" class="cls-1" transform="translate(92.277 257.796)"/>
                    <path id="Path_49206" d="M9.911 7.557A1.842 1.842 0 1 1 8.081 9.4a1.84 1.84 0 0 1 1.83-1.843z" class="cls-1" transform="translate(95.876 265.225)"/>
                    <path id="Path_49207" d="M10.258 7.012a1.842 1.842 0 1 1-1.83 1.842 1.84 1.84 0 0 1 1.83-1.842z" class="cls-1" transform="translate(99.791 272.463)"/>
                    <path id="Path_49208" d="M10.687 6.48A1.891 1.891 0 1 1 8.8 8.371a1.882 1.882 0 0 1 1.887-1.891z" class="cls-1" transform="translate(103.942 279.431)"/>
                    <path id="Path_49209" d="M11.152 5.964a1.965 1.965 0 1 1-1.965 1.965 1.96 1.96 0 0 1 1.965-1.965z" class="cls-1" transform="translate(108.354 286.137)"/>
                    <circle id="Ellipse_10849" cx="2.084" cy="2.084" r="2.084" class="cls-1" transform="translate(122.582 298.008)"/>
                    <circle id="Ellipse_10850" cx="2.256" cy="2.256" r="2.256" class="cls-1" transform="translate(127.855 303.613)"/>
                    <path id="Path_49210" d="M12.807 4.525a2.327 2.327 0 1 1-2.321 2.334 2.333 2.333 0 0 1 2.321-2.334z" class="cls-1" transform="translate(123.009 304.525)"/>
                    <path id="Path_49211" d="M13.417 4.088a2.456 2.456 0 1 1-2.456 2.456 2.464 2.464 0 0 1 2.456-2.456z" class="cls-1" transform="translate(128.368 310.071)"/>
                    <path id="Path_49212" d="M13.979 3.679a2.53 2.53 0 1 1-2.518 2.53 2.526 2.526 0 0 1 2.518-2.53z" class="cls-1" transform="translate(134.009 315.356)"/>
                    <path id="Path_49213" d="M14.491 3.3a2.5 2.5 0 1 1-2.505 2.505A2.508 2.508 0 0 1 14.491 3.3z" class="cls-1" transform="translate(139.932 320.411)"/>
                    <path id="Path_49214" d="M15.1 2.943a2.579 2.579 0 1 1-2.579 2.579A2.579 2.579 0 0 1 15.1 2.943z" class="cls-1" transform="translate(145.967 325.033)"/>
                    <path id="Path_49215" d="M15.725 2.61a2.647 2.647 0 1 1-2.653 2.653 2.65 2.65 0 0 1 2.653-2.653z" class="cls-1" transform="translate(152.184 329.321)"/>
                    <path id="Path_49216" d="M16.252 2.313a2.6 2.6 0 1 1-2.6 2.591 2.6 2.6 0 0 1 2.6-2.591z" class="cls-1" transform="translate(158.682 333.364)"/>
                    <path id="Path_49217" d="M16.916 2.032a2.7 2.7 0 1 1-2.69 2.7 2.7 2.7 0 0 1 2.69-2.7z" class="cls-1" transform="translate(165.203 336.899)"/>
                    <path id="Path_49218" d="M17.6 1.778a2.794 2.794 0 1 1-2.788 2.788A2.8 2.8 0 0 1 17.6 1.778z" class="cls-1" transform="translate(171.859 340.077)"/>
                    <circle id="Ellipse_10851" cx="2.894" cy="2.894" r="2.894" class="cls-1" transform="translate(194.048 344.419)"/>
                    <path id="Path_49219" d="M19.147 1.345a3.138 3.138 0 1 1-3.132 3.132 3.14 3.14 0 0 1 3.132-3.132z" class="cls-1" transform="translate(185.386 345.14)"/>
                    <path id="Path_49220" d="M19.921 1.174a3.285 3.285 0 1 1-3.292 3.279 3.279 3.279 0 0 1 3.292-3.279z" class="cls-1" transform="translate(192.313 347.116)"/>
                    <path id="Path_49221" d="M20.463 1.053a3.193 3.193 0 1 1-3.193 3.193 3.192 3.192 0 0 1 3.193-3.193z" class="cls-1" transform="translate(199.545 348.908)"/>
                    <path id="Path_49222" d="M21.045.959A3.138 3.138 0 1 1 17.913 4.1 3.15 3.15 0 0 1 21.045.959z" class="cls-1" transform="translate(206.799 350.267)"/>
                    <path id="Path_49223" d="M21.541.9a2.966 2.966 0 1 1-2.972 2.96A2.961 2.961 0 0 1 21.541.9z" class="cls-1" transform="translate(214.2 351.341)"/>
                    <path id="Path_49224" d="M22.119.872a2.892 2.892 0 1 1-2.9 2.9 2.9 2.9 0 0 1 2.9-2.9z" class="cls-1" transform="translate(221.544 351.913)"/>
                    <path id="Path_49225" d="M22.956.846a3.113 3.113 0 1 1-3.107 3.107A3.114 3.114 0 0 1 22.956.846z" class="cls-1" transform="translate(228.64 351.817)"/>
                    <path id="Path_49226" d="M23.411.887a2.892 2.892 0 1 1-2.9 2.886 2.893 2.893 0 0 1 2.9-2.886z" class="cls-1" transform="translate(236.12 351.714)"/>
                    <path id="Path_49227" d="M23.851.958a2.677 2.677 0 1 1-2.677 2.677A2.684 2.684 0 0 1 23.851.958z" class="cls-1" transform="translate(243.589 351.201)"/>
                    <path id="Path_49228" d="M24.583 1.034A2.77 2.77 0 1 1 21.807 3.8a2.768 2.768 0 0 1 2.776-2.766z" class="cls-1" transform="translate(250.73 350.007)"/>
                    <circle id="Ellipse_10852" cx="2.894" cy="2.894" r="2.894" class="cls-1" transform="translate(280.229 349.513)"/>
                    <circle id="Ellipse_10853" cx="2.771" cy="2.771" r="2.771" class="cls-1" transform="translate(288.09 347.87)"/>
                    <path id="Path_49229" d="M26.527 1.459A2.843 2.843 0 1 1 23.69 4.3a2.841 2.841 0 0 1 2.837-2.841z" class="cls-1" transform="translate(271.974 344.215)"/>
                    <path id="Path_49230" d="M27.152 1.662A2.843 2.843 0 1 1 24.3 4.511a2.851 2.851 0 0 1 2.852-2.849z" class="cls-1" transform="translate(278.89 341.519)"/>
                    <path id="Path_49231" d="M27.767 1.891A2.868 2.868 0 1 1 24.9 4.753a2.867 2.867 0 0 1 2.867-2.862z" class="cls-1" transform="translate(285.681 338.428)"/>
                    <path id="Path_49232" d="M28.471 2.141a2.991 2.991 0 1 1-2.984 3 2.993 2.993 0 0 1 2.984-3z" class="cls-1" transform="translate(292.247 334.862)"/>
                    <circle id="Ellipse_10854" cx="2.844" cy="2.844" r="2.844" class="cls-1" transform="translate(324.987 333.622)"/>
                    <path id="Path_49233" d="M29.356 2.766a2.7 2.7 0 1 1-2.7 2.7 2.7 2.7 0 0 1 2.7-2.7z" class="cls-1" transform="translate(305.413 327.138)"/>
                    <path id="Path_49234" d="M29.724 3.123a2.5 2.5 0 1 1-2.505 2.505 2.5 2.5 0 0 1 2.505-2.505z" class="cls-1" transform="translate(311.787 322.802)"/>
                    <path id="Path_49235" d="M30.2 3.493a2.45 2.45 0 1 1-2.444 2.444A2.445 2.445 0 0 1 30.2 3.493z" class="cls-1" transform="translate(317.846 317.986)"/>
                    <circle id="Ellipse_10855" cx="2.354" cy="2.354" r="2.354" class="cls-1" transform="translate(352.017 316.773)"/>
                    <path id="Path_49236" d="M31.042 4.314a2.26 2.26 0 1 1-2.26 2.26 2.251 2.251 0 0 1 2.26-2.26z" class="cls-1" transform="translate(329.421 307.462)"/>
                    <circle id="Ellipse_10856" cx="2.207" cy="2.207" r="2.207" class="cls-1" transform="translate(364.09 306.451)"/>
                    <circle id="Ellipse_10857" cx="2.182" cy="2.182" r="2.182" class="cls-1" transform="translate(369.693 300.831)"/>
                    <circle id="Ellipse_10858" cx="2.109" cy="2.109" r="2.109" class="cls-1" transform="translate(375.072 295.002)"/>
                    <path id="Path_49237" d="M32.609 6.211A2.033 2.033 0 1 1 30.57 8.25a2.034 2.034 0 0 1 2.039-2.039z" class="cls-1" transform="translate(349.593 282.721)"/>
                    <path id="Path_49238" d="M32.9 6.738a1.934 1.934 0 1 1-1.941 1.928A1.934 1.934 0 0 1 32.9 6.738z" class="cls-1" transform="translate(354.027 275.918)"/>
                    <path id="Path_49239" d="M33.264 7.275a1.934 1.934 0 1 1-1.941 1.941 1.926 1.926 0 0 1 1.941-1.941z" class="cls-1" transform="translate(358.088 268.786)"/>
                    <path id="Path_49240" d="M33.53 7.834a1.861 1.861 0 1 1-1.867 1.855 1.861 1.861 0 0 1 1.867-1.855z" class="cls-1" transform="translate(361.924 261.509)"/>
                    <path id="Path_49241" d="M33.814 8.4a1.842 1.842 0 1 1-1.842 1.842A1.84 1.84 0 0 1 33.814 8.4z" class="cls-1" transform="translate(365.41 253.975)"/>
                    <path id="Path_49242" d="M34.05 8.99a1.793 1.793 0 1 1-1.793 1.793A1.785 1.785 0 0 1 34.05 8.99z" class="cls-1" transform="translate(368.625 246.29)"/>
                    <path id="Path_49243" d="M34.212 9.593a1.695 1.695 0 1 1-1.695 1.695 1.7 1.7 0 0 1 1.695-1.695z" class="cls-1" transform="translate(371.559 238.478)"/>
                    <path id="Path_49244" d="M34.334 10.207a1.6 1.6 0 1 1-1.584 1.6 1.593 1.593 0 0 1 1.584-1.6z" class="cls-1" transform="translate(374.187 230.519)"/>
                    <path id="Path_49245" d="M34.451 10.831a1.5 1.5 0 1 1-1.5 1.5 1.494 1.494 0 0 1 1.5-1.5z" class="cls-1" transform="translate(376.477 222.428)"/>
                    <circle id="Ellipse_10859" cx="1.496" cy="1.496" r="1.496" class="cls-1" transform="translate(411.469 225.59)"/>
                    <circle id="Ellipse_10860" cx="1.447" cy="1.447" r="1.447" class="cls-1" transform="translate(413.192 217.882)"/>
                    <circle id="Ellipse_10861" cx="1.373" cy="1.373" r="1.373" class="cls-1" transform="translate(414.573 210.127)"/>
                    <path id="Path_49246" d="M34.778 13.38a1.326 1.326 0 1 1-1.326 1.326 1.318 1.318 0 0 1 1.326-1.326z" class="cls-1" transform="translate(382.107 188.916)"/>
                    <path id="Path_49247" d="M34.767 14.029a1.277 1.277 0 1 1-1.267 1.277 1.276 1.276 0 0 1 1.267-1.277z" class="cls-1" transform="translate(382.671 180.395)"/>
                    <path id="Path_49248" d="M35.424 14.683a1.179 1.179 0 1 1-1.179 1.179 1.169 1.169 0 0 1 1.179-1.179z" class="cls-1" transform="translate(391.054 171.905)"/>
                    <path id="Path_49249" d="M35.386 15.331a1.154 1.154 0 1 1-1.155 1.154 1.153 1.153 0 0 1 1.155-1.154z" class="cls-1" transform="translate(390.907 163.347)"/>
                    <path id="Path_49250" d="M35.276 15.982a1.081 1.081 0 1 1-1.081 1.081 1.08 1.08 0 0 1 1.081-1.081z" class="cls-1" transform="translate(390.489 154.848)"/>
                    <path id="Path_49251" d="M35.18 16.626a1.056 1.056 0 1 1-1.056 1.056 1.056 1.056 0 0 1 1.056-1.056z" class="cls-1" transform="translate(389.688 146.344)"/>
                    <path id="Path_49252" d="M35.034 17.268a1.007 1.007 0 1 1-1.007 1.007 1.012 1.012 0 0 1 1.007-1.007z" class="cls-1" transform="translate(388.594 137.915)"/>
                    <path id="Path_49253" d="M34.86 17.9a.958.958 0 0 1 0 1.916.958.958 0 0 1 0-1.916z" class="cls-1" transform="translate(387.184 129.553)"/>
                    <circle id="Ellipse_10862" cx=".932" cy=".932" r=".932" class="cls-1" transform="translate(419.167 139.784)"/>
                    <path id="Path_49254" d="M34.471 19.155a.909.909 0 1 1-.909.909.907.907 0 0 1 .909-.909z" class="cls-1" transform="translate(383.348 113.049)"/>
                    <path id="Path_49255" d="M34.246 19.765a.909.909 0 1 1-.9.909.907.907 0 0 1 .9-.909z" class="cls-1" transform="translate(380.945 104.947)"/>
                    <path id="Path_49256" d="M33.972 20.369a.854.854 0 1 1 0 1.707.854.854 0 1 1 0-1.707z" class="cls-1" transform="translate(378.271 97.035)"/>
                    <circle id="Ellipse_10863" cx=".809" cy=".809" r=".809" class="cls-1" transform="translate(408.149 110.222)"/>
                    <circle id="Ellipse_10864" cx=".736" cy=".736" r=".736" class="cls-1" transform="translate(404.62 103.224)"/>
                    <path id="Path_49257" d="M32.866 22.115a.616.616 0 0 1 .614.614.608.608 0 0 1-.614.614.616.616 0 0 1-.614-.614.624.624 0 0 1 .614-.614z" class="cls-1" transform="translate(368.569 74.324)"/>
                    <path id="Path_49258" d="M32.421 22.67a.516.516 0 1 1-.5.516.511.511 0 0 1 .5-.516z" class="cls-1" transform="translate(364.789 67.149)"/>
                    <path id="Path_49259" d="M32.03 23.2a.491.491 0 0 1 0 .983.491.491 0 0 1 0-.983z" class="cls-1" transform="translate(360.66 60.119)"/>
                    <path id="Path_49260" d="M31.605 23.721a.442.442 0 1 1-.442.442.44.44 0 0 1 .442-.442z" class="cls-1" transform="translate(356.283 53.338)"/>
                    <path id="Path_49261" d="M31.169 24.219a.418.418 0 1 1-.418.418.414.414 0 0 1 .418-.418z" class="cls-1" transform="translate(351.635 46.772)"/>
                    <path id="Path_49262" d="M30.71 24.7a.4.4 0 0 1 .393.393.4.4 0 0 1-.393.393.4.4 0 0 1-.393-.393.388.388 0 0 1 .393-.393z" class="cls-1" transform="translate(346.739 40.46)"/>
                    <path id="Path_49263" d="M30.253 25.155a.388.388 0 0 1 .393.393.393.393 0 0 1-.786 0 .388.388 0 0 1 .393-.393z" class="cls-1" transform="translate(341.583 34.39)"/>
                    <path id="Path_49264" d="M29.776 25.591a.393.393 0 1 1-.393.393.388.388 0 0 1 .393-.393z" class="cls-1" transform="translate(336.201 28.599)"/>
                    <path id="Path_49265" d="M29.257 26.007a.369.369 0 0 1 .368.368.378.378 0 0 1-.368.368.37.37 0 0 1-.368-.368.362.362 0 0 1 .368-.368z" class="cls-1" transform="translate(330.628 23.123)"/>
                    <path id="Path_49266" d="M28.743 26.4a.378.378 0 0 1 .368.368.37.37 0 0 1-.368.368.362.362 0 0 1-.368-.368.37.37 0 0 1 .368-.368z" class="cls-1" transform="translate(324.829 17.916)"/>
                    <path id="Path_49267" d="M28.212 26.767a.367.367 0 0 1 .356.368.362.362 0 1 1-.725 0 .37.37 0 0 1 .369-.368z" class="cls-1" transform="translate(318.839 13.029)"/>
                    <path id="Path_49268" d="M27.642 27.113a.343.343 0 0 1 .344.344.336.336 0 0 1-.344.344.343.343 0 0 1-.344-.344.351.351 0 0 1 .344-.344z" class="cls-1" transform="translate(312.679 8.482)"/>
                    <path id="Path_49269" d="M27.1 27.43a.372.372 0 0 1 .368.381.359.359 0 0 1-.368.356.367.367 0 0 1-.368-.356.38.38 0 0 1 .368-.381z" class="cls-1" transform="translate(306.316 4.223)"/>
                    <path id="Path_49270" d="M26.527 27.723a.367.367 0 0 1 .356.368.362.362 0 1 1-.725 0 .37.37 0 0 1 .369-.368z" class="cls-1" transform="translate(299.829 .331)"/>
                    <path id="Path_49271" d="M25.916 27.992a.336.336 0 0 1 .344.344.343.343 0 0 1-.344.344.351.351 0 0 1-.344-.344.343.343 0 0 1 .344-.344z" class="cls-1" transform="translate(293.206 -3.193)"/>
                    <path id="Path_49272" d="M25.338 28.231a.37.37 0 0 1 .368.368.362.362 0 0 1-.368.368.369.369 0 0 1-.368-.368.378.378 0 0 1 .368-.368z" class="cls-1" transform="translate(286.415 -6.416)"/>
                    <path id="Path_49273" d="M24.706 28.446a.336.336 0 0 1 .344.344.343.343 0 0 1-.344.344.351.351 0 0 1-.344-.344.343.343 0 0 1 .344-.344z" class="cls-1" transform="translate(279.555 -9.223)"/>
                    <path id="Path_49274" d="M24.065 28.634a.319.319 0 1 1-.319.319.315.315 0 0 1 .319-.319z" class="cls-1" transform="translate(272.606 -11.67)"/>
                    <path id="Path_49275" d="M23.393 28.8a.27.27 0 1 1-.27.27.273.273 0 0 1 .27-.27z" class="cls-1" transform="translate(265.577 -13.724)"/>
                    <path id="Path_49276" d="M22.76 28.926a.275.275 0 0 1 .27.282.271.271 0 0 1-.54 0 .275.275 0 0 1 .27-.282z" class="cls-1" transform="translate(258.436 -15.45)"/>
                    <path id="Path_49277" d="M22.1 29.029a.246.246 0 1 1-.246.246.246.246 0 0 1 .246-.246z" class="cls-1" transform="translate(251.26 -16.769)"/>
                    <path id="Path_49278" d="M21.434 29.1a.221.221 0 1 1-.221.221.22.22 0 0 1 .221-.221z" class="cls-1" transform="translate(244.029 -17.703)"/>
                    <path id="Path_49279" d="M20.79 29.146a.221.221 0 1 1-.221.221.22.22 0 0 1 .221-.221z" class="cls-1" transform="translate(236.763 -18.274)"/>
                    <path id="Path_49280" d="M20.122 29.163a.2.2 0 1 1 0 .393.2.2 0 1 1 0-.393z" class="cls-1" transform="translate(229.498 -18.451)"/>
                    <path id="Path_49281" d="M19.5 29.146a.221.221 0 0 1 0 .442.221.221 0 0 1 0-.442z" class="cls-1" transform="translate(222.187 -18.274)"/>
                    <path id="Path_49282" d="M18.876 29.1a.246.246 0 1 1-.246.246.246.246 0 0 1 .246-.246z" class="cls-1" transform="translate(214.888 -17.726)"/>
                    <path id="Path_49283" d="M18.234 29.029a.246.246 0 1 1-.246.246.246.246 0 0 1 .246-.246z" class="cls-1" transform="translate(207.645 -16.769)"/>
                    <path id="Path_49284" d="M17.595 28.928a.239.239 0 0 1 .246.246.246.246 0 0 1-.491 0 .239.239 0 0 1 .245-.246z" class="cls-1" transform="translate(200.436 -15.416)"/>
                    <path id="Path_49285" d="M16.962 28.8a.246.246 0 1 1-.246.246.246.246 0 0 1 .246-.246z" class="cls-1" transform="translate(193.295 -13.701)"/>
                    <path id="Path_49286" d="M16.336 28.64a.246.246 0 1 1-.246.246.246.246 0 0 1 .246-.246z" class="cls-1" transform="translate(186.232 -11.603)"/>
                    <path id="Path_49287" d="M15.717 28.454a.246.246 0 1 1-.246.246.246.246 0 0 1 .246-.246z" class="cls-1" transform="translate(179.249 -9.132)"/>
                    <path id="Path_49288" d="M15.129 28.239a.27.27 0 1 1-.27.27.273.273 0 0 1 .27-.27z" class="cls-1" transform="translate(172.344 -6.326)"/>
                    <path id="Path_49289" d="M14.529 28a.27.27 0 1 1-.27.27.273.273 0 0 1 .27-.27z" class="cls-1" transform="translate(165.575 -3.125)"/>
                    <path id="Path_49290" d="M13.964 27.729a.295.295 0 0 1 0 .59.295.295 0 0 1 0-.59z" class="cls-1" transform="translate(158.919 .399)"/>
                    <path id="Path_49291" d="M13.433 27.432a.354.354 0 0 1 .344.356.341.341 0 0 1-.344.332.333.333 0 0 1-.344-.332.346.346 0 0 1 .344-.356z" class="cls-1" transform="translate(152.375 4.245)"/>
                    <path id="Path_49292" d="M12.893 27.111a.378.378 0 0 1 .368.368.37.37 0 0 1-.368.368.362.362 0 0 1-.368-.368.37.37 0 0 1 .368-.368z" class="cls-1" transform="translate(146.012 8.46)"/>
                    <path id="Path_49293" d="M12.369 26.765a.4.4 0 0 1 .393.393.4.4 0 0 1-.393.393.388.388 0 0 1-.393-.393.4.4 0 0 1 .393-.393z" class="cls-1" transform="translate(139.819 13.006)"/>
                    <path id="Path_49294" d="M11.848 26.395a.422.422 0 0 1 .418.418.411.411 0 1 1-.823 0 .42.42 0 0 1 .405-.418z" class="cls-1" transform="translate(133.805 17.871)"/>
                    <path id="Path_49295" d="M11.368 26a.442.442 0 1 1-.442.442.44.44 0 0 1 .442-.442z" class="cls-1" transform="translate(127.973 23.055)"/>
                    <path id="Path_49296" d="M10.94 25.581a.516.516 0 1 1-.516.516.519.519 0 0 1 .516-.516z" class="cls-1" transform="translate(122.309 28.486)"/>
                    <path id="Path_49297" d="M10.508 25.141a.556.556 0 0 1 .565.565.563.563 0 0 1-.565.565.571.571 0 0 1-.565-.565.563.563 0 0 1 .565-.565z" class="cls-1" transform="translate(116.883 34.232)"/>
                    <path id="Path_49298" d="M10.119 24.678a.634.634 0 0 1 .639.639.642.642 0 0 1-.639.639.65.65 0 0 1-.639-.639.642.642 0 0 1 .639-.639z" class="cls-1" transform="translate(111.659 40.234)"/>
                    <path id="Path_49299" d="M9.728 24.2a.688.688 0 1 1-.688.688.687.687 0 0 1 .688-.688z" class="cls-1" transform="translate(106.695 46.524)"/>
                    <path id="Path_49300" d="M9.359 23.7a.737.737 0 1 1-.737.737.739.739 0 0 1 .737-.737z" class="cls-1" transform="translate(101.979 53.067)"/>
                    <circle id="Ellipse_10865" cx=".76" cy=".76" r=".76" class="cls-1" transform="translate(105.773 83.052)"/>
                    <circle id="Ellipse_10866" cx=".858" cy=".858" r=".858" class="cls-1" transform="translate(101.156 89.478)"/>
                    <circle id="Ellipse_10867" cx=".883" cy=".883" r=".883" class="cls-1" transform="translate(96.908 96.174)"/>
                    <path id="Path_49301" d="M8.14 21.525a.949.949 0 0 1 .958.946.958.958 0 1 1-1.916 0 .949.949 0 0 1 .958-.946z" class="cls-1" transform="translate(85.734 81.485)"/>
                    <path id="Path_49302" d="M7.87 20.947a.983.983 0 1 1-.983.983.985.985 0 0 1 .983-.983z" class="cls-1" transform="translate(82.406 89.101)"/>
                    <path id="Path_49303" d="M7.613 20.357a1 1 0 1 1-.995 1.007 1 1 0 0 1 .995-1.007z" class="cls-1" transform="translate(79.371 96.9)"/>
                    <path id="Path_49304" d="M7.452 19.751a1.081 1.081 0 0 1 0 2.162 1.081 1.081 0 1 1 0-2.162z" class="cls-1" transform="translate(76.584 104.789)"/>
                    <path id="Path_49305" d="M7.294 19.135a1.155 1.155 0 1 1-1.142 1.154 1.153 1.153 0 0 1 1.142-1.154z" class="cls-1" transform="translate(74.113 112.823)"/>
                    <path id="Path_49306" d="M7.166 18.512a1.2 1.2 0 1 1-1.2 1.2 1.2 1.2 0 0 1 1.2-1.2z" class="cls-1" transform="translate(71.97 121)"/>
                    <path id="Path_49307" d="M7.053 17.881A1.253 1.253 0 1 1 5.8 19.134a1.248 1.248 0 0 1 1.253-1.253z" class="cls-1" transform="translate(70.142 129.282)"/>
                    <path id="Path_49308" d="M6.945 17.246a1.277 1.277 0 1 1-1.277 1.277 1.276 1.276 0 0 1 1.277-1.277z" class="cls-1" transform="translate(68.653 137.667)"/>
                    <circle id="Ellipse_10868" cx="1.324" cy="1.324" r="1.324" class="cls-1" transform="translate(73.034 162.703)"/>
                    <path id="Path_49309" d="M6.863 15.958a1.376 1.376 0 1 1-1.376 1.376 1.371 1.371 0 0 1 1.376-1.376z" class="cls-1" transform="translate(66.611 154.577)"/>
                    <path id="Path_49310" d="M6.841 15.311a1.4 1.4 0 1 1-1.4 1.4 1.4 1.4 0 0 1 1.4-1.4z" class="cls-1" transform="translate(66.092 163.122)"/>
                    <path id="Path_49311" d="M6.85 14.663a1.425 1.425 0 1 1-1.425 1.425 1.415 1.415 0 0 1 1.425-1.425z" class="cls-1" transform="translate(65.911 171.679)"/>
                    <path id="Path_49312" d="M6.886 14.015a1.449 1.449 0 1 1-1.449 1.449 1.452 1.452 0 0 1 1.449-1.449z" class="cls-1" transform="translate(66.047 180.237)"/>
                    <path id="Path_49313" d="M7 13.364a1.523 1.523 0 1 1-1.523 1.523A1.52 1.52 0 0 1 7 13.364z" class="cls-1" transform="translate(66.476 188.736)"/>
                    <circle id="Ellipse_10869" cx="1.545" cy="1.545" r="1.545" class="cls-1" transform="translate(72.813 209.963)"/>
                    <path id="Path_49314" d="M7.216 12.08a1.566 1.566 0 1 1-1.572 1.56 1.565 1.565 0 0 1 1.572-1.56z" class="cls-1" transform="translate(68.382 205.704)"/>
                    <path id="Path_49315" d="M7.391 11.443a1.615 1.615 0 1 1-1.621 1.609 1.614 1.614 0 0 1 1.621-1.609z" class="cls-1" transform="translate(69.804 214.066)"/>
                    <path id="Path_49316" d="M7.549 10.816a1.621 1.621 0 1 1-1.621 1.621 1.617 1.617 0 0 1 1.621-1.621z" class="cls-1" transform="translate(71.586 222.381)"/>
                    <path id="Path_49317" d="M7.7 10.2a1.6 1.6 0 1 1-1.584 1.6A1.593 1.593 0 0 1 7.7 10.2z" class="cls-1" transform="translate(73.707 230.625)"/>
                    <path id="Path_49318" d="M7.926 9.589a1.6 1.6 0 1 1-1.6 1.6 1.6 1.6 0 0 1 1.6-1.6z" class="cls-1" transform="translate(76.11 238.727)"/>
                    <path id="Path_49319" d="M8.29 8.978a1.738 1.738 0 1 1-1.732 1.744A1.735 1.735 0 0 1 8.29 8.978z" class="cls-1" transform="translate(78.694 246.56)"/>
                    <path id="Path_49320" d="M8.637 8.383A1.818 1.818 0 1 1 6.819 10.2a1.811 1.811 0 0 1 1.818-1.817z" class="cls-1" transform="translate(81.638 254.303)"/>
                    <path id="Path_49321" d="M8.93 7.807a1.818 1.818 0 1 1-1.818 1.818A1.814 1.814 0 0 1 8.93 7.807z" class="cls-1" transform="translate(84.944 261.953)"/>
                    <path id="Path_49322" d="M9.2 7.249a1.769 1.769 0 1 1-1.765 1.769A1.769 1.769 0 0 1 9.2 7.249z" class="cls-1" transform="translate(88.588 269.463)"/>
                    <path id="Path_49323" d="M9.638 6.694a1.867 1.867 0 1 1-1.867 1.867 1.856 1.856 0 0 1 1.867-1.867z" class="cls-1" transform="translate(92.379 276.638)"/>
                    <path id="Path_49324" d="M10.051 6.159a1.916 1.916 0 1 1-1.916 1.916 1.908 1.908 0 0 1 1.916-1.916z" class="cls-1" transform="translate(96.485 283.645)"/>
                    <circle id="Ellipse_10870" cx="2.084" cy="2.084" r="2.084" class="cls-1" transform="translate(109.258 295.953)"/>
                    <path id="Path_49325" d="M11.115 5.125a2.2 2.2 0 1 1-2.2 2.2 2.2 2.2 0 0 1 2.2-2.2z" class="cls-1" transform="translate(105.308 296.801)"/>
                    <path id="Path_49326" d="M11.642 4.64a2.3 2.3 0 1 1-2.3 2.3 2.3 2.3 0 0 1 2.3-2.3z" class="cls-1" transform="translate(110.136 303.047)"/>
                    <path id="Path_49327" d="M12.121 4.181A2.327 2.327 0 1 1 9.8 6.5a2.33 2.33 0 0 1 2.321-2.319z" class="cls-1" transform="translate(115.269 309.094)"/>
                    <path id="Path_49328" d="M12.621 3.743a2.352 2.352 0 1 1-2.346 2.346 2.348 2.348 0 0 1 2.346-2.346z" class="cls-1" transform="translate(120.628 314.862)"/>
                    <path id="Path_49329" d="M13.139 3.327a2.377 2.377 0 1 1-2.37 2.37 2.382 2.382 0 0 1 2.37-2.37z" class="cls-1" transform="translate(126.202 320.338)"/>
                    <path id="Path_49330" d="M13.789 2.923a2.53 2.53 0 1 1-2.518 2.53 2.526 2.526 0 0 1 2.518-2.53z" class="cls-1" transform="translate(131.865 325.397)"/>
                    <path id="Path_49331" d="M14.422 2.547a2.628 2.628 0 1 1-2.628 2.628 2.621 2.621 0 0 1 2.628-2.628z" class="cls-1" transform="translate(137.765 330.194)"/>
                    <circle id="Ellipse_10871" cx="2.722" cy="2.722" r="2.722" class="cls-1" transform="translate(156.183 336.869)"/>
                    <path id="Path_49332" d="M15.554 1.883A2.647 2.647 0 1 1 12.9 4.536a2.658 2.658 0 0 1 2.654-2.653z" class="cls-1" transform="translate(150.254 338.977)"/>
                    <circle id="Ellipse_10872" cx="2.648" cy="2.648" r="2.648" class="cls-1" transform="translate(170.231 344.463)"/>
                    <circle id="Ellipse_10873" cx="2.771" cy="2.771" r="2.771" class="cls-1" transform="translate(177.335 347.622)"/>
                    <path id="Path_49333" d="M17.769 1.042a3.138 3.138 0 1 1-3.144 3.144 3.14 3.14 0 0 1 3.144-3.144z" class="cls-1" transform="translate(169.704 349.164)"/>
                    <path id="Path_49334" d="M18.447.822a3.212 3.212 0 1 1-3.218 3.206A3.208 3.208 0 0 1 18.447.822z" class="cls-1" transform="translate(176.518 351.939)"/>
                    <path id="Path_49335" d="M18.976.644a3.113 3.113 0 1 1-3.12 3.107 3.1 3.1 0 0 1 3.12-3.107z" class="cls-1" transform="translate(183.592 354.499)"/>
                    <path id="Path_49336" d="M19.816.466a3.365 3.365 0 1 1-3.353 3.365A3.37 3.37 0 0 1 19.816.466z" class="cls-1" transform="translate(190.44 356.36)"/>
                    <path id="Path_49337" d="M20.178.361a3.064 3.064 0 1 1-3.058 3.07 3.072 3.072 0 0 1 3.058-3.07z" class="cls-1" transform="translate(197.852 358.357)"/>
                    <circle id="Ellipse_10874" cx="2.943" cy="2.943" r="2.943" class="cls-1" transform="translate(222.932 360.082)"/>
                    <path id="Path_49338" d="M21.4.193a2.991 2.991 0 1 1-3 2.984 2.98 2.98 0 0 1 3-2.984z" class="cls-1" transform="translate(212.361 360.735)"/>
                    <path id="Path_49339" d="M22.048.15a2.991 2.991 0 1 1-3 3 2.99 2.99 0 0 1 3-3z" class="cls-1" transform="translate(219.638 361.306)"/>
                    <path id="Path_49340" d="M22.558.147A2.849 2.849 0 1 1 19.709 3 2.841 2.841 0 0 1 22.558.147z" class="cls-1" transform="translate(227.061 361.629)"/>
                    <path id="Path_49341" d="M23 .18a2.622 2.622 0 1 1-2.628 2.628A2.621 2.621 0 0 1 23 .18z" class="cls-1" transform="translate(234.552 361.645)"/>
                    <path id="Path_49342" d="M23.7.217a2.7 2.7 0 1 1-2.69 2.7 2.7 2.7 0 0 1 2.69-2.7z" class="cls-1" transform="translate(241.761 360.994)"/>
                    <circle id="Ellipse_10875" cx="2.746" cy="2.746" r="2.746" class="cls-1" transform="translate(270.609 360.279)"/>
                    <circle id="Ellipse_10876" cx="2.844" cy="2.844" r="2.844" class="cls-1" transform="translate(278.35 358.939)"/>
                    <path id="Path_49343" d="M25.853.5A2.948 2.948 0 1 1 22.9 3.448 2.946 2.946 0 0 1 25.853.5z" class="cls-1" transform="translate(263.118 356.744)"/>
                    <circle id="Ellipse_10877" cx="2.918" cy="2.918" r="2.918" class="cls-1" transform="translate(293.748 355.334)"/>
                    <path id="Path_49344" d="M27.109.842a2.966 2.966 0 1 1-2.96 2.96 2.964 2.964 0 0 1 2.96-2.96z" class="cls-1" transform="translate(277.152 352.164)"/>
                    <path id="Path_49345" d="M27.877 1.042a3.138 3.138 0 1 1-3.132 3.144 3.142 3.142 0 0 1 3.132-3.144z" class="cls-1" transform="translate(283.876 349.164)"/>
                    <path id="Path_49346" d="M28.432 1.286a3.089 3.089 0 1 1-3.083 3.083 3.087 3.087 0 0 1 3.083-3.083z" class="cls-1" transform="translate(290.69 346.022)"/>
                    <circle id="Ellipse_10878" cx="2.967" cy="2.967" r="2.967" class="cls-1" transform="translate(323.384 344.144)"/>
                    <path id="Path_49347" d="M29.325 1.871a2.794 2.794 0 1 1-2.788 2.8 2.8 2.8 0 0 1 2.788-2.8z" class="cls-1" transform="translate(304.093 338.841)"/>
                    <path id="Path_49348" d="M29.752 2.2a2.647 2.647 0 1 1-2.641 2.653A2.657 2.657 0 0 1 29.752 2.2z" class="cls-1" transform="translate(310.569 334.74)"/>
                    <path id="Path_49349" d="M30.221 2.553a2.555 2.555 0 1 1-2.555 2.555 2.55 2.55 0 0 1 2.555-2.555z" class="cls-1" transform="translate(316.83 330.262)"/>
                    <path id="Path_49350" d="M30.684 2.927A2.481 2.481 0 1 1 28.2 5.408a2.479 2.479 0 0 1 2.484-2.481z" class="cls-1" transform="translate(322.889 325.442)"/>
                    <path id="Path_49351" d="M31.108 3.327A2.377 2.377 0 1 1 28.725 5.7a2.382 2.382 0 0 1 2.383-2.373z" class="cls-1" transform="translate(328.778 320.338)"/>
                    <path id="Path_49352" d="M31.513 3.749a2.278 2.278 0 1 1-2.284 2.272 2.285 2.285 0 0 1 2.284-2.272z" class="cls-1" transform="translate(334.464 314.93)"/>
                    <path id="Path_49353" d="M31.9 4.193a2.18 2.18 0 1 1-2.186 2.174A2.181 2.181 0 0 1 31.9 4.193z" class="cls-1" transform="translate(339.936 309.229)"/>
                    <circle id="Ellipse_10879" cx="2.158" cy="2.158" r="2.158" class="cls-1" transform="translate(375.289 307.829)"/>
                    <circle id="Ellipse_10880" cx="2.084" cy="2.084" r="2.084" class="cls-1" transform="translate(380.718 302.046)"/>
                    <circle id="Ellipse_10881" cx="2.035" cy="2.035" r="2.035" class="cls-1" transform="translate(385.853 296.002)"/>
                    <path id="Path_49354" d="M33.429 6.151a2.014 2.014 0 1 1-2 2.014 2.015 2.015 0 0 1 2-2.014z" class="cls-1" transform="translate(359.261 283.555)"/>
                    <path id="Path_49355" d="M33.707 6.69a1.916 1.916 0 1 1-1.9 1.916 1.918 1.918 0 0 1 1.9-1.916z" class="cls-1" transform="translate(363.503 276.593)"/>
                    <circle id="Ellipse_10882" cx="1.986" cy="1.986" r="1.986" class="cls-1" transform="translate(399.453 276.492)"/>
                    <path id="Path_49356" d="M34.358 7.8a1.891 1.891 0 1 1-1.891 1.891A1.892 1.892 0 0 1 34.358 7.8z" class="cls-1" transform="translate(370.994 261.886)"/>
                    <path id="Path_49357" d="M34.54 8.387a1.769 1.769 0 1 1-1.769 1.769 1.766 1.766 0 0 1 1.769-1.769z" class="cls-1" transform="translate(374.424 254.348)"/>
                    <path id="Path_49358" d="M34.694 8.986a1.64 1.64 0 1 1-1.646 1.646 1.646 1.646 0 0 1 1.646-1.646z" class="cls-1" transform="translate(377.549 246.65)"/>
                    <path id="Path_49359" d="M34.922 9.585a1.646 1.646 0 1 1-1.633 1.646 1.646 1.646 0 0 1 1.633-1.646z" class="cls-1" transform="translate(380.268 238.682)"/>
                    <path id="Path_49360" d="M35.1 10.2a1.6 1.6 0 1 1-1.6 1.6 1.6 1.6 0 0 1 1.6-1.6z" class="cls-1" transform="translate(382.716 230.625)"/>
                    <circle id="Ellipse_10883" cx="1.496" cy="1.496" r="1.496" class="cls-1" transform="translate(418.604 233.323)"/>
                    <path id="Path_49361" d="M35.266 11.461a1.394 1.394 0 1 1-1.4 1.388 1.394 1.394 0 0 1 1.4-1.388z" class="cls-1" transform="translate(386.778 214.269)"/>
                    <path id="Path_49362" d="M35.35 12.1A1.345 1.345 0 1 1 34 13.437a1.345 1.345 0 0 1 1.35-1.337z" class="cls-1" transform="translate(388.278 205.907)"/>
                    <circle id="Ellipse_10884" cx="1.349" cy="1.349" r="1.349" class="cls-1" transform="translate(423.524 210.159)"/>
                    <path id="Path_49363" d="M35.456 13.384a1.277 1.277 0 1 1-1.277 1.277 1.274 1.274 0 0 1 1.277-1.277z" class="cls-1" transform="translate(390.309 188.961)"/>
                    <path id="Path_49364" d="M35.477 14.031a1.253 1.253 0 1 1-1.253 1.253 1.258 1.258 0 0 1 1.253-1.253z" class="cls-1" transform="translate(390.817 180.417)"/>
                    <path id="Path_49365" d="M36.076 14.689a1.105 1.105 0 1 1-1.105 1.105 1.1 1.1 0 0 1 1.105-1.105z" class="cls-1" transform="translate(399.244 171.973)"/>
                    <path id="Path_49366" d="M36.108 15.331a1.154 1.154 0 1 1-1.155 1.154 1.153 1.153 0 0 1 1.155-1.154z" class="cls-1" transform="translate(399.041 163.347)"/>
                    <path id="Path_49367" d="M35.941 15.986a1.032 1.032 0 1 1-1.019 1.032 1.03 1.03 0 0 1 1.019-1.032z" class="cls-1" transform="translate(398.691 154.893)"/>
                    <path id="Path_49368" d="M35.827 16.633a.976.976 0 1 1-.97.983.97.97 0 0 1 .97-.983z" class="cls-1" transform="translate(397.958 146.411)"/>
                    <path id="Path_49369" d="M35.72 17.274a.952.952 0 1 1-.958.958.959.959 0 0 1 .958-.958z" class="cls-1" transform="translate(396.886 137.946)"/>
                    <path id="Path_49370" d="M35.6 17.908a.958.958 0 0 1 0 1.916.958.958 0 0 1 0-1.916z" class="cls-1" transform="translate(395.499 129.513)"/>
                    <path id="Path_49371" d="M35.378 18.542a.884.884 0 1 1-.884.884.881.881 0 0 1 .884-.884z" class="cls-1" transform="translate(393.863 121.24)"/>
                    <path id="Path_49372" d="M35.269 19.158a.949.949 0 0 1 .958.946.958.958 0 1 1-1.916 0 .949.949 0 0 1 .958-.946z" class="cls-1" transform="translate(391.798 112.923)"/>
                    <path id="Path_49373" d="M35.223 19.757a1.13 1.13 0 1 1-1.13 1.13 1.127 1.127 0 0 1 1.13-1.13z" class="cls-1" transform="translate(389.339 104.611)"/>
                    <path id="Path_49374" d="M34.859 20.373a.983.983 0 1 1-.983.983.975.975 0 0 1 .983-.983z" class="cls-1" transform="translate(386.891 96.724)"/>
                    <path id="Path_49375" d="M34.512 20.975a.878.878 0 1 1 0 1.756.878.878 0 1 1 0-1.756z" class="cls-1" transform="translate(384.093 88.937)"/>
                    <circle id="Ellipse_10885" cx=".883" cy=".883" r=".883" class="cls-1" transform="translate(414.283 102.755)"/>
                    <circle id="Ellipse_10886" cx=".834" cy=".834" r=".834" class="cls-1" transform="translate(410.586 95.807)"/>
                    <circle id="Ellipse_10887" cx=".613" cy=".613" r=".613" class="cls-1" transform="translate(406.765 89.197)"/>
                    <path id="Path_49376" d="M32.907 23.254a.516.516 0 1 1-.516.516.519.519 0 0 1 .516-.516z" class="cls-1" transform="translate(370.137 59.393)"/>
                    <path id="Path_49377" d="M32.487 23.784a.467.467 0 1 1-.467.467.467.467 0 0 1 .467-.467z" class="cls-1" transform="translate(365.951 52.452)"/>
                    <path id="Path_49378" d="M32.032 24.3a.418.418 0 1 1-.405.418.414.414 0 0 1 .405-.418z" class="cls-1" transform="translate(361.518 45.723)"/>
                    <path id="Path_49379" d="M31.58 24.794a.378.378 0 0 1 .368.368.37.37 0 0 1-.368.368.362.362 0 0 1-.368-.368.369.369 0 0 1 .368-.368z" class="cls-1" transform="translate(356.836 39.234)"/>
                    <path id="Path_49380" d="M31.14 25.268a.37.37 0 0 1 .368.368.362.362 0 0 1-.368.364.37.37 0 0 1-.368-.368.378.378 0 0 1 .368-.364z" class="cls-1" transform="translate(351.872 32.938)"/>
                    <path id="Path_49381" d="M30.7 25.72a.393.393 0 1 1 0 .786.393.393 0 1 1 0-.786z" class="cls-1" transform="translate(346.671 26.885)"/>
                    <path id="Path_49382" d="M30.2 26.157a.369.369 0 0 1 .368.368.362.362 0 0 1-.368.368.37.37 0 0 1-.368-.368.378.378 0 0 1 .368-.368z" class="cls-1" transform="translate(341.289 21.13)"/>
                    <path id="Path_49383" d="M29.661 26.574a.317.317 0 0 1 .319.319.325.325 0 0 1-.319.319.317.317 0 0 1-.319-.319.31.31 0 0 1 .319-.319z" class="cls-1" transform="translate(335.739 15.69)"/>
                    <path id="Path_49384" d="M29.147 26.966a.317.317 0 0 1 .319.319.319.319 0 0 1-.639 0 .317.317 0 0 1 .32-.319z" class="cls-1" transform="translate(329.94 10.484)"/>
                    <path id="Path_49385" d="M28.595 27.338a.295.295 0 1 1-.295.295.3.3 0 0 1 .295-.295z" class="cls-1" transform="translate(323.983 5.592)"/>
                    <path id="Path_49386" d="M28.05 27.685a.3.3 0 0 1 .295.295.291.291 0 0 1-.295.295.284.284 0 0 1-.295-.295.291.291 0 0 1 .295-.295z" class="cls-1" transform="translate(317.835 .983)"/>
                    <path id="Path_49387" d="M27.467 28.01a.27.27 0 1 1-.27.27.273.273 0 0 1 .27-.27z" class="cls-1" transform="translate(311.539 -3.284)"/>
                    <path id="Path_49388" d="M26.894 28.309a.27.27 0 1 1-.27.27.273.273 0 0 1 .27-.27z" class="cls-1" transform="translate(305.075 -7.256)"/>
                    <path id="Path_49389" d="M26.309 28.583a.27.27 0 1 1-.27.27.273.273 0 0 1 .27-.27z" class="cls-1" transform="translate(298.475 -10.895)"/>
                    <path id="Path_49390" d="M25.736 28.83a.3.3 0 0 1 .295.295.291.291 0 0 1-.295.295.284.284 0 0 1-.295-.295.291.291 0 0 1 .295-.295z" class="cls-1" transform="translate(291.728 -14.224)"/>
                    <path id="Path_49391" d="M25.106 29.055a.27.27 0 1 1-.27.27.273.273 0 0 1 .27-.27z" class="cls-1" transform="translate(284.903 -17.164)"/>
                    <path id="Path_49392" d="M24.514 29.25a.295.295 0 0 1 0 .59.295.295 0 0 1 0-.59z" class="cls-1" transform="translate(277.942 -19.803)"/>
                    <circle id="Ellipse_10888" cx=".246" cy=".246" r=".246" class="cls-1" transform="translate(294.551 7.401)"/>
                    <circle id="Ellipse_10889" cx=".197" cy=".197" r=".197" class="cls-1" transform="translate(286.863 5.684)"/>
                    <path id="Path_49393" d="M22.489 29.693a.147.147 0 0 1 0 .295.147.147 0 1 1 0-.295z" class="cls-1" transform="translate(256.766 -25.392)"/>
                    <circle id="Ellipse_10890" cx=".098" cy=".098" r=".098" class="cls-1" transform="translate(271.294 3.25)"/>
                    <circle id="Ellipse_10891" cx=".074" cy=".074" r=".074" class="cls-1" transform="translate(263.419 2.512)"/>
                    <circle id="Ellipse_10892" cx=".049" cy=".049" r=".049" class="cls-1" transform="translate(255.518 2.112)"/>
                    <circle id="Ellipse_10893" cx=".049" cy=".049" r=".049" class="cls-1" transform="translate(247.582 2.028)"/>
                    <circle id="Ellipse_10894" cx=".074" cy=".074" r=".074" class="cls-1" transform="translate(239.624 2.257)"/>
                    <circle id="Ellipse_10895" cx=".074" cy=".074" r=".074" class="cls-1" transform="translate(231.71 2.851)"/>
                    <circle id="Ellipse_10896" cx=".123" cy=".123" r=".123" class="cls-1" transform="translate(223.778 3.732)"/>
                    <circle id="Ellipse_10897" cx=".147" cy=".147" r=".147" class="cls-1" transform="translate(215.919 4.974)"/>
                    <path id="Path_49394" d="M16.757 29.5a.2.2 0 1 1-.2.2.194.194 0 0 1 .2-.2z" class="cls-1" transform="translate(191.535 -22.98)"/>
                    <path id="Path_49395" d="M16.152 29.345a.221.221 0 1 1-.221.221.22.22 0 0 1 .221-.221z" class="cls-1" transform="translate(184.438 -20.917)"/>
                    <path id="Path_49396" d="M15.556 29.159a.246.246 0 1 1-.246.246.246.246 0 0 1 .246-.246z" class="cls-1" transform="translate(177.432 -18.496)"/>
                    <path id="Path_49397" d="M14.945 28.949a.246.246 0 1 1-.246.246.246.246 0 0 1 .246-.246z" class="cls-1" transform="translate(170.539 -15.707)"/>
                    <path id="Path_49398" d="M14.343 28.712a.246.246 0 0 1 .246.246.246.246 0 0 1-.491 0 .246.246 0 0 1 .245-.246z" class="cls-1" transform="translate(163.747 -12.559)"/>
                    <path id="Path_49399" d="M13.752 28.451a.246.246 0 1 1-.246.246.246.246 0 0 1 .246-.246z" class="cls-1" transform="translate(157.08 -9.092)"/>
                    <path id="Path_49400" d="M13.2 28.162a.27.27 0 1 1-.27.27.273.273 0 0 1 .27-.27z" class="cls-1" transform="translate(150.525 -5.303)"/>
                    <path id="Path_49401" d="M12.652 27.849a.295.295 0 1 1 0 .59.295.295 0 1 1 0-.59z" class="cls-1" transform="translate(144.117 -1.195)"/>
                    <path id="Path_49402" d="M12.121 27.512a.317.317 0 0 1 .319.319.319.319 0 1 1-.639 0 .317.317 0 0 1 .32-.319z" class="cls-1" transform="translate(137.856 3.232)"/>
                    <path id="Path_49403" d="M11.628 27.15a.369.369 0 0 1 .368.368.362.362 0 0 1-.368.368.37.37 0 0 1-.368-.368.378.378 0 0 1 .368-.368z" class="cls-1" transform="translate(131.741 7.942)"/>
                    <path id="Path_49404" d="M11.129 26.767a.393.393 0 1 1 0 .786.393.393 0 1 1 0-.786z" class="cls-1" transform="translate(125.829 12.979)"/>
                    <path id="Path_49405" d="M10.669 26.36a.442.442 0 1 1-.442.442.44.44 0 0 1 .442-.442z" class="cls-1" transform="translate(120.087 18.287)"/>
                    <path id="Path_49406" d="M10.226 25.932a.491.491 0 1 1-.491.491.493.493 0 0 1 .491-.491z" class="cls-1" transform="translate(114.536 23.873)"/>
                    <path id="Path_49407" d="M9.836 25.48a.583.583 0 1 1-.577.59.582.582 0 0 1 .577-.59z" class="cls-1" transform="translate(109.166 29.692)"/>
                    <circle id="Ellipse_10898" cx=".637" cy=".637" r=".637" class="cls-1" transform="translate(112.849 60.821)"/>
                    <circle id="Ellipse_10899" cx=".637" cy=".637" r=".637" class="cls-1" transform="translate(107.576 66.753)"/>
                    <path id="Path_49408" d="M8.673 24.021a.712.712 0 1 1-.712.712.713.713 0 0 1 .712-.712z" class="cls-1" transform="translate(94.522 48.813)"/>
                    <circle id="Ellipse_10900" cx=".76" cy=".76" r=".76" class="cls-1" transform="translate(97.692 79.143)"/>
                    <path id="Path_49409" d="M8.014 22.962a.8.8 0 1 1 0 1.609.8.8 0 1 1 0-1.609z" class="cls-1" transform="translate(85.971 62.694)"/>
                    <path id="Path_49410" d="M7.74 22.407a.878.878 0 1 1-.884.884.881.881 0 0 1 .884-.884z" class="cls-1" transform="translate(82.056 69.918)"/>
                    <path id="Path_49411" d="M7.468 21.839a.933.933 0 1 1-.933.933.933.933 0 0 1 .933-.933z" class="cls-1" transform="translate(78.434 77.351)"/>
                    <path id="Path_49412" d="M7.221 21.259a.983.983 0 1 1-.983.983.985.985 0 0 1 .983-.983z" class="cls-1" transform="translate(75.084 84.957)"/>
                    <path id="Path_49413" d="M7 20.667A1.032 1.032 0 1 1 5.966 21.7 1.038 1.038 0 0 1 7 20.667z" class="cls-1" transform="translate(72.015 92.721)"/>
                    <path id="Path_49414" d="M6.8 20.064a1.081 1.081 0 1 1-1.08 1.081 1.072 1.072 0 0 1 1.08-1.081z" class="cls-1" transform="translate(69.24 100.632)"/>
                    <path id="Path_49415" d="M6.651 19.45A1.148 1.148 0 1 1 5.5 20.6a1.153 1.153 0 0 1 1.151-1.15z" class="cls-1" transform="translate(66.724 108.652)"/>
                    <path id="Path_49416" d="M6.494 18.828a1.2 1.2 0 1 1-1.191 1.2 1.206 1.206 0 0 1 1.191-1.2z" class="cls-1" transform="translate(64.535 116.803)"/>
                    <path id="Path_49417" d="M6.375 18.2a1.253 1.253 0 1 1-1.24 1.253 1.25 1.25 0 0 1 1.24-1.253z" class="cls-1" transform="translate(62.64 125.059)"/>
                    <circle id="Ellipse_10901" cx="1.299" cy="1.299" r="1.299" class="cls-1" transform="translate(66.039 150.969)"/>
                    <circle id="Ellipse_10902" cx="1.373" cy="1.373" r="1.373" class="cls-1" transform="translate(64.615 158.717)"/>
                    <circle id="Ellipse_10903" cx="1.373" cy="1.373" r="1.373" class="cls-1" transform="translate(63.6 166.588)"/>
                    <circle id="Ellipse_10904" cx="1.398" cy="1.398" r="1.398" class="cls-1" transform="translate(62.898 174.472)"/>
                    <circle id="Ellipse_10905" cx="1.447" cy="1.447" r="1.447" class="cls-1" transform="translate(62.51 182.352)"/>
                    <path id="Path_49418" d="M6.178 14.336A1.474 1.474 0 1 1 4.7 15.81a1.478 1.478 0 0 1 1.478-1.474z" class="cls-1" transform="translate(57.777 175.924)"/>
                    <circle id="Ellipse_10906" cx="1.496" cy="1.496" r="1.496" class="cls-1" transform="translate(62.799 198.17)"/>
                    <path id="Path_49419" d="M6.351 13.039a1.566 1.566 0 1 1-1.572 1.572 1.575 1.575 0 0 1 1.572-1.572z" class="cls-1" transform="translate(58.623 192.966)"/>
                    <path id="Path_49420" d="M6.4 12.4a1.541 1.541 0 1 1-1.535 1.548A1.541 1.541 0 0 1 6.4 12.4z" class="cls-1" transform="translate(59.582 201.503)"/>
                    <path id="Path_49421" d="M6.532 11.761a1.566 1.566 0 1 1-1.56 1.56 1.565 1.565 0 0 1 1.56-1.56z" class="cls-1" transform="translate(60.801 209.941)"/>
                    <path id="Path_49422" d="M6.669 11.129a1.572 1.572 0 1 1-1.56 1.571 1.567 1.567 0 0 1 1.56-1.571z" class="cls-1" transform="translate(62.346 218.322)"/>
                    <path id="Path_49423" d="M6.833 10.5a1.572 1.572 0 1 1-1.56 1.572 1.567 1.567 0 0 1 1.56-1.572z" class="cls-1" transform="translate(64.197 226.624)"/>
                    <path id="Path_49424" d="M7.1 9.881a1.64 1.64 0 1 1-1.646 1.646A1.646 1.646 0 0 1 7.1 9.881z" class="cls-1" transform="translate(66.272 234.763)"/>
                    <path id="Path_49425" d="M7.365 9.268a1.689 1.689 0 1 1-1.695 1.683 1.677 1.677 0 0 1 1.695-1.683z" class="cls-1" transform="translate(68.676 242.806)"/>
                    <path id="Path_49426" d="M7.7 8.661a1.787 1.787 0 1 1-1.8 1.781 1.785 1.785 0 0 1 1.8-1.781z" class="cls-1" transform="translate(71.315 250.672)"/>
                    <path id="Path_49427" d="M7.965 8.073a1.787 1.787 0 1 1-1.793 1.781 1.793 1.793 0 0 1 1.793-1.781z" class="cls-1" transform="translate(74.339 258.482)"/>
                    <path id="Path_49428" d="M8.236 7.5a1.762 1.762 0 1 1-1.769 1.768A1.759 1.759 0 0 1 8.236 7.5z" class="cls-1" transform="translate(77.667 266.155)"/>
                    <path id="Path_49429" d="M8.507 6.94a1.713 1.713 0 1 1-1.719 1.719A1.717 1.717 0 0 1 8.507 6.94z" class="cls-1" transform="translate(81.289 273.677)"/>
                    <path id="Path_49430" d="M8.939 6.383A1.812 1.812 0 1 1 7.121 8.2a1.811 1.811 0 0 1 1.818-1.817z" class="cls-1" transform="translate(85.045 280.879)"/>
                    <path id="Path_49431" d="M9.461 5.835a1.984 1.984 0 1 1-1.99 1.99 1.979 1.979 0 0 1 1.99-1.99z" class="cls-1" transform="translate(88.994 287.813)"/>
                    <path id="Path_49432" d="M9.9 5.311a2.057 2.057 0 1 1-2.048 2.051A2.057 2.057 0 0 1 9.9 5.311z" class="cls-1" transform="translate(93.292 294.626)"/>
                    <path id="Path_49433" d="M10.414 4.8a2.155 2.155 0 1 1-2.162 2.151A2.144 2.144 0 0 1 10.414 4.8z" class="cls-1" transform="translate(97.805 301.19)"/>
                    <path id="Path_49434" d="M10.843 4.319a2.155 2.155 0 1 1-2.162 2.149 2.154 2.154 0 0 1 2.162-2.149z" class="cls-1" transform="translate(102.645 307.605)"/>
                    <circle id="Ellipse_10907" cx="2.084" cy="2.084" r="2.084" class="cls-1" transform="translate(116.924 317.694)"/>
                    <circle id="Ellipse_10908" cx="2.158" cy="2.158" r="2.158" class="cls-1" transform="translate(122.611 323.079)"/>
                    <path id="Path_49435" d="M12.407 2.972a2.327 2.327 0 1 1-2.334 2.321 2.322 2.322 0 0 1 2.334-2.321z" class="cls-1" transform="translate(118.349 325.151)"/>
                    <path id="Path_49436" d="M13.058 2.555a2.506 2.506 0 1 1-2.493 2.505 2.508 2.508 0 0 1 2.493-2.505z" class="cls-1" transform="translate(123.9 330.334)"/>
                    <path id="Path_49437" d="M13.806 2.154a2.751 2.751 0 1 1-2.739 2.751 2.754 2.754 0 0 1 2.739-2.751z" class="cls-1" transform="translate(129.564 335.169)"/>
                    <path id="Path_49438" d="M14.423 1.79A2.819 2.819 0 1 1 11.6 4.6a2.823 2.823 0 0 1 2.823-2.81z" class="cls-1" transform="translate(135.554 339.868)"/>
                    <path id="Path_49439" d="M15.066 1.447a2.917 2.917 0 1 1-2.923 2.911 2.909 2.909 0 0 1 2.923-2.911z" class="cls-1" transform="translate(141.703 344.227)"/>
                    <circle id="Ellipse_10909" cx="2.844" cy="2.844" r="2.844" class="cls-1" transform="translate(160.877 349.565)"/>
                    <path id="Path_49440" d="M16.29.841a3.021 3.021 0 1 1-3.009 3.021A3.019 3.019 0 0 1 16.29.841z" class="cls-1" transform="translate(154.541 352.067)"/>
                    <path id="Path_49441" d="M16.9.578a3.04 3.04 0 1 1-3.03 3.046A3.045 3.045 0 0 1 16.9.578z" class="cls-1" transform="translate(161.186 355.523)"/>
                    <circle id="Ellipse_10910" cx="2.869" cy="2.869" r="2.869" class="cls-1" transform="translate(182.611 359.173)"/>
                    <path id="Path_49442" d="M18.06.138a2.966 2.966 0 1 1-2.972 2.972A2.964 2.964 0 0 1 18.06.138z" class="cls-1" transform="translate(174.928 361.515)"/>
                    <path id="Path_49443" d="M18.69-.048a2.991 2.991 0 1 1-2.985 3 2.993 2.993 0 0 1 2.985-3z" class="cls-1" transform="translate(181.9 363.936)"/>
                    <path id="Path_49444" d="M19.216-.2a2.874 2.874 0 1 1-2.874 2.874A2.878 2.878 0 0 1 19.216-.2z" class="cls-1" transform="translate(189.075 366.135)"/>
                    <path id="Path_49445" d="M19.217-.27a2.18 2.18 0 1 1-2.186 2.17 2.181 2.181 0 0 1 2.186-2.17z" class="cls-1" transform="translate(196.848 368.506)"/>
                    <circle id="Ellipse_10911" cx="1.545" cy="1.545" r="1.545" class="cls-1" transform="translate(222.356 370.135)"/>
                    <path id="Path_49446" d="M19.572-.367A1.179 1.179 0 1 1 18.393.812a1.179 1.179 0 0 1 1.179-1.179z" class="cls-1" transform="translate(212.214 371.796)"/>
                    <path id="Path_49447" d="M20.1-.4A1.05 1.05 0 1 1 19.047.651 1.056 1.056 0 0 1 20.1-.4z" class="cls-1" transform="translate(219.592 372.559)"/>
                    <path id="Path_49448" d="M20.7-.422A1.012 1.012 0 0 1 21.711.585a1.007 1.007 0 1 1-2.014 0A1.012 1.012 0 0 1 20.7-.422z" class="cls-1" transform="translate(226.926 372.871)"/>
                    <path id="Path_49449" d="M21.26-.407a.909.909 0 1 1-.909.907.915.915 0 0 1 .909-.907z" class="cls-1" transform="translate(234.304 372.868)"/>
                    <path id="Path_49450" d="M22.041-.385A1.046 1.046 0 0 1 23.085.671a1.05 1.05 0 1 1-2.1 0 1.048 1.048 0 0 1 1.056-1.056z" class="cls-1" transform="translate(241.457 372.281)"/>
                    <circle id="Ellipse_10912" cx="1.324" cy="1.324" r="1.324" class="cls-1" transform="translate(270.069 370.863)"/>
                    <path id="Path_49451" d="M24.091-.3a1.871 1.871 0 0 1 1.879 1.879A1.885 1.885 0 1 1 24.091-.3z" class="cls-1" transform="translate(255.164 369.507)"/>
                    <path id="Path_49452" d="M25.279-.234a2.5 2.5 0 1 1-2.493 2.505 2.5 2.5 0 0 1 2.493-2.505z" class="cls-1" transform="translate(261.775 367.389)"/>
                    <path id="Path_49453" d="M26.248-.12a2.868 2.868 0 1 1-2.862 2.874A2.878 2.878 0 0 1 26.248-.12z" class="cls-1" transform="translate(268.544 365.138)"/>
                    <circle id="Ellipse_10913" cx="3.016" cy="3.016" r="3.016" class="cls-1" transform="translate(299.436 362.777)"/>
                    <path id="Path_49454" d="M27.577.239a2.966 2.966 0 1 1-2.96 2.96 2.964 2.964 0 0 1 2.96-2.96z" class="cls-1" transform="translate(282.432 360.173)"/>
                    <path id="Path_49455" d="M28.353.449a3.138 3.138 0 1 1-3.144 3.144A3.14 3.14 0 0 1 28.353.449z" class="cls-1" transform="translate(289.111 357.04)"/>
                    <path id="Path_49456" d="M29.017.691A3.218 3.218 0 1 1 25.8 3.909 3.218 3.218 0 0 1 29.017.691z" class="cls-1" transform="translate(295.767 353.666)"/>
                    <path id="Path_49457" d="M29.342.988a2.942 2.942 0 1 1-2.935 2.948A2.956 2.956 0 0 1 29.342.988z" class="cls-1" transform="translate(302.627 350.274)"/>
                    <circle id="Ellipse_10914" cx="2.844" cy="2.844" r="2.844" class="cls-1" transform="translate(336.163 347.692)"/>
                    <path id="Path_49458" d="M30.329 1.624A2.77 2.77 0 1 1 27.553 4.4a2.77 2.77 0 0 1 2.776-2.776z" class="cls-1" transform="translate(315.556 342.171)"/>
                    <path id="Path_49459" d="M30.738 1.982A2.628 2.628 0 1 1 28.11 4.61a2.631 2.631 0 0 1 2.628-2.628z" class="cls-1" transform="translate(321.84 337.699)"/>
                    <path id="Path_49460" d="M31.133 2.364a2.475 2.475 0 1 1-2.481 2.469 2.479 2.479 0 0 1 2.481-2.469z" class="cls-1" transform="translate(327.954 332.932)"/>
                    <path id="Path_49461" d="M31.557 2.764a2.377 2.377 0 1 1-2.383 2.37 2.364 2.364 0 0 1 2.383-2.37z" class="cls-1" transform="translate(333.843 327.816)"/>
                    <circle id="Ellipse_10915" cx="2.281" cy="2.281" r="2.281" class="cls-1" transform="translate(369.215 325.593)"/>
                    <path id="Path_49462" d="M32.441 3.62a2.278 2.278 0 1 1-2.284 2.272 2.275 2.275 0 0 1 2.284-2.272z" class="cls-1" transform="translate(344.933 316.643)"/>
                    <path id="Path_49463" d="M32.81 4.082a2.186 2.186 0 1 1-2.186 2.186 2.191 2.191 0 0 1 2.186-2.186z" class="cls-1" transform="translate(350.202 310.691)"/>
                    <circle id="Ellipse_10916" cx="2.133" cy="2.133" r="2.133" class="cls-1" transform="translate(386.278 309.004)"/>
                    <circle id="Ellipse_10917" cx="2.084" cy="2.084" r="2.084" class="cls-1" transform="translate(391.472 303.011)"/>
                    <circle id="Ellipse_10918" cx="1.986" cy="1.986" r="1.986" class="cls-1" transform="translate(396.452 296.852)"/>
                    <path id="Path_49464" d="M34.2 6.1a1.934 1.934 0 1 1-1.928 1.928A1.934 1.934 0 0 1 34.2 6.1z" class="cls-1" transform="translate(368.84 284.339)"/>
                    <path id="Path_49465" d="M34.569 6.645a1.941 1.941 0 1 1-1.941 1.941 1.945 1.945 0 0 1 1.941-1.941z" class="cls-1" transform="translate(372.811 277.141)"/>
                    <circle id="Ellipse_10919" cx="1.863" cy="1.863" r="1.863" class="cls-1" transform="translate(409.557 277.031)"/>
                    <path id="Path_49466" d="M35.045 7.785a1.769 1.769 0 1 1-1.769 1.769 1.777 1.777 0 0 1 1.769-1.769z" class="cls-1" transform="translate(380.121 262.344)"/>
                    <path id="Path_49467" d="M35.246 8.373a1.695 1.695 0 1 1-1.683 1.695 1.7 1.7 0 0 1 1.683-1.695z" class="cls-1" transform="translate(383.359 254.681)"/>
                    <path id="Path_49468" d="M35.49 8.969a1.67 1.67 0 1 1-1.67 1.67 1.662 1.662 0 0 1 1.67-1.67z" class="cls-1" transform="translate(386.259 246.815)"/>
                    <path id="Path_49469" d="M35.7 9.575a1.646 1.646 0 1 1-1.646 1.646A1.646 1.646 0 0 1 35.7 9.575z" class="cls-1" transform="translate(388.865 238.815)"/>
                    <path id="Path_49470" d="M35.788 10.2a1.523 1.523 0 1 1-1.523 1.523 1.523 1.523 0 0 1 1.523-1.523z" class="cls-1" transform="translate(391.279 230.786)"/>
                    <path id="Path_49471" d="M35.9 10.826a1.443 1.443 0 1 1-1.449 1.437 1.441 1.441 0 0 1 1.449-1.437z" class="cls-1" transform="translate(393.344 222.605)"/>
                    <path id="Path_49472" d="M35.981 11.46a1.376 1.376 0 1 1-1.381 1.376 1.371 1.371 0 0 1 1.381-1.376z" class="cls-1" transform="translate(395.115 214.319)"/>
                    <path id="Path_49473" d="M35.968 12.107a1.222 1.222 0 1 1-1.228 1.228 1.224 1.224 0 0 1 1.228-1.228z" class="cls-1" transform="translate(396.638 206.033)"/>
                    <path id="Path_49474" d="M36.03 12.748a1.2 1.2 0 1 1 0 2.395 1.2 1.2 0 0 1 0-2.395z" class="cls-1" transform="translate(397.755 197.568)"/>
                    <path id="Path_49475" d="M36.009 13.4a1.105 1.105 0 1 1-1.093 1.1 1.1 1.1 0 0 1 1.093-1.1z" class="cls-1" transform="translate(398.624 189.119)"/>
                    <path id="Path_49476" d="M36.062 14.043a1.105 1.105 0 0 1 0 2.211 1.105 1.105 0 1 1 0-2.211z" class="cls-1" transform="translate(399.086 180.553)"/>
                    <path id="Path_49477" d="M37.022 14.669a1.351 1.351 0 1 1-1.351 1.351 1.345 1.345 0 0 1 1.351-1.351z" class="cls-1" transform="translate(407.141 171.747)"/>
                    <path id="Path_49478" d="M36.839 15.329a1.179 1.179 0 1 1-1.167 1.179 1.179 1.179 0 0 1 1.167-1.179z" class="cls-1" transform="translate(407.153 163.325)"/>
                    <path id="Path_49479" d="M36.721 15.982a1.081 1.081 0 1 1-1.081 1.081 1.082 1.082 0 0 1 1.081-1.081z" class="cls-1" transform="translate(406.792 154.848)"/>
                    <path id="Path_49480" d="M36.632 16.627a1.056 1.056 0 1 1-1.056 1.056 1.056 1.056 0 0 1 1.056-1.056z" class="cls-1" transform="translate(406.07 146.331)"/>
                    <path id="Path_49481" d="M36.518 17.269a1.026 1.026 0 1 1-1.032 1.019 1.027 1.027 0 0 1 1.032-1.019z" class="cls-1" transform="translate(405.054 137.865)"/>
                    <path id="Path_49482" d="M36.422 17.9a1.056 1.056 0 1 1-1.056 1.056 1.056 1.056 0 0 1 1.056-1.056z" class="cls-1" transform="translate(403.7 129.396)"/>
                    <path id="Path_49483" d="M36.312 18.528a1.105 1.105 0 1 1-1.093 1.105 1.1 1.1 0 0 1 1.093-1.105z" class="cls-1" transform="translate(402.042 120.984)"/>
                    <circle id="Ellipse_10920" cx=".932" cy=".932" r=".932" class="cls-1" transform="translate(435.346 132.026)"/>
                    <path id="Path_49484" d="M35.982 19.766a1.13 1.13 0 1 1-1.13 1.13 1.127 1.127 0 0 1 1.13-1.13z" class="cls-1" transform="translate(397.902 104.492)"/>
                    <path id="Path_49485" d="M35.831 20.368a1.2 1.2 0 0 1 0 2.395 1.2 1.2 0 1 1 0-2.395z" class="cls-1" transform="translate(395.363 96.361)"/>
                    <path id="Path_49486" d="M35.507 20.972a1.13 1.13 0 1 1-1.118 1.13 1.127 1.127 0 0 1 1.118-1.13z" class="cls-1" transform="translate(392.678 88.474)"/>
                    <path id="Path_49487" d="M35.25 21.56a1.124 1.124 0 1 1-1.13 1.118 1.124 1.124 0 0 1 1.13-1.118z" class="cls-1" transform="translate(389.643 80.676)"/>
                    <path id="Path_49488" d="M34.868 22.144a1.032 1.032 0 1 1-1.032 1.032 1.038 1.038 0 0 1 1.032-1.032z" class="cls-1" transform="translate(386.439 73.104)"/>
                    <path id="Path_49489" d="M34.281 22.732a.737.737 0 1 1-.737.737.739.739 0 0 1 .737-.737z" class="cls-1" transform="translate(383.145 65.884)"/>
                    <circle id="Ellipse_10921" cx=".564" cy=".564" r=".564" class="cls-1" transform="translate(412.712 82.025)"/>
                    <circle id="Ellipse_10922" cx=".539" cy=".539" r=".539" class="cls-1" transform="translate(408.31 75.462)"/>
                    <path id="Path_49490" d="M32.908 24.366a.422.422 0 0 1 .418.418.43.43 0 0 1-.418.418.422.422 0 0 1-.418-.418.414.414 0 0 1 .418-.418z" class="cls-1" transform="translate(371.254 44.82)"/>
                    <path id="Path_49491" d="M32.459 24.876a.378.378 0 0 1 .368.368.37.37 0 0 1-.368.368.362.362 0 0 1-.368-.368.369.369 0 0 1 .368-.368z" class="cls-1" transform="translate(366.752 38.144)"/>
                    <path id="Path_49492" d="M32.036 25.364a.378.378 0 0 1 .368.368.37.37 0 0 1-.368.368.362.362 0 0 1-.368-.368.37.37 0 0 1 .368-.368z" class="cls-1" transform="translate(361.98 31.663)"/>
                    <path id="Path_49493" d="M31.616 25.833a.4.4 0 0 1 .393.393.4.4 0 0 1-.393.393.388.388 0 0 1-.393-.393.4.4 0 0 1 .393-.393z" class="cls-1" transform="translate(356.96 25.385)"/>
                    <path id="Path_49494" d="M31.109 26.289a.343.343 0 0 1 .344.344.336.336 0 0 1-.344.344.343.343 0 0 1-.344-.344.351.351 0 0 1 .344-.344z" class="cls-1" transform="translate(351.793 19.426)"/>
                    <path id="Path_49495" d="M30.607 26.724a.319.319 0 1 1 0 .639.319.319 0 1 1 0-.639z" class="cls-1" transform="translate(346.411 13.698)"/>
                    <path id="Path_49496" d="M30.11 27.137a.319.319 0 1 1 0 .639.319.319 0 0 1 0-.639z" class="cls-1" transform="translate(340.804 8.213)"/>
                    <path id="Path_49497" d="M29.574 27.532a.295.295 0 0 1 0 .59.295.295 0 1 1 0-.59z" class="cls-1" transform="translate(335.028 3.015)"/>
                    <path id="Path_49498" d="M29.022 27.9a.27.27 0 0 1 0 .54.27.27 0 0 1 0-.54z" class="cls-1" transform="translate(329.082 -1.89)"/>
                    <path id="Path_49499" d="M28.457 28.256a.246.246 0 1 1-.246.246.246.246 0 0 1 .246-.246z" class="cls-1" transform="translate(322.979 -6.502)"/>
                    <path id="Path_49500" d="M27.9 28.583a.246.246 0 1 1-.246.246.246.246 0 0 1 .246-.246z" class="cls-1" transform="translate(316.684 -10.846)"/>
                    <path id="Path_49501" d="M27.329 28.887a.246.246 0 1 1-.246.246.246.246 0 0 1 .246-.246z" class="cls-1" transform="translate(310.253 -14.883)"/>
                    <path id="Path_49502" d="M26.747 29.168a.239.239 0 0 1 .246.246.246.246 0 0 1-.491 0 .239.239 0 0 1 .245-.246z" class="cls-1" transform="translate(303.687 -18.603)"/>
                    <path id="Path_49503" d="M26.154 29.424a.246.246 0 1 1-.246.246.246.246 0 0 1 .246-.246z" class="cls-1" transform="translate(296.997 -22.016)"/>
                    <path id="Path_49504" d="M25.482 29.662a.172.172 0 1 1 0 .344.172.172 0 1 1 0-.344z" class="cls-1" transform="translate(290.25 -25.029)"/>
                    <circle id="Ellipse_10923" cx=".074" cy=".074" r=".074" class="cls-1" transform="translate(308.147 2.187)"/>
                    <circle id="Ellipse_10924" cx=".025" cy=".025" r=".025" class="cls-1" transform="translate(300.58)"/>
                    <circle id="Ellipse_10925" cx=".025" cy=".025" r=".025" class="cls-1" transform="translate(198.601)"/>
                    <circle id="Ellipse_10926" cx=".074" cy=".074" r=".074" class="cls-1" transform="translate(190.936 2.187)"/>
                    <path id="Path_49505" d="M14.692 29.664a.158.158 0 0 1 .147.147.149.149 0 0 1-.147.147.142.142 0 0 1-.147-.147.149.149 0 0 1 .147-.147z" class="cls-1" transform="translate(168.802 -25.007)"/>
                    <path id="Path_49506" d="M14.157 29.426a.221.221 0 1 1-.221.221.22.22 0 0 1 .221-.221z" class="cls-1" transform="translate(161.931 -21.993)"/>
                    <path id="Path_49507" d="M13.586 29.168a.239.239 0 0 1 .246.246.246.246 0 0 1-.491 0 .239.239 0 0 1 .245-.246z" class="cls-1" transform="translate(155.207 -18.603)"/>
                    <path id="Path_49508" d="M13 28.887a.246.246 0 1 1-.246.246.246.246 0 0 1 .246-.246z" class="cls-1" transform="translate(148.641 -14.883)"/>
                    <path id="Path_49509" d="M12.456 28.581a.27.27 0 1 1-.27.27.273.273 0 0 1 .27-.27z" class="cls-1" transform="translate(142.188 -10.868)"/>
                    <path id="Path_49510" d="M11.9 28.254a.27.27 0 1 1 0 .54.27.27 0 0 1 0-.54z" class="cls-1" transform="translate(135.893 -6.525)"/>
                    <path id="Path_49511" d="M11.378 27.9a.295.295 0 1 1-.295.295.3.3 0 0 1 .295-.295z" class="cls-1" transform="translate(129.744 -1.912)"/>
                    <path id="Path_49512" d="M10.894 27.528a.351.351 0 0 1 .344.344.343.343 0 0 1-.344.344.336.336 0 0 1-.344-.344.343.343 0 0 1 .344-.344z" class="cls-1" transform="translate(123.731 2.97)"/>
                    <path id="Path_49513" d="M10.4 27.133a.359.359 0 0 1 .356.368.362.362 0 1 1-.725 0 .362.362 0 0 1 .369-.368z" class="cls-1" transform="translate(117.921 8.167)"/>
                    <path id="Path_49514" d="M9.952 26.716a.418.418 0 1 1 0 .835.418.418 0 0 1 0-.835z" class="cls-1" transform="translate(112.268 13.608)"/>
                    <path id="Path_49515" d="M9.539 26.277a.491.491 0 1 1-.491.491.493.493 0 0 1 .491-.491z" class="cls-1" transform="translate(106.786 19.291)"/>
                    <path id="Path_49516" d="M9.145 25.819a.563.563 0 0 1 .565.565.556.556 0 0 1-.565.565.563.563 0 0 1-.565-.565.571.571 0 0 1 .565-.565z" class="cls-1" transform="translate(101.506 25.227)"/>
                    <path id="Path_49517" d="M8.748 25.344a.614.614 0 0 1 0 1.228.614.614 0 0 1 0-1.228z" class="cls-1" transform="translate(96.474 31.437)"/>
                    <path id="Path_49518" d="M8.335 24.854a.633.633 0 1 1-.626.626.632.632 0 0 1 .626-.626z" class="cls-1" transform="translate(91.679 37.909)"/>
                    <circle id="Ellipse_10927" cx=".711" cy=".711" r=".711" class="cls-1" transform="translate(94.361 68.887)"/>
                    <circle id="Ellipse_10928" cx=".76" cy=".76" r=".76" class="cls-1" transform="translate(89.62 75.241)"/>
                    <circle id="Ellipse_10929" cx=".809" cy=".809" r=".809" class="cls-1" transform="translate(85.145 81.78)"/>
                    <path id="Path_49519" d="M7.089 22.72a.884.884 0 1 1-.889.88.881.881 0 0 1 .889-.88z" class="cls-1" transform="translate(74.711 65.748)"/>
                    <path id="Path_49520" d="M6.807 22.152a.933.933 0 1 1-.921.933.933.933 0 0 1 .921-.933z" class="cls-1" transform="translate(71.112 73.194)"/>
                    <path id="Path_49521" d="M6.594 21.57a1 1 0 1 1-1.007.995 1 1 0 0 1 1.007-.995z" class="cls-1" transform="translate(67.739 80.789)"/>
                    <path id="Path_49522" d="M6.394 20.976a1.081 1.081 0 1 1 0 2.162 1.081 1.081 0 1 1 0-2.162z" class="cls-1" transform="translate(64.648 88.519)"/>
                    <path id="Path_49523" d="M6.195 20.374a1.124 1.124 0 1 1-1.13 1.118 1.122 1.122 0 0 1 1.13-1.118z" class="cls-1" transform="translate(61.85 96.429)"/>
                    <path id="Path_49524" d="M6 19.764a1.154 1.154 0 1 1-1.154 1.154A1.153 1.153 0 0 1 6 19.764z" class="cls-1" transform="translate(59.345 104.469)"/>
                    <circle id="Ellipse_10930" cx="1.201" cy="1.201" r="1.201" class="cls-1" transform="translate(61.751 131.757)"/>
                    <path id="Path_49525" d="M5.724 18.516a1.253 1.253 0 1 1-1.253 1.253 1.258 1.258 0 0 1 1.253-1.253z" class="cls-1" transform="translate(55.149 120.848)"/>
                    <path id="Path_49526" d="M5.625 17.882a1.3 1.3 0 1 1-1.3 1.3 1.31 1.31 0 0 1 1.3-1.3z" class="cls-1" transform="translate(53.479 129.171)"/>
                    <circle id="Ellipse_10931" cx="1.349" cy="1.349" r="1.349" class="cls-1" transform="translate(56.307 154.81)"/>
                    <path id="Path_49527" d="M5.505 16.6A1.4 1.4 0 1 1 4.1 18a1.4 1.4 0 0 1 1.405-1.4z" class="cls-1" transform="translate(51.019 146.015)"/>
                    <path id="Path_49528" d="M5.45 15.954a1.425 1.425 0 1 1-1.412 1.425 1.426 1.426 0 0 1 1.412-1.425z" class="cls-1" transform="translate(50.264 154.532)"/>
                    <path id="Path_49529" d="M5.445 15.307A1.449 1.449 0 1 1 4 16.756a1.452 1.452 0 0 1 1.445-1.449z" class="cls-1" transform="translate(49.79 163.077)"/>
                    <path id="Path_49530" d="M5.455 14.659a1.474 1.474 0 1 1-1.474 1.474 1.468 1.468 0 0 1 1.474-1.474z" class="cls-1" transform="translate(49.621 171.634)"/>
                    <circle id="Ellipse_10932" cx="1.496" cy="1.496" r="1.496" class="cls-1" transform="translate(53.737 194.206)"/>
                    <path id="Path_49531" d="M5.563 13.362a1.548 1.548 0 1 1-1.535 1.548 1.549 1.549 0 0 1 1.535-1.548z" class="cls-1" transform="translate(50.151 188.713)"/>
                    <path id="Path_49532" d="M5.663 12.717a1.572 1.572 0 1 1-1.572 1.572 1.567 1.567 0 0 1 1.572-1.572z" class="cls-1" transform="translate(50.862 197.231)"/>
                    <path id="Path_49533" d="M5.778 12.076a1.591 1.591 0 1 1-1.6 1.6 1.593 1.593 0 0 1 1.6-1.6z" class="cls-1" transform="translate(51.877 205.708)"/>
                    <circle id="Ellipse_10933" cx="1.545" cy="1.545" r="1.545" class="cls-1" transform="translate(57.56 225.634)"/>
                    <path id="Path_49534" d="M5.995 10.814a1.548 1.548 0 1 1 0 3.1 1.548 1.548 0 1 1 0-3.1z" class="cls-1" transform="translate(54.878 222.555)"/>
                    <circle id="Ellipse_10934" cx="1.57" cy="1.57" r="1.57" class="cls-1" transform="translate(61.382 241.007)"/>
                    <path id="Path_49535" d="M6.494 9.562A1.695 1.695 0 1 1 4.8 11.257a1.7 1.7 0 0 1 1.694-1.695z" class="cls-1" transform="translate(58.849 238.889)"/>
                    <path id="Path_49536" d="M6.759 8.951A1.738 1.738 0 1 1 5.015 10.7a1.732 1.732 0 0 1 1.744-1.749z" class="cls-1" transform="translate(61.286 246.919)"/>
                    <path id="Path_49537" d="M7.048 8.348a1.793 1.793 0 1 1-1.793 1.793 1.8 1.8 0 0 1 1.793-1.793z" class="cls-1" transform="translate(63.994 254.817)"/>
                    <path id="Path_49538" d="M7.327 7.758a1.818 1.818 0 1 1-1.805 1.818 1.814 1.814 0 0 1 1.805-1.818z" class="cls-1" transform="translate(67.006 262.604)"/>
                    <path id="Path_49539" d="M7.6 7.184a1.793 1.793 0 1 1-1.784 1.793A1.8 1.8 0 0 1 7.6 7.184z" class="cls-1" transform="translate(70.323 270.277)"/>
                    <path id="Path_49540" d="M7.879 6.624a1.744 1.744 0 1 1-1.744 1.744 1.751 1.751 0 0 1 1.744-1.744z" class="cls-1" transform="translate(73.922 277.813)"/>
                    <circle id="Ellipse_10935" cx="1.839" cy="1.839" r="1.839" class="cls-1" transform="translate(84.116 291.107)"/>
                    <circle id="Ellipse_10936" cx="1.961" cy="1.961" r="1.961" class="cls-1" transform="translate(88.419 297.572)"/>
                    <path id="Path_49541" d="M9.141 5A1.934 1.934 0 1 1 7.2 6.928 1.924 1.924 0 0 1 9.141 5z" class="cls-1" transform="translate(85.937 299.002)"/>
                    <circle id="Ellipse_10937" cx="2.011" cy="2.011" r="2.011" class="cls-1" transform="translate(98.01 310.131)"/>
                    <path id="Path_49542" d="M10.057 4a2.039 2.039 0 1 1-2.039 2.037A2.039 2.039 0 0 1 10.057 4z" class="cls-1" transform="translate(95.165 312.102)"/>
                    <path id="Path_49543" d="M10.487 3.527a2.039 2.039 0 1 1-2.026 2.039 2.034 2.034 0 0 1 2.026-2.039z" class="cls-1" transform="translate(100.163 318.357)"/>
                    <circle id="Ellipse_10938" cx="2.133" cy="2.133" r="2.133" class="cls-1" transform="translate(114.191 327.342)"/>
                    <path id="Path_49544" d="M11.644 2.624a2.26 2.26 0 1 1-2.26 2.26 2.259 2.259 0 0 1 2.26-2.26z" class="cls-1" transform="translate(110.576 329.909)"/>
                    <path id="Path_49545" d="M12.366 2.191a2.5 2.5 0 1 1-2.505 2.493 2.5 2.5 0 0 1 2.505-2.493z" class="cls-1" transform="translate(115.958 335.181)"/>
                    <path id="Path_49546" d="M12.925 1.795A2.548 2.548 0 1 1 10.37 4.35a2.553 2.553 0 0 1 2.555-2.555z" class="cls-1" transform="translate(121.7 340.342)"/>
                    <path id="Path_49547" d="M13.544 1.415a2.653 2.653 0 1 1-2.653 2.653 2.647 2.647 0 0 1 2.653-2.653z" class="cls-1" transform="translate(127.578 345.18)"/>
                    <circle id="Ellipse_10939" cx="2.82" cy="2.82" r="2.82" class="cls-1" transform="translate(144.977 350.72)"/>
                    <path id="Path_49548" d="M15.006.707a3.04 3.04 0 1 1-3.046 3.034A3.032 3.032 0 0 1 15.006.707z" class="cls-1" transform="translate(139.638 353.81)"/>
                    <path id="Path_49549" d="M15.632.4a3.113 3.113 0 1 1-3.107 3.1A3.114 3.114 0 0 1 15.632.4z" class="cls-1" transform="translate(146.012 357.78)"/>
                    <circle id="Ellipse_10940" cx="2.943" cy="2.943" r="2.943" class="cls-1" transform="translate(165.856 361.788)"/>
                    <path id="Path_49550" d="M16.617-.122a2.9 2.9 0 1 1-2.9 2.9 2.893 2.893 0 0 1 2.9-2.9z" class="cls-1" transform="translate(159.472 365.103)"/>
                    <circle id="Ellipse_10941" cx="1.937" cy="1.937" r="1.937" class="cls-1" transform="translate(181.555 368.792)"/>
                    <path id="Path_49551" d="M16.117-.409A1.032 1.032 0 1 1 15.085.623a1.038 1.038 0 0 1 1.032-1.032z" class="cls-1" transform="translate(174.894 372.649)"/>
                    <path id="Path_49552" d="M15.947-.521a.176.176 0 0 1 .172.172.168.168 0 0 1-.172.172.168.168 0 0 1-.172-.172.176.176 0 0 1 .172-.172z" class="cls-1" transform="translate(182.678 375.856)"/>
                    <path id="Path_49553" d="M24.25-.521a.176.176 0 0 1 .172.172.168.168 0 0 1-.172.172.176.176 0 0 1-.172-.172.185.185 0 0 1 .172-.172z" class="cls-1" transform="translate(276.351 375.856)"/>
                    <path id="Path_49554" d="M25.682-.411A1.056 1.056 0 0 1 26.738.645 1.048 1.048 0 0 1 25.682 1.7 1.056 1.056 0 0 1 24.626.645a1.064 1.064 0 0 1 1.056-1.056z" class="cls-1" transform="translate(282.534 372.626)"/>
                    <circle id="Ellipse_10942" cx="2.109" cy="2.109" r="2.109" class="cls-1" transform="translate(313.63 368.62)"/>
                    <path id="Path_49555" d="M28.952-.154a3.285 3.285 0 1 1-3.292 3.279 3.279 3.279 0 0 1 3.292-3.279z" class="cls-1" transform="translate(294.199 364.755)"/>
                    <path id="Path_49556" d="M29.522.105a3.261 3.261 0 1 1-3.267 3.267A3.263 3.263 0 0 1 29.522.105z" class="cls-1" transform="translate(300.912 361.364)"/>
                    <path id="Path_49557" d="M29.856.407a2.991 2.991 0 1 1-3 2.984 2.99 2.99 0 0 1 3-2.984z" class="cls-1" transform="translate(307.726 357.893)"/>
                    <path id="Path_49558" d="M30.324.719a2.892 2.892 0 1 1-2.886 2.886A2.893 2.893 0 0 1 30.324.719z" class="cls-1" transform="translate(314.258 353.945)"/>
                    <path id="Path_49559" d="M30.781 1.056A2.77 2.77 0 1 1 28 3.819a2.768 2.768 0 0 1 2.781-2.763z" class="cls-1" transform="translate(320.655 349.715)"/>
                    <path id="Path_49560" d="M31.177 1.417a2.628 2.628 0 1 1-2.616 2.628 2.631 2.631 0 0 1 2.616-2.628z" class="cls-1" transform="translate(326.928 345.203)"/>
                    <path id="Path_49561" d="M31.593 1.8A2.5 2.5 0 1 1 29.1 4.3a2.5 2.5 0 0 1 2.493-2.5z" class="cls-1" transform="translate(333.009 340.387)"/>
                    <path id="Path_49562" d="M32.051 2.2a2.426 2.426 0 1 1-2.432 2.42 2.416 2.416 0 0 1 2.432-2.42z" class="cls-1" transform="translate(338.864 335.248)"/>
                    <path id="Path_49563" d="M32.412 2.622a2.284 2.284 0 1 1-2.284 2.284 2.285 2.285 0 0 1 2.284-2.284z" class="cls-1" transform="translate(344.606 329.886)"/>
                    <path id="Path_49564" d="M32.835 3.059a2.235 2.235 0 1 1-2.223 2.235 2.236 2.236 0 0 1 2.223-2.235z" class="cls-1" transform="translate(350.067 324.18)"/>
                    <circle id="Ellipse_10943" cx="2.256" cy="2.256" r="2.256" class="cls-1" transform="translate(386.318 321.664)"/>
                    <circle id="Ellipse_10944" cx="2.207" cy="2.207" r="2.207" class="cls-1" transform="translate(391.805 315.933)"/>
                    <circle id="Ellipse_10945" cx="2.133" cy="2.133" r="2.133" class="cls-1" transform="translate(397.076 310.008)"/>
                    <path id="Path_49565" d="M34.329 5a1.959 1.959 0 1 1-1.965 1.953A1.95 1.95 0 0 1 34.329 5z" class="cls-1" transform="translate(369.832 298.979)"/>
                    <path id="Path_49566" d="M34.643 5.525a1.885 1.885 0 0 1 0 3.771 1.885 1.885 0 1 1 0-3.771z" class="cls-1" transform="translate(374.21 292.127)"/>
                    <path id="Path_49567" d="M34.981 6.063a1.867 1.867 0 1 1-1.867 1.867 1.866 1.866 0 0 1 1.867-1.867z" class="cls-1" transform="translate(378.294 285.019)"/>
                    <path id="Path_49568" d="M35.308 6.614a1.867 1.867 0 1 1-1.855 1.867 1.866 1.866 0 0 1 1.855-1.867z" class="cls-1" transform="translate(382.118 277.7)"/>
                    <path id="Path_49569" d="M35.545 7.186a1.769 1.769 0 1 1-1.769 1.769 1.766 1.766 0 0 1 1.769-1.769z" class="cls-1" transform="translate(385.762 270.3)"/>
                    <path id="Path_49570" d="M35.746 7.77a1.67 1.67 0 1 1-1.67 1.67 1.672 1.672 0 0 1 1.67-1.67z" class="cls-1" transform="translate(389.147 262.74)"/>
                    <path id="Path_49571" d="M35.935 8.364a1.6 1.6 0 1 1-1.584 1.6 1.593 1.593 0 0 1 1.584-1.6z" class="cls-1" transform="translate(392.249 254.997)"/>
                    <path id="Path_49572" d="M36.192 8.963a1.591 1.591 0 1 1-1.6 1.6 1.591 1.591 0 0 1 1.6-1.6z" class="cls-1" transform="translate(395.002 247.054)"/>
                    <path id="Path_49573" d="M36.309 9.578a1.5 1.5 0 1 1-1.486 1.5 1.5 1.5 0 0 1 1.486-1.5z" class="cls-1" transform="translate(397.574 239.07)"/>
                    <circle id="Ellipse_10946" cx="1.496" cy="1.496" r="1.496" class="cls-1" transform="translate(434.783 241.081)"/>
                    <path id="Path_49574" d="M36.56 10.828A1.376 1.376 0 1 1 35.2 12.2a1.373 1.373 0 0 1 1.36-1.372z" class="cls-1" transform="translate(401.794 222.713)"/>
                    <path id="Path_49575" d="M36.6 11.468a1.253 1.253 0 1 1-1.253 1.253 1.258 1.258 0 0 1 1.253-1.253z" class="cls-1" transform="translate(403.52 214.458)"/>
                    <path id="Path_49576" d="M36.653 12.109a1.179 1.179 0 1 1-1.179 1.179 1.179 1.179 0 0 1 1.179-1.179z" class="cls-1" transform="translate(404.919 206.092)"/>
                    <path id="Path_49577" d="M36.655 12.757a1.081 1.081 0 1 1-1.081 1.081 1.082 1.082 0 0 1 1.081-1.081z" class="cls-1" transform="translate(406.047 197.682)"/>
                    <path id="Path_49578" d="M36.631 13.408a.983.983 0 1 1-.983.983.985.985 0 0 1 .983-.983z" class="cls-1" transform="translate(406.882 189.232)"/>
                    <path id="Path_49579" d="M36.861 14.035a1.2 1.2 0 1 1-1.191 1.2 1.206 1.206 0 0 1 1.191-1.2z" class="cls-1" transform="translate(407.13 180.462)"/>
                    <path id="Path_49580" d="M37.81 14.663a1.425 1.425 0 1 1-1.425 1.425 1.415 1.415 0 0 1 1.425-1.425z" class="cls-1" transform="translate(415.197 171.679)"/>
                    <path id="Path_49581" d="M37.887 15.3a1.523 1.523 0 1 1-1.523 1.523 1.531 1.531 0 0 1 1.523-1.523z" class="cls-1" transform="translate(414.96 163.009)"/>
                    <path id="Path_49582" d="M37.714 15.958a1.376 1.376 0 1 1-1.376 1.376 1.373 1.373 0 0 1 1.376-1.376z" class="cls-1" transform="translate(414.666 154.577)"/>
                    <path id="Path_49583" d="M37.538 16.611a1.253 1.253 0 1 1-1.253 1.253 1.25 1.25 0 0 1 1.253-1.253z" class="cls-1" transform="translate(414.068 146.15)"/>
                    <path id="Path_49584" d="M37.4 17.256a1.2 1.2 0 1 1-1.2 1.191 1.2 1.2 0 0 1 1.2-1.191z" class="cls-1" transform="translate(413.121 137.694)"/>
                    <path id="Path_49585" d="M37.3 17.89a1.228 1.228 0 1 1-1.216 1.228A1.232 1.232 0 0 1 37.3 17.89z" class="cls-1" transform="translate(411.835 129.212)"/>
                    <path id="Path_49586" d="M37.177 18.521a1.228 1.228 0 1 1-1.228 1.228 1.232 1.232 0 0 1 1.228-1.228z" class="cls-1" transform="translate(410.278 120.831)"/>
                    <path id="Path_49587" d="M36.9 19.157a1.105 1.105 0 1 1-1.1 1.105 1.106 1.106 0 0 1 1.1-1.105z" class="cls-1" transform="translate(408.563 112.629)"/>
                    <path id="Path_49588" d="M36.715 19.776a1.1 1.1 0 1 1-1.105 1.105 1.1 1.1 0 0 1 1.105-1.105z" class="cls-1" transform="translate(406.453 104.42)"/>
                    <path id="Path_49589" d="M36.6 20.379a1.2 1.2 0 1 1-1.2 1.2 1.187 1.187 0 0 1 1.2-1.2z" class="cls-1" transform="translate(403.994 96.215)"/>
                    <path id="Path_49590" d="M36.327 20.983a1.179 1.179 0 1 1-1.167 1.179 1.179 1.179 0 0 1 1.167-1.179z" class="cls-1" transform="translate(401.376 88.229)"/>
                    <path id="Path_49591" d="M36.036 21.58a1.124 1.124 0 1 1-1.13 1.118 1.124 1.124 0 0 1 1.13-1.118z" class="cls-1" transform="translate(398.511 80.411)"/>
                    <path id="Path_49592" d="M35.643 22.172a1.007 1.007 0 1 1-1.007 1.007 1 1 0 0 1 1.007-1.007z" class="cls-1" transform="translate(395.465 72.781)"/>
                    <path id="Path_49593" d="M35.295 22.747a.949.949 0 0 1 .958.946.958.958 0 1 1-1.916 0 .949.949 0 0 1 .958-.946z" class="cls-1" transform="translate(392.091 65.255)"/>
                    <circle id="Ellipse_10947" cx=".76" cy=".76" r=".76" class="cls-1" transform="translate(422.632 81.33)"/>
                    <path id="Path_49594" d="M34.51 23.861a.835.835 0 1 1-.835.835.836.836 0 0 1 .835-.835z" class="cls-1" transform="translate(384.623 50.692)"/>
                    <path id="Path_49595" d="M33.963 24.408a.642.642 0 0 1 .639.639.65.65 0 0 1-.639.639.642.642 0 0 1-.639-.639.634.634 0 0 1 .639-.639z" class="cls-1" transform="translate(380.663 43.82)"/>
                    <path id="Path_49596" d="M33.372 24.943a.418.418 0 1 1-.418.418.414.414 0 0 1 .418-.418z" class="cls-1" transform="translate(376.489 37.156)"/>
                    <path id="Path_49597" d="M32.918 25.448a.362.362 0 0 1 .368.368.368.368 0 1 1-.737 0 .362.362 0 0 1 .369-.368z" class="cls-1" transform="translate(371.931 30.547)"/>
                    <path id="Path_49598" d="M32.446 25.937a.317.317 0 0 1 .319.319.319.319 0 1 1-.639 0 .317.317 0 0 1 .32-.319z" class="cls-1" transform="translate(367.159 24.151)"/>
                    <path id="Path_49599" d="M32.023 26.4a.336.336 0 0 1 .344.344.343.343 0 0 1-.344.344.351.351 0 0 1-.344-.344.343.343 0 0 1 .344-.344z" class="cls-1" transform="translate(362.104 17.912)"/>
                    <path id="Path_49600" d="M31.537 26.856a.325.325 0 0 1 .319.319.317.317 0 0 1-.319.319.31.31 0 0 1-.319-.319.317.317 0 0 1 .319-.319z" class="cls-1" transform="translate(356.903 11.945)"/>
                    <path id="Path_49601" d="M31.034 27.289a.291.291 0 0 1 .295.295.295.295 0 0 1-.59 0 .291.291 0 0 1 .295-.295z" class="cls-1" transform="translate(351.499 6.243)"/>
                    <path id="Path_49602" d="M30.514 27.7a.27.27 0 1 1 0 .54.27.27 0 1 1 0-.54z" class="cls-1" transform="translate(345.915 .78)"/>
                    <path id="Path_49603" d="M29.979 28.1a.246.246 0 1 1-.246.246.246.246 0 0 1 .246-.246z" class="cls-1" transform="translate(340.15 -4.417)"/>
                    <path id="Path_49604" d="M29.451 28.472a.246.246 0 1 1-.246.246.246.246 0 0 1 .246-.246z" class="cls-1" transform="translate(334.193 -9.371)"/>
                    <path id="Path_49605" d="M28.909 28.824a.249.249 0 0 1 .246.258.246.246 0 0 1-.491 0 .249.249 0 0 1 .245-.258z" class="cls-1" transform="translate(328.078 -14.047)"/>
                    <circle id="Ellipse_10948" cx=".221" cy=".221" r=".221" class="cls-1" transform="translate(349.94 10.75)"/>
                    <path id="Path_49606" d="M27.74 29.466a.2.2 0 1 1-.2.2.194.194 0 0 1 .2-.2z" class="cls-1" transform="translate(315.443 -22.475)"/>
                    <path id="Path_49607" d="M27.093 29.758a.123.123 0 0 1 .123.123.132.132 0 0 1-.123.123.123.123 0 0 1-.123-.123.116.116 0 0 1 .123-.123z" class="cls-1" transform="translate(308.978 -26.206)"/>
                    <circle id="Ellipse_10949" cx=".025" cy=".025" r=".025" class="cls-1" transform="translate(328.797 .413)"/>
                    <path id="Path_49608" d="M13.24 29.9l.048.049-.048.051-.049-.049z" class="cls-1" transform="translate(153.529 -27.93)"/>
                    <circle id="Ellipse_10950" cx=".172" cy=".172" r=".172" class="cls-1" transform="translate(159.413 5.22)"/>
                    <path id="Path_49609" d="M12.25 29.311a.246.246 0 1 1 0 .491.246.246 0 0 1 0-.491z" class="cls-1" transform="translate(140.281 -20.515)"/>
                    <path id="Path_49610" d="M11.7 28.991a.246.246 0 1 1-.246.246.246.246 0 0 1 .246-.246z" class="cls-1" transform="translate(133.941 -16.265)"/>
                    <path id="Path_49611" d="M11.152 28.65a.246.246 0 1 1-.246.246.246.246 0 0 1 .246-.246z" class="cls-1" transform="translate(127.747 -11.735)"/>
                    <path id="Path_49612" d="M10.662 28.284a.295.295 0 1 1-.295.295.3.3 0 0 1 .295-.295z" class="cls-1" transform="translate(121.666 -6.973)"/>
                    <path id="Path_49613" d="M10.186 27.9a.344.344 0 1 1 0 .688.344.344 0 1 1 0-.688z" class="cls-1" transform="translate(115.743 -1.931)"/>
                    <path id="Path_49614" d="M9.7 27.492a.37.37 0 0 1 .368.368.378.378 0 0 1-.368.368.369.369 0 0 1-.368-.368.362.362 0 0 1 .368-.368z" class="cls-1" transform="translate(110.023 3.399)"/>
                    <path id="Path_49615" d="M9.26 27.066a.418.418 0 1 1-.418.418.414.414 0 0 1 .418-.418z" class="cls-1" transform="translate(104.461 8.959)"/>
                    <path id="Path_49616" d="M8.878 26.617a.516.516 0 1 1-.516.516.509.509 0 0 1 .516-.516z" class="cls-1" transform="translate(99.046 14.726)"/>
                    <path id="Path_49617" d="M8.491 26.152a.6.6 0 0 1 .59.59.59.59 0 0 1-.59.59.582.582 0 0 1-.59-.59.59.59 0 0 1 .59-.59z" class="cls-1" transform="translate(93.845 20.755)"/>
                    <path id="Path_49618" d="M8.1 25.671a.639.639 0 0 1 0 1.277.639.639 0 0 1 0-1.277z" class="cls-1" transform="translate(88.87 27.045)"/>
                    <circle id="Ellipse_10951" cx=".662" cy=".662" r=".662" class="cls-1" transform="translate(91.184 58.75)"/>
                    <circle id="Ellipse_10952" cx=".711" cy=".711" r=".711" class="cls-1" transform="translate(86.247 64.955)"/>
                    <circle id="Ellipse_10953" cx=".76" cy=".76" r=".76" class="cls-1" transform="translate(81.557 71.345)"/>
                    <path id="Path_49619" d="M6.729 23.59a.835.835 0 1 1-.835.835.844.844 0 0 1 .835-.835z" class="cls-1" transform="translate(71.203 54.291)"/>
                    <path id="Path_49620" d="M6.461 23.032a.9.9 0 1 1-.909.9.9.9 0 0 1 .909-.9z" class="cls-1" transform="translate(67.344 61.568)"/>
                    <path id="Path_49621" d="M6.192 22.463a.958.958 0 1 1-.958.958.959.959 0 0 1 .958-.958z" class="cls-1" transform="translate(63.757 69.014)"/>
                    <path id="Path_49622" d="M5.991 21.878a1.056 1.056 0 1 1-1.056 1.056 1.054 1.054 0 0 1 1.056-1.056z" class="cls-1" transform="translate(60.383 76.588)"/>
                    <path id="Path_49623" d="M5.767 21.287a1.1 1.1 0 1 1-1.105 1.105 1.1 1.1 0 0 1 1.105-1.105z" class="cls-1" transform="translate(57.303 84.351)"/>
                    <path id="Path_49624" d="M5.521 20.689a1.105 1.105 0 1 1-1.105 1.105 1.109 1.109 0 0 1 1.105-1.105z" class="cls-1" transform="translate(54.528 92.282)"/>
                    <path id="Path_49625" d="M5.332 20.078a1.155 1.155 0 1 1-1.142 1.155 1.153 1.153 0 0 1 1.142-1.155z" class="cls-1" transform="translate(51.978 100.299)"/>
                    <path id="Path_49626" d="M5.191 19.459a1.2 1.2 0 1 1-1.2 1.2 1.206 1.206 0 0 1 1.2-1.2z" class="cls-1" transform="translate(49.688 108.422)"/>
                    <path id="Path_49627" d="M5.062 18.833a1.253 1.253 0 1 1-1.253 1.253 1.248 1.248 0 0 1 1.253-1.253z" class="cls-1" transform="translate(47.68 116.638)"/>
                    <path id="Path_49628" d="M4.979 18.2a1.326 1.326 0 1 1-1.326 1.326A1.318 1.318 0 0 1 4.979 18.2z" class="cls-1" transform="translate(45.92 124.924)"/>
                    <path id="Path_49629" d="M4.865 17.562a1.351 1.351 0 1 1-1.339 1.351 1.347 1.347 0 0 1 1.339-1.351z" class="cls-1" transform="translate(44.487 133.323)"/>
                    <circle id="Ellipse_10954" cx="1.422" cy="1.422" r="1.422" class="cls-1" transform="translate(46.7 158.65)"/>
                    <path id="Path_49630" d="M4.779 16.274a1.449 1.449 0 1 1-1.437 1.449 1.452 1.452 0 0 1 1.437-1.449z" class="cls-1" transform="translate(42.411 150.233)"/>
                    <circle id="Ellipse_10955" cx="1.447" cy="1.447" r="1.447" class="cls-1" transform="translate(45.13 174.421)"/>
                    <circle id="Ellipse_10956" cx="1.471" cy="1.471" r="1.471" class="cls-1" transform="translate(44.795 182.327)"/>
                    <path id="Path_49631" d="M4.76 14.334a1.5 1.5 0 1 1-1.5 1.5 1.5 1.5 0 0 1 1.5-1.5z" class="cls-1" transform="translate(41.509 175.902)"/>
                    <circle id="Ellipse_10957" cx="1.52" cy="1.52" r="1.52" class="cls-1" transform="translate(45.056 198.146)"/>
                    <path id="Path_49632" d="M4.914 13.036a1.6 1.6 0 1 1-1.584 1.6 1.6 1.6 0 0 1 1.584-1.6z" class="cls-1" transform="translate(42.276 192.945)"/>
                    <path id="Path_49633" d="M5.024 12.392A1.621 1.621 0 1 1 3.4 14.013a1.62 1.62 0 0 1 1.624-1.621z" class="cls-1" transform="translate(43.1 201.449)"/>
                    <path id="Path_49634" d="M5.09 11.756a1.591 1.591 0 1 1-1.584 1.584 1.591 1.591 0 0 1 1.584-1.584z" class="cls-1" transform="translate(44.262 209.958)"/>
                    <path id="Path_49635" d="M5.205 11.124A1.572 1.572 0 1 1 3.633 12.7a1.573 1.573 0 0 1 1.572-1.576z" class="cls-1" transform="translate(45.694 218.389)"/>
                    <path id="Path_49636" d="M5.4 10.491a1.621 1.621 0 1 1-1.621 1.621A1.617 1.617 0 0 1 5.4 10.491z" class="cls-1" transform="translate(47.342 226.698)"/>
                    <path id="Path_49637" d="M5.642 9.863a1.695 1.695 0 1 1-1.695 1.695 1.7 1.7 0 0 1 1.695-1.695z" class="cls-1" transform="translate(49.237 234.892)"/>
                    <path id="Path_49638" d="M5.874 9.244a1.744 1.744 0 1 1-1.732 1.744 1.743 1.743 0 0 1 1.732-1.744z" class="cls-1" transform="translate(51.437 243.015)"/>
                    <path id="Path_49639" d="M6.131 8.635A1.769 1.769 0 1 1 4.362 10.4a1.766 1.766 0 0 1 1.769-1.765z" class="cls-1" transform="translate(53.919 251.054)"/>
                    <path id="Path_49640" d="M6.377 8.038a1.762 1.762 0 1 1-1.769 1.769 1.759 1.759 0 0 1 1.769-1.769z" class="cls-1" transform="translate(56.694 258.996)"/>
                    <path id="Path_49641" d="M6.691 7.446a1.818 1.818 0 1 1-1.818 1.818 1.819 1.819 0 0 1 1.818-1.818z" class="cls-1" transform="translate(59.684 266.748)"/>
                    <circle id="Ellipse_10958" cx="1.888" cy="1.888" r="1.888" class="cls-1" transform="translate(68.065 281.208)"/>
                    <path id="Path_49642" d="M7.318 6.3a1.836 1.836 0 1 1-1.842 1.845A1.84 1.84 0 0 1 7.318 6.3z" class="cls-1" transform="translate(66.487 281.892)"/>
                    <path id="Path_49643" d="M7.677 5.748A1.867 1.867 0 1 1 5.81 7.615a1.866 1.866 0 0 1 1.867-1.867z" class="cls-1" transform="translate(70.255 289.202)"/>
                    <path id="Path_49644" d="M8.034 5.21a1.861 1.861 0 1 1-1.867 1.855A1.863 1.863 0 0 1 8.034 5.21z" class="cls-1" transform="translate(74.283 296.36)"/>
                    <circle id="Ellipse_10959" cx="1.863" cy="1.863" r="1.863" class="cls-1" transform="translate(85.095 308.006)"/>
                    <path id="Path_49645" d="M8.855 4.172a1.916 1.916 0 1 1-1.916 1.916 1.918 1.918 0 0 1 1.916-1.916z" class="cls-1" transform="translate(82.992 310.036)"/>
                    <path id="Path_49646" d="M9.306 3.675A1.965 1.965 0 1 1 7.353 5.64a1.963 1.963 0 0 1 1.953-1.965z" class="cls-1" transform="translate(87.663 316.539)"/>
                    <path id="Path_49647" d="M9.777 3.2a1.984 1.984 0 1 1-1.99 1.99 1.989 1.989 0 0 1 1.99-1.99z" class="cls-1" transform="translate(92.559 322.851)"/>
                    <circle id="Ellipse_10960" cx="2.06" cy="2.06" r="2.06" class="cls-1" transform="translate(105.859 331.613)"/>
                    <circle id="Ellipse_10961" cx="2.182" cy="2.182" r="2.182" class="cls-1" transform="translate(111.537 336.907)"/>
                    <path id="Path_49648" d="M11.4 1.856a2.2 2.2 0 1 1-2.211 2.2 2.207 2.207 0 0 1 2.211-2.2z" class="cls-1" transform="translate(108.331 340.22)"/>
                    <circle id="Ellipse_10962" cx="2.158" cy="2.158" r="2.158" class="cls-1" transform="translate(123.774 347.068)"/>
                    <path id="Path_49649" d="M12.512 1.062A2.309 2.309 0 1 1 10.2 3.371a2.3 2.3 0 0 1 2.312-2.309z" class="cls-1" transform="translate(119.816 350.557)"/>
                    <path id="Path_49650" d="M13.431.666A2.72 2.72 0 1 1 10.7 3.38 2.726 2.726 0 0 1 13.431.666z" class="cls-1" transform="translate(125.468 354.993)"/>
                    <path id="Path_49651" d="M14.183.307a2.942 2.942 0 1 1-2.948 2.948A2.938 2.938 0 0 1 14.183.307z" class="cls-1" transform="translate(131.459 359.319)"/>
                    <path id="Path_49652" d="M14.8-.019A3.021 3.021 0 1 1 11.791 3 3.019 3.019 0 0 1 14.8-.019z" class="cls-1" transform="translate(137.732 363.49)"/>
                    <path id="Path_49653" d="M14.72-.258a2.3 2.3 0 1 1-2.3 2.3 2.3 2.3 0 0 1 2.3-2.3z" class="cls-1" transform="translate(144.862 368.101)"/>
                    <path id="Path_49654" d="M14.1-.425a.985.985 0 0 1 .983.983.983.983 0 0 1-1.965 0 .985.985 0 0 1 .982-.983z" class="cls-1" transform="translate(152.669 372.96)"/>
                    <path id="Path_49655" d="M26.683-.5A.317.317 0 0 1 27-.181a.325.325 0 0 1-.319.319.317.317 0 0 1-.319-.319.31.31 0 0 1 .321-.319z" class="cls-1" transform="translate(302.142 375.282)"/>
                    <path id="Path_49656" d="M28.424-.338A1.575 1.575 0 0 1 30 1.234a1.572 1.572 0 1 1-1.576-1.572z" class="cls-1" transform="translate(307.647 370.637)"/>
                    <circle id="Ellipse_10963" cx="2.869" cy="2.869" r="2.869" class="cls-1" transform="translate(340.317 365.482)"/>
                    <circle id="Ellipse_10964" cx="2.82" cy="2.82" r="2.82" class="cls-1" transform="translate(347.341 361.744)"/>
                    <circle id="Ellipse_10965" cx="2.722" cy="2.722" r="2.722" class="cls-1" transform="translate(354.26 357.784)"/>
                    <path id="Path_49657" d="M31.594.856a2.579 2.579 0 1 1-2.579 2.579A2.576 2.576 0 0 1 31.594.856z" class="cls-1" transform="translate(332.05 352.752)"/>
                    <path id="Path_49658" d="M32.077 1.233a2.524 2.524 0 1 1-2.53 2.518 2.521 2.521 0 0 1 2.53-2.518z" class="cls-1" transform="translate(338.052 347.856)"/>
                    <path id="Path_49659" d="M32.5 1.634a2.426 2.426 0 1 1-2.432 2.42 2.416 2.416 0 0 1 2.432-2.42z" class="cls-1" transform="translate(343.929 342.726)"/>
                    <path id="Path_49660" d="M32.974 2.049a2.4 2.4 0 1 1-2.407 2.407 2.4 2.4 0 0 1 2.407-2.407z" class="cls-1" transform="translate(349.559 337.263)"/>
                    <path id="Path_49661" d="M33.32 2.493a2.254 2.254 0 1 1-2.26 2.26 2.251 2.251 0 0 1 2.26-2.26z" class="cls-1" transform="translate(355.121 331.661)"/>
                    <circle id="Ellipse_10966" cx="2.207" cy="2.207" r="2.207" class="cls-1" transform="translate(391.924 328.674)"/>
                    <circle id="Ellipse_10967" cx="2.182" cy="2.182" r="2.182" class="cls-1" transform="translate(397.422 322.95)"/>
                    <path id="Path_49662" d="M34.52 3.908a2.106 2.106 0 1 1-2.112 2.112 2.112 2.112 0 0 1 2.112-2.112z" class="cls-1" transform="translate(370.329 313.162)"/>
                    <circle id="Ellipse_10968" cx="1.986" cy="1.986" r="1.986" class="cls-1" transform="translate(407.873 311.033)"/>
                    <path id="Path_49663" d="M35.136 4.942a1.91 1.91 0 1 1-1.916 1.9 1.908 1.908 0 0 1 1.916-1.9z" class="cls-1" transform="translate(379.49 299.822)"/>
                    <path id="Path_49664" d="M35.334 5.487A1.744 1.744 0 1 1 33.6 7.231a1.743 1.743 0 0 1 1.734-1.744z" class="cls-1" transform="translate(383.799 292.914)"/>
                    <path id="Path_49665" d="M35.715 6.031a1.762 1.762 0 1 1-1.769 1.756 1.766 1.766 0 0 1 1.769-1.756z" class="cls-1" transform="translate(387.68 285.652)"/>
                    <path id="Path_49666" d="M35.994 6.593a1.719 1.719 0 1 1-1.719 1.719 1.714 1.714 0 0 1 1.719-1.719z" class="cls-1" transform="translate(391.392 278.274)"/>
                    <path id="Path_49667" d="M36.252 7.168a1.67 1.67 0 1 1-1.67 1.67 1.662 1.662 0 0 1 1.67-1.67z" class="cls-1" transform="translate(394.855 270.735)"/>
                    <path id="Path_49668" d="M36.442 7.759a1.566 1.566 0 1 1-1.572 1.572 1.567 1.567 0 0 1 1.572-1.572z" class="cls-1" transform="translate(398.105 263.094)"/>
                    <path id="Path_49669" d="M36.62 8.357a1.5 1.5 0 1 1-1.486 1.5 1.5 1.5 0 0 1 1.486-1.5z" class="cls-1" transform="translate(401.083 255.287)"/>
                    <path id="Path_49670" d="M36.912 8.956a1.541 1.541 0 1 1-1.548 1.544 1.539 1.539 0 0 1 1.548-1.544z" class="cls-1" transform="translate(403.678 247.245)"/>
                    <circle id="Ellipse_10969" cx="1.471" cy="1.471" r="1.471" class="cls-1" transform="translate(441.698 248.768)"/>
                    <path id="Path_49671" d="M37.2 10.195a1.425 1.425 0 1 1-1.425 1.425 1.423 1.423 0 0 1 1.425-1.425z" class="cls-1" transform="translate(408.27 231.022)"/>
                    <circle id="Ellipse_10970" cx="1.349" cy="1.349" r="1.349" class="cls-1" transform="translate(446.103 233.609)"/>
                    <path id="Path_49672" d="M37.28 11.47a1.2 1.2 0 1 1-1.191 1.2 1.206 1.206 0 0 1 1.191-1.2z" class="cls-1" transform="translate(411.857 214.53)"/>
                    <path id="Path_49673" d="M37.292 12.116a1.081 1.081 0 0 1 0 2.162 1.081 1.081 0 1 1 0-2.162z" class="cls-1" transform="translate(413.234 206.196)"/>
                    <path id="Path_49674" d="M37.312 12.763a1 1 0 1 1-1.007.995 1 1 0 0 1 1.007-.995z" class="cls-1" transform="translate(414.294 197.762)"/>
                    <path id="Path_49675" d="M37.4 13.4a1.032 1.032 0 1 1-1.032 1.032A1.038 1.038 0 0 1 37.4 13.4z" class="cls-1" transform="translate(414.982 189.187)"/>
                    <path id="Path_49676" d="M37.548 14.039a1.154 1.154 0 1 1-1.154 1.154 1.153 1.153 0 0 1 1.154-1.154z" class="cls-1" transform="translate(415.298 180.507)"/>
                    <path id="Path_49677" d="M38.733 14.645a1.646 1.646 0 1 1-1.646 1.646 1.643 1.643 0 0 1 1.646-1.646z" class="cls-1" transform="translate(423.117 171.476)"/>
                    <path id="Path_49678" d="M38.608 15.3a1.523 1.523 0 1 1-1.523 1.523 1.52 1.52 0 0 1 1.523-1.523z" class="cls-1" transform="translate(423.094 163.009)"/>
                    <circle id="Ellipse_10971" cx="1.447" cy="1.447" r="1.447" class="cls-1" transform="translate(459.804 170.461)"/>
                    <circle id="Ellipse_10972" cx="1.447" cy="1.447" r="1.447" class="cls-1" transform="translate(459.064 162.558)"/>
                    <path id="Path_49679" d="M38.292 17.243a1.369 1.369 0 1 1-1.376 1.376 1.371 1.371 0 0 1 1.376-1.376z" class="cls-1" transform="translate(421.187 137.523)"/>
                    <path id="Path_49680" d="M38.126 17.884a1.32 1.32 0 1 1-1.314 1.326 1.321 1.321 0 0 1 1.314-1.326z" class="cls-1" transform="translate(420.014 129.107)"/>
                    <path id="Path_49681" d="M37.994 18.516a1.327 1.327 0 1 1-1.314 1.326 1.321 1.321 0 0 1 1.314-1.326z" class="cls-1" transform="translate(418.525 120.701)"/>
                    <path id="Path_49682" d="M37.805 19.148a1.271 1.271 0 1 1-1.277 1.277 1.276 1.276 0 0 1 1.277-1.277z" class="cls-1" transform="translate(416.81 112.417)"/>
                    <path id="Path_49683" d="M37.536 19.776a1.179 1.179 0 1 1-1.179 1.179 1.179 1.179 0 0 1 1.179-1.179z" class="cls-1" transform="translate(414.881 104.26)"/>
                    <path id="Path_49684" d="M37.311 20.392a1.154 1.154 0 1 1-1.154 1.154 1.153 1.153 0 0 1 1.154-1.154z" class="cls-1" transform="translate(412.624 96.128)"/>
                    <path id="Path_49685" d="M37.154 20.992a1.228 1.228 0 1 1-1.228 1.228 1.232 1.232 0 0 1 1.228-1.228z" class="cls-1" transform="translate(410.018 88.012)"/>
                    <path id="Path_49686" d="M36.817 21.6a1.13 1.13 0 1 1-1.13 1.13 1.127 1.127 0 0 1 1.13-1.13z" class="cls-1" transform="translate(407.322 80.173)"/>
                    <path id="Path_49687" d="M36.479 22.191a1.05 1.05 0 1 1-1.056 1.056 1.048 1.048 0 0 1 1.056-1.056z" class="cls-1" transform="translate(404.343 72.443)"/>
                    <path id="Path_49688" d="M36.143 22.771a1.007 1.007 0 1 1-1.007 1.007 1 1 0 0 1 1.007-1.007z" class="cls-1" transform="translate(401.106 64.825)"/>
                    <path id="Path_49689" d="M35.786 23.341a.958.958 0 0 1 0 1.916.958.958 0 0 1 0-1.916z" class="cls-1" transform="translate(397.631 57.353)"/>
                    <path id="Path_49690" d="M35.429 23.9a.927.927 0 1 1-.933.933.933.933 0 0 1 .933-.933z" class="cls-1" transform="translate(393.885 50.03)"/>
                    <path id="Path_49691" d="M34.827 24.459a.663.663 0 1 1-.663.663.66.66 0 0 1 .663-.663z" class="cls-1" transform="translate(390.14 43.093)"/>
                    <path id="Path_49692" d="M34.3 25a.491.491 0 1 1-.491.491A.493.493 0 0 1 34.3 25z" class="cls-1" transform="translate(386.078 36.252)"/>
                    <path id="Path_49693" d="M33.789 25.523a.378.378 0 0 1 .368.368.369.369 0 0 1-.368.368.362.362 0 0 1-.368-.368.369.369 0 0 1 .368-.368z" class="cls-1" transform="translate(381.757 29.551)"/>
                    <path id="Path_49694" d="M33.309 26.026a.281.281 0 0 1 .295.282.294.294 0 0 1-.295.307.3.3 0 0 1-.295-.307.288.288 0 0 1 .295-.282z" class="cls-1" transform="translate(377.166 23.018)"/>
                    <path id="Path_49695" d="M32.879 26.508a.291.291 0 0 1 .295.295.295.295 0 1 1-.59 0 .291.291 0 0 1 .295-.295z" class="cls-1" transform="translate(372.314 16.616)"/>
                    <path id="Path_49696" d="M32.385 26.978a.246.246 0 1 1-.246.246.246.246 0 0 1 .246-.246z" class="cls-1" transform="translate(367.294 10.472)"/>
                    <path id="Path_49697" d="M31.965 27.422a.295.295 0 1 1-.295.295.3.3 0 0 1 .295-.295z" class="cls-1" transform="translate(362.003 4.476)"/>
                    <path id="Path_49698" d="M31.483 27.853a.295.295 0 1 1-.295.295.3.3 0 0 1 .295-.295z" class="cls-1" transform="translate(356.565 -1.248)"/>
                    <path id="Path_49699" d="M30.941 28.269a.246.246 0 0 1 0 .491.246.246 0 0 1 0-.491z" class="cls-1" transform="translate(351.003 -6.675)"/>
                    <path id="Path_49700" d="M30.428 28.662a.246.246 0 1 1-.246.246.246.246 0 0 1 .246-.246z" class="cls-1" transform="translate(345.215 -11.895)"/>
                    <path id="Path_49701" d="M29.878 29.038a.221.221 0 1 1-.221.221.22.22 0 0 1 .221-.221z" class="cls-1" transform="translate(339.293 -16.84)"/>
                    <path id="Path_49702" d="M29.337 29.392a.221.221 0 1 1-.221.221.22.22 0 0 1 .221-.221z" class="cls-1" transform="translate(333.189 -21.541)"/>
                    <path id="Path_49703" d="M28.694 29.734a.132.132 0 0 1 .123.123.123.123 0 0 1-.123.123.116.116 0 0 1-.123-.123.123.123 0 0 1 .123-.123z" class="cls-1" transform="translate(327.04 -25.887)"/>
                    <path id="Path_49704" d="M28.038 30.054l.023.025-.023.025-.025-.025z" class="cls-1" transform="translate(320.746 -29.948)"/>
                    <path id="Path_49705" d="M11.888 30.054l.025.025-.025.025-.023-.025z" class="cls-1" transform="translate(138.559 -29.948)"/>
                    <path id="Path_49706" d="M11.414 29.734a.132.132 0 0 1 .123.123.123.123 0 0 1-.123.123.116.116 0 0 1-.123-.123.123.123 0 0 1 .123-.123z" class="cls-1" transform="translate(132.091 -25.887)"/>
                    <path id="Path_49707" d="M10.95 29.392a.221.221 0 1 1-.221.221.22.22 0 0 1 .221-.221z" class="cls-1" transform="translate(125.75 -21.541)"/>
                    <path id="Path_49708" d="M10.432 29.036a.246.246 0 1 1-.246.246.246.246 0 0 1 .246-.246z" class="cls-1" transform="translate(119.624 -16.862)"/>
                    <path id="Path_49709" d="M9.927 28.66a.27.27 0 1 1 0 .54.27.27 0 1 1 0-.54z" class="cls-1" transform="translate(113.656 -11.917)"/>
                    <path id="Path_49710" d="M9.46 28.263a.319.319 0 0 1 0 .639.319.319 0 0 1 0-.639z" class="cls-1" transform="translate(107.835 -6.743)"/>
                    <path id="Path_49711" d="M8.985 27.849a.343.343 0 0 1 .344.344.336.336 0 0 1-.344.344.343.343 0 0 1-.344-.344.351.351 0 0 1 .344-.344z" class="cls-1" transform="translate(102.194 -1.293)"/>
                    <path id="Path_49712" d="M8.548 27.414a.393.393 0 0 1 0 .786.393.393 0 1 1 0-.786z" class="cls-1" transform="translate(96.711 4.386)"/>
                    <path id="Path_49713" d="M8.173 26.958a.491.491 0 1 1-.491.491.493.493 0 0 1 .491-.491z" class="cls-1" transform="translate(91.375 10.246)"/>
                    <path id="Path_49714" d="M7.781 26.486a.556.556 0 0 1 .565.565.559.559 0 1 1-1.118 0 .553.553 0 0 1 .553-.565z" class="cls-1" transform="translate(86.253 16.368)"/>
                    <circle id="Ellipse_10973" cx=".613" cy=".613" r=".613" class="cls-1" transform="translate(88.138 48.719)"/>
                    <circle id="Ellipse_10974" cx=".662" cy=".662" r=".662" class="cls-1" transform="translate(83.025 54.782)"/>
                    <circle id="Ellipse_10975" cx=".736" cy=".736" r=".736" class="cls-1" transform="translate(78.12 61.005)"/>
                    <path id="Path_49715" d="M6.362 24.451a.761.761 0 1 1-.761.761.765.765 0 0 1 .761-.761z" class="cls-1" transform="translate(67.897 43.003)"/>
                    <path id="Path_49716" d="M6.054 23.907a.8.8 0 1 1-.811.811.8.8 0 0 1 .811-.811z" class="cls-1" transform="translate(63.858 50.143)"/>
                    <path id="Path_49717" d="M5.833 23.343a.933.933 0 1 1-.933.933.933.933 0 0 1 .933-.933z" class="cls-1" transform="translate(59.989 57.376)"/>
                    <path id="Path_49718" d="M5.543 22.775a.958.958 0 1 1-.958.958.959.959 0 0 1 .958-.958z" class="cls-1" transform="translate(56.435 64.87)"/>
                    <path id="Path_49719" d="M5.342 22.191a1.05 1.05 0 1 1-1.056 1.056 1.056 1.056 0 0 1 1.056-1.056z" class="cls-1" transform="translate(53.061 72.443)"/>
                    <path id="Path_49720" d="M5.129 21.6a1.13 1.13 0 1 1-1.118 1.13 1.127 1.127 0 0 1 1.118-1.13z" class="cls-1" transform="translate(49.959 80.173)"/>
                    <path id="Path_49721" d="M4.938 21a1.179 1.179 0 1 1-1.179 1.179A1.179 1.179 0 0 1 4.938 21z" class="cls-1" transform="translate(47.116 88.057)"/>
                    <path id="Path_49722" d="M4.736 20.388a1.2 1.2 0 1 1-1.2 1.2 1.206 1.206 0 0 1 1.2-1.2z" class="cls-1" transform="translate(44.555 96.083)"/>
                    <path id="Path_49723" d="M4.534 19.775a1.2 1.2 0 1 1-1.2 1.2 1.206 1.206 0 0 1 1.2-1.2z" class="cls-1" transform="translate(42.276 104.237)"/>
                    <path id="Path_49724" d="M4.388 19.15a1.247 1.247 0 1 1-1.24 1.25 1.242 1.242 0 0 1 1.24-1.25z" class="cls-1" transform="translate(40.223 112.44)"/>
                    <circle id="Ellipse_10976" cx="1.324" cy="1.324" r="1.324" class="cls-1" transform="translate(41.382 139.218)"/>
                    <circle id="Ellipse_10977" cx="1.373" cy="1.373" r="1.373" class="cls-1" transform="translate(39.712 146.938)"/>
                    <circle id="Ellipse_10978" cx="1.422" cy="1.422" r="1.422" class="cls-1" transform="translate(38.334 154.714)"/>
                    <circle id="Ellipse_10979" cx="1.447" cy="1.447" r="1.447" class="cls-1" transform="translate(37.273 162.558)"/>
                    <circle id="Ellipse_10980" cx="1.471" cy="1.471" r="1.471" class="cls-1" transform="translate(36.508 170.436)"/>
                    <circle id="Ellipse_10981" cx="1.496" cy="1.496" r="1.496" class="cls-1" transform="translate(36.037 178.336)"/>
                    <path id="Path_49725" d="M4.06 14.655a1.523 1.523 0 1 1-1.523 1.523 1.52 1.52 0 0 1 1.523-1.523z" class="cls-1" transform="translate(33.33 171.589)"/>
                    <path id="Path_49726" d="M4.117 14a1.572 1.572 0 1 1-1.572 1.572A1.573 1.573 0 0 1 4.117 14z" class="cls-1" transform="translate(33.42 180.124)"/>
                    <path id="Path_49727" d="M4.176 13.358a1.591 1.591 0 1 1-1.6 1.584 1.591 1.591 0 0 1 1.6-1.584z" class="cls-1" transform="translate(33.803 188.68)"/>
                    <circle id="Ellipse_10982" cx="1.594" cy="1.594" r="1.594" class="cls-1" transform="translate(37.125 209.936)"/>
                    <path id="Path_49728" d="M4.321 12.074a1.591 1.591 0 1 1-1.6 1.6 1.591 1.591 0 0 1 1.6-1.6z" class="cls-1" transform="translate(35.439 205.734)"/>
                    <circle id="Ellipse_10983" cx="1.594" cy="1.594" r="1.594" class="cls-1" transform="translate(39.491 225.629)"/>
                    <circle id="Ellipse_10984" cx="1.619" cy="1.619" r="1.619" class="cls-1" transform="translate(41.088 233.374)"/>
                    <path id="Path_49729" d="M4.772 10.171a1.664 1.664 0 1 1-1.658 1.658 1.67 1.67 0 0 1 1.658-1.658z" class="cls-1" transform="translate(39.839 230.862)"/>
                    <path id="Path_49730" d="M5 9.546a1.713 1.713 0 1 1-1.707 1.707A1.714 1.714 0 0 1 5 9.546z" class="cls-1" transform="translate(41.814 239.065)"/>
                    <path id="Path_49731" d="M5.243 8.928a1.762 1.762 0 1 1-1.756 1.756 1.759 1.759 0 0 1 1.756-1.756z" class="cls-1" transform="translate(44.047 247.175)"/>
                    <path id="Path_49732" d="M5.5 8.32a1.793 1.793 0 1 1-1.793 1.793A1.8 1.8 0 0 1 5.5 8.32z" class="cls-1" transform="translate(46.552 255.189)"/>
                    <path id="Path_49733" d="M5.76 7.721a1.818 1.818 0 1 1-1.805 1.818A1.821 1.821 0 0 1 5.76 7.721z" class="cls-1" transform="translate(49.327 263.096)"/>
                    <path id="Path_49734" d="M6.087 7.13A1.861 1.861 0 1 1 4.22 9a1.866 1.866 0 0 1 1.867-1.87z" class="cls-1" transform="translate(52.317 270.859)"/>
                    <path id="Path_49735" d="M6.423 6.549a1.91 1.91 0 1 1-1.916 1.9 1.908 1.908 0 0 1 1.916-1.9z" class="cls-1" transform="translate(55.555 278.478)"/>
                    <path id="Path_49736" d="M6.781 5.979a1.965 1.965 0 1 1-1.965 1.965 1.96 1.96 0 0 1 1.965-1.965z" class="cls-1" transform="translate(59.041 285.938)"/>
                    <path id="Path_49737" d="M7.114 5.426a1.959 1.959 0 1 1-1.965 1.965 1.963 1.963 0 0 1 1.965-1.965z" class="cls-1" transform="translate(62.798 293.295)"/>
                    <path id="Path_49738" d="M7.378 4.893A1.867 1.867 0 1 1 5.511 6.76a1.866 1.866 0 0 1 1.867-1.867z" class="cls-1" transform="translate(66.882 300.558)"/>
                    <path id="Path_49739" d="M7.8 4.362a1.91 1.91 0 1 1-1.916 1.9 1.908 1.908 0 0 1 1.916-1.9z" class="cls-1" transform="translate(71.056 307.525)"/>
                    <path id="Path_49740" d="M8.168 3.851a1.891 1.891 0 1 1-1.891 1.891 1.89 1.89 0 0 1 1.891-1.891z" class="cls-1" transform="translate(75.524 314.349)"/>
                    <path id="Path_49741" d="M8.6 3.352a1.91 1.91 0 1 1-1.913 1.916A1.918 1.918 0 0 1 8.6 3.352z" class="cls-1" transform="translate(80.149 320.94)"/>
                    <path id="Path_49742" d="M8.977 2.874a1.861 1.861 0 1 1-1.855 1.855 1.863 1.863 0 0 1 1.855-1.855z" class="cls-1" transform="translate(85.057 327.387)"/>
                    <path id="Path_49743" d="M9.55 2.4a1.99 1.99 0 1 1-1.99 1.99A2 2 0 0 1 9.55 2.4z" class="cls-1" transform="translate(89.998 333.451)"/>
                    <circle id="Ellipse_10985" cx="2.084" cy="2.084" r="2.084" class="cls-1" transform="translate(103.178 341.259)"/>
                    <path id="Path_49744" d="M10.609 1.509A2.112 2.112 0 1 1 8.5 3.621a2.112 2.112 0 0 1 2.109-2.112z" class="cls-1" transform="translate(100.569 345.013)"/>
                    <path id="Path_49745" d="M11.2 1.089A2.211 2.211 0 1 1 8.987 3.3 2.207 2.207 0 0 1 11.2 1.089z" class="cls-1" transform="translate(106.097 350.395)"/>
                    <path id="Path_49746" d="M11.789.688A2.3 2.3 0 1 1 9.492 3 2.306 2.306 0 0 1 11.789.688z" class="cls-1" transform="translate(111.795 355.536)"/>
                    <path id="Path_49747" d="M12.564.292A2.573 2.573 0 1 1 10 2.859 2.576 2.576 0 0 1 12.564.292z" class="cls-1" transform="translate(117.492 360.255)"/>
                    <circle id="Ellipse_10986" cx="2.844" cy="2.844" r="2.844" class="cls-1" transform="translate(133.857 364.623)"/>
                    <path id="Path_49748" d="M12.813-.32a1.646 1.646 0 1 1-1.646 1.646A1.643 1.643 0 0 1 12.813-.32z" class="cls-1" transform="translate(130.692 370.239)"/>
                    <path id="Path_49749" d="M12.024-.513a.168.168 0 0 1 .172.172.176.176 0 0 1-.172.172.176.176 0 0 1-.172-.172.168.168 0 0 1 .172-.172z" class="cls-1" transform="translate(138.42 375.75)"/>
                    <path id="Path_49750" d="M28.2-.515a.194.194 0 0 1 .2.2.2.2 0 0 1-.2.2.2.2 0 0 1-.2-.2.194.194 0 0 1 .2-.2z" class="cls-1" transform="translate(320.587 375.727)"/>
                    <path id="Path_49751" d="M30-.312a1.548 1.548 0 1 1-1.548 1.548A1.546 1.546 0 0 1 30-.312z" class="cls-1" transform="translate(325.732 370.329)"/>
                    <path id="Path_49752" d="M31.616-.072a2.7 2.7 0 1 1-2.7 2.69 2.7 2.7 0 0 1 2.7-2.69z" class="cls-1" transform="translate(330.91 364.844)"/>
                    <path id="Path_49753" d="M32.022.294a2.548 2.548 0 1 1-2.555 2.542A2.547 2.547 0 0 1 32.022.294z" class="cls-1" transform="translate(337.149 360.278)"/>
                    <path id="Path_49754" d="M32.5.672A2.5 2.5 0 1 1 30 3.177 2.5 2.5 0 0 1 32.5.672z" class="cls-1" transform="translate(343.14 355.356)"/>
                    <path id="Path_49755" d="M32.926 1.073a2.407 2.407 0 1 1-2.407 2.407 2.4 2.4 0 0 1 2.407-2.407z" class="cls-1" transform="translate(349.017 350.214)"/>
                    <circle id="Ellipse_10987" cx="2.281" cy="2.281" r="2.281" class="cls-1" transform="translate(385.769 346.351)"/>
                    <path id="Path_49756" d="M33.792 1.926A2.278 2.278 0 1 1 31.508 4.2a2.278 2.278 0 0 1 2.284-2.274z" class="cls-1" transform="translate(360.175 339.143)"/>
                    <path id="Path_49757" d="M34.2 2.378a2.235 2.235 0 1 1-2.223 2.235A2.236 2.236 0 0 1 34.2 2.378z" class="cls-1" transform="translate(365.478 333.225)"/>
                    <circle id="Ellipse_10988" cx="2.133" cy="2.133" r="2.133" class="cls-1" transform="translate(403.057 329.987)"/>
                    <path id="Path_49758" d="M34.945 3.338a2.082 2.082 0 1 1-2.076 2.088 2.086 2.086 0 0 1 2.076-2.088z" class="cls-1" transform="translate(375.53 320.782)"/>
                    <path id="Path_49759" d="M35.324 3.839a2.039 2.039 0 1 1-2.039 2.039 2.031 2.031 0 0 1 2.039-2.039z" class="cls-1" transform="translate(380.223 314.213)"/>
                    <path id="Path_49760" d="M35.627 4.36a1.934 1.934 0 1 1-1.941 1.928 1.934 1.934 0 0 1 1.941-1.928z" class="cls-1" transform="translate(384.747 307.502)"/>
                    <path id="Path_49761" d="M35.933 4.893a1.867 1.867 0 1 1-1.867 1.867 1.866 1.866 0 0 1 1.867-1.867z" class="cls-1" transform="translate(389.034 300.558)"/>
                    <path id="Path_49762" d="M36.219 5.44a1.787 1.787 0 1 1-1.793 1.793 1.8 1.8 0 0 1 1.793-1.793z" class="cls-1" transform="translate(393.095 293.453)"/>
                    <path id="Path_49763" d="M36.44 6a1.67 1.67 0 1 1-1.67 1.67A1.67 1.67 0 0 1 36.44 6z" class="cls-1" transform="translate(396.977 286.208)"/>
                    <path id="Path_49764" d="M36.707 6.573a1.615 1.615 0 1 1-1.621 1.609 1.617 1.617 0 0 1 1.621-1.609z" class="cls-1" transform="translate(400.542 278.748)"/>
                    <path id="Path_49765" d="M36.942 7.154a1.566 1.566 0 1 1-1.56 1.572 1.567 1.567 0 0 1 1.56-1.572z" class="cls-1" transform="translate(403.881 271.13)"/>
                    <path id="Path_49766" d="M37.2 7.743a1.548 1.548 0 1 1 0 3.1 1.548 1.548 0 0 1 0-3.1z" class="cls-1" transform="translate(406.938 263.344)"/>
                    <path id="Path_49767" d="M37.4 8.344a1.5 1.5 0 1 1-1.5 1.5 1.5 1.5 0 0 1 1.5-1.5z" class="cls-1" transform="translate(409.77 255.46)"/>
                    <path id="Path_49768" d="M37.627 8.95a1.492 1.492 0 1 1-1.5 1.486 1.494 1.494 0 0 1 1.5-1.486z" class="cls-1" transform="translate(412.308 247.423)"/>
                    <path id="Path_49769" d="M37.694 9.576a1.345 1.345 0 1 1-1.351 1.339 1.345 1.345 0 0 1 1.351-1.339z" class="cls-1" transform="translate(414.723 239.403)"/>
                    <path id="Path_49770" d="M37.9 10.195a1.369 1.369 0 1 1-1.376 1.363 1.371 1.371 0 0 1 1.376-1.363z" class="cls-1" transform="translate(416.72 231.133)"/>
                    <path id="Path_49771" d="M37.972 10.828a1.3 1.3 0 1 1-1.29 1.3 1.3 1.3 0 0 1 1.29-1.3z" class="cls-1" transform="translate(418.547 222.861)"/>
                    <path id="Path_49772" d="M37.923 11.477a1.1 1.1 0 1 1-1.093 1.105 1.1 1.1 0 0 1 1.093-1.105z" class="cls-1" transform="translate(420.217 214.646)"/>
                    <path id="Path_49773" d="M38 12.118a1.05 1.05 0 1 1-1.056 1.056A1.046 1.046 0 0 1 38 12.118z" class="cls-1" transform="translate(421.481 206.231)"/>
                    <path id="Path_49774" d="M38.06 12.76a1.032 1.032 0 1 1-1.032 1.032 1.038 1.038 0 0 1 1.032-1.032z" class="cls-1" transform="translate(422.451 197.741)"/>
                    <circle id="Ellipse_10989" cx="1.471" cy="1.471" r="1.471" class="cls-1" transform="translate(459.78 202.156)"/>
                    <path id="Path_49775" d="M38.473 14.021A1.376 1.376 0 1 1 37.1 15.4a1.371 1.371 0 0 1 1.373-1.379z" class="cls-1" transform="translate(423.229 180.304)"/>
                    <path id="Path_49776" d="M39.43 14.647a1.621 1.621 0 1 1-1.621 1.621 1.617 1.617 0 0 1 1.621-1.621z" class="cls-1" transform="translate(431.262 171.499)"/>
                    <path id="Path_49777" d="M39.328 15.3a1.523 1.523 0 1 1-1.528 1.524 1.531 1.531 0 0 1 1.528-1.524z" class="cls-1" transform="translate(431.217 163.009)"/>
                    <path id="Path_49778" d="M39.315 15.945a1.541 1.541 0 1 1-1.548 1.548 1.541 1.541 0 0 1 1.548-1.548z" class="cls-1" transform="translate(430.799 154.419)"/>
                    <circle id="Ellipse_10990" cx="1.422" cy="1.422" r="1.422" class="cls-1" transform="translate(467.984 162.579)"/>
                    <circle id="Ellipse_10991" cx="1.471" cy="1.471" r="1.471" class="cls-1" transform="translate(466.94 154.655)"/>
                    <path id="Path_49779" d="M38.948 17.877a1.425 1.425 0 1 1-1.412 1.423 1.426 1.426 0 0 1 1.412-1.423z" class="cls-1" transform="translate(428.182 128.991)"/>
                    <path id="Path_49780" d="M38.743 18.519a1.32 1.32 0 1 1-1.326 1.314 1.316 1.316 0 0 1 1.326-1.314z" class="cls-1" transform="translate(426.839 120.673)"/>
                    <path id="Path_49781" d="M38.548 19.152a1.271 1.271 0 1 1-1.277 1.277 1.276 1.276 0 0 1 1.277-1.277z" class="cls-1" transform="translate(425.192 112.364)"/>
                    <path id="Path_49782" d="M38.286 19.783a1.173 1.173 0 1 1-1.179 1.179 1.179 1.179 0 0 1 1.179-1.179z" class="cls-1" transform="translate(423.342 104.18)"/>
                    <path id="Path_49783" d="M38.092 20.4a1.173 1.173 0 1 1-1.179 1.167 1.169 1.169 0 0 1 1.179-1.167z" class="cls-1" transform="translate(421.153 95.998)"/>
                    <path id="Path_49784" d="M37.876 21.008a1.173 1.173 0 1 1-1.176 1.167 1.169 1.169 0 0 1 1.176-1.167z" class="cls-1" transform="translate(418.717 87.91)"/>
                    <path id="Path_49785" d="M37.615 21.611a1.148 1.148 0 1 1-1.155 1.142 1.151 1.151 0 0 1 1.155-1.142z" class="cls-1" transform="translate(416.054 79.95)"/>
                    <path id="Path_49786" d="M37.289 22.209a1.075 1.075 0 1 1-1.081 1.081 1.072 1.072 0 0 1 1.081-1.081z" class="cls-1" transform="translate(413.2 72.155)"/>
                    <path id="Path_49787" d="M36.985 22.793a1.056 1.056 0 1 1-1.056 1.056 1.056 1.056 0 0 1 1.056-1.056z" class="cls-1" transform="translate(410.052 64.435)"/>
                    <path id="Path_49788" d="M36.617 23.371a.976.976 0 1 1-.983.983.978.978 0 0 1 .983-.983z" class="cls-1" transform="translate(406.724 56.918)"/>
                    <path id="Path_49789" d="M36.3 23.931a.983.983 0 1 1-.983.983.985.985 0 0 1 .983-.983z" class="cls-1" transform="translate(403.102 49.468)"/>
                    <path id="Path_49790" d="M35.863 24.488a.884.884 0 1 1-.884.884.881.881 0 0 1 .884-.884z" class="cls-1" transform="translate(399.334 42.266)"/>
                    <path id="Path_49791" d="M35.265 25.044a.639.639 0 1 1-.626.639.634.634 0 0 1 .626-.639z" class="cls-1" transform="translate(395.499 35.373)"/>
                    <circle id="Ellipse_10992" cx=".49" cy=".49" r=".49" class="cls-1" transform="translate(425.615 54.144)"/>
                    <path id="Path_49792" d="M34.273 26.1a.4.4 0 0 1 .393.393.388.388 0 0 1-.393.393.4.4 0 0 1-.393-.393.4.4 0 0 1 .393-.393z" class="cls-1" transform="translate(386.936 21.891)"/>
                    <path id="Path_49793" d="M33.812 26.594a.351.351 0 0 1 .344.344.343.343 0 0 1-.344.344.336.336 0 0 1-.344-.344.343.343 0 0 1 .344-.344z" class="cls-1" transform="translate(382.288 15.375)"/>
                    <path id="Path_49794" d="M33.333 27.077a.295.295 0 1 1-.295.295.3.3 0 0 1 .295-.295z" class="cls-1" transform="translate(377.436 9.059)"/>
                    <path id="Path_49795" d="M32.859 27.542a.27.27 0 1 1-.27.27.273.273 0 0 1 .27-.27z" class="cls-1" transform="translate(372.371 2.932)"/>
                    <path id="Path_49796" d="M32.37 27.99a.246.246 0 1 1-.246.246.246.246 0 0 1 .246-.246z" class="cls-1" transform="translate(367.125 -2.97)"/>
                    <circle id="Ellipse_10993" cx=".246" cy=".246" r=".246" class="cls-1" transform="translate(393.322 19.739)"/>
                    <path id="Path_49797" d="M31.389 28.832a.246.246 0 1 1-.246.246.246.246 0 0 1 .246-.246z" class="cls-1" transform="translate(356.057 -14.153)"/>
                    <path id="Path_49798" d="M30.854 29.228a.221.221 0 1 1-.221.221.22.22 0 0 1 .221-.221z" class="cls-1" transform="translate(350.304 -19.363)"/>
                    <path id="Path_49799" d="M30.283 29.607a.172.172 0 1 1-.172.172.168.168 0 0 1 .172-.172z" class="cls-1" transform="translate(344.414 -24.299)"/>
                    <circle id="Ellipse_10994" cx=".025" cy=".025" r=".025" class="cls-1" transform="translate(368.047 1.084)"/>
                    <circle id="Ellipse_10995" cx=".098" cy=".098" r=".098" class="cls-1" transform="translate(127.728 3.167)"/>
                    <path id="Path_49800" d="M9.7 29.418a.221.221 0 1 1-.221.221.22.22 0 0 1 .221-.221z" class="cls-1" transform="translate(111.592 -21.887)"/>
                    <path id="Path_49801" d="M9.22 29.029a.27.27 0 1 1-.27.27.273.273 0 0 1 .27-.27z" class="cls-1" transform="translate(105.68 -16.818)"/>
                    <path id="Path_49802" d="M8.738 28.624a.295.295 0 1 1-.295.295.3.3 0 0 1 .295-.295z" class="cls-1" transform="translate(99.96 -11.488)"/>
                    <path id="Path_49803" d="M8.27 28.2a.307.307 0 0 1 .307.319.313.313 0 1 1-.626 0 .31.31 0 0 1 .319-.319z" class="cls-1" transform="translate(94.409 -5.919)"/>
                    <path id="Path_49804" d="M7.851 27.757a.388.388 0 0 1 .393.393.387.387 0 1 1-.774 0 .385.385 0 0 1 .381-.393z" class="cls-1" transform="translate(88.983 -.17)"/>
                    <path id="Path_49805" d="M7.459 27.3a.467.467 0 1 1-.459.463.467.467 0 0 1 .459-.463z" class="cls-1" transform="translate(83.737 5.806)"/>
                    <path id="Path_49806" d="M7.119 26.817a.563.563 0 0 1 .565.565.565.565 0 1 1-1.13 0 .563.563 0 0 1 .565-.565z" class="cls-1" transform="translate(78.649 11.971)"/>
                    <path id="Path_49807" d="M6.739 26.327a.608.608 0 1 1-.614.6.606.606 0 0 1 .614-.6z" class="cls-1" transform="translate(73.809 18.394)"/>
                    <path id="Path_49808" d="M6.365 25.821a.663.663 0 1 1-.651.663.66.66 0 0 1 .651-.663z" class="cls-1" transform="translate(69.172 25.004)"/>
                    <path id="Path_49809" d="M6.032 25.3a.712.712 0 1 1-.712.712.713.713 0 0 1 .712-.712z" class="cls-1" transform="translate(64.727 31.812)"/>
                    <path id="Path_49810" d="M5.707 24.768a.755.755 0 1 1-.761.761.757.757 0 0 1 .761-.761z" class="cls-1" transform="translate(60.507 38.805)"/>
                    <path id="Path_49811" d="M5.4 24.221a.811.811 0 1 1-.811.811.818.818 0 0 1 .811-.811z" class="cls-1" transform="translate(56.502 45.96)"/>
                    <path id="Path_49812" d="M5.137 23.66a.884.884 0 0 1 0 1.769.884.884 0 0 1 0-1.769z" class="cls-1" transform="translate(52.689 53.263)"/>
                    <path id="Path_49813" d="M4.871 23.09a.933.933 0 1 1-.933.933.933.933 0 0 1 .933-.933z" class="cls-1" transform="translate(49.135 60.736)"/>
                    <path id="Path_49814" d="M4.693 22.5a1.056 1.056 0 1 1-1.056 1.056A1.056 1.056 0 0 1 4.693 22.5z" class="cls-1" transform="translate(45.74 68.287)"/>
                    <path id="Path_49815" d="M4.468 21.912a1.1 1.1 0 1 1-1.105 1.093 1.1 1.1 0 0 1 1.105-1.093z" class="cls-1" transform="translate(42.648 76.05)"/>
                    <path id="Path_49816" d="M4.265 21.311a1.154 1.154 0 1 1-1.154 1.154 1.151 1.151 0 0 1 1.154-1.154z" class="cls-1" transform="translate(39.805 83.922)"/>
                    <path id="Path_49817" d="M4.106 20.7a1.228 1.228 0 1 1-1.228 1.228A1.221 1.221 0 0 1 4.106 20.7z" class="cls-1" transform="translate(37.177 91.89)"/>
                    <path id="Path_49818" d="M3.889 20.088a1.222 1.222 0 1 1 0 2.444 1.222 1.222 0 0 1 0-2.444z" class="cls-1" transform="translate(34.864 100.031)"/>
                    <circle id="Ellipse_10996" cx="1.25" cy="1.25" r="1.25" class="cls-1" transform="translate(35.259 127.704)"/>
                    <path id="Path_49819" d="M3.67 18.832a1.345 1.345 0 1 1-1.351 1.339 1.342 1.342 0 0 1 1.351-1.339z" class="cls-1" transform="translate(30.87 116.467)"/>
                    <circle id="Ellipse_10997" cx="1.373" cy="1.373" r="1.373" class="cls-1" transform="translate(31.466 143.022)"/>
                    <circle id="Ellipse_10998" cx="1.422" cy="1.422" r="1.422" class="cls-1" transform="translate(30 150.783)"/>
                    <path id="Path_49820" d="M3.437 16.915a1.474 1.474 0 1 1-1.474 1.474 1.468 1.468 0 0 1 1.474-1.474z" class="cls-1" transform="translate(26.854 141.67)"/>
                    <circle id="Ellipse_10999" cx="1.496" cy="1.496" r="1.496" class="cls-1" transform="translate(27.936 166.454)"/>
                    <path id="Path_49821" d="M3.366 15.624a1.523 1.523 0 1 1-1.523 1.523 1.52 1.52 0 0 1 1.523-1.523z" class="cls-1" transform="translate(25.5 158.719)"/>
                    <path id="Path_49822" d="M3.331 14.978A1.523 1.523 0 1 1 1.82 16.5a1.523 1.523 0 0 1 1.511-1.522z" class="cls-1" transform="translate(25.241 167.299)"/>
                    <path id="Path_49823" d="M3.376 14.328a1.572 1.572 0 1 1-1.56 1.572 1.575 1.575 0 0 1 1.56-1.572z" class="cls-1" transform="translate(25.195 175.834)"/>
                    <path id="Path_49824" d="M3.434 13.68a1.6 1.6 0 1 1-1.6 1.6 1.591 1.591 0 0 1 1.6-1.6z" class="cls-1" transform="translate(25.432 184.391)"/>
                    <path id="Path_49825" d="M3.5 13.034a1.615 1.615 0 1 1-1.621 1.609A1.617 1.617 0 0 1 3.5 13.034z" class="cls-1" transform="translate(25.929 192.935)"/>
                    <path id="Path_49826" d="M3.595 12.389a1.646 1.646 0 1 1-1.646 1.646 1.643 1.643 0 0 1 1.646-1.646z" class="cls-1" transform="translate(26.696 201.44)"/>
                    <circle id="Ellipse_11000" cx="1.545" cy="1.545" r="1.545" class="cls-1" transform="translate(29.877 221.785)"/>
                    <path id="Path_49827" d="M3.723 11.12a1.566 1.566 0 1 1-1.56 1.572 1.567 1.567 0 0 1 1.56-1.572z" class="cls-1" transform="translate(29.11 218.454)"/>
                    <path id="Path_49828" d="M3.963 10.48a1.67 1.67 0 1 1-1.67 1.67 1.662 1.662 0 0 1 1.67-1.67z" class="cls-1" transform="translate(30.577 226.746)"/>
                    <path id="Path_49829" d="M4.157 9.85a1.719 1.719 0 1 1-1.707 1.719A1.725 1.725 0 0 1 4.157 9.85z" class="cls-1" transform="translate(32.348 235.015)"/>
                    <path id="Path_49830" d="M4.363 9.229a1.738 1.738 0 1 1-1.732 1.744 1.735 1.735 0 0 1 1.732-1.744z" class="cls-1" transform="translate(34.39 243.226)"/>
                    <path id="Path_49831" d="M4.6 8.614a1.762 1.762 0 1 1-1.766 1.756A1.756 1.756 0 0 1 4.6 8.614z" class="cls-1" transform="translate(36.68 251.345)"/>
                    <path id="Path_49832" d="M4.852 8.007a1.787 1.787 0 1 1-1.793 1.781 1.782 1.782 0 0 1 1.793-1.781z" class="cls-1" transform="translate(39.219 259.358)"/>
                    <path id="Path_49833" d="M5.134 7.407A1.836 1.836 0 1 1 3.3 9.249a1.84 1.84 0 0 1 1.834-1.842z" class="cls-1" transform="translate(41.983 267.229)"/>
                    <path id="Path_49834" d="M5.46 6.815a1.891 1.891 0 1 1-1.891 1.891A1.892 1.892 0 0 1 5.46 6.815z" class="cls-1" transform="translate(44.972 274.981)"/>
                    <path id="Path_49835" d="M5.774 6.236a1.916 1.916 0 1 1-1.916 1.916 1.918 1.918 0 0 1 1.916-1.916z" class="cls-1" transform="translate(48.233 282.622)"/>
                    <path id="Path_49836" d="M6.074 5.67a1.91 1.91 0 1 1-1.9 1.9 1.908 1.908 0 0 1 1.9-1.9z" class="cls-1" transform="translate(51.753 290.152)"/>
                    <path id="Path_49837" d="M6.417 5.115A1.916 1.916 0 1 1 4.5 7.031a1.908 1.908 0 0 1 1.917-1.916z" class="cls-1" transform="translate(55.487 297.511)"/>
                    <path id="Path_49838" d="M6.723 4.577a1.861 1.861 0 1 1-1.867 1.867 1.866 1.866 0 0 1 1.867-1.867z" class="cls-1" transform="translate(59.492 304.768)"/>
                    <path id="Path_49839" d="M7.036 4.051a1.818 1.818 0 1 1-1.805 1.818 1.821 1.821 0 0 1 1.805-1.818z" class="cls-1" transform="translate(63.723 311.84)"/>
                    <path id="Path_49840" d="M7.425 3.535A1.818 1.818 0 1 1 5.62 5.353a1.821 1.821 0 0 1 1.805-1.818z" class="cls-1" transform="translate(68.111 318.693)"/>
                    <path id="Path_49841" d="M7.845 3.034a1.812 1.812 0 1 1-1.818 1.818 1.814 1.814 0 0 1 1.818-1.818z" class="cls-1" transform="translate(72.703 325.36)"/>
                    <path id="Path_49842" d="M8.405 2.535A1.959 1.959 0 1 1 6.44 4.488a1.96 1.96 0 0 1 1.965-1.953z" class="cls-1" transform="translate(77.363 331.693)"/>
                    <path id="Path_49843" d="M8.881 2.06a2.008 2.008 0 1 1-2 2 2 2 0 0 1 2-2z" class="cls-1" transform="translate(82.315 337.903)"/>
                    <path id="Path_49844" d="M9.408 1.6a2.082 2.082 0 1 1-2.076 2.075A2.084 2.084 0 0 1 9.408 1.6z" class="cls-1" transform="translate(87.426 343.879)"/>
                    <path id="Path_49845" d="M10.03 1.149a2.229 2.229 0 1 1-2.235 2.223 2.222 2.222 0 0 1 2.235-2.223z" class="cls-1" transform="translate(92.649 349.561)"/>
                    <circle id="Ellipse_11001" cx="2.305" cy="2.305" r="2.305" class="cls-1" transform="translate(106.392 355.802)"/>
                    <path id="Path_49846" d="M11.149.313a2.377 2.377 0 1 1-2.37 2.37 2.374 2.374 0 0 1 2.37-2.37z" class="cls-1" transform="translate(103.751 360.37)"/>
                    <path id="Path_49847" d="M11.523-.057a2.2 2.2 0 1 1-2.211 2.211 2.207 2.207 0 0 1 2.211-2.211z" class="cls-1" transform="translate(109.764 365.628)"/>
                    <path id="Path_49848" d="M11.1-.339A1.173 1.173 0 1 1 9.929.828 1.169 1.169 0 0 1 11.1-.339z" class="cls-1" transform="translate(116.725 371.437)"/>
                    <path id="Path_49849" d="M29.957-.453a.414.414 0 0 1 .418.418.414.414 0 0 1-.418.418.412.412 0 0 1-.405-.418.412.412 0 0 1 .405-.418z" class="cls-1" transform="translate(338.108 374.461)"/>
                    <path id="Path_49850" d="M31.84-.215a1.867 1.867 0 1 1-1.867 1.867A1.866 1.866 0 0 1 31.84-.215z" class="cls-1" transform="translate(342.858 368.402)"/>
                    <path id="Path_49851" d="M32.907.113a2.45 2.45 0 1 1-2.456 2.456A2.464 2.464 0 0 1 32.907.113z" class="cls-1" transform="translate(348.25 362.879)"/>
                    <path id="Path_49852" d="M33.363.51a2.407 2.407 0 1 1-2.395 2.407A2.411 2.411 0 0 1 33.363.51z" class="cls-1" transform="translate(354.083 357.692)"/>
                    <path id="Path_49853" d="M33.748.932a2.284 2.284 0 1 1-2.272 2.284A2.288 2.288 0 0 1 33.748.932z" class="cls-1" transform="translate(359.814 352.332)"/>
                    <path id="Path_49854" d="M34.22 1.364a2.254 2.254 0 1 1-2.26 2.26 2.254 2.254 0 0 1 2.26-2.26z" class="cls-1" transform="translate(365.275 346.656)"/>
                    <circle id="Ellipse_11002" cx="2.084" cy="2.084" r="2.084" class="cls-1" transform="translate(403.149 342.706)"/>
                    <path id="Path_49855" d="M35 2.285A2.112 2.112 0 1 1 32.89 4.4 2.112 2.112 0 0 1 35 2.285z" class="cls-1" transform="translate(375.767 334.706)"/>
                    <circle id="Ellipse_11003" cx="2.06" cy="2.06" r="2.06" class="cls-1" transform="translate(414.038 331.16)"/>
                    <circle id="Ellipse_11004" cx="2.011" cy="2.011" r="2.011" class="cls-1" transform="translate(419.202 325.139)"/>
                    <path id="Path_49856" d="M36.116 3.779a1.965 1.965 0 1 1-1.965 1.965 1.96 1.96 0 0 1 1.965-1.965z" class="cls-1" transform="translate(389.993 315.158)"/>
                    <path id="Path_49857" d="M36.416 4.308A1.891 1.891 0 1 1 34.537 6.2a1.892 1.892 0 0 1 1.879-1.892z" class="cls-1" transform="translate(394.348 308.279)"/>
                    <path id="Path_49858" d="M36.664 4.854a1.769 1.769 0 1 1-1.756 1.769 1.769 1.769 0 0 1 1.756-1.769z" class="cls-1" transform="translate(398.533 301.273)"/>
                    <path id="Path_49859" d="M36.927 5.411a1.664 1.664 0 0 1 0 3.328 1.664 1.664 0 1 1 0-3.328z" class="cls-1" transform="translate(402.471 294.084)"/>
                    <path id="Path_49860" d="M37.248 5.972a1.664 1.664 0 1 1-1.67 1.67 1.672 1.672 0 0 1 1.67-1.67z" class="cls-1" transform="translate(406.092 286.632)"/>
                    <circle id="Ellipse_11005" cx="1.594" cy="1.594" r="1.594" class="cls-1" transform="translate(445.447 285.653)"/>
                    <path id="Path_49861" d="M37.74 7.134a1.566 1.566 0 1 1-1.572 1.572 1.565 1.565 0 0 1 1.572-1.572z" class="cls-1" transform="translate(412.748 271.396)"/>
                    <path id="Path_49862" d="M37.931 7.732a1.492 1.492 0 1 1-1.5 1.5 1.5 1.5 0 0 1 1.5-1.5z" class="cls-1" transform="translate(415.738 263.6)"/>
                    <circle id="Ellipse_11006" cx="1.447" cy="1.447" r="1.447" class="cls-1" transform="translate(455.145 264)"/>
                    <path id="Path_49863" d="M38.363 8.943a1.474 1.474 0 1 1-1.474 1.474 1.478 1.478 0 0 1 1.474-1.474z" class="cls-1" transform="translate(420.883 247.553)"/>
                    <path id="Path_49864" d="M38.444 9.57a1.345 1.345 0 1 1-1.351 1.339 1.345 1.345 0 0 1 1.351-1.339z" class="cls-1" transform="translate(423.184 239.483)"/>
                    <path id="Path_49865" d="M38.526 10.2a1.247 1.247 0 1 1-1.253 1.253 1.25 1.25 0 0 1 1.253-1.253z" class="cls-1" transform="translate(425.215 231.299)"/>
                    <path id="Path_49866" d="M38.676 10.829a1.253 1.253 0 1 1-1.253 1.253 1.248 1.248 0 0 1 1.253-1.253z" class="cls-1" transform="translate(426.907 222.946)"/>
                    <path id="Path_49867" d="M38.621 11.479a1.056 1.056 0 1 1-1.056 1.056 1.056 1.056 0 0 1 1.056-1.056z" class="cls-1" transform="translate(428.509 214.705)"/>
                    <path id="Path_49868" d="M38.635 12.125a.958.958 0 1 1-.958.958.959.959 0 0 1 .958-.958z" class="cls-1" transform="translate(429.773 206.322)"/>
                    <path id="Path_49869" d="M38.761 12.762a1.007 1.007 0 1 1-1.007 1.007 1.012 1.012 0 0 1 1.007-1.007z" class="cls-1" transform="translate(430.641 197.763)"/>
                    <path id="Path_49870" d="M39.315 13.362a1.541 1.541 0 1 1-1.548 1.548 1.541 1.541 0 0 1 1.548-1.548z" class="cls-1" transform="translate(430.799 188.725)"/>
                    <path id="Path_49871" d="M39.531 13.991a1.744 1.744 0 1 1-1.744 1.744 1.751 1.751 0 0 1 1.744-1.744z" class="cls-1" transform="translate(431.014 179.966)"/>
                    <path id="Path_49872" d="M40.15 14.647a1.621 1.621 0 1 1-1.621 1.621 1.617 1.617 0 0 1 1.621-1.621z" class="cls-1" transform="translate(439.385 171.499)"/>
                    <circle id="Ellipse_11007" cx="1.545" cy="1.545" r="1.545" class="cls-1" transform="translate(477.849 178.287)"/>
                    <path id="Path_49873" d="M40.015 15.947a1.517 1.517 0 1 1-1.523 1.523 1.523 1.523 0 0 1 1.523-1.523z" class="cls-1" transform="translate(438.967 154.441)"/>
                    <circle id="Ellipse_11008" cx="1.398" cy="1.398" r="1.398" class="cls-1" transform="translate(476.901 162.6)"/>
                    <path id="Path_49874" d="M39.757 17.242a1.4 1.4 0 1 1-1.388 1.4 1.4 1.4 0 0 1 1.388-1.4z" class="cls-1" transform="translate(437.58 137.475)"/>
                    <path id="Path_49875" d="M39.657 17.881a1.394 1.394 0 1 1-1.388 1.4 1.4 1.4 0 0 1 1.388-1.4z" class="cls-1" transform="translate(436.452 129)"/>
                    <circle id="Ellipse_11009" cx="1.275" cy="1.275" r="1.275" class="cls-1" transform="translate(473.341 139.208)"/>
                    <path id="Path_49876" d="M39.245 19.159a1.228 1.228 0 1 1-1.228 1.228 1.221 1.221 0 0 1 1.228-1.228z" class="cls-1" transform="translate(433.608 112.357)"/>
                    <path id="Path_49877" d="M39.057 19.786a1.2 1.2 0 1 1-1.2 1.191 1.2 1.2 0 0 1 1.2-1.191z" class="cls-1" transform="translate(431.758 104.091)"/>
                    <path id="Path_49878" d="M38.87 20.4a1.2 1.2 0 1 1-1.2 1.2 1.206 1.206 0 0 1 1.2-1.2z" class="cls-1" transform="translate(429.649 95.87)"/>
                    <path id="Path_49879" d="M38.662 21.016a1.2 1.2 0 1 1-1.2 1.2 1.206 1.206 0 0 1 1.2-1.2z" class="cls-1" transform="translate(427.302 87.742)"/>
                    <path id="Path_49880" d="M38.387 21.624a1.154 1.154 0 1 1-1.154 1.154 1.153 1.153 0 0 1 1.154-1.154z" class="cls-1" transform="translate(424.764 79.765)"/>
                    <path id="Path_49881" d="M38.07 22.226a1.081 1.081 0 1 1 0 2.162 1.081 1.081 0 0 1 0-2.162z" class="cls-1" transform="translate(422.011 71.917)"/>
                    <path id="Path_49882" d="M37.8 22.813a1.081 1.081 0 1 1-1.081 1.081 1.082 1.082 0 0 1 1.081-1.081z" class="cls-1" transform="translate(418.965 64.12)"/>
                    <path id="Path_49883" d="M37.464 23.395a1.026 1.026 0 1 1 0 2.051 1.026 1.026 0 1 1 0-2.051z" class="cls-1" transform="translate(415.727 56.501)"/>
                    <path id="Path_49884" d="M37.109 23.966a.976.976 0 1 1-.983.983.978.978 0 0 1 .983-.983z" class="cls-1" transform="translate(412.275 49.015)"/>
                    <path id="Path_49885" d="M36.734 24.526a.927.927 0 1 1-.933.933.933.933 0 0 1 .933-.933z" class="cls-1" transform="translate(408.608 41.675)"/>
                    <path id="Path_49886" d="M36.3 25.078a.829.829 0 1 1 0 1.658.829.829 0 1 1 0-1.658z" class="cls-1" transform="translate(404.761 34.54)"/>
                    <circle id="Ellipse_11010" cx=".687" cy=".687" r=".687" class="cls-1" transform="translate(435.863 53.227)"/>
                    <path id="Path_49887" d="M35.25 26.154a.511.511 0 0 1 .516.516.516.516 0 1 1-1.032 0 .511.511 0 0 1 .516-.516z" class="cls-1" transform="translate(396.57 20.876)"/>
                    <path id="Path_49888" d="M34.757 26.668a.411.411 0 1 1-.418.405.412.412 0 0 1 .418-.405z" class="cls-1" transform="translate(392.114 14.257)"/>
                    <path id="Path_49889" d="M34.269 27.165a.351.351 0 0 1 .344.344.343.343 0 0 1-.344.344.336.336 0 0 1-.344-.344.343.343 0 0 1 .344-.344z" class="cls-1" transform="translate(387.443 7.791)"/>
                    <path id="Path_49890" d="M33.787 27.645a.295.295 0 1 1-.295.295.3.3 0 0 1 .295-.295z" class="cls-1" transform="translate(382.558 1.514)"/>
                    <path id="Path_49891" d="M33.311 28.108a.27.27 0 1 1-.27.27.273.273 0 0 1 .27-.27z" class="cls-1" transform="translate(377.47 -4.586)"/>
                    <path id="Path_49892" d="M32.82 28.555a.246.246 0 1 1-.246.246.246.246 0 0 1 .246-.246z" class="cls-1" transform="translate(372.202 -10.474)"/>
                    <path id="Path_49893" d="M32.314 28.985a.221.221 0 1 1 0 .442.221.221 0 1 1 0-.442z" class="cls-1" transform="translate(366.775 -16.136)"/>
                    <path id="Path_49894" d="M31.792 29.4a.2.2 0 1 1 0 .393.2.2 0 0 1 0-.393z" class="cls-1" transform="translate(361.168 -21.585)"/>
                    <path id="Path_49895" d="M31.19 29.8a.1.1 0 1 1 0 .2.1.1 0 1 1 0-.2z" class="cls-1" transform="translate(355.482 -26.728)"/>
                    <path id="Path_49896" d="M8.871 29.8a.1.1 0 1 1-.1.1.106.106 0 0 1 .1-.1z" class="cls-1" transform="translate(103.683 -26.728)"/>
                    <path id="Path_49897" d="M8.495 29.395a.246.246 0 1 1-.246.246.246.246 0 0 1 .246-.246z" class="cls-1" transform="translate(97.771 -21.63)"/>
                    <path id="Path_49898" d="M8.019 28.981a.27.27 0 1 1-.27.27.273.273 0 0 1 .27-.27z" class="cls-1" transform="translate(92.13 -16.181)"/>
                    <path id="Path_49899" d="M7.558 28.551a.3.3 0 0 1 .295.295.295.295 0 0 1-.59 0 .3.3 0 0 1 .295-.295z" class="cls-1" transform="translate(86.647 -10.519)"/>
                    <path id="Path_49900" d="M7.156 28.1a.37.37 0 0 1 .368.368.362.362 0 0 1-.368.368.37.37 0 0 1-.368-.368.378.378 0 0 1 .368-.368z" class="cls-1" transform="translate(81.289 -4.676)"/>
                    <path id="Path_49901" d="M6.771 27.633a.442.442 0 1 1-.442.442.44.44 0 0 1 .442-.442z" class="cls-1" transform="translate(76.11 1.379)"/>
                    <path id="Path_49902" d="M6.413 27.149a.534.534 0 1 1-.528.528.527.527 0 0 1 .528-.528z" class="cls-1" transform="translate(71.101 7.623)"/>
                    <path id="Path_49903" d="M6.072 26.652a.608.608 0 1 1 0 1.216.608.608 0 1 1 0-1.216z" class="cls-1" transform="translate(66.284 14.077)"/>
                    <path id="Path_49904" d="M5.725 26.14a.687.687 0 0 1 .688.688.682.682 0 1 1-1.363 0 .684.684 0 0 1 .675-.688z" class="cls-1" transform="translate(61.681 20.718)"/>
                    <circle id="Ellipse_11011" cx=".736" cy=".736" r=".736" class="cls-1" transform="translate(61.945 53.178)"/>
                    <circle id="Ellipse_11012" cx=".76" cy=".76" r=".76" class="cls-1" transform="translate(57.411 59.686)"/>
                    <circle id="Ellipse_11013" cx=".834" cy=".834" r=".834" class="cls-1" transform="translate(53.057 66.296)"/>
                    <path id="Path_49905" d="M4.532 23.97a.927.927 0 1 1-.932.93.933.933 0 0 1 .932-.93z" class="cls-1" transform="translate(45.311 49.06)"/>
                    <path id="Path_49906" d="M4.245 23.4a.949.949 0 0 1 .958.946.958.958 0 0 1-1.916 0 .949.949 0 0 1 .958-.946z" class="cls-1" transform="translate(41.791 56.568)"/>
                    <path id="Path_49907" d="M4.01 22.817a1.032 1.032 0 1 1-1.019 1.032 1.022 1.022 0 0 1 1.019-1.032z" class="cls-1" transform="translate(38.452 64.165)"/>
                    <path id="Path_49908" d="M3.819 22.224a1.105 1.105 0 1 1 0 2.211 1.105 1.105 0 1 1 0-2.211z" class="cls-1" transform="translate(35.326 71.894)"/>
                    <path id="Path_49909" d="M3.614 21.624a1.154 1.154 0 1 1-1.154 1.154 1.153 1.153 0 0 1 1.154-1.154z" class="cls-1" transform="translate(32.461 79.765)"/>
                    <path id="Path_49910" d="M3.453 21.014a1.228 1.228 0 1 1-1.228 1.228 1.232 1.232 0 0 1 1.228-1.228z" class="cls-1" transform="translate(29.81 87.719)"/>
                    <path id="Path_49911" d="M3.29 20.4a1.277 1.277 0 1 1-1.277 1.277A1.276 1.276 0 0 1 3.29 20.4z" class="cls-1" transform="translate(27.418 95.803)"/>
                    <path id="Path_49912" d="M3.1 19.78a1.277 1.277 0 1 1-1.277 1.277A1.284 1.284 0 0 1 3.1 19.78z" class="cls-1" transform="translate(25.308 104.011)"/>
                    <path id="Path_49913" d="M3.006 19.149A1.351 1.351 0 1 1 1.655 20.5a1.344 1.344 0 0 1 1.351-1.351z" class="cls-1" transform="translate(23.379 112.244)"/>
                    <circle id="Ellipse_11014" cx="1.373" cy="1.373" r="1.373" class="cls-1" transform="translate(23.241 139.11)"/>
                    <circle id="Ellipse_11015" cx="1.422" cy="1.422" r="1.422" class="cls-1" transform="translate(21.693 146.855)"/>
                    <path id="Path_49914" d="M2.753 17.236a1.474 1.474 0 1 1-1.474 1.474 1.478 1.478 0 0 1 1.474-1.474z" class="cls-1" transform="translate(19.137 137.407)"/>
                    <path id="Path_49915" d="M2.7 16.592a1.5 1.5 0 1 1-1.5 1.5 1.5 1.5 0 0 1 1.5-1.5z" class="cls-1" transform="translate(18.235 145.911)"/>
                    <path id="Path_49916" d="M2.664 15.947a1.517 1.517 0 1 1-1.523 1.523 1.515 1.515 0 0 1 1.523-1.523z" class="cls-1" transform="translate(17.58 154.441)"/>
                    <circle id="Ellipse_11016" cx="1.545" cy="1.545" r="1.545" class="cls-1" transform="translate(18.291 178.287)"/>
                    <path id="Path_49917" d="M2.665 14.651a1.572 1.572 0 1 1-1.572 1.572 1.573 1.573 0 0 1 1.572-1.572z" class="cls-1" transform="translate(17.039 171.544)"/>
                    <circle id="Ellipse_11017" cx="1.619" cy="1.619" r="1.619" class="cls-1" transform="translate(18.218 194.085)"/>
                    <path id="Path_49918" d="M2.777 13.354A1.64 1.64 0 1 1 1.131 15a1.646 1.646 0 0 1 1.646-1.646z" class="cls-1" transform="translate(17.467 188.635)"/>
                    <path id="Path_49919" d="M2.743 12.718a1.541 1.541 0 1 1-1.548 1.535 1.546 1.546 0 0 1 1.548-1.535z" class="cls-1" transform="translate(18.189 197.279)"/>
                    <path id="Path_49920" d="M2.821 12.076a1.548 1.548 0 1 1-1.548 1.548 1.549 1.549 0 0 1 1.548-1.548z" class="cls-1" transform="translate(19.069 205.794)"/>
                    <path id="Path_49921" d="M2.966 11.434a1.591 1.591 0 1 1-1.6 1.584 1.6 1.6 0 0 1 1.6-1.584z" class="cls-1" transform="translate(20.152 214.235)"/>
                    <circle id="Ellipse_11018" cx="1.643" cy="1.643" r="1.643" class="cls-1" transform="translate(22.971 233.409)"/>
                    <path id="Path_49922" d="M3.344 10.159a1.719 1.719 0 1 1-1.719 1.719 1.714 1.714 0 0 1 1.719-1.719z" class="cls-1" transform="translate(23.041 230.911)"/>
                    <path id="Path_49923" d="M3.532 9.532a1.744 1.744 0 1 1-1.744 1.744 1.743 1.743 0 0 1 1.744-1.744z" class="cls-1" transform="translate(24.88 239.19)"/>
                    <path id="Path_49924" d="M3.719 8.914a1.738 1.738 0 1 1-1.744 1.732 1.74 1.74 0 0 1 1.744-1.732z" class="cls-1" transform="translate(26.989 247.41)"/>
                    <path id="Path_49925" d="M3.95 8.3a1.769 1.769 0 1 1-1.769 1.769A1.769 1.769 0 0 1 3.95 8.3z" class="cls-1" transform="translate(29.313 255.504)"/>
                    <path id="Path_49926" d="M4.19 7.694a1.787 1.787 0 1 1-1.781 1.781A1.785 1.785 0 0 1 4.19 7.694z" class="cls-1" transform="translate(31.886 263.516)"/>
                    <path id="Path_49927" d="M4.5 7.094a1.836 1.836 0 1 1-1.842 1.83A1.837 1.837 0 0 1 4.5 7.094z" class="cls-1" transform="translate(34.65 271.386)"/>
                    <path id="Path_49928" d="M4.8 6.5a1.885 1.885 0 1 1-1.879 1.882A1.882 1.882 0 0 1 4.8 6.5z" class="cls-1" transform="translate(37.662 279.138)"/>
                    <path id="Path_49929" d="M5.148 5.922a1.934 1.934 0 1 1-1.941 1.941 1.945 1.945 0 0 1 1.941-1.941z" class="cls-1" transform="translate(40.888 286.756)"/>
                    <path id="Path_49930" d="M5.458 5.355A1.934 1.934 0 1 1 3.517 7.3a1.945 1.945 0 0 1 1.941-1.945z" class="cls-1" transform="translate(44.386 294.287)"/>
                    <circle id="Ellipse_11019" cx="1.937" cy="1.937" r="1.937" class="cls-1" transform="translate(51.955 306.468)"/>
                    <path id="Path_49931" d="M6.113 4.257A1.91 1.91 0 1 1 4.2 6.173a1.918 1.918 0 0 1 1.913-1.916z" class="cls-1" transform="translate(52.057 308.92)"/>
                    <path id="Path_49932" d="M6.39 3.733a1.812 1.812 0 1 1-1.818 1.818A1.814 1.814 0 0 1 6.39 3.733z" class="cls-1" transform="translate(56.288 316.076)"/>
                    <path id="Path_49933" d="M6.763 3.214a1.812 1.812 0 1 1-1.805 1.805 1.811 1.811 0 0 1 1.805-1.805z" class="cls-1" transform="translate(60.643 322.969)"/>
                    <path id="Path_49934" d="M7.189 2.707a1.836 1.836 0 1 1-1.83 1.842 1.84 1.84 0 0 1 1.83-1.842z" class="cls-1" transform="translate(65.167 329.654)"/>
                    <path id="Path_49935" d="M7.677 2.21a1.91 1.91 0 1 1 0 3.82 1.91 1.91 0 0 1 0-3.82z" class="cls-1" transform="translate(69.838 336.107)"/>
                    <path id="Path_49936" d="M8.339 1.713A2.162 2.162 0 1 1 6.19 3.875a2.165 2.165 0 0 1 2.149-2.162z" class="cls-1" transform="translate(74.542 342.205)"/>
                    <path id="Path_49937" d="M8.792 1.252a2.162 2.162 0 1 1-2.149 2.162 2.165 2.165 0 0 1 2.149-2.162z" class="cls-1" transform="translate(79.653 348.328)"/>
                    <path id="Path_49938" d="M9.476.789a2.383 2.383 0 1 1-2.383 2.383A2.385 2.385 0 0 1 9.476.789z" class="cls-1" transform="translate(84.73 354.035)"/>
                    <path id="Path_49939" d="M10 .357a2.426 2.426 0 1 1-2.432 2.42A2.416 2.416 0 0 1 10 .357z" class="cls-1" transform="translate(90.145 359.687)"/>
                    <path id="Path_49940" d="M10.593-.063a2.53 2.53 0 1 1-2.53 2.53 2.534 2.534 0 0 1 2.53-2.53z" class="cls-1" transform="translate(95.673 365.057)"/>
                    <path id="Path_49941" d="M9.593-.323a.881.881 0 0 1 .884.884.884.884 0 0 1-1.769 0 .881.881 0 0 1 .885-.884z" class="cls-1" transform="translate(102.961 371.801)"/>
                    <path id="Path_49942" d="M32.093-.339A1.081 1.081 0 1 1 31.012.742a1.09 1.09 0 0 1 1.081-1.081z" class="cls-1" transform="translate(354.579 371.621)"/>
                    <path id="Path_49943" d="M33.744-.047a2.334 2.334 0 1 1-2.321 2.334 2.333 2.333 0 0 1 2.321-2.334z" class="cls-1" transform="translate(359.216 365.237)"/>
                    <path id="Path_49944" d="M34.277.363a2.352 2.352 0 1 1-2.358 2.346A2.353 2.353 0 0 1 34.277.363z" class="cls-1" transform="translate(364.812 359.755)"/>
                    <circle id="Ellipse_11020" cx="2.182" cy="2.182" r="2.182" class="cls-1" transform="translate(402.842 355.022)"/>
                    <path id="Path_49945" d="M35 1.256a2.112 2.112 0 1 1-2.113 2.112A2.112 2.112 0 0 1 35 1.256z" class="cls-1" transform="translate(375.778 348.373)"/>
                    <path id="Path_49946" d="M35.411 1.721a2.063 2.063 0 1 1-2.063 2.063 2.06 2.06 0 0 1 2.063-2.063z" class="cls-1" transform="translate(380.934 342.295)"/>
                    <circle id="Ellipse_11021" cx="2.06" cy="2.06" r="2.06" class="cls-1" transform="translate(419.65 338.17)"/>
                    <circle id="Ellipse_11022" cx="2.109" cy="2.109" r="2.109" class="cls-1" transform="translate(424.761 332.09)"/>
                    <circle id="Ellipse_11023" cx="2.011" cy="2.011" r="2.011" class="cls-1" transform="translate(429.807 325.983)"/>
                    <path id="Path_49947" d="M36.966 3.721A1.959 1.959 0 1 1 35 5.686a1.963 1.963 0 0 1 1.966-1.965z" class="cls-1" transform="translate(399.583 315.94)"/>
                    <path id="Path_49948" d="M37.333 4.253a1.959 1.959 0 1 1-1.965 1.965 1.971 1.971 0 0 1 1.965-1.965z" class="cls-1" transform="translate(403.723 308.874)"/>
                    <path id="Path_49949" d="M37.524 4.811A1.787 1.787 0 1 1 35.731 6.6a1.785 1.785 0 0 1 1.793-1.789z" class="cls-1" transform="translate(407.818 301.807)"/>
                    <path id="Path_49950" d="M37.831 5.369a1.762 1.762 0 1 1-1.769 1.769 1.761 1.761 0 0 1 1.769-1.769z" class="cls-1" transform="translate(411.553 294.445)"/>
                    <path id="Path_49951" d="M38.062 5.942a1.689 1.689 0 1 1 0 3.378 1.689 1.689 0 0 1 0-3.378z" class="cls-1" transform="translate(415.129 286.982)"/>
                    <path id="Path_49952" d="M38.228 6.531a1.541 1.541 0 1 1-1.547 1.535 1.546 1.546 0 0 1 1.547-1.535z" class="cls-1" transform="translate(418.536 279.454)"/>
                    <path id="Path_49953" d="M38.5 7.118a1.541 1.541 0 1 1-1.547 1.535A1.538 1.538 0 0 1 38.5 7.118z" class="cls-1" transform="translate(421.582 271.657)"/>
                    <path id="Path_49954" d="M38.748 7.714A1.541 1.541 0 1 1 37.2 9.249a1.546 1.546 0 0 1 1.548-1.535z" class="cls-1" transform="translate(424.403 263.741)"/>
                    <circle id="Ellipse_11024" cx="1.447" cy="1.447" r="1.447" class="cls-1" transform="translate(464.518 264.127)"/>
                    <circle id="Ellipse_11025" cx="1.398" cy="1.398" r="1.398" class="cls-1" transform="translate(467.124 256.662)"/>
                    <path id="Path_49955" d="M39.169 9.566a1.326 1.326 0 0 1 0 2.653 1.326 1.326 0 1 1 0-2.653z" class="cls-1" transform="translate(431.645 239.573)"/>
                    <path id="Path_49956" d="M39.268 10.2a1.253 1.253 0 1 1-1.253 1.253 1.247 1.247 0 0 1 1.253-1.253z" class="cls-1" transform="translate(433.586 231.34)"/>
                    <path id="Path_49957" d="M39.332 10.833a1.179 1.179 0 1 1-1.167 1.179 1.179 1.179 0 0 1 1.167-1.179z" class="cls-1" transform="translate(435.278 223.04)"/>
                    <path id="Path_49958" d="M39.409 11.472a1.124 1.124 0 1 1-1.118 1.118 1.124 1.124 0 0 1 1.118-1.118z" class="cls-1" transform="translate(436.7 214.663)"/>
                    <path id="Path_49959" d="M39.373 12.122a.983.983 0 0 1 0 1.965.983.983 0 0 1 0-1.965z" class="cls-1" transform="translate(437.963 206.313)"/>
                    <path id="Path_49960" d="M39.463 12.764a.975.975 0 0 1 .983.97.983.983 0 0 1-1.965 0 .975.975 0 0 1 .982-.97z" class="cls-1" transform="translate(438.832 197.798)"/>
                    <path id="Path_49961" d="M39.812 13.382a1.3 1.3 0 1 1-1.3 1.3 1.3 1.3 0 0 1 1.3-1.3z" class="cls-1" transform="translate(439.17 188.951)"/>
                    <path id="Path_49962" d="M40.262 13.989a1.769 1.769 0 1 1-1.756 1.769 1.769 1.769 0 0 1 1.756-1.769z" class="cls-1" transform="translate(439.125 179.943)"/>
                    <path id="Path_49963" d="M40.825 14.651a1.572 1.572 0 1 1-1.572 1.572 1.573 1.573 0 0 1 1.572-1.572z" class="cls-1" transform="translate(447.553 171.544)"/>
                    <circle id="Ellipse_11026" cx="1.545" cy="1.545" r="1.545" class="cls-1" transform="translate(486.697 178.287)"/>
                    <path id="Path_49964" d="M40.714 15.949a1.492 1.492 0 1 1-1.5 1.5 1.486 1.486 0 0 1 1.5-1.5z" class="cls-1" transform="translate(447.135 154.464)"/>
                    <path id="Path_49965" d="M40.548 16.6a1.369 1.369 0 1 1-1.376 1.363 1.371 1.371 0 0 1 1.376-1.363z" class="cls-1" transform="translate(446.639 146.023)"/>
                    <circle id="Ellipse_11027" cx="1.373" cy="1.373" r="1.373" class="cls-1" transform="translate(484.892 154.739)"/>
                    <path id="Path_49966" d="M40.377 17.884A1.369 1.369 0 1 1 39 19.26a1.371 1.371 0 0 1 1.377-1.376z" class="cls-1" transform="translate(444.71 129.009)"/>
                    <path id="Path_49967" d="M40.191 18.525a1.3 1.3 0 1 1-1.3 1.3 1.3 1.3 0 0 1 1.3-1.3z" class="cls-1" transform="translate(443.446 120.63)"/>
                    <path id="Path_49968" d="M40.03 19.158a1.277 1.277 0 1 1-1.277 1.277 1.274 1.274 0 0 1 1.277-1.277z" class="cls-1" transform="translate(441.912 112.272)"/>
                    <path id="Path_49969" d="M39.825 19.789a1.222 1.222 0 1 1-1.225 1.228 1.224 1.224 0 0 1 1.225-1.228z" class="cls-1" transform="translate(440.152 104.002)"/>
                    <circle id="Ellipse_11028" cx="1.226" cy="1.226" r="1.226" class="cls-1" transform="translate(476.541 116.166)"/>
                    <path id="Path_49970" d="M39.4 21.027a1.179 1.179 0 1 1-1.179 1.179 1.179 1.179 0 0 1 1.179-1.179z" class="cls-1" transform="translate(435.899 87.645)"/>
                    <path id="Path_49971" d="M39.133 21.639A1.124 1.124 0 1 1 38 22.769a1.127 1.127 0 0 1 1.133-1.13z" class="cls-1" transform="translate(433.451 79.627)"/>
                    <path id="Path_49972" d="M38.869 22.24a1.105 1.105 0 1 1-1.105 1.105 1.1 1.1 0 0 1 1.105-1.105z" class="cls-1" transform="translate(430.754 71.682)"/>
                    <path id="Path_49973" d="M38.586 22.833a1.081 1.081 0 1 1 0 2.162 1.081 1.081 0 0 1 0-2.162z" class="cls-1" transform="translate(427.832 63.854)"/>
                    <path id="Path_49974" d="M38.283 23.418a1.05 1.05 0 1 1-1.056 1.044 1.054 1.054 0 0 1 1.056-1.044z" class="cls-1" transform="translate(424.696 56.146)"/>
                    <path id="Path_49975" d="M37.916 24a.983.983 0 1 1-.983.983.985.985 0 0 1 .983-.983z" class="cls-1" transform="translate(421.379 48.604)"/>
                    <path id="Path_49976" d="M37.552 24.563a.927.927 0 1 1-.933.921.93.93 0 0 1 .933-.921z" class="cls-1" transform="translate(417.837 41.184)"/>
                    <path id="Path_49977" d="M37.148 25.12a.86.86 0 1 1-.86.86.862.862 0 0 1 .86-.86z" class="cls-1" transform="translate(414.102 33.921)"/>
                    <circle id="Ellipse_11029" cx=".711" cy=".711" r=".711" class="cls-1" transform="translate(446.175 52.559)"/>
                    <path id="Path_49978" d="M36.149 26.212a.571.571 0 0 1 .565.565.563.563 0 0 1-.565.565.556.556 0 0 1-.565-.565.563.563 0 0 1 .565-.565z" class="cls-1" transform="translate(406.16 20.007)"/>
                    <path id="Path_49979" d="M35.646 26.737a.442.442 0 0 1 0 .884.442.442 0 1 1 0-.884z" class="cls-1" transform="translate(401.873 13.28)"/>
                    <path id="Path_49980" d="M35.149 27.247a.341.341 0 0 1 .332.344.338.338 0 1 1-.676 0 .343.343 0 0 1 .344-.344z" class="cls-1" transform="translate(397.371 6.702)"/>
                    <path id="Path_49981" d="M34.68 27.739a.295.295 0 1 1-.295.295.3.3 0 0 1 .295-.295z" class="cls-1" transform="translate(392.633 .266)"/>
                    <path id="Path_49982" d="M34.24 28.213a.289.289 0 1 1 0 .577.289.289 0 1 1 0-.577z" class="cls-1" transform="translate(387.669 -6.017)"/>
                    <path id="Path_49983" d="M33.762 28.673a.27.27 0 1 1-.27.27.273.273 0 0 1 .27-.27z" class="cls-1" transform="translate(382.558 -12.09)"/>
                    <circle id="Ellipse_11030" cx=".246" cy=".246" r=".246" class="cls-1" transform="translate(410.306 11.156)"/>
                    <path id="Path_49984" d="M32.741 29.551a.194.194 0 0 1 .2.2.2.2 0 0 1-.393 0 .194.194 0 0 1 .193-.2z" class="cls-1" transform="translate(371.863 -23.592)"/>
                    <circle id="Ellipse_11031" cx=".049" cy=".049" r=".049" class="cls-1" transform="translate(398.43 1.049)"/>
                    <path id="Path_49985" d="M7.682 29.764a.116.116 0 0 1 .123.123.123.123 0 1 1-.246 0 .116.116 0 0 1 .123-.123z" class="cls-1" transform="translate(89.987 -26.286)"/>
                    <path id="Path_49986" d="M7.3 29.335a.246.246 0 1 1-.246.246.246.246 0 0 1 .246-.246z" class="cls-1" transform="translate(84.323 -20.834)"/>
                    <path id="Path_49987" d="M6.871 28.895a.295.295 0 1 1-.295.295.3.3 0 0 1 .295-.295z" class="cls-1" transform="translate(78.897 -15.088)"/>
                    <path id="Path_49988" d="M6.453 28.44a.343.343 0 0 1 .344.344.336.336 0 0 1-.344.344.343.343 0 0 1-.344-.344.351.351 0 0 1 .344-.344z" class="cls-1" transform="translate(73.628 -9.143)"/>
                    <path id="Path_49989" d="M6.074 27.968a.411.411 0 1 1-.418.418.414.414 0 0 1 .418-.418z" class="cls-1" transform="translate(68.518 -3.009)"/>
                    <path id="Path_49990" d="M5.743 27.477a.534.534 0 1 1 0 1.069.534.534 0 0 1 0-1.069z" class="cls-1" transform="translate(63.542 3.267)"/>
                    <circle id="Ellipse_11032" cx=".613" cy=".613" r=".613" class="cls-1" transform="translate(63.577 36.745)"/>
                    <path id="Path_49991" d="M5.1 26.459a.712.712 0 1 1-.712.712.713.713 0 0 1 .712-.712z" class="cls-1" transform="translate(54.19 16.432)"/>
                    <circle id="Ellipse_11033" cx=".736" cy=".736" r=".736" class="cls-1" transform="translate(53.871 49.273)"/>
                    <circle id="Ellipse_11034" cx=".76" cy=".76" r=".76" class="cls-1" transform="translate(49.375 55.807)"/>
                    <path id="Path_49992" d="M4.143 24.846a.854.854 0 1 1-.86.847.86.86 0 0 1 .86-.847z" class="cls-1" transform="translate(41.746 37.573)"/>
                    <circle id="Ellipse_11035" cx=".908" cy=".908" r=".908" class="cls-1" transform="translate(40.951 69.203)"/>
                    <path id="Path_49993" d="M3.619 23.711a.983.983 0 1 1-.983.983.985.985 0 0 1 .983-.983z" class="cls-1" transform="translate(34.446 52.39)"/>
                    <path id="Path_49994" d="M3.4 23.128a1.056 1.056 0 1 1 0 2.112 1.056 1.056 0 1 1 0-2.112z" class="cls-1" transform="translate(31.107 59.986)"/>
                    <path id="Path_49995" d="M3.215 22.533a1.154 1.154 0 1 1-1.154 1.154 1.153 1.153 0 0 1 1.154-1.154z" class="cls-1" transform="translate(27.959 67.692)"/>
                    <path id="Path_49996" d="M2.987 21.936a1.173 1.173 0 1 1-1.179 1.179 1.179 1.179 0 0 1 1.179-1.179z" class="cls-1" transform="translate(25.105 75.584)"/>
                    <path id="Path_49997" d="M2.8 21.328a1.228 1.228 0 1 1-1.228 1.228A1.232 1.232 0 0 1 2.8 21.328z" class="cls-1" transform="translate(22.454 83.549)"/>
                    <path id="Path_49998" d="M2.613 20.715a1.253 1.253 0 1 1-1.253 1.253 1.258 1.258 0 0 1 1.253-1.253z" class="cls-1" transform="translate(20.051 91.642)"/>
                    <path id="Path_49999" d="M2.49 20.092a1.32 1.32 0 1 1-1.326 1.326 1.318 1.318 0 0 1 1.326-1.326z" class="cls-1" transform="translate(17.84 99.781)"/>
                    <circle id="Ellipse_11036" cx="1.349" cy="1.349" r="1.349" class="cls-1" transform="translate(16.891 127.504)"/>
                    <path id="Path_50000" d="M2.217 18.835a1.376 1.376 0 1 1-1.376 1.376 1.381 1.381 0 0 1 1.376-1.376z" class="cls-1" transform="translate(14.196 116.366)"/>
                    <circle id="Ellipse_11037" cx="1.422" cy="1.422" r="1.422" class="cls-1" transform="translate(13.414 142.932)"/>
                    <circle id="Ellipse_11038" cx="1.447" cy="1.447" r="1.447" class="cls-1" transform="translate(12.077 150.736)"/>
                    <circle id="Ellipse_11039" cx="1.471" cy="1.471" r="1.471" class="cls-1" transform="translate(11 158.578)"/>
                    <path id="Path_50001" d="M1.967 16.269a1.523 1.523 0 1 1-1.523 1.523 1.52 1.52 0 0 1 1.523-1.523z" class="cls-1" transform="translate(9.717 150.152)"/>
                    <path id="Path_50002" d="M1.947 15.622a1.548 1.548 0 1 1 0 3.1 1.548 1.548 0 1 1 0-3.1z" class="cls-1" transform="translate(9.209 158.696)"/>
                    <path id="Path_50003" d="M1.913 14.976a1.548 1.548 0 1 1-1.535 1.548 1.549 1.549 0 0 1 1.535-1.548z" class="cls-1" transform="translate(8.972 167.276)"/>
                    <path id="Path_50004" d="M1.958 14.326a1.6 1.6 0 1 1-1.584 1.6 1.6 1.6 0 0 1 1.584-1.6z" class="cls-1" transform="translate(8.927 175.811)"/>
                    <path id="Path_50005" d="M2.014 13.678A1.621 1.621 0 1 1 .393 15.3a1.62 1.62 0 0 1 1.621-1.622z" class="cls-1" transform="translate(9.141 184.369)"/>
                    <path id="Path_50006" d="M1.99 13.039a1.548 1.548 0 1 1-1.548 1.548 1.538 1.538 0 0 1 1.548-1.548z" class="cls-1" transform="translate(9.694 193.003)"/>
                    <circle id="Ellipse_11040" cx="1.594" cy="1.594" r="1.594" class="cls-1" transform="translate(10.877 213.892)"/>
                    <path id="Path_50007" d="M2.252 11.746a1.664 1.664 0 0 1 0 3.328 1.664 1.664 0 1 1 0-3.328z" class="cls-1" transform="translate(11.274 209.943)"/>
                    <path id="Path_50008" d="M2.382 11.106A1.695 1.695 0 1 1 .687 12.8a1.688 1.688 0 0 1 1.695-1.694z" class="cls-1" transform="translate(12.458 218.382)"/>
                    <path id="Path_50009" d="M2.532 10.471A1.719 1.719 0 1 1 .813 12.19a1.714 1.714 0 0 1 1.719-1.719z" class="cls-1" transform="translate(13.88 226.767)"/>
                    <path id="Path_50010" d="M2.7 9.84a1.744 1.744 0 1 1-1.74 1.744A1.74 1.74 0 0 1 2.7 9.84z" class="cls-1" transform="translate(15.538 235.099)"/>
                    <path id="Path_50011" d="M2.9 9.215a1.762 1.762 0 1 1-1.769 1.769A1.759 1.759 0 0 1 2.9 9.215z" class="cls-1" transform="translate(17.434 243.363)"/>
                    <path id="Path_50012" d="M3.087 8.6a1.769 1.769 0 1 1-1.769 1.769A1.777 1.777 0 0 1 3.087 8.6z" class="cls-1" transform="translate(19.577 251.559)"/>
                    <path id="Path_50013" d="M3.32 7.984a1.793 1.793 0 1 1-1.793 1.793A1.8 1.8 0 0 1 3.32 7.984z" class="cls-1" transform="translate(21.935 259.652)"/>
                    <path id="Path_50014" d="M3.6 7.377a1.836 1.836 0 1 1-1.842 1.83A1.837 1.837 0 0 1 3.6 7.377z" class="cls-1" transform="translate(24.496 267.628)"/>
                    <path id="Path_50015" d="M3.87 6.779A1.867 1.867 0 1 1 2 8.646a1.866 1.866 0 0 1 1.87-1.867z" class="cls-1" transform="translate(27.305 275.509)"/>
                    <path id="Path_50016" d="M4.163 6.19a1.891 1.891 0 1 1-1.891 1.891A1.882 1.882 0 0 1 4.163 6.19z" class="cls-1" transform="translate(30.34 283.283)"/>
                    <path id="Path_50017" d="M4.476 5.611a1.91 1.91 0 1 1-1.916 1.9 1.908 1.908 0 0 1 1.916-1.9z" class="cls-1" transform="translate(33.589 290.936)"/>
                    <circle id="Ellipse_11041" cx="1.961" cy="1.961" r="1.961" class="cls-1" transform="translate(39.897 303.463)"/>
                    <path id="Path_50018" d="M5.181 4.48a1.99 1.99 0 1 1-1.99 1.99 1.979 1.979 0 0 1 1.99-1.99z" class="cls-1" transform="translate(40.708 305.798)"/>
                    <path id="Path_50019" d="M5.527 3.935a1.984 1.984 0 1 1-1.99 1.99 1.979 1.979 0 0 1 1.99-1.99z" class="cls-1" transform="translate(44.611 313.049)"/>
                    <path id="Path_50020" d="M5.868 3.4A1.959 1.959 0 1 1 3.9 5.356 1.95 1.95 0 0 1 5.868 3.4z" class="cls-1" transform="translate(48.741 320.164)"/>
                    <path id="Path_50021" d="M6.1 2.893a1.818 1.818 0 1 1-1.8 1.818 1.814 1.814 0 0 1 1.8-1.818z" class="cls-1" transform="translate(53.186 327.22)"/>
                    <path id="Path_50022" d="M6.468 2.389A1.762 1.762 0 1 1 4.7 4.158a1.769 1.769 0 0 1 1.768-1.769z" class="cls-1" transform="translate(57.721 334.025)"/>
                    <circle id="Ellipse_11042" cx="2.011" cy="2.011" r="2.011" class="cls-1" transform="translate(67.281 342.246)"/>
                    <path id="Path_50023" d="M7.676 1.381a2.155 2.155 0 1 1-2.162 2.162 2.165 2.165 0 0 1 2.162-2.162z" class="cls-1" transform="translate(66.916 346.627)"/>
                    <path id="Path_50024" d="M8.2.906a2.26 2.26 0 1 1-2.248 2.26A2.262 2.262 0 0 1 8.2.906z" class="cls-1" transform="translate(71.88 352.727)"/>
                    <path id="Path_50025" d="M8.721.451a2.3 2.3 0 1 1-2.309 2.3 2.3 2.3 0 0 1 2.309-2.3z" class="cls-1" transform="translate(77.047 358.684)"/>
                    <circle id="Ellipse_11043" cx="2.207" cy="2.207" r="2.207" class="cls-1" transform="translate(89.425 364.577)"/>
                    <path id="Path_50026" d="M8.629-.31A1.154 1.154 0 1 1 7.475.844 1.161 1.161 0 0 1 8.629-.31z" class="cls-1" transform="translate(89.039 371.088)"/>
                    <path id="Path_50027" d="M32.4-.45a.362.362 0 0 1 .368.368.37.37 0 0 1-.368.369.378.378 0 0 1-.369-.368.37.37 0 0 1 .369-.369z" class="cls-1" transform="translate(366.076 374.52)"/>
                    <path id="Path_50028" d="M34.275-.16a1.861 1.861 0 1 1-1.867 1.867A1.856 1.856 0 0 1 34.275-.16z" class="cls-1" transform="translate(370.329 367.684)"/>
                    <circle id="Ellipse_11044" cx="2.207" cy="2.207" r="2.207" class="cls-1" transform="translate(408.345 361.927)"/>
                    <path id="Path_50029" d="M35.466.689a2.131 2.131 0 1 1-2.125 2.137A2.139 2.139 0 0 1 35.466.689z" class="cls-1" transform="translate(380.855 355.867)"/>
                    <path id="Path_50030" d="M35.921 1.148A2.131 2.131 0 1 1 33.8 3.285a2.139 2.139 0 0 1 2.121-2.137z" class="cls-1" transform="translate(385.988 349.771)"/>
                    <circle id="Ellipse_11045" cx="2.06" cy="2.06" r="2.06" class="cls-1" transform="translate(425.253 345.173)"/>
                    <path id="Path_50031" d="M36.728 2.115a2.063 2.063 0 1 1-2.063 2.063 2.057 2.057 0 0 1 2.063-2.063z" class="cls-1" transform="translate(395.792 337.062)"/>
                    <path id="Path_50032" d="M37.045 2.625A1.965 1.965 0 1 1 35.08 4.59a1.96 1.96 0 0 1 1.965-1.965z" class="cls-1" transform="translate(400.474 330.485)"/>
                    <path id="Path_50033" d="M37.39 3.144a1.916 1.916 0 1 1-1.916 1.916 1.918 1.918 0 0 1 1.916-1.916z" class="cls-1" transform="translate(404.919 323.69)"/>
                    <path id="Path_50034" d="M37.785 3.67a1.941 1.941 0 1 1-1.94 1.941 1.934 1.934 0 0 1 1.94-1.941z" class="cls-1" transform="translate(409.104 316.655)"/>
                    <path id="Path_50035" d="M38.163 4.208A1.965 1.965 0 1 1 36.2 6.173a1.971 1.971 0 0 1 1.963-1.965z" class="cls-1" transform="translate(413.087 309.46)"/>
                    <path id="Path_50036" d="M38.432 4.766a1.885 1.885 0 1 1-1.891 1.891 1.892 1.892 0 0 1 1.891-1.891z" class="cls-1" transform="translate(416.957 302.208)"/>
                    <path id="Path_50037" d="M38.547 5.346A1.664 1.664 0 1 1 36.877 7a1.662 1.662 0 0 1 1.67-1.654z" class="cls-1" transform="translate(420.747 294.947)"/>
                    <path id="Path_50038" d="M38.78 5.925a1.591 1.591 0 1 1-1.6 1.6 1.6 1.6 0 0 1 1.6-1.6z" class="cls-1" transform="translate(424.199 287.404)"/>
                    <path id="Path_50039" d="M39.014 6.511a1.541 1.541 0 1 1-1.547 1.548 1.541 1.541 0 0 1 1.547-1.548z" class="cls-1" transform="translate(427.404 279.719)"/>
                    <path id="Path_50040" d="M39.23 7.106a1.5 1.5 0 1 1-1.5 1.5 1.5 1.5 0 0 1 1.5-1.5z" class="cls-1" transform="translate(430.393 271.902)"/>
                    <path id="Path_50041" d="M39.494 7.7a1.517 1.517 0 1 1-1.523 1.523A1.515 1.515 0 0 1 39.494 7.7z" class="cls-1" transform="translate(433.09 263.923)"/>
                    <circle id="Ellipse_11046" cx="1.447" cy="1.447" r="1.447" class="cls-1" transform="translate(473.855 264.241)"/>
                    <circle id="Ellipse_11047" cx="1.349" cy="1.349" r="1.349" class="cls-1" transform="translate(476.418 256.794)"/>
                    <path id="Path_50042" d="M39.825 9.57A1.222 1.222 0 1 1 38.6 10.8a1.224 1.224 0 0 1 1.225-1.23z" class="cls-1" transform="translate(440.152 239.729)"/>
                    <path id="Path_50043" d="M39.94 10.2a1.179 1.179 0 1 1-1.179 1.179A1.169 1.169 0 0 1 39.94 10.2z" class="cls-1" transform="translate(442.002 231.447)"/>
                    <path id="Path_50044" d="M39.965 10.841a1.056 1.056 0 1 1-1.056 1.059 1.056 1.056 0 0 1 1.056-1.059z" class="cls-1" transform="translate(443.672 223.179)"/>
                    <path id="Path_50045" d="M40.128 11.473a1.1 1.1 0 1 1-1.105 1.093 1.106 1.106 0 0 1 1.105-1.093z" class="cls-1" transform="translate(444.958 214.699)"/>
                    <path id="Path_50046" d="M40.2 12.114a1.075 1.075 0 1 1-1.081 1.081 1.082 1.082 0 0 1 1.081-1.081z" class="cls-1" transform="translate(446.064 206.235)"/>
                    <path id="Path_50047" d="M40.3 12.753a1.105 1.105 0 1 1-1.105 1.105 1.1 1.1 0 0 1 1.105-1.105z" class="cls-1" transform="translate(446.887 197.686)"/>
                    <circle id="Ellipse_11048" cx="1.349" cy="1.349" r="1.349" class="cls-1" transform="translate(486.498 202.282)"/>
                    <circle id="Ellipse_11049" cx="1.692" cy="1.692" r="1.692" class="cls-1" transform="translate(486.549 194.011)"/>
                    <path id="Path_50048" d="M40.507 14.743a.442.442 0 0 1 0 .884.442.442 0 1 1 0-.884z" class="cls-1" transform="translate(456.714 172.582)"/>
                    <path id="Path_50049" d="M40.5 15.389a.442.442 0 1 1-.442.442.44.44 0 0 1 .442-.442z" class="cls-1" transform="translate(456.59 164.002)"/>
                    <path id="Path_50050" d="M40.51 16.031a.482.482 0 0 1 .49.479.491.491 0 0 1-.982 0 .482.482 0 0 1 .492-.479z" class="cls-1" transform="translate(456.195 155.389)"/>
                    <path id="Path_50051" d="M40.56 16.665a.616.616 0 0 1 .614.614.608.608 0 1 1-.614-.614z" class="cls-1" transform="translate(455.507 146.71)"/>
                    <circle id="Ellipse_11050" cx=".736" cy=".736" r=".736" class="cls-1" transform="translate(494.448 155.369)"/>
                    <path id="Path_50052" d="M40.7 17.921a.927.927 0 1 1-.933.921.93.93 0 0 1 .933-.921z" class="cls-1" transform="translate(453.34 129.402)"/>
                    <path id="Path_50053" d="M40.722 18.545a1.081 1.081 0 1 1 0 2.162 1.081 1.081 0 1 1 0-2.162z" class="cls-1" transform="translate(451.93 120.807)"/>
                    <path id="Path_50054" d="M40.723 19.165a1.228 1.228 0 1 1-1.228 1.228 1.232 1.232 0 0 1 1.228-1.228z" class="cls-1" transform="translate(450.283 112.277)"/>
                    <path id="Path_50055" d="M40.569 19.793a1.222 1.222 0 1 1-1.228 1.216 1.221 1.221 0 0 1 1.228-1.216z" class="cls-1" transform="translate(448.546 103.949)"/>
                    <path id="Path_50056" d="M40.361 20.417a1.2 1.2 0 1 1-1.191 1.2 1.206 1.206 0 0 1 1.191-1.2z" class="cls-1" transform="translate(446.616 95.698)"/>
                    <path id="Path_50057" d="M40.18 21.034a1.2 1.2 0 0 1 0 2.395 1.2 1.2 0 1 1 0-2.395z" class="cls-1" transform="translate(444.428 87.515)"/>
                    <path id="Path_50058" d="M39.875 21.652a1.1 1.1 0 1 1-1.105 1.105 1.1 1.1 0 0 1 1.105-1.105z" class="cls-1" transform="translate(442.104 79.504)"/>
                    <path id="Path_50059" d="M39.6 22.258a1.056 1.056 0 1 1 0 2.112 1.056 1.056 0 0 1 0-2.112z" class="cls-1" transform="translate(439.52 71.541)"/>
                    <path id="Path_50060" d="M39.368 22.851a1.081 1.081 0 1 1 0 2.162 1.081 1.081 0 1 1 0-2.162z" class="cls-1" transform="translate(436.655 63.615)"/>
                    <path id="Path_50061" d="M39.074 23.44a1.056 1.056 0 1 1-1.056 1.06 1.056 1.056 0 0 1 1.056-1.06z" class="cls-1" transform="translate(433.62 55.842)"/>
                    <path id="Path_50062" d="M38.773 24.018a1.056 1.056 0 1 1-1.044 1.056 1.056 1.056 0 0 1 1.044-1.056z" class="cls-1" transform="translate(430.359 48.165)"/>
                    <path id="Path_50063" d="M38.4 24.592a.983.983 0 0 1 0 1.965.983.983 0 0 1 0-1.965z" class="cls-1" transform="translate(426.952 40.688)"/>
                    <path id="Path_50064" d="M37.97 25.16a.86.86 0 1 1-.86.86.862.862 0 0 1 .86-.86z" class="cls-1" transform="translate(423.376 33.39)"/>
                    <path id="Path_50065" d="M37.547 25.713a.786.786 0 1 1-.774.786.784.784 0 0 1 .774-.786z" class="cls-1" transform="translate(419.574 26.192)"/>
                    <path id="Path_50066" d="M37.017 26.265a.59.59 0 0 1 .59.59.582.582 0 0 1-.59.59.59.59 0 0 1-.59-.59.6.6 0 0 1 .59-.59z" class="cls-1" transform="translate(415.67 19.254)"/>
                    <path id="Path_50067" d="M36.5 26.8a.442.442 0 1 1-.442.442.44.44 0 0 1 .442-.442z" class="cls-1" transform="translate(411.541 12.43)"/>
                    <path id="Path_50068" d="M36.04 27.319a.362.362 0 1 1 0 .725.362.362 0 1 1 0-.725z" class="cls-1" transform="translate(407.153 5.709)"/>
                    <path id="Path_50069" d="M35.584 27.821a.31.31 0 0 1 .319.319.317.317 0 0 1-.319.319.325.325 0 0 1-.319-.319.317.317 0 0 1 .319-.319z" class="cls-1" transform="translate(402.561 -.872)"/>
                    <path id="Path_50070" d="M35.136 28.309a.289.289 0 1 1 0 .577.289.289 0 1 1 0-.577z" class="cls-1" transform="translate(397.777 -7.292)"/>
                    <path id="Path_50071" d="M34.649 28.784a.246.246 0 0 1 0 .491.246.246 0 1 1 0-.491z" class="cls-1" transform="translate(392.836 -13.515)"/>
                    <circle id="Ellipse_11051" cx=".221" cy=".221" r=".221" class="cls-1" transform="translate(421.646 9.682)"/>
                    <path id="Path_50072" d="M33.607 29.693a.123.123 0 0 1 .123.123.116.116 0 0 1-.123.123.123.123 0 0 1-.123-.123.132.132 0 0 1 .123-.123z" class="cls-1" transform="translate(382.468 -25.343)"/>
                    <path id="Path_50073" d="M6.522 29.691a.147.147 0 1 1-.147.147.142.142 0 0 1 .147-.147z" class="cls-1" transform="translate(76.629 -25.365)"/>
                    <path id="Path_50074" d="M6.187 29.237a.295.295 0 1 1 0 .59.295.295 0 1 1 0-.59z" class="cls-1" transform="translate(71.18 -19.63)"/>
                    <path id="Path_50075" d="M5.775 28.776a.351.351 0 0 1 .344.344.343.343 0 0 1-.344.344.336.336 0 0 1-.344-.344.343.343 0 0 1 .344-.344z" class="cls-1" transform="translate(65.979 -13.606)"/>
                    <path id="Path_50076" d="M5.423 28.3a.436.436 0 1 1 0 .872.436.436 0 1 1 0-.872z" class="cls-1" transform="translate(60.902 -7.428)"/>
                    <path id="Path_50077" d="M5.064 27.8a.516.516 0 1 1-.516.516.519.519 0 0 1 .516-.516z" class="cls-1" transform="translate(56.017 -1.053)"/>
                    <circle id="Ellipse_11052" cx=".613" cy=".613" r=".613" class="cls-1" transform="translate(55.419 32.778)"/>
                    <path id="Path_50078" d="M4.416 26.781a.688.688 0 1 1-.688.688.687.687 0 0 1 .688-.688z" class="cls-1" transform="translate(46.766 12.204)"/>
                    <circle id="Ellipse_11053" cx=".76" cy=".76" r=".76" class="cls-1" transform="translate(45.779 45.351)"/>
                    <path id="Path_50079" d="M3.767 25.713a.786.786 0 0 1 0 1.572.786.786 0 0 1 0-1.572z" class="cls-1" transform="translate(38.339 26.192)"/>
                    <path id="Path_50080" d="M3.491 25.16a.86.86 0 1 1-.86.86.862.862 0 0 1 .86-.86z" class="cls-1" transform="translate(34.39 33.39)"/>
                    <path id="Path_50081" d="M3.21 24.6a.909.909 0 1 1-.909.909.907.907 0 0 1 .909-.909z" class="cls-1" transform="translate(30.667 40.756)"/>
                    <path id="Path_50082" d="M2.992 24.022a1.007 1.007 0 1 1-1.007 1.007 1.012 1.012 0 0 1 1.007-1.007z" class="cls-1" transform="translate(27.102 48.21)"/>
                    <path id="Path_50083" d="M2.747 23.44a1.056 1.056 0 1 1-1.056 1.06 1.064 1.064 0 0 1 1.056-1.06z" class="cls-1" transform="translate(23.785 55.842)"/>
                    <path id="Path_50084" d="M2.544 22.848a1.124 1.124 0 1 1-1.13 1.13 1.127 1.127 0 0 1 1.13-1.13z" class="cls-1" transform="translate(20.66 63.569)"/>
                    <path id="Path_50085" d="M2.337 22.248a1.179 1.179 0 1 1-1.179 1.179 1.179 1.179 0 0 1 1.179-1.179z" class="cls-1" transform="translate(17.772 71.428)"/>
                    <path id="Path_50086" d="M2.127 21.644a1.2 1.2 0 1 1-1.2 1.2 1.206 1.206 0 0 1 1.2-1.2z" class="cls-1" transform="translate(15.121 79.413)"/>
                    <path id="Path_50087" d="M1.959 21.03a1.247 1.247 0 1 1-1.253 1.24 1.237 1.237 0 0 1 1.253-1.24z" class="cls-1" transform="translate(12.673 87.47)"/>
                    <path id="Path_50088" d="M1.81 20.409a1.3 1.3 0 1 1-1.3 1.3 1.311 1.311 0 0 1 1.3-1.3z" class="cls-1" transform="translate(10.439 95.607)"/>
                    <circle id="Ellipse_11054" cx="1.349" cy="1.349" r="1.349" class="cls-1" transform="translate(8.763 123.614)"/>
                    <circle id="Ellipse_11055" cx="1.373" cy="1.373" r="1.373" class="cls-1" transform="translate(6.848 131.298)"/>
                    <path id="Path_50089" d="M1.269 18.533a1.222 1.222 0 1 1-1.216 1.216 1.221 1.221 0 0 1 1.216-1.216z" class="cls-1" transform="translate(5.306 120.684)"/>
                    <path id="Path_50090" d="M.942 17.917a.976.976 0 1 1 0 1.953.976.976 0 1 1 0-1.953z" class="cls-1" transform="translate(4.245 129.357)"/>
                    <circle id="Ellipse_11056" cx=".736" cy=".736" r=".736" class="cls-1" transform="translate(3.311 155.369)"/>
                    <circle id="Ellipse_11057" cx=".613" cy=".613" r=".613" class="cls-1" transform="translate(2.545 163.379)"/>
                    <path id="Path_50091" d="M.273 16.031a.482.482 0 0 1 .491.479.493.493 0 0 1-.491.49.493.493 0 0 1-.491-.491.482.482 0 0 1 .491-.478z" class="cls-1" transform="translate(2.248 155.389)"/>
                    <path id="Path_50092" d="M.2 15.389a.442.442 0 1 1 0 .884.442.442 0 1 1 0-.884z" class="cls-1" transform="translate(1.944 164.002)"/>
                    <path id="Path_50093" d="M.119 14.749a.378.378 0 0 1 .368.368.37.37 0 0 1-.368.368.362.362 0 0 1-.368-.368.369.369 0 0 1 .368-.368z" class="cls-1" transform="translate(1.898 172.649)"/>
                    <circle id="Ellipse_11058" cx=".465" cy=".465" r=".465" class="cls-1" transform="translate(1.675 195.238)"/>
                    <path id="Path_50094" d="M.3 13.445a.516.516 0 0 1 0 1.032.516.516 0 0 1 0-1.032z" class="cls-1" transform="translate(2.226 189.674)"/>
                    <circle id="Ellipse_11059" cx=".637" cy=".637" r=".637" class="cls-1" transform="translate(2.52 210.906)"/>
                    <path id="Path_50095" d="M.713 12.133a.836.836 0 0 1 .835.835.835.835 0 0 1-1.67 0 .844.844 0 0 1 .835-.835z" class="cls-1" transform="translate(3.331 206.461)"/>
                    <path id="Path_50096" d="M1.077 11.47a1.124 1.124 0 1 1-1.13 1.13 1.127 1.127 0 0 1 1.13-1.13z" class="cls-1" transform="translate(4.11 214.69)"/>
                    <path id="Path_50097" d="M1.472 10.807a1.449 1.449 0 1 1-1.437 1.449 1.452 1.452 0 0 1 1.437-1.449z" class="cls-1" transform="translate(5.102 222.845)"/>
                    <path id="Path_50098" d="M1.865 10.153a1.719 1.719 0 1 1-1.719 1.719 1.725 1.725 0 0 1 1.719-1.719z" class="cls-1" transform="translate(6.355 230.991)"/>
                    <path id="Path_50099" d="M2.065 9.521A1.769 1.769 0 1 1 .3 11.29a1.769 1.769 0 0 1 1.765-1.769z" class="cls-1" transform="translate(8.047 239.287)"/>
                    <path id="Path_50100" d="M2.239 8.9A1.769 1.769 0 1 1 .47 10.668 1.777 1.777 0 0 1 2.239 8.9z" class="cls-1" transform="translate(10.01 247.548)"/>
                    <path id="Path_50101" d="M2.455 8.281a1.787 1.787 0 1 1-1.793 1.793 1.785 1.785 0 0 1 1.793-1.793z" class="cls-1" transform="translate(12.176 255.719)"/>
                    <path id="Path_50102" d="M2.713 7.667A1.836 1.836 0 1 1 .871 9.509a1.84 1.84 0 0 1 1.842-1.842z" class="cls-1" transform="translate(14.534 263.776)"/>
                    <path id="Path_50103" d="M2.946 7.064A1.836 1.836 0 1 1 1.1 8.894a1.837 1.837 0 0 1 1.846-1.83z" class="cls-1" transform="translate(17.163 271.785)"/>
                    <path id="Path_50104" d="M3.221 6.467a1.861 1.861 0 1 1-1.867 1.867 1.866 1.866 0 0 1 1.867-1.867z" class="cls-1" transform="translate(19.983 279.665)"/>
                    <path id="Path_50105" d="M3.514 5.878a1.891 1.891 0 1 1-1.891 1.891 1.892 1.892 0 0 1 1.891-1.891z" class="cls-1" transform="translate(23.018 287.427)"/>
                    <circle id="Ellipse_11060" cx="1.912" cy="1.912" r="1.912" class="cls-1" transform="translate(28.179 300.38)"/>
                    <path id="Path_50106" d="M4.158 4.728a1.941 1.941 0 1 1-1.941 1.941 1.945 1.945 0 0 1 1.941-1.941z" class="cls-1" transform="translate(29.719 302.602)"/>
                    <path id="Path_50107" d="M4.506 4.168a1.965 1.965 0 1 1-1.965 1.965 1.971 1.971 0 0 1 1.965-1.965z" class="cls-1" transform="translate(33.375 309.991)"/>
                    <circle id="Ellipse_11061" cx="2.011" cy="2.011" r="2.011" class="cls-1" transform="translate(40.093 320.832)"/>
                    <circle id="Ellipse_11062" cx="2.035" cy="2.035" r="2.035" class="cls-1" transform="translate(44.504 327.389)"/>
                    <path id="Path_50108" d="M5.544 2.565a1.916 1.916 0 1 1-1.916 1.916 1.918 1.918 0 0 1 1.916-1.916z" class="cls-1" transform="translate(45.638 331.38)"/>
                    <path id="Path_50109" d="M5.826 2.064a1.787 1.787 0 1 1-1.793 1.793 1.8 1.8 0 0 1 1.793-1.793z" class="cls-1" transform="translate(50.207 338.292)"/>
                    <circle id="Ellipse_11063" cx="2.011" cy="2.011" r="2.011" class="cls-1" transform="translate(59.069 346.259)"/>
                    <circle id="Ellipse_11064" cx="2.109" cy="2.109" r="2.109" class="cls-1" transform="translate(64.212 352.121)"/>
                    <path id="Path_50110" d="M7.377.584a2.088 2.088 0 1 1-2.088 2.088A2.084 2.084 0 0 1 7.377.584z" class="cls-1" transform="translate(64.377 357.347)"/>
                    <path id="Path_50111" d="M7.766.133a2.014 2.014 0 1 1-2.014 2.014A2.013 2.013 0 0 1 7.766.133z" class="cls-1" transform="translate(69.601 363.485)"/>
                    <path id="Path_50112" d="M7.515-.245A1.228 1.228 0 1 1 6.287.983 1.232 1.232 0 0 1 7.515-.245z" class="cls-1" transform="translate(75.636 370.078)"/>
                    <path id="Path_50113" d="M34.78-.259a1.4 1.4 0 1 1-1.4 1.4 1.4 1.4 0 0 1 1.4-1.4z" class="cls-1" transform="translate(381.295 369.92)"/>
                    <circle id="Ellipse_11065" cx="2.182" cy="2.182" r="2.182" class="cls-1" transform="translate(419.684 363.45)"/>
                    <circle id="Ellipse_11066" cx="2.06" cy="2.06" r="2.06" class="cls-1" transform="translate(425.42 357.96)"/>
                    <path id="Path_50114" d="M36.783 1.056a2.082 2.082 0 1 1-2.088 2.088 2.084 2.084 0 0 1 2.088-2.088z" class="cls-1" transform="translate(396.13 351.091)"/>
                    <path id="Path_50115" d="M37.13 1.547a2.008 2.008 0 1 1-2 2 2 2 0 0 1 2-2z" class="cls-1" transform="translate(401.015 344.717)"/>
                    <path id="Path_50116" d="M37.564 2.044a2.033 2.033 0 1 1-2.027 2.039 2.034 2.034 0 0 1 2.027-2.039z" class="cls-1" transform="translate(405.63 338.067)"/>
                    <path id="Path_50117" d="M37.857 2.565a1.916 1.916 0 1 1-1.916 1.916 1.918 1.918 0 0 1 1.916-1.916z" class="cls-1" transform="translate(410.188 331.38)"/>
                    <path id="Path_50118" d="M38.179 3.093a1.867 1.867 0 1 1-1.855 1.867 1.866 1.866 0 0 1 1.855-1.867z" class="cls-1" transform="translate(414.508 324.466)"/>
                    <path id="Path_50119" d="M38.472 3.635a1.793 1.793 0 1 1-1.781 1.793 1.8 1.8 0 0 1 1.781-1.793z" class="cls-1" transform="translate(418.649 317.414)"/>
                    <path id="Path_50120" d="M38.906 4.174a1.891 1.891 0 1 1-1.879 1.891 1.892 1.892 0 0 1 1.879-1.891z" class="cls-1" transform="translate(422.44 310.059)"/>
                    <path id="Path_50121" d="M39.1 4.744a1.744 1.744 0 1 1-1.732 1.744A1.743 1.743 0 0 1 39.1 4.744z" class="cls-1" transform="translate(426.253 302.783)"/>
                    <circle id="Ellipse_11067" cx="1.594" cy="1.594" r="1.594" class="cls-1" transform="translate(467.544 300.698)"/>
                    <path id="Path_50122" d="M39.458 5.912a1.474 1.474 0 1 1-1.474 1.474 1.478 1.478 0 0 1 1.474-1.474z" class="cls-1" transform="translate(433.236 287.81)"/>
                    <path id="Path_50123" d="M39.706 6.5a1.443 1.443 0 1 1-1.449 1.45 1.444 1.444 0 0 1 1.449-1.45z" class="cls-1" transform="translate(436.316 280.049)"/>
                    <circle id="Ellipse_11068" cx="1.471" cy="1.471" r="1.471" class="cls-1" transform="translate(477.65 279.212)"/>
                    <path id="Path_50124" d="M40.191 7.7a1.443 1.443 0 1 1-1.449 1.449A1.452 1.452 0 0 1 40.191 7.7z" class="cls-1" transform="translate(441.788 264.137)"/>
                    <path id="Path_50125" d="M40.383 8.311a1.419 1.419 0 1 1-1.425 1.425 1.415 1.415 0 0 1 1.425-1.425z" class="cls-1" transform="translate(444.225 256.058)"/>
                    <path id="Path_50126" d="M40.5 8.933a1.351 1.351 0 1 1-1.339 1.351A1.355 1.355 0 0 1 40.5 8.933z" class="cls-1" transform="translate(446.481 247.931)"/>
                    <circle id="Ellipse_11069" cx="1.275" cy="1.275" r="1.275" class="cls-1" transform="translate(487.844 249.298)"/>
                    <path id="Path_50127" d="M40.633 10.2a1.13 1.13 0 1 1-1.13 1.13 1.127 1.127 0 0 1 1.13-1.13z" class="cls-1" transform="translate(450.373 231.532)"/>
                    <circle id="Ellipse_11070" cx=".932" cy=".932" r=".932" class="cls-1" transform="translate(491.719 234.166)"/>
                    <circle id="Ellipse_11071" cx=".76" cy=".76" r=".76" class="cls-1" transform="translate(493.282 226.525)"/>
                    <path id="Path_50128" d="M40.477 12.153a.59.59 0 1 1 0 1.179.59.59 0 1 1 0-1.179z" class="cls-1" transform="translate(454.706 206.687)"/>
                    <path id="Path_50129" d="M40.424 12.8a.467.467 0 0 1 0 .933.467.467 0 0 1 0-.933z" class="cls-1" transform="translate(455.642 198.273)"/>
                    <path id="Path_50130" d="M40.51 13.447a.491.491 0 1 1-.491.491.493.493 0 0 1 .491-.491z" class="cls-1" transform="translate(456.195 189.697)"/>
                    <path id="Path_50131" d="M40.541 14.093a.491.491 0 1 1-.491.491.493.493 0 0 1 .491-.491z" class="cls-1" transform="translate(456.544 181.117)"/>
                    <circle id="Ellipse_11072" cx=".025" cy=".025" r=".025" class="cls-1" transform="translate(500.039 132.615)"/>
                    <path id="Path_50132" d="M40.342 19.882a.176.176 0 0 1 .172.172.185.185 0 0 1-.172.172.176.176 0 0 1-.172-.172.168.168 0 0 1 .172-.172z" class="cls-1" transform="translate(457.898 104.867)"/>
                    <path id="Path_50133" d="M40.445 20.482a.467.467 0 1 1-.467.467.467.467 0 0 1 .467-.467z" class="cls-1" transform="translate(455.732 96.308)"/>
                    <path id="Path_50134" d="M40.584 21.071a.835.835 0 0 1 0 1.67.835.835 0 0 1 0-1.67z" class="cls-1" transform="translate(453.284 87.748)"/>
                    <path id="Path_50135" d="M40.615 21.663a1.081 1.081 0 0 1 0 2.162 1.081 1.081 0 0 1 0-2.162z" class="cls-1" transform="translate(450.723 79.394)"/>
                    <path id="Path_50136" d="M40.412 22.267a1.105 1.105 0 1 1-1.105 1.105 1.109 1.109 0 0 1 1.105-1.105z" class="cls-1" transform="translate(448.162 71.323)"/>
                    <path id="Path_50137" d="M40.168 22.866a1.1 1.1 0 1 1-1.105 1.093 1.1 1.1 0 0 1 1.105-1.093z" class="cls-1" transform="translate(445.409 63.379)"/>
                    <path id="Path_50138" d="M39.839 23.462a1.032 1.032 0 1 1-1.032 1.032 1.03 1.03 0 0 1 1.032-1.032z" class="cls-1" transform="translate(442.521 55.599)"/>
                    <path id="Path_50139" d="M39.524 24.047a1 1 0 1 1-.995 1.007 1 1 0 0 1 .995-1.007z" class="cls-1" transform="translate(439.385 47.89)"/>
                    <path id="Path_50140" d="M39.237 24.62a1.007 1.007 0 1 1-1.007 1.007 1.012 1.012 0 0 1 1.007-1.007z" class="cls-1" transform="translate(436.012 40.267)"/>
                    <path id="Path_50141" d="M38.853 25.19a.927.927 0 1 1-.933.921.93.93 0 0 1 .933-.921z" class="cls-1" transform="translate(432.514 32.856)"/>
                    <circle id="Ellipse_11073" cx=".883" cy=".883" r=".883" class="cls-1" transform="translate(466.396 51.289)"/>
                    <path id="Path_50142" d="M38.012 26.3a.755.755 0 1 1-.761.749.755.755 0 0 1 .761-.749z" class="cls-1" transform="translate(424.967 18.444)"/>
                    <path id="Path_50143" d="M37.42 26.853a.51.51 0 1 1-.516.516.511.511 0 0 1 .516-.516z" class="cls-1" transform="translate(421.052 11.604)"/>
                    <path id="Path_50144" d="M36.924 27.383a.393.393 0 1 1-.393.393.388.388 0 0 1 .393-.393z" class="cls-1" transform="translate(416.844 4.798)"/>
                    <path id="Path_50145" d="M36.48 27.895a.343.343 0 0 1 .344.344.344.344 0 1 1-.688 0 .343.343 0 0 1 .344-.344z" class="cls-1" transform="translate(412.387 -1.904)"/>
                    <path id="Path_50146" d="M36.008 28.395a.3.3 0 1 1-.282.295.291.291 0 0 1 .282-.295z" class="cls-1" transform="translate(407.762 -8.447)"/>
                    <path id="Path_50147" d="M35.568 28.88a.27.27 0 1 1-.27.27.273.273 0 0 1 .27-.27z" class="cls-1" transform="translate(402.933 -14.839)"/>
                    <circle id="Ellipse_11074" cx=".221" cy=".221" r=".221" class="cls-1" transform="translate(432.82 8.33)"/>
                    <circle id="Ellipse_11075" cx=".074" cy=".074" r=".074" class="cls-1" transform="translate(427.334 2.886)"/>
                    <circle id="Ellipse_11076" cx=".025" cy=".025" r=".025" class="cls-1" transform="translate(74.68 .206)"/>
                    <path id="Path_50148" d="M5.436 29.582a.221.221 0 1 1 0 .442.221.221 0 1 1 0-.442z" class="cls-1" transform="translate(63.542 -24.065)"/>
                    <path id="Path_50149" d="M5.1 29.11a.343.343 0 0 1 .344.344.351.351 0 0 1-.344.346.343.343 0 0 1-.344-.344.336.336 0 0 1 .344-.346z" class="cls-1" transform="translate(58.341 -18.042)"/>
                    <path id="Path_50150" d="M4.751 28.626a.442.442 0 1 1-.442.442.44.44 0 0 1 .442-.442z" class="cls-1" transform="translate(53.321 -11.81)"/>
                    <path id="Path_50151" d="M4.4 28.131a.516.516 0 1 1-.516.516.509.509 0 0 1 .516-.516z" class="cls-1" transform="translate(48.492 -5.383)"/>
                    <path id="Path_50152" d="M4.058 27.623a.6.6 0 0 1 .59.59.59.59 0 0 1-.59.59.582.582 0 0 1-.59-.59.59.59 0 0 1 .59-.59z" class="cls-1" transform="translate(43.833 1.217)"/>
                    <path id="Path_50153" d="M3.712 27.1a.642.642 0 0 1 .639.639.65.65 0 0 1-.639.639.642.642 0 0 1-.639-.639.634.634 0 0 1 .639-.639z" class="cls-1" transform="translate(39.377 8.012)"/>
                    <circle id="Ellipse_11077" cx=".736" cy=".736" r=".736" class="cls-1" transform="translate(37.743 41.481)"/>
                    <path id="Path_50154" d="M3.136 26.026a.811.811 0 0 1 0 1.621.811.811 0 0 1 0-1.621z" class="cls-1" transform="translate(30.938 21.986)"/>
                    <path id="Path_50155" d="M2.827 25.474a.86.86 0 1 1 0 1.719.86.86 0 0 1 0-1.719z" class="cls-1" transform="translate(27.046 29.219)"/>
                    <circle id="Ellipse_11078" cx=".908" cy=".908" r=".908" class="cls-1" transform="translate(24.985 61.512)"/>
                    <circle id="Ellipse_11079" cx=".957" cy=".957" r=".957" class="cls-1" transform="translate(21.164 68.447)"/>
                    <path id="Path_50156" d="M2.064 23.755a1.026 1.026 0 1 1-1.019 1.032 1.022 1.022 0 0 1 1.019-1.032z" class="cls-1" transform="translate(16.497 51.719)"/>
                    <path id="Path_50157" d="M1.872 23.162a1.105 1.105 0 1 1-1.105 1.105 1.1 1.1 0 0 1 1.105-1.105z" class="cls-1" transform="translate(13.361 59.436)"/>
                    <circle id="Ellipse_11080" cx="1.152" cy="1.152" r="1.152" class="cls-1" transform="translate(10.974 89.855)"/>
                    <path id="Path_50158" d="M1.486 21.955A1.228 1.228 0 1 1 .27 23.183a1.224 1.224 0 0 1 1.216-1.228z" class="cls-1" transform="translate(7.754 75.221)"/>
                    <path id="Path_50159" d="M1.147 21.358a1.081 1.081 0 0 1 0 2.162 1.081 1.081 0 1 1 0-2.162z" class="cls-1" transform="translate(5.452 83.445)"/>
                    <circle id="Ellipse_11081" cx=".711" cy=".711" r=".711" class="cls-1" transform="translate(3.466 112.734)"/>
                    <path id="Path_50160" d="M.117 20.179a.362.362 0 0 1 .368.368.369.369 0 0 1-.368.368.378.378 0 0 1-.368-.368.37.37 0 0 1 .368-.368z" class="cls-1" transform="translate(1.876 100.529)"/>
                    <circle id="Ellipse_11082" cx=".025" cy=".025" r=".025" class="cls-1" transform="translate(.025 128.745)"/>
                    <path id="Path_50161" d="M-.334 9.971l.049.049-.049.048-.049-.048z" class="cls-1" transform="translate(.383 236.745)"/>
                    <circle id="Ellipse_11083" cx=".465" cy=".465" r=".465" class="cls-1" transform="translate(1.529 253.994)"/>
                    <path id="Path_50162" d="M.814 8.652a.927.927 0 1 1-.933.933.933.933 0 0 1 .933-.933z" class="cls-1" transform="translate(3.365 252.511)"/>
                    <path id="Path_50163" d="M1.576 7.986A1.548 1.548 0 1 1 .028 9.533a1.546 1.546 0 0 1 1.548-1.547z" class="cls-1" transform="translate(5.024 260.116)"/>
                    <path id="Path_50164" d="M2.05 7.353a1.836 1.836 0 1 1-1.83 1.83 1.837 1.837 0 0 1 1.83-1.83z" class="cls-1" transform="translate(7.19 267.946)"/>
                    <path id="Path_50165" d="M2.319 6.749A1.861 1.861 0 1 1 .452 8.6a1.863 1.863 0 0 1 1.867-1.851z" class="cls-1" transform="translate(9.807 275.919)"/>
                    <path id="Path_50166" d="M2.572 6.154A1.867 1.867 0 1 1 .7 8.021a1.866 1.866 0 0 1 1.872-1.867z" class="cls-1" transform="translate(12.661 283.81)"/>
                    <path id="Path_50167" d="M2.854 5.566A1.885 1.885 0 1 1 .975 7.457a1.892 1.892 0 0 1 1.879-1.891z" class="cls-1" transform="translate(15.707 291.583)"/>
                    <path id="Path_50168" d="M3.178 4.986a1.91 1.91 0 0 1 0 3.82 1.91 1.91 0 1 1 0-3.82z" class="cls-1" transform="translate(18.945 299.237)"/>
                    <path id="Path_50169" d="M3.508 4.415a1.941 1.941 0 1 1-1.941 1.941 1.945 1.945 0 0 1 1.941-1.941z" class="cls-1" transform="translate(22.386 306.76)"/>
                    <path id="Path_50170" d="M3.843 3.854A1.965 1.965 0 1 1 1.89 5.819a1.963 1.963 0 0 1 1.953-1.965z" class="cls-1" transform="translate(26.03 314.162)"/>
                    <circle id="Ellipse_11084" cx="2.011" cy="2.011" r="2.011" class="cls-1" transform="translate(32.065 324.704)"/>
                    <path id="Path_50171" d="M4.6 2.764a2.014 2.014 0 1 1-2.014 2.014A2.013 2.013 0 0 1 4.6 2.764z" class="cls-1" transform="translate(33.882 328.54)"/>
                    <path id="Path_50172" d="M4.908 2.244a1.934 1.934 0 0 1 0 3.869 1.934 1.934 0 1 1 0-3.869z" class="cls-1" transform="translate(38.181 335.607)"/>
                    <path id="Path_50173" d="M5.231 1.735A1.867 1.867 0 1 1 3.364 3.6a1.856 1.856 0 0 1 1.867-1.865z" class="cls-1" transform="translate(42.66 342.502)"/>
                    <circle id="Ellipse_11085" cx="1.937" cy="1.937" r="1.937" class="cls-1" transform="translate(50.947 350.331)"/>
                    <path id="Path_50174" d="M6.218.73a2.033 2.033 0 1 1-2.039 2.026A2.029 2.029 0 0 1 6.218.73z" class="cls-1" transform="translate(51.854 355.519)"/>
                    <path id="Path_50175" d="M6.61.258a1.984 1.984 0 1 1-1.99 1.977A1.987 1.987 0 0 1 6.61.258z" class="cls-1" transform="translate(56.83 361.886)"/>
                    <path id="Path_50176" d="M6.643-.168a1.541 1.541 0 1 1-1.535 1.535A1.538 1.538 0 0 1 6.643-.168z" class="cls-1" transform="translate(62.335 368.428)"/>
                    <circle id="Ellipse_11086" cx=".147" cy=".147" r=".147" class="cls-1" transform="translate(74.557 375.157)"/>
                    <path id="Path_50177" d="M35.229-.34a.9.9 0 0 1 .884.884.888.888 0 0 1-.884.884.884.884 0 0 1 0-1.769z" class="cls-1" transform="translate(392.182 372.027)"/>
                    <path id="Path_50178" d="M36.827.013A2.137 2.137 0 1 1 34.7 2.15 2.139 2.139 0 0 1 36.827.013z" class="cls-1" transform="translate(396.209 364.833)"/>
                    <circle id="Ellipse_11087" cx="2.133" cy="2.133" r="2.133" class="cls-1" transform="translate(436.366 359.088)"/>
                    <circle id="Ellipse_11088" cx="2.035" cy="2.035" r="2.035" class="cls-1" transform="translate(441.741 353.258)"/>
                    <path id="Path_50179" d="M38.037 1.469A2.033 2.033 0 1 1 36 3.5a2.031 2.031 0 0 1 2.037-2.031z" class="cls-1" transform="translate(410.831 345.704)"/>
                    <path id="Path_50180" d="M38.3 1.989a1.891 1.891 0 1 1-1.891 1.891A1.892 1.892 0 0 1 38.3 1.989z" class="cls-1" transform="translate(415.467 339.08)"/>
                    <path id="Path_50181" d="M38.638 2.514A1.836 1.836 0 1 1 36.8 4.356a1.84 1.84 0 0 1 1.838-1.842z" class="cls-1" transform="translate(419.833 332.217)"/>
                    <path id="Path_50182" d="M38.8 3.064a1.615 1.615 0 1 1-1.621 1.621A1.62 1.62 0 0 1 38.8 3.064z" class="cls-1" transform="translate(424.177 325.354)"/>
                    <circle id="Ellipse_11089" cx="1.619" cy="1.619" r="1.619" class="cls-1" transform="translate(465.66 321.744)"/>
                    <path id="Path_50183" d="M39.621 4.149a1.762 1.762 0 1 1-1.769 1.769 1.761 1.761 0 0 1 1.769-1.769z" class="cls-1" transform="translate(431.747 310.649)"/>
                    <path id="Path_50184" d="M39.8 4.724a1.621 1.621 0 1 1-1.62 1.621 1.62 1.62 0 0 1 1.62-1.621z" class="cls-1" transform="translate(435.448 303.294)"/>
                    <path id="Path_50185" d="M40.043 5.3a1.566 1.566 0 1 1-1.56 1.572 1.567 1.567 0 0 1 1.56-1.572z" class="cls-1" transform="translate(438.866 295.728)"/>
                    <circle id="Ellipse_11090" cx="1.471" cy="1.471" r="1.471" class="cls-1" transform="translate(480.886 293.974)"/>
                    <circle id="Ellipse_11091" cx="1.422" cy="1.422" r="1.422" class="cls-1" transform="translate(484.157 286.769)"/>
                    <circle id="Ellipse_11092" cx="1.422" cy="1.422" r="1.422" class="cls-1" transform="translate(487.151 279.419)"/>
                    <circle id="Ellipse_11093" cx="1.422" cy="1.422" r="1.422" class="cls-1" transform="translate(489.917 271.98)"/>
                    <path id="Path_50186" d="M40.742 8.337a1.007 1.007 0 1 1-.995 1.007 1 1 0 0 1 .995-1.007z" class="cls-1" transform="translate(453.126 256.535)"/>
                    <path id="Path_50187" d="M40.512 8.993a.537.537 0 0 1 .54.54.545.545 0 0 1-.54.54.537.537 0 0 1-.54-.54.53.53 0 0 1 .54-.54z" class="cls-1" transform="translate(455.664 248.756)"/>
                    <path id="Path_50188" d="M40.342 9.648a.176.176 0 0 1 .172.172.174.174 0 0 1-.172.16.165.165 0 0 1-.172-.16.168.168 0 0 1 .172-.172z" class="cls-1" transform="translate(457.898 240.805)"/>
                    <circle id="Ellipse_11094" cx=".025" cy=".025" r=".025" class="cls-1" transform="translate(500.039 242.87)"/>
                    <circle id="Ellipse_11095" cx=".025" cy=".025" r=".025" class="cls-1" transform="translate(500.639 101.999)"/>
                    <path id="Path_50189" d="M40.321 22.355a.176.176 0 0 1 .172.172.168.168 0 0 1-.172.172.176.176 0 0 1-.172-.172.185.185 0 0 1 .172-.172z" class="cls-1" transform="translate(457.661 72.021)"/>
                    <circle id="Ellipse_11096" cx=".588" cy=".588" r=".588" class="cls-1" transform="translate(494.498 86.576)"/>
                    <path id="Path_50190" d="M40.553 23.487a.959.959 0 0 1 .958.958.958.958 0 0 1-1.916 0 .959.959 0 0 1 .958-.958z" class="cls-1" transform="translate(451.411 55.426)"/>
                    <path id="Path_50191" d="M40.35 24.067a1.032 1.032 0 1 1-1.032 1.033 1.027 1.027 0 0 1 1.032-1.033z" class="cls-1" transform="translate(448.286 47.563)"/>
                    <path id="Path_50192" d="M40 24.649a.983.983 0 1 1-.97.983.978.978 0 0 1 .97-.983z" class="cls-1" transform="translate(445.071 39.931)"/>
                    <path id="Path_50193" d="M39.686 25.22a.958.958 0 1 1-.958.958.959.959 0 0 1 .958-.958z" class="cls-1" transform="translate(441.63 32.396)"/>
                    <path id="Path_50194" d="M39.318 25.784a.9.9 0 1 1-.909.9.9.9 0 0 1 .909-.9z" class="cls-1" transform="translate(438.031 25.016)"/>
                    <path id="Path_50195" d="M38.888 26.341a.811.811 0 1 1 0 1.621.811.811 0 1 1 0-1.621z" class="cls-1" transform="translate(434.285 17.802)"/>
                    <path id="Path_50196" d="M38.4 26.893a.668.668 0 0 1 .663.663.66.66 0 0 1-.663.663.668.668 0 0 1-.663-.663.677.677 0 0 1 .663-.663z" class="cls-1" transform="translate(430.405 10.765)"/>
                    <path id="Path_50197" d="M37.821 27.439a.442.442 0 0 1 0 .884.442.442 0 0 1 0-.884z" class="cls-1" transform="translate(426.411 3.956)"/>
                    <path id="Path_50198" d="M37.344 27.964a.343.343 0 0 1 .344.344.351.351 0 0 1-.344.344.343.343 0 0 1-.344-.344.336.336 0 0 1 .344-.344z" class="cls-1" transform="translate(422.135 -2.821)"/>
                    <path id="Path_50199" d="M36.9 28.473a.288.288 0 0 1 .295.282.295.295 0 1 1-.589 0 .288.288 0 0 1 .294-.282z" class="cls-1" transform="translate(417.633 -9.483)"/>
                    <path id="Path_50200" d="M36.455 28.968a.265.265 0 0 1 .27.27.27.27 0 1 1-.54 0 .265.265 0 0 1 .27-.27z" class="cls-1" transform="translate(412.94 -16.008)"/>
                    <path id="Path_50201" d="M35.978 29.453a.221.221 0 0 1 0 .442.221.221 0 1 1 0-.442z" class="cls-1" transform="translate(408.112 -22.352)"/>
                    <circle id="Ellipse_11097" cx=".049" cy=".049" r=".049" class="cls-1" transform="translate(438.551 1.54)"/>
                    <circle id="Ellipse_11098" cx=".074" cy=".074" r=".074" class="cls-1" transform="translate(60.557 1.516)"/>
                    <path id="Path_50202" d="M4.378 29.447a.3.3 0 0 1 .295.295.291.291 0 0 1-.295.295.284.284 0 0 1-.295-.295.291.291 0 0 1 .295-.295z" class="cls-1" transform="translate(50.771 -22.419)"/>
                    <path id="Path_50203" d="M3.99 28.962a.336.336 0 0 1 .344.344.343.343 0 0 1-.344.344.351.351 0 0 1-.344-.344.343.343 0 0 1 .344-.344z" class="cls-1" transform="translate(45.841 -16.076)"/>
                    <path id="Path_50204" d="M3.662 28.462a.436.436 0 1 1 0 .872.436.436 0 1 1 0-.872z" class="cls-1" transform="translate(41.035 -9.619)"/>
                    <path id="Path_50205" d="M3.338 27.948a.541.541 0 1 1-.528.54.537.537 0 0 1 .528-.54z" class="cls-1" transform="translate(36.41 -3.001)"/>
                    <circle id="Ellipse_11099" cx=".613" cy=".613" r=".613" class="cls-1" transform="translate(34.38 31.223)"/>
                    <circle id="Ellipse_11100" cx=".687" cy=".687" r=".687" class="cls-1" transform="translate(29.738 37.639)"/>
                    <circle id="Ellipse_11101" cx=".785" cy=".785" r=".785" class="cls-1" transform="translate(25.267 44.165)"/>
                    <path id="Path_50206" d="M2.165 25.79a.835.835 0 1 1-.835.835.836.836 0 0 1 .835-.835z" class="cls-1" transform="translate(19.712 25.071)"/>
                    <path id="Path_50207" d="M1.887 25.226A.884.884 0 1 1 1 26.11a.881.881 0 0 1 .887-.884z" class="cls-1" transform="translate(16.023 32.464)"/>
                    <path id="Path_50208" d="M1.626 24.653a.933.933 0 1 1-.933.933.933.933 0 0 1 .933-.933z" class="cls-1" transform="translate(12.526 39.976)"/>
                    <path id="Path_50209" d="M1.405 24.069A1.007 1.007 0 1 1 .4 25.076a1.012 1.012 0 0 1 1.005-1.007z" class="cls-1" transform="translate(9.198 47.586)"/>
                    <path id="Path_50210" d="M1.133 23.483A1 1 0 1 1 .126 24.49a1 1 0 0 1 1.007-1.007z" class="cls-1" transform="translate(6.129 55.381)"/>
                    <circle id="Ellipse_11102" cx=".588" cy=".588" r=".588" class="cls-1" transform="translate(3.556 86.576)"/>
                    <path id="Path_50211" d="M-.124 22.355a.176.176 0 0 1 .172.172.168.168 0 0 1-.172.172.168.168 0 0 1-.176-.172.176.176 0 0 1 .176-.172z" class="cls-1" transform="translate(1.368 72.021)"/>
                    <path id="Path_50212" d="M-.056 7.169a.246.246 0 0 1 .246.246.246.246 0 0 1-.246.246.246.246 0 0 1-.244-.246.246.246 0 0 1 .244-.246z" class="cls-1" transform="translate(1.301 273.571)"/>
                    <path id="Path_50213" d="M.857 6.508a.983.983 0 1 1-.983.983.985.985 0 0 1 .983-.983z" class="cls-1" transform="translate(3.286 280.877)"/>
                    <path id="Path_50214" d="M1.787 5.854A1.713 1.713 0 1 1 .068 7.573a1.717 1.717 0 0 1 1.719-1.719z" class="cls-1" transform="translate(5.475 288.101)"/>
                    <path id="Path_50215" d="M2.217 5.253A1.891 1.891 0 1 1 .326 7.144a1.882 1.882 0 0 1 1.891-1.891z" class="cls-1" transform="translate(8.385 295.728)"/>
                    <circle id="Ellipse_11103" cx="1.912" cy="1.912" r="1.912" class="cls-1" transform="translate(12.238 308.057)"/>
                    <path id="Path_50216" d="M2.835 4.1A1.916 1.916 0 1 1 .919 6.02 1.918 1.918 0 0 1 2.835 4.1z" class="cls-1" transform="translate(15.076 310.939)"/>
                    <path id="Path_50217" d="M3.181 3.543A1.934 1.934 0 1 1 1.24 5.484a1.945 1.945 0 0 1 1.941-1.941z" class="cls-1" transform="translate(18.697 318.354)"/>
                    <circle id="Ellipse_11104" cx="1.961" cy="1.961" r="1.961" class="cls-1" transform="translate(24.091 328.623)"/>
                    <path id="Path_50218" d="M3.944 2.447A2.014 2.014 0 1 1 1.93 4.461a2.015 2.015 0 0 1 2.014-2.014z" class="cls-1" transform="translate(26.482 332.751)"/>
                    <circle id="Ellipse_11105" cx="2.035" cy="2.035" r="2.035" class="cls-1" transform="translate(32.958 341.664)"/>
                    <circle id="Ellipse_11106" cx="1.961" cy="1.961" r="1.961" class="cls-1" transform="translate(37.792 348.089)"/>
                    <path id="Path_50219" d="M5.027.9A1.934 1.934 0 1 1 3.1 2.844 1.929 1.929 0 0 1 5.027.9z" class="cls-1" transform="translate(39.67 353.418)"/>
                    <circle id="Ellipse_11107" cx="2.011" cy="2.011" r="2.011" class="cls-1" transform="translate(47.824 360.299)"/>
                    <path id="Path_50220" d="M5.89-.071A1.941 1.941 0 1 1 3.949 1.87 1.934 1.934 0 0 1 5.89-.071z" class="cls-1" transform="translate(49.26 366.342)"/>
                    <path id="Path_50221" d="M5-.42a.493.493 0 0 1 .5.491.491.491 0 1 1-.983 0A.493.493 0 0 1 5-.42z" class="cls-1" transform="translate(55.622 373.876)"/>
                    <circle id="Ellipse_11108" cx=".588" cy=".588" r=".588" class="cls-1" transform="translate(438.011 373.357)"/>
                    <circle id="Ellipse_11109" cx="2.06" cy="2.06" r="2.06" class="cls-1" transform="translate(442.025 366.149)"/>
                    <circle id="Ellipse_11110" cx="2.035" cy="2.035" r="2.035" class="cls-1" transform="translate(447.36 360.275)"/>
                    <path id="Path_50222" d="M38.5.9a2.033 2.033 0 1 1-2.039 2.039A2.042 2.042 0 0 1 38.5.9z" class="cls-1" transform="translate(416.031 353.327)"/>
                    <path id="Path_50223" d="M38.72 1.416a1.836 1.836 0 1 1-1.842 1.83 1.835 1.835 0 0 1 1.842-1.83z" class="cls-1" transform="translate(420.759 346.801)"/>
                    <path id="Path_50224" d="M39.164 1.927a1.91 1.91 0 1 1-1.9 1.9 1.908 1.908 0 0 1 1.9-1.9z" class="cls-1" transform="translate(425.068 339.866)"/>
                    <path id="Path_50225" d="M39.378 2.469a1.744 1.744 0 1 1-1.732 1.744 1.743 1.743 0 0 1 1.732-1.744z" class="cls-1" transform="translate(429.423 332.999)"/>
                    <path id="Path_50226" d="M39.621 3.019a1.615 1.615 0 1 1-1.609 1.609 1.617 1.617 0 0 1 1.609-1.609z" class="cls-1" transform="translate(433.552 325.952)"/>
                    <path id="Path_50227" d="M40.04 3.563a1.689 1.689 0 1 1-1.695 1.695 1.7 1.7 0 0 1 1.695-1.695z" class="cls-1" transform="translate(437.309 318.579)"/>
                    <path id="Path_50228" d="M40.3 4.128a1.621 1.621 0 1 1-1.621 1.621A1.62 1.62 0 0 1 40.3 4.128z" class="cls-1" transform="translate(441.021 311.21)"/>
                    <circle id="Ellipse_11111" cx="1.619" cy="1.619" r="1.619" class="cls-1" transform="translate(483.461 308.351)"/>
                    <path id="Path_50229" d="M40.891 5.275A1.621 1.621 0 1 1 39.27 6.9a1.617 1.617 0 0 1 1.621-1.625z" class="cls-1" transform="translate(447.745 295.976)"/>
                    <path id="Path_50230" d="M40.891 5.886a1.32 1.32 0 1 1-1.326 1.326 1.321 1.321 0 0 1 1.326-1.326z" class="cls-1" transform="translate(451.073 288.463)"/>
                    <circle id="Ellipse_11112" cx=".785" cy=".785" r=".785" class="cls-1" transform="translate(494.301 287.586)"/>
                    <path id="Path_50231" d="M40.389 7.169a.246.246 0 1 1-.246.246.246.246 0 0 1 .246-.246z" class="cls-1" transform="translate(457.594 273.571)"/>
                    <circle id="Ellipse_11113" cx=".025" cy=".025" r=".025" class="cls-1" transform="translate(500.639 273.487)"/>
                    <path id="Path_50232" d="M40.323 24.159a.147.147 0 1 1 0 .295.147.147 0 1 1 0-.295z" class="cls-1" transform="translate(457.966 48.11)"/>
                    <path id="Path_50233" d="M40.45 24.7a.59.59 0 0 1 .59.59.6.6 0 0 1-.59.59.59.59 0 0 1-.59-.59.582.582 0 0 1 .59-.59z" class="cls-1" transform="translate(454.401 39.973)"/>
                    <path id="Path_50234" d="M40.468 25.251a.933.933 0 1 1-.933.933.933.933 0 0 1 .933-.933z" class="cls-1" transform="translate(450.734 32.034)"/>
                    <circle id="Ellipse_11114" cx=".908" cy=".908" r=".908" class="cls-1" transform="translate(486.441 50.368)"/>
                    <path id="Path_50235" d="M39.734 26.38a.835.835 0 1 1-.835.835.836.836 0 0 1 .835-.835z" class="cls-1" transform="translate(443.559 17.235)"/>
                    <circle id="Ellipse_11115" cx=".711" cy=".711" r=".711" class="cls-1" transform="translate(478.34 37.033)"/>
                    <path id="Path_50236" d="M38.779 27.484a.571.571 0 0 1 .565.565.565.565 0 1 1-1.13 0 .571.571 0 0 1 .565-.565z" class="cls-1" transform="translate(435.831 3.112)"/>
                    <path id="Path_50237" d="M38.267 28.021a.422.422 0 0 1 .418.418.418.418 0 0 1-.835 0 .422.422 0 0 1 .417-.418z" class="cls-1" transform="translate(431.713 -3.725)"/>
                    <path id="Path_50238" d="M37.784 28.543a.317.317 0 0 1 .319.319.31.31 0 0 1-.319.319.317.317 0 0 1-.319-.319.325.325 0 0 1 .319-.319z" class="cls-1" transform="translate(427.381 -10.462)"/>
                    <path id="Path_50239" d="M37.333 29.049a.27.27 0 1 1-.27.27.273.273 0 0 1 .27-.27z" class="cls-1" transform="translate(422.846 -17.084)"/>
                    <path id="Path_50240" d="M36.867 29.543a.221.221 0 1 1-.221.221.22.22 0 0 1 .221-.221z" class="cls-1" transform="translate(418.141 -23.547)"/>
                    <circle id="Ellipse_11116" cx=".025" cy=".025" r=".025" class="cls-1" transform="translate(449.64 .319)"/>
                    <circle id="Ellipse_11117" cx=".123" cy=".123" r=".123" class="cls-1" transform="translate(46.751 3.137)"/>
                    <path id="Path_50241" d="M3.276 29.294a.3.3 0 0 1 .295.295.295.295 0 0 1-.59 0 .3.3 0 0 1 .295-.295z" class="cls-1" transform="translate(38.339 -20.387)"/>
                    <path id="Path_50242" d="M2.975 28.787a.418.418 0 0 1 0 .835.418.418 0 1 1 0-.835z" class="cls-1" transform="translate(33.555 -13.899)"/>
                    <path id="Path_50243" d="M2.643 28.273a.491.491 0 1 1-.491.491.493.493 0 0 1 .491-.491z" class="cls-1" transform="translate(28.986 -7.22)"/>
                    <path id="Path_50244" d="M2.327 27.748a.559.559 0 1 1 0 1.118.559.559 0 1 1 0-1.118z" class="cls-1" transform="translate(24.586 -.382)"/>
                    <path id="Path_50245" d="M2.013 27.211a.639.639 0 1 1-.626.639.634.634 0 0 1 .626-.639z" class="cls-1" transform="translate(20.356 6.591)"/>
                    <circle id="Ellipse_11118" cx=".736" cy=".736" r=".736" class="cls-1" transform="translate(17.296 40.347)"/>
                    <path id="Path_50246" d="M1.469 26.107a.784.784 0 0 1 .786.786.786.786 0 0 1-1.572 0 .784.784 0 0 1 .786-.786z" class="cls-1" transform="translate(12.413 20.959)"/>
                    <path id="Path_50247" d="M1.215 25.541a.86.86 0 1 1-.86.86.854.854 0 0 1 .86-.86z" class="cls-1" transform="translate(8.713 28.33)"/>
                    <circle id="Ellipse_11119" cx=".736" cy=".736" r=".736" class="cls-1" transform="translate(5.443 60.99)"/>
                    <path id="Path_50248" d="M.147 24.435a.336.336 0 0 1 .344.344.343.343 0 0 1-.344.344.351.351 0 0 1-.347-.344.343.343 0 0 1 .347-.344z" class="cls-1" transform="translate(2.485 44.051)"/>
                    <circle id="Ellipse_11120" cx=".637" cy=".637" r=".637" class="cls-1" transform="translate(1.995 306.07)"/>
                    <path id="Path_50249" d="M1.519 4.393A1.517 1.517 0 1 1 0 5.916a1.523 1.523 0 0 1 1.519-1.523z" class="cls-1" transform="translate(4.662 307.899)"/>
                    <path id="Path_50250" d="M2.185 3.791A1.916 1.916 0 1 1 .269 5.707a1.918 1.918 0 0 1 1.916-1.916z" class="cls-1" transform="translate(7.742 315.097)"/>
                    <path id="Path_50251" d="M2.507 3.231a1.91 1.91 0 1 1-1.916 1.9 1.908 1.908 0 0 1 1.916-1.9z" class="cls-1" transform="translate(11.375 322.547)"/>
                    <path id="Path_50252" d="M2.868 2.678A1.934 1.934 0 1 1 .927 4.606a1.934 1.934 0 0 1 1.941-1.928z" class="cls-1" transform="translate(15.166 329.842)"/>
                    <path id="Path_50253" d="M3.232 2.135a1.959 1.959 0 1 1-1.953 1.953 1.953 1.953 0 0 1 1.953-1.953z" class="cls-1" transform="translate(19.137 337.005)"/>
                    <path id="Path_50254" d="M3.636 1.6a1.984 1.984 0 1 1-1.99 1.99 1.979 1.979 0 0 1 1.99-1.99z" class="cls-1" transform="translate(23.277 344.022)"/>
                    <path id="Path_50255" d="M4.042 1.081A2.014 2.014 0 1 1 2.028 3.1a2.023 2.023 0 0 1 2.014-2.019z" class="cls-1" transform="translate(27.587 350.894)"/>
                    <path id="Path_50256" d="M4.453.571A2.033 2.033 0 1 1 2.426 2.6 2.031 2.031 0 0 1 4.453.571z" class="cls-1" transform="translate(32.077 357.631)"/>
                    <circle id="Ellipse_11121" cx="2.035" cy="2.035" r="2.035" class="cls-1" transform="translate(39.582 364.293)"/>
                    <path id="Path_50257" d="M4.245-.316a.881.881 0 0 1 .885.884.884.884 0 1 1-1.769 0 .881.881 0 0 1 .884-.884z" class="cls-1" transform="translate(42.626 371.708)"/>
                    <circle id="Ellipse_11122" cx=".172" cy=".172" r=".172" class="cls-1" transform="translate(449.492 375.019)"/>
                    <path id="Path_50258" d="M38.243-.143a1.713 1.713 0 1 1-1.719 1.707 1.714 1.714 0 0 1 1.719-1.707z" class="cls-1" transform="translate(416.765 367.753)"/>
                    <path id="Path_50259" d="M38.755.339a1.818 1.818 0 1 1-1.818 1.818A1.821 1.821 0 0 1 38.755.339z" class="cls-1" transform="translate(421.424 361.142)"/>
                    <path id="Path_50260" d="M39.127.844a1.787 1.787 0 1 1-1.781 1.793A1.787 1.787 0 0 1 39.127.844z" class="cls-1" transform="translate(426.038 354.496)"/>
                    <path id="Path_50261" d="M39.53 1.357a1.793 1.793 0 1 1-1.793 1.793 1.787 1.787 0 0 1 1.793-1.793z" class="cls-1" transform="translate(430.45 347.67)"/>
                    <path id="Path_50262" d="M39.885 1.884a1.769 1.769 0 1 1-1.769 1.769 1.769 1.769 0 0 1 1.769-1.769z" class="cls-1" transform="translate(434.725 340.72)"/>
                    <path id="Path_50263" d="M40.156 2.428a1.67 1.67 0 1 1-1.67 1.67 1.669 1.669 0 0 1 1.67-1.67z" class="cls-1" transform="translate(438.9 333.691)"/>
                    <path id="Path_50264" d="M40.467 2.976a1.646 1.646 0 1 1-1.633 1.646 1.646 1.646 0 0 1 1.633-1.646z" class="cls-1" transform="translate(442.826 326.462)"/>
                    <path id="Path_50265" d="M40.786 3.534a1.615 1.615 0 1 1-1.621 1.609 1.617 1.617 0 0 1 1.621-1.609z" class="cls-1" transform="translate(446.56 319.112)"/>
                    <circle id="Ellipse_11123" cx="1.471" cy="1.471" r="1.471" class="cls-1" transform="translate(489.729 315.848)"/>
                    <path id="Path_50266" d="M40.788 4.727a.949.949 0 0 1 .958.946.958.958 0 0 1-1.916 0 .949.949 0 0 1 .958-.946z" class="cls-1" transform="translate(454.063 304.593)"/>
                    <path id="Path_50267" d="M40.369 5.371a.2.2 0 1 1-.2.2.194.194 0 0 1 .2-.2z" class="cls-1" transform="translate(457.921 297.55)"/>
                    <path id="Path_50268" d="M40.332 25.9a.246.246 0 1 1-.246.246.246.246 0 0 1 .246-.246z" class="cls-1" transform="translate(456.951 24.736)"/>
                    <path id="Path_50269" d="M40.417 26.429a.688.688 0 1 1-.688.688.687.687 0 0 1 .688-.688z" class="cls-1" transform="translate(452.923 16.879)"/>
                    <circle id="Ellipse_11124" cx=".858" cy=".858" r=".858" class="cls-1" transform="translate(488.357 36.358)"/>
                    <circle id="Ellipse_11125" cx=".711" cy=".711" r=".711" class="cls-1" transform="translate(484.187 29.845)"/>
                    <path id="Path_50270" d="M39.2 28.07a.51.51 0 1 1-.516.516.511.511 0 0 1 .516-.516z" class="cls-1" transform="translate(441.19 -4.56)"/>
                    <path id="Path_50271" d="M38.688 28.6a.37.37 0 0 1 .368.368.378.378 0 0 1-.368.368.37.37 0 0 1-.368-.368.362.362 0 0 1 .368-.368z" class="cls-1" transform="translate(437.027 -11.357)"/>
                    <path id="Path_50272" d="M38.225 29.12a.295.295 0 1 1-.295.295.3.3 0 0 1 .295-.295z" class="cls-1" transform="translate(432.627 -18.076)"/>
                    <path id="Path_50273" d="M37.724 29.628a.2.2 0 0 1 .2.2.2.2 0 0 1-.393 0 .2.2 0 0 1 .193-.2z" class="cls-1" transform="translate(428.092 -24.627)"/>
                    <path id="Path_50274" d="M2.518 29.628a.2.2 0 0 1 .2.2.2.2 0 0 1-.393 0 .2.2 0 0 1 .193-.2z" class="cls-1" transform="translate(30.893 -24.627)"/>
                    <path id="Path_50275" d="M2.243 29.116a.336.336 0 0 1 .344.344.343.343 0 0 1-.344.344.351.351 0 0 1-.343-.344.343.343 0 0 1 .343-.344z" class="cls-1" transform="translate(26.132 -18.121)"/>
                    <path id="Path_50276" d="M1.937 28.6a.44.44 0 0 1 .442.442.448.448 0 0 1-.442.442.457.457 0 0 1-.442-.442.448.448 0 0 1 .442-.442z" class="cls-1" transform="translate(21.574 -11.425)"/>
                    <path id="Path_50277" d="M1.624 28.07a.51.51 0 1 1-.516.516.511.511 0 0 1 .516-.516z" class="cls-1" transform="translate(17.208 -4.56)"/>
                    <circle id="Ellipse_11126" cx=".588" cy=".588" r=".588" class="cls-1" transform="translate(13.743 29.968)"/>
                    <circle id="Ellipse_11127" cx=".687" cy=".687" r=".687" class="cls-1" transform="translate(9.328 36.53)"/>
                    <circle id="Ellipse_11128" cx=".588" cy=".588" r=".588" class="cls-1" transform="translate(5.298 43.408)"/>
                    <path id="Path_50278" d="M-.021 25.906a.228.228 0 0 1 .221.221.228.228 0 0 1-.221.221.22.22 0 0 1-.221-.221.22.22 0 0 1 .221-.221z" class="cls-1" transform="translate(1.977 24.759)"/>
                    <path id="Path_50279" d="M.227 3.594a.491.491 0 0 1 0 .983.491.491 0 1 1 0-.983z" class="cls-1" transform="translate(1.729 320.562)"/>
                    <circle id="Ellipse_11129" cx="1.447" cy="1.447" r="1.447" class="cls-1" transform="translate(4.44 330.092)"/>
                    <path id="Path_50280" d="M2.215 2.363A1.941 1.941 0 1 1 .274 4.3a1.945 1.945 0 0 1 1.941-1.937z" class="cls-1" transform="translate(7.799 334.014)"/>
                    <circle id="Ellipse_11130" cx="1.961" cy="1.961" r="1.961" class="cls-1" transform="translate(12.37 343.018)"/>
                    <path id="Path_50281" d="M2.955 1.287A1.959 1.959 0 1 1 .99 3.252a1.963 1.963 0 0 1 1.965-1.965z" class="cls-1" transform="translate(15.877 348.268)"/>
                    <path id="Path_50282" d="M3.347.763A1.984 1.984 0 1 1 1.37 2.74 1.979 1.979 0 0 1 3.347.763z" class="cls-1" transform="translate(20.164 355.179)"/>
                    <path id="Path_50283" d="M3.755.252a1.984 1.984 0 1 1-1.99 1.977A1.979 1.979 0 0 1 3.755.252z" class="cls-1" transform="translate(24.62 361.966)"/>
                    <path id="Path_50284" d="M3.691-.206a1.474 1.474 0 1 1-1.474 1.474A1.478 1.478 0 0 1 3.691-.206z" class="cls-1" transform="translate(29.719 369.068)"/>
                    <circle id="Ellipse_11131" cx="1.349" cy="1.349" r="1.349" class="cls-1" transform="translate(464.469 368.985)"/>
                    <path id="Path_50285" d="M39.579.27a1.762 1.762 0 1 1-1.769 1.756A1.766 1.766 0 0 1 39.579.27z" class="cls-1" transform="translate(431.273 362.169)"/>
                    <path id="Path_50286" d="M40 .779a1.787 1.787 0 1 1-1.8 1.781A1.793 1.793 0 0 1 40 .779z" class="cls-1" transform="translate(435.718 355.359)"/>
                    <path id="Path_50287" d="M40.31 1.307a1.713 1.713 0 1 1-1.719 1.719 1.717 1.717 0 0 1 1.719-1.719z" class="cls-1" transform="translate(440.084 348.494)"/>
                    <circle id="Ellipse_11132" cx="1.619" cy="1.619" r="1.619" class="cls-1" transform="translate(483.28 343.36)"/>
                    <path id="Path_50288" d="M40.938 2.389a1.621 1.621 0 1 1-1.621 1.621 1.62 1.62 0 0 1 1.621-1.621z" class="cls-1" transform="translate(448.275 334.307)"/>
                    <circle id="Ellipse_11133" cx="1.25" cy="1.25" r="1.25" class="cls-1" transform="translate(492.093 330.289)"/>
                    <path id="Path_50289" d="M40.467 3.6a.393.393 0 0 1 0 .786.393.393 0 1 1 0-.786z" class="cls-1" transform="translate(456.815 320.653)"/>
                    <circle id="Ellipse_11134" cx=".049" cy=".049" r=".049" class="cls-1" transform="translate(499.257 36.686)"/>
                    <path id="Path_50290" d="M40.313 27.591a.422.422 0 0 1 .418.418.418.418 0 0 1-.835 0 .422.422 0 0 1 .417-.418z" class="cls-1" transform="translate(454.796 1.986)"/>
                    <path id="Path_50291" d="M40.114 28.115a.59.59 0 0 1 .59.59.59.59 0 0 1-1.179 0 .59.59 0 0 1 .589-.59z" class="cls-1" transform="translate(450.61 -5.318)"/>
                    <circle id="Ellipse_11135" cx=".49" cy=".49" r=".49" class="cls-1" transform="translate(485.675 16.395)"/>
                    <path id="Path_50292" d="M39.131 29.183a.344.344 0 0 1 0 .688.344.344 0 0 1 0-.688z" class="cls-1" transform="translate(442.296 -19.011)"/>
                    <path id="Path_50293" d="M38.574 29.7a.172.172 0 0 1 0 .344.172.172 0 1 1 0-.344z" class="cls-1" transform="translate(437.952 -25.6)"/>
                    <circle id="Ellipse_11136" cx=".049" cy=".049" r=".049" class="cls-1" transform="translate(25.174 1.158)"/>
                    <path id="Path_50294" d="M1.557 29.44a.317.317 0 0 1 .319.319.319.319 0 1 1-.639 0 .317.317 0 0 1 .32-.319z" class="cls-1" transform="translate(18.675 -22.376)"/>
                    <path id="Path_50295" d="M1.232 28.921a.393.393 0 0 1 0 .786.393.393 0 0 1 0-.786z" class="cls-1" transform="translate(14.173 -15.63)"/>
                    <path id="Path_50296" d="M.944 28.389a.491.491 0 1 1-.491.491.493.493 0 0 1 .491-.491z" class="cls-1" transform="translate(9.818 -8.76)"/>
                    <path id="Path_50297" d="M.558 27.857a.467.467 0 1 1-.467.467.466.466 0 0 1 .467-.467z" class="cls-1" transform="translate(5.734 -1.645)"/>
                    <path id="Path_50298" d="M-.062 27.338a.174.174 0 0 1 .172.16.176.176 0 0 1-.172.172.168.168 0 0 1-.172-.17.165.165 0 0 1 .172-.162z" class="cls-1" transform="translate(2.068 5.85)"/>
                    <path id="Path_50299" d="M.254 2.164a.516.516 0 1 1 0 1.032.516.516 0 1 1 0-1.032z" class="cls-1" transform="translate(1.752 339.506)"/>
                    <circle id="Ellipse_11137" cx="1.545" cy="1.545" r="1.545" class="cls-1" transform="translate(4.747 347.314)"/>
                    <path id="Path_50300" d="M2.276.971A1.934 1.934 0 1 1 .335 2.9 1.934 1.934 0 0 1 2.276.971z" class="cls-1" transform="translate(8.487 352.514)"/>
                    <circle id="Ellipse_11138" cx="1.961" cy="1.961" r="1.961" class="cls-1" transform="translate(13.45 359.889)"/>
                    <path id="Path_50301" d="M3.024-.064a1.91 1.91 0 1 1-1.916 1.916A1.918 1.918 0 0 1 3.024-.064z" class="cls-1" transform="translate(17.208 366.31)"/>
                    <path id="Path_50302" d="M1.986-.439A.343.343 0 0 1 2.33-.1a.343.343 0 0 1-.344.344.351.351 0 0 1-.344-.344.351.351 0 0 1 .344-.339z" class="cls-1" transform="translate(23.232 374.423)"/>
                    <path id="Path_50303" d="M39.386-.247a1.056 1.056 0 0 1 0 2.112 1.056 1.056 0 0 1 0-2.112z" class="cls-1" transform="translate(437.14 370.448)"/>
                    <path id="Path_50304" d="M40.349.211a1.67 1.67 0 1 1-1.67 1.67 1.672 1.672 0 0 1 1.67-1.67z" class="cls-1" transform="translate(441.077 363.137)"/>
                    <path id="Path_50305" d="M40.78.726a1.713 1.713 0 1 1-1.719 1.719A1.717 1.717 0 0 1 40.78.726z" class="cls-1" transform="translate(445.387 356.211)"/>
                    <path id="Path_50306" d="M41.106 1.259a1.664 1.664 0 1 1-1.67 1.67 1.672 1.672 0 0 1 1.67-1.67z" class="cls-1" transform="translate(449.617 349.23)"/>
                    <path id="Path_50307" d="M40.809 1.855a.958.958 0 1 1-.958.958.959.959 0 0 1 .958-.958z" class="cls-1" transform="translate(454.299 342.726)"/>
                    <circle id="Ellipse_11139" cx=".098" cy=".098" r=".098" class="cls-1" transform="translate(499.208 338.702)"/>
                    <path id="Path_50308" d="M40.2 28.732a.165.165 0 0 1 .172.16.172.172 0 1 1-.344 0 .165.165 0 0 1 .172-.16z" class="cls-1" transform="translate(456.33 -12.677)"/>
                    <path id="Path_50309" d="M40.007 29.242a.362.362 0 0 1 .368.368.369.369 0 0 1-.368.368.378.378 0 0 1-.368-.368.369.369 0 0 1 .368-.368z" class="cls-1" transform="translate(451.908 -19.844)"/>
                    <path id="Path_50310" d="M39.438 29.774a.172.172 0 1 1 0 .344.172.172 0 0 1 0-.344z" class="cls-1" transform="translate(447.699 -26.517)"/>
                    <path id="Path_50311" d="M.737 29.776a.147.147 0 1 1 0 .295.147.147 0 1 1 0-.295z" class="cls-1" transform="translate(11.364 -26.494)"/>
                    <path id="Path_50312" d="M.505 29.246a.317.317 0 0 1 .319.319.325.325 0 0 1-.319.319.325.325 0 0 1-.319-.319.317.317 0 0 1 .319-.319z" class="cls-1" transform="translate(6.806 -19.799)"/>
                    <path id="Path_50313" d="M-.005 28.732a.163.163 0 0 1 .16.16.177.177 0 0 1-.16.184.178.178 0 0 1-.172-.184.165.165 0 0 1 .172-.16z" class="cls-1" transform="translate(2.711 -12.677)"/>
                    <path id="Path_50314" d="M.446.757a.658.658 0 0 1 .654.663.666.666 0 0 1-.651.663.668.668 0 0 1-.666-.663.66.66 0 0 1 .663-.663z" class="cls-1" transform="translate(2.259 357.899)"/>
                    <path id="Path_50315" d="M1.859.14A1.787 1.787 0 1 1 .066 1.921 1.785 1.785 0 0 1 1.859.14z" class="cls-1" transform="translate(5.452 363.846)"/>
                    <circle id="Ellipse_11140" cx=".932" cy=".932" r=".932" class="cls-1" transform="translate(11.164 371.174)"/>
                    <circle id="Ellipse_11141" cx=".785" cy=".785" r=".785" class="cls-1" transform="translate(486.349 371.321)"/>
                    <path id="Path_50316" d="M41.068.162a1.517 1.517 0 1 1-1.523 1.511A1.52 1.52 0 0 1 41.068.162z" class="cls-1" transform="translate(450.847 364.095)"/>
                    <path id="Path_50317" d="M40.564.765a.563.563 0 0 1 .565.565.571.571 0 0 1-.565.565A.563.563 0 0 1 40 1.33a.556.556 0 0 1 .564-.565z" class="cls-1" transform="translate(455.969 357.989)"/>
                    <circle id="Ellipse_11142" cx=".025" cy=".025" r=".025" class="cls-1" transform="translate(497.63 2.627)"/>
                    <path id="Path_50318" d="M-.037-.553l.023.025-.023.028-.025-.029z" class="cls-1" transform="translate(4.008 376.577)"/>
                    <circle id="Ellipse_11143" cx=".123" cy=".123" r=".123" class="cls-1" transform="translate(497.532 372.761)"/>
                </g>
            </g>
        </g>
    </g>
</svg>

''');
  }
}