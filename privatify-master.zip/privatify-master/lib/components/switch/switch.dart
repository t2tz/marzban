import 'dart:developer';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:privatify/components/switch/spots.dart';
import 'package:privatify/store/vpn.dart';

class PSwitch extends StatefulWidget {
  const PSwitch(
      {super.key, this.status = Status.notConnected, required this.onConnect});

  final Status status;
  final void Function(bool) onConnect;

  @override
  State<PSwitch> createState() => _PSwitchState();
}

class _PSwitchState extends State<PSwitch> with SingleTickerProviderStateMixin {
  var dy = 10.0;
  var start = 0.0;

  final VPN vpn = Get.find<VPN>();

  // green #0eff2d
  // red #ff5c5c

  // yellow #ffc500

  var color1 = "#ffffff";
  var color2 = "#000000";
  var color3 = "#000000";

  var dynamicColor = "#000000";

  changeColor(double second) {
    setState(() {
      if (second > 0) {
        color1 = dynamicColor;
      } else {
        color1 = "#000000";
      }
      if (second > 1) {
        color2 = dynamicColor;
      } else {
        color2 = "#000000";
      }

      if (second > 2) {
        color3 = dynamicColor;
      } else {
        color3 = "#000000";
      }
    });
  }

  late AnimationController _controller;

  @override
  void initState() {
    vpn.status.value == Status.connected ? Connect() : Disconnect();

    _controller = AnimationController(
        vsync: this, // the SingleTickerProviderStateMixin
        duration: const Duration(seconds: 3),
        upperBound: 3.0,
        lowerBound: 0.0)
      ..addListener(() {
        setState(() {
          changeColor(_controller.value);
        });
      });

    vpn.status.listen((value) {
      // _controller.dispose();

      // disconnect
      if (value == Status.notConnected) {
        color1 = "#ffffff";
        color2 = "#000000";
        color3 = "#000000";
        Disconnect();
      }

      // disconnecting
      if (value == Status.disconnecting) {
        _controller.repeat();

        setState(() {
          dynamicColor = "#ff5c5c";
        });
        //Disconnect();
      }

      // connecting
      if (value == Status.connecting) {
        setState(() {
          dynamicColor = "#ffc500";
        });

        _controller.repeat();

        Connect();
      }

      // conneted
      if (value == Status.connected) {
        setState(() {
          dynamicColor = "#0eff2d";
        });

        _controller.forward();

        Connect();
      }
    });
    super.initState();
  }

  @override
  void dispose() {
    _controller.dispose();
    //  vpn.status.close();
    //  super.dispose();
  }

  var isOn = false;

  void setPosition(double y) {
    // print(y);

    var position = isOn ? ((y + start) - 95) : (y - start);
    //print(position);
    //  print(start);

    if (position > 10 && position < 95) {
      setState(() {
        dy = position;
      });
    }
  }

  void Connect() {
    setState(() {
      dy = 95;
      isOn = true;
    });
  }

  void Disconnect() {
    setState(() {
      dy = 10;
      isOn = false;
    });
  }

  void onPositionEnd() {
    setState(() {
      if (dy > 50) {
        dy = 95;
        isOn = true;
        //  _controller.repeat();
        _controller.repeat();
      } else {
        isOn = false;
        dy = 10;
      }

      widget.onConnect(isOn);
    });
  }

  getLight(status) {
    Widget light;

    switch (status) {
      case Status.connected:
        light = Positioned(
          left: 37,
          top: 21,
          child: Image.asset(
            'assets/light_green_off.png',
          ),
        );
        break;
      case Status.connecting:
        light = Positioned(
          left: 16,
          child: Image.asset(
            'assets/light_yellow.png',
          ),
        );
        break;
      case Status.disconnecting:
        light = Positioned(
          left: 16,
          child: Image.asset(
            'assets/light_red.png',
          ),
        );
        break;
      default:
        light = Positioned(
          left: 16,
          child: Image.asset(
            'assets/light_green.png',
          ),
        );
    }

    return light;
  }

  @override
  Widget build(BuildContext context) {
    // _controller.addListener(() {
    //   print(_controller.value);
    // });
    return Container(
      width: double.maxFinite,
      child: Stack(alignment: Alignment.topCenter, children: [
        Positioned(
          bottom: -40,
          child: Spots(
            color1: color1,
            color2: color2,
            color3: color3,
          ),
        ),
        // Positioned(child: SvgPicture.asset("assets/white.svg"), bottom:0,),
        Positioned(
          child: GestureDetector(
            child: widget.status == Status.connected
                ? Image.asset(
                    "assets/switch_outer_green.png",
                    height: 255,
                  )
                : Image.asset(
                    "assets/switch_outer_gray.png",
                    height: 255,
                  ),
          ),
        ),

        isOn != true
            ? Positioned(
                top: 200,
                child: Image.asset(
                  "assets/arrow_bottom.png",
                  width: 44,
                ))
            : Positioned(
                top: 20,
                child: Image.asset(
                  "assets/arrow_top.png",
                  width: 44,
                )),
        //  Image.asset("assets/switch_inner_gray.png")
        Positioned(
          top: dy,
          child: GestureDetector(
            child: Stack(
              alignment: Alignment.topCenter,
              children: [
                widget.status == Status.connected
                    ? SvgPicture.asset('assets/switch_inner_green.svg')
                    : SvgPicture.asset('assets/switch_inner_gray.svg'),
                getLight(widget.status),
                Positioned(
                  bottom: 20,
                  left: 24,
                  child: widget.status == Status.connected
                      ? Image.asset(
                          "assets/switch_hole_green.png",
                          width: 48,
                        )
                      : Image.asset(
                          "assets/switch_hole_gray.png",
                          width: 48,
                        ),
                ),
                Positioned(
                  bottom: 27,
                  left: 31,
                  child: widget.status == Status.connecting
                      ? Image.asset(
                          "assets/rotate.png",
                          width: 34,
                        )
                      : Image.asset(
                          "assets/power.png",
                          width: 34,
                        ),
                ),
                Positioned(
                  top: 45,
                  child: Container(
                      width: 95,
                      alignment: Alignment.center,
                      child: Text(
                        isOn != true ? "START" : "STOP",
                        style: GoogleFonts.baloo2(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: Colors.white54),
                      )),
                )
              ],
            ),
            onVerticalDragUpdate: (e) => setPosition(e.localPosition.dy),
            onVerticalDragStart: (e) => setState(() {
              start = e.localPosition.dy;
            }),
            onVerticalDragEnd: (e) => onPositionEnd(),
          ),
        ),
      ]),
    );
  }
}
