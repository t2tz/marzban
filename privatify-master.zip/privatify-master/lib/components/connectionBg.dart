import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter_svg/flutter_svg.dart';

class ConnectionBackground extends StatefulWidget {
  const ConnectionBackground({super.key});

  @override
  State<ConnectionBackground> createState() => _ConnectionBackgroundState();
}

class _ConnectionBackgroundState extends State<ConnectionBackground> {
  @override
  Widget build(BuildContext context) {
    return  Stack(children: [
        //Positioned(child: SvgPicture.asset("assets/connection_bg.svg"))
      ]);
  }
}