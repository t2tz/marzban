import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:privatify/components/searchInput.dart';

class ServerHeader extends StatefulWidget {
  const ServerHeader({super.key, required this.onSearch});

  final void Function(String) onSearch;

  @override
  State<ServerHeader> createState() => _ServerHeaderState();
}

class _ServerHeaderState extends State<ServerHeader> {
 
  var search = false;

  isSearch() {
    setState(() {
      search = !search;
    }); 
  }
  @override
  Widget build(BuildContext context) {
    return search == false ? Container(
            padding: const  EdgeInsets.symmetric(vertical: 12, horizontal: 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                GestureDetector(child: Row(
                  children: [
                    const Padding(
                      padding: EdgeInsets.only(right: 10),
                      child: Icon(Icons.arrow_back_outlined, color: Colors.white,),),
                    Text("Locations", style: Theme.of(context).textTheme.bodySmall)
                  ],
                ), onTap: () => Navigator.of(context).pop(),),
                GestureDetector(
                  onTap: () => isSearch(),
                  child: const Icon(Icons.search_outlined, color: Colors.white, size: 24,),)
              ],
            )
    ) :

     Container(
            padding: const  EdgeInsets.symmetric(vertical: 15, horizontal: 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                GestureDetector(child: Row(
                  children: [
                    const Padding(
                      padding: EdgeInsets.only(right: 10),
                      child: Icon(Icons.arrow_back_outlined, color: Colors.white,),),
                  
                  ],
                ), onTap: () => Navigator.of(context).pop(),),
                 Expanded(child: SearchInput(onType: (value) => widget.onSearch(value), icon: Icons.search_rounded,))
              ],
            )
    );
  
  }
}