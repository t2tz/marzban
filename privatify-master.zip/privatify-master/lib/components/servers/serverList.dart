import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:get/get.dart';
import 'package:privatify/components/servers/serverItem.dart';
import 'package:privatify/models/servers.dart' as ServerModel;
import 'package:privatify/store/vpn.dart';

import '../../helpers/helpers.dart';
import '../../store/server.dart';
import '../../store/user.dart';

class ServerList extends StatefulWidget {
  const ServerList({super.key, required this.servers});

  final List<ServerModel.Data> servers;

  @override
  State<ServerList> createState() => _ServerListState();
}

class _ServerListState extends State<ServerList> {
  final server = Get.find<Server>();
  final vpn = Get.find<VPN>();
  final user = Get.find<User>();

  handleSelectServer(ServerModel.Data serverData) async {
    if (vpn.status.value == Status.connected) {
      Helpers.dialogPrompt(context, "Change Protocol",
          "VPN will disconnect to make these change.", () async {
        await vpn.disconnect();
        await connectToServer(serverData);
      }, () {});
    } else {
      await connectToServer(serverData);
    }
  }

  connectToServer(ServerModel.Data serverData) async {
    await server.selectServer(serverData);
    await vpn.connect();
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      Expanded(
          child: ListView.builder(
              itemCount: widget.servers.length,
              itemBuilder: (context, index) {
                return ServerItem(
                  key: Key((widget.servers[index].id ?? 0).toString()),
                  serverId: widget.servers[index].id ?? 0,
                  title: widget.servers[index].city!.name ?? "",
                  url:
                      "https://api.privatify.net/flags/${widget.servers[index].country?.shortName}.png",
                  onItem: () => handleSelectServer(widget.servers[index]),
                  onFav: (id) => server.toggleFavorite(id),
                  isFav: true,
                  isPremium: user.profile.value.isPremium == true
                      ? false
                      : (widget.servers[index].premium ?? false),
                );
              }))
    ]);
  }
}
