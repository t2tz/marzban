import 'dart:convert';
import 'dart:developer';
import 'dart:ffi';

import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:get/get.dart';
import 'package:modal_bottom_sheet/modal_bottom_sheet.dart';
import 'package:privatify/components/servers/serverItem.dart';
import 'package:privatify/components/servers/serverList.dart';
import 'package:privatify/components/servers/serversHeader.dart';
import 'package:privatify/components/servers/tabs.dart';
import 'package:privatify/models/servers.dart' as ServerModel;

import '../../store/server.dart';
import '../../store/user.dart';
import '../../store/vpn.dart';

class ServersWidget {
  show(BuildContext context) async {
    showMaterialModalBottomSheet(
        backgroundColor: Colors.transparent,
        context: context,
        builder: (context) {
          return const Servers();
        });
  }
}

class Servers extends StatefulWidget {
  const Servers({super.key});

  @override
  State<Servers> createState() => _ServersState();
}

class _ServersState extends State<Servers> {
  final server = Get.find<Server>();
  final vpn = Get.find<VPN>();
  final user = Get.find<User>();
  final storage = new FlutterSecureStorage();

  List<ServerModel.Data> filterServers = [];

  List<ServerModel.Data> getRecomendedServers(List<ServerModel.Data> servers) {
    var recServers = <ServerModel.Data>[];
    for (var i = 0; i < 5; i++) {
      recServers.add(servers[i]);
    }
    return recServers;
  }

  List<ServerModel.Data> getAllServers(List<ServerModel.Data> servers) {
    return servers;
  }

  List<ServerModel.Data> getFavoriteServers(List<ServerModel.Data> servers) {
    return servers.where((element){
      return server.favServerIds.contains(element.id);
    }).toList();
  }

  @override
  void initState() {
    // TODO: implement initState
    filterServers = getRecomendedServers(server.servers);
    super.initState();
  }

  var search = "";
  onSearch(value) {
    setState(() {
      this.search = value;
      filterServers = server.servers.where((location) {
        return location.city!.name!.toLowerCase().contains(value) || location.country!.name!.toLowerCase().contains(value);
      }).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
        height: 550,
        padding: const EdgeInsets.symmetric(vertical: 20),
        decoration: const BoxDecoration(
            color: Color(0xff3a3a47),
            borderRadius: BorderRadius.only(
                topLeft: Radius.circular(25), topRight: Radius.circular(10))),
        child: Column(
          children: [
            Container(
              width: 32,
              height: 4,
              decoration: const BoxDecoration(
                  borderRadius: BorderRadius.all(Radius.circular(10)),
                  color: Color(0xff727289)),
            ),
           ServerHeader(onSearch: (value) => onSearch(value),),
           search.isEmpty ? PTabs(
              handleTab: (id) {
                setState(() {
                  if (id == 0) {
                  filterServers = getRecomendedServers(server.servers);
                }

                if (id == 1) {
                  filterServers = getAllServers(server.servers);
                }

                if(id == 2) {
                  filterServers = getFavoriteServers(server.servers);
                }
                });
              },
            ) : Container(),
            Expanded(
                //  margin: const EdgeInsets.only(top: 20),
                child: ServerList(servers: filterServers))
          ],
        ));
  }
}
