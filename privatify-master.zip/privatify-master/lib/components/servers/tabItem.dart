import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:get/get.dart';

class TabItem extends StatefulWidget {
  const TabItem(
      {super.key,
      this.title = "",
      required this.onTab,
      required this.id,
      required this.currentState});

  final String title;
  final int id;
  final int currentState;
  final void Function(int) onTab;

  @override
  State<TabItem> createState() => _TabItemState();
}

class _TabItemState extends State<TabItem> {
  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () => widget.onTab(widget.id),
        child: Container(
          
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: widget.id == widget.currentState ? const Color(0xff727289) : Colors.transparent,
              borderRadius: BorderRadius.circular(10),
              boxShadow: const [
                BoxShadow(
                    color: Color(0x40000000),
                    offset: Offset(0, 15),
                    blurRadius: 26,
                    spreadRadius: 0)
              ],
            ),
            child: Text(widget.title,
                style: Theme.of(context).textTheme.titleSmall)));
  }
}
