import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:privatify/components/servers/tabItem.dart';

class PTabs extends StatefulWidget {
  const PTabs({super.key, required this.handleTab});

  @override
  State<PTabs> createState() => _PTabsState();

  final void Function(int) handleTab;
}

class _PTabsState extends State<PTabs> {
  int currentState = 0;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 15, horizontal: 10),
      width: double.maxFinite,
      height: 48,
      decoration: const BoxDecoration(
          color: Color(0xff31323e),
          borderRadius: BorderRadius.all(Radius.circular(14))),
      child: Padding(padding: const EdgeInsets.all(7), child: Stack(children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Expanded(child: TabItem(currentState: currentState, id: 0, title: "Recomended", onTab: (id) {
              setState(() {
                currentState = id;
                widget.handleTab(id);
              });
            },)),
           Expanded(child: TabItem(currentState: currentState, id: 1, title: "All Servers", onTab: (id) {
              setState(() {
                currentState = id;
                widget.handleTab(id);
              });
            },)),
            Expanded(child: TabItem(currentState: currentState, id: 2, title: "Favorites", onTab: (id) {
              setState(() {
                currentState = id;
                widget.handleTab(id);
              });
            },))
          ],
        )
      ]),)
    );
  }
}
