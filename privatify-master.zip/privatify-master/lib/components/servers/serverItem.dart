import 'dart:developer';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:get/get.dart';
import 'package:privatify/components/circleImage.dart';
import 'package:privatify/helpers/helpers.dart';

import '../../store/server.dart';
import '../../store/user.dart';

class ServerItem extends StatelessWidget {
  const ServerItem(
      {super.key,
      required this.url,
      required this.title,
      required this.onItem,
      required this.onFav,
      required this.serverId,
      required this.isFav,
      this.isPremium = true});

  final String url;
  final String title;
  final int serverId;
  final bool isFav;
  final bool isPremium;
  final void Function() onItem;
  final void Function(int) onFav;

  @override
  Widget build(BuildContext context) {


    handlePremiumServer() {
      Helpers.errorToast(context, "This Location is for premium members only.");
      Navigator.of(context).pop();
    }

    final server = Get.find<Server>();

    return GestureDetector(
      onTap: () => isPremium != true ? onItem() : handlePremiumServer(),
      child: Row(children: [
        SizedBox(
          width: 50,
          child: Center(
              child: CircleImage(key: Key(serverId.toString()), url: url)),
        ),
        Expanded(
            child: Container(
          padding:
              const EdgeInsets.only(right: 15, left: 5, bottom: 15, top: 15),
          decoration: const BoxDecoration(
            border:
                Border(bottom: BorderSide(color: Color(0xff5a5d78), width: 1)),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                title,
                style: Theme.of(context).textTheme.bodyMedium,
              ),
              isPremium != true 
                  ? InkWell(
                      onTap: () => onFav(serverId),
                      child: Obx(
                        () => !server.favServerIds.contains(serverId)
                            ? Image.asset(
                                "assets/star_off.png",
                                width: 24,
                              )
                            : Image.asset(
                                "assets/star_on.png",
                                width: 24,
                              ),
                      ))
                  : const Icon(
                      Icons.lock_outline_rounded,
                      color: Colors.white54,
                    )
            ],
          ),
        ))
      ]),
    );
  }
}
