import 'package:flutter/material.dart';

class CircleImage extends StatelessWidget {
  const CircleImage({super.key, this.size = 20, required this.url});

  final double size;
  final String url;

  @override
  Widget build(BuildContext context) {
    return Center(
        child: Container(
            width: size,
            height: size,
            decoration: BoxDecoration(
                shape: BoxShape.circle,
                image: DecorationImage(
                    fit: BoxFit.cover, image: NetworkImage(url)))));
  }
}
