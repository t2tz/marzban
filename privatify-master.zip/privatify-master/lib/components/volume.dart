import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';

class Volume extends StatelessWidget {
  const Volume({super.key, this.leftUsage = 0, this.totalUsage = 2.0, this.isPremium = false});

  final double leftUsage;
  final double totalUsage;
  final bool isPremium;

  @override
  Widget build(BuildContext context) {

    
    return Stack(  children: [Container(
       width: 130,
       height: 40,
      decoration: BoxDecoration(

        borderRadius: BorderRadius.circular(10),
        color: const Color(0x552e2e38).withOpacity(.5),
       ),
       
      
  ), Positioned(

    left: 0,
    top: 0,
    
    child: SizedBox(
       width: 130,
       height: 40,
       
       child: FractionallySizedBox(
        
        widthFactor: totalUsage == 0 ? 1 : leftUsage / totalUsage,
        heightFactor: 1,
        alignment: FractionalOffset.centerLeft,
        
        child: DecoratedBox(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            color: const Color(0xff2e2e38).withOpacity(.5),
          ),
        ),
        
       )

    )),
    Container(
      width: 130,
      height: 40,
      child: Center(child:Text( isPremium == true ? "Premium" :   leftUsage > 0 ? "$leftUsage GB Left" : "Go Premium", style: Theme.of(context).textTheme.titleSmall,)),
    )
    ]);
  }
}