import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';

class SearchInput extends StatelessWidget {
  const SearchInput({
    Key? key,
    this.placeholder = "",
    required this.onType,
    this.password = false,
    this.icon,
    this.type = TextInputType.text,
    this.inputFormatters,
  });

  final String placeholder;
  final void Function(String) onType;
  final bool password;
  final IconData? icon;
  final TextInputType type;
  final List<TextInputFormatter>? inputFormatters;

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      
      keyboardType: type,
      inputFormatters: inputFormatters,
      cursorColor: const Color(0xff5a5d78),
      onChanged: (value) => onType(value),
      style: GoogleFonts.baloo2(
          fontSize: 22, fontWeight: FontWeight.w600, color:  Colors.white),
      decoration: InputDecoration(
       filled: true,
       fillColor: Color(0xff31323e),
          label: null,
          contentPadding:
              const EdgeInsets.only(top: 12, bottom: 12, left: 10, right: 10),
          hintStyle: const TextStyle(color: Color(0xff5a5d78)),
          labelStyle: GoogleFonts.baloo2(
          fontSize: 22, fontWeight: FontWeight.w600, color: const Color(0xff5a5d78)),
          focusedBorder: const OutlineInputBorder(
            borderRadius: BorderRadius.all(Radius.circular(20)),
              borderSide: BorderSide.none),
          enabled: true,
          enabledBorder: const OutlineInputBorder(
              borderRadius: BorderRadius.all(Radius.circular(20)),
              borderSide: BorderSide.none),

          // border: OutlineInputBorder(
          //     borderSide: BorderSide(
          //         color: Colors.black, width: 10, style: BorderStyle.solid)),
          labelText: placeholder,
          suffixIcon: icon != null
              ? Icon(
                  icon,
                  color: const Color(0xff5a5d78),
                )
              : null,
          suffixIconColor: Color(0xff5a5d78),
          iconColor: Colors.black,
          focusColor: Colors.black),
    );
  }
}
