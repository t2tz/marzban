import 'dart:developer';

import 'package:flutter/material.dart';

enum ButtonColors { yellow, gray }

class PButton extends StatelessWidget {
  const PButton(
      {super.key,
      this.title = "Hello world",
      this.loading = "",
      
      this.color = ButtonColors.yellow, required this.onPress});

  final String title;
  final ButtonColors color;
  final void Function() onPress;
  final String loading;

  @override
  Widget build(BuildContext context) {
    Color getColor(Set<MaterialState> states) {
      const Set<MaterialState> interactiveStates = <MaterialState>{
        MaterialState.pressed,
        MaterialState.hovered,
        MaterialState.focused,
      };
      if (states.any(interactiveStates.contains)) {
        return Colors.transparent;
      }
      return Colors.transparent;
    }

    return TextButton(
      onPressed: () => onPress(),
      
      style: ButtonStyle(
          //overlayColor: MaterialStateProperty.all(0),
          padding: MaterialStateProperty.all(EdgeInsets.zero),
          backgroundColor: MaterialStateColor.resolveWith(getColor),
          foregroundColor: MaterialStateProperty.resolveWith(getColor),
          mouseCursor: MaterialStateProperty.all(SystemMouseCursors.click)),
      child: Container(
          width: double.maxFinite,
          alignment: Alignment.center,
          padding: EdgeInsets.symmetric(vertical: 10),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            gradient: color == ButtonColors.yellow
                ? const LinearGradient(
                    colors: [Color(0xffffc500), Color(0xffff9100)],
                    stops: [0, 1],
                    begin: Alignment(0.99, -0.16),
                    end: Alignment(-0.99, 0.16),
                    // angle: 261,
                    // scale: undefined,
                  )
                : null,
            color: color == ButtonColors.gray ? const Color(0xff565762) : null,
            boxShadow: color == ButtonColors.yellow
                ? const [
                    BoxShadow(
                        color: Color(0x3dffc300),
                        offset: Offset(0, 21),
                        blurRadius: 26,
                        spreadRadius: 0)
                  ]
                : null,
          ),
          child: Text(loading.isNotEmpty ? loading :  title, style: Theme.of(context).textTheme.titleMedium)),
    );
  }
}
