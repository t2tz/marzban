import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';

class Background extends StatelessWidget {
  const Background(
      {super.key,
      this.child = const SizedBox(),
      this.hasBackground = false,
      this.scrollView = false,
      this.color = "gray"});

  final Widget child;
  final bool hasBackground;
  final bool scrollView;
  final String color;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Container(
            width: double.infinity,
            height: double.maxFinite,
            decoration: color == "gray"
                ? BoxDecoration(
                    image: hasBackground == true
                        ? const DecorationImage(
                            image: AssetImage("assets/map.png"),
                            fit: BoxFit.none,
                            alignment: Alignment.center)
                        : null,
                    gradient: const LinearGradient(
                      colors: [
                        Color(0xff0f1018),
                        Color(0xff15161f),
                        Color(0xff3a3a47)
                      ],
                      stops: [0, 0.1478630006313324, 1],
                      begin: Alignment(-0.78, 0.63),
                      end: Alignment(0.78, -0.63),
                      // angle: 51,
                      // scale: undefined,
                    ))
                :  BoxDecoration(
                  image: hasBackground == true
                        ? const DecorationImage(
                            image: AssetImage("assets/map.png"),
                            fit: BoxFit.none,
                            alignment: Alignment.center)
                        : null,
                    gradient: LinearGradient(
                    colors: [
                      Color(0xff74958a),
                      Color(0xff5f8277),
                      Color(0xff10231d)
                    ],
                    stops: [0, 0.3319369852542877, 1],
                    begin: Alignment(0.79, -0.62),
                    end: Alignment(-0.79, 0.62),
                    // angle: 232,
                    // scale: undefined,
                  )),
            child: SafeArea(
              minimum: EdgeInsets.only(top: 15),
              child: scrollView == true
                ? SingleChildScrollView(child: child)
                : child,)));
  }
}
