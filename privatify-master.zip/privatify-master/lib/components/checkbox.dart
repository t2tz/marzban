import 'package:flutter/material.dart';
import 'package:privatify/helpers/helpers.dart';

class PCheckbox extends StatefulWidget {
  const PCheckbox({super.key, this.value = false, required this.onChanged, this.locked = false});

  final bool value;
  final bool locked;
  final void Function(bool) onChanged;

  @override
  State<PCheckbox> createState() => _PCheckboxState();
}

class _PCheckboxState extends State<PCheckbox> {

  bool value = false;

  @override
  void initState() {
    value = widget.value;
    // TODO: implement initState
    super.initState();
  }

  changeValue() {
    setState(() {
      value = !value;
      widget.onChanged(value);
    });

  }

   handleLockedOption() {
    Helpers.errorToast(context, "This option available for Premium Members.");
    Navigator.of(context).pop();
   }
  
  @override
  Widget build(BuildContext context) {
    return InkWell(

      onTap: () => widget.locked == false ? changeValue() : handleLockedOption(),


      child: Stack(alignment: Alignment.center, children: [
        Container(
            width: 28,
            height: 28,
            decoration: BoxDecoration(
                color: const Color(0xff5b5c74),
                borderRadius: BorderRadius.circular(6))),
      value == true ?   Container(
            width: 14,
            height: 14,
            decoration: BoxDecoration(
                color: const Color(0xff0ef62c),
                borderRadius: BorderRadius.circular(4),
                boxShadow: const [
                  BoxShadow(
                      color: Color(0xff0ef62c),
                      offset: Offset(0, 0),
                      blurRadius: 14,
                      spreadRadius: 0)
                ])) : widget.locked == true ?  const Icon(Icons.lock_outline_rounded, color: Colors.white54,) : Container()
      ]),
    );
  }
}
