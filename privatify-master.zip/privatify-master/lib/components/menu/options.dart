import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:get/get.dart';
import 'package:privatify/store/refrences.dart';

import 'option.dart';

class Options extends StatefulWidget {
  const Options({Key? key}) : super(key: key);

  @override
  State<Options> createState() => _OptionsState();
}

class _OptionsState extends State<Options> {
  @override
  Widget build(BuildContext context) {
    return Container(
        padding: EdgeInsets.only(top: 25),
        child: SingleChildScrollView(
          child: Column(children: [
            Option(
              title: "Preferences",
              description: "discover app preferences here.",
              icon: "assets/settings.png",
              toPath: () => Get.toNamed("/pref"),
              hasBorder: true,
            ),
            Option(
              title: "Privacy and Security  Tools",
              description: "Check privacy and security here.",
              icon: "assets/fingerprint.png",
              toPath: () => Get.toNamed("/contents", arguments: 0),
              hasBorder: true,
            ),
            Option(
              title: "Help and Support",
              description: "Get Help and Support here.",
              icon: "assets/help.png",
              toPath: () => Get.toNamed("/contents", arguments: 1),
              hasBorder: true,
            ),
            Option(
                title: "Refer Friends",
                description: "Get free days with referer friends.",
                icon: "assets/gift.png",
                toPath: () => Get.toNamed("/referer"),
                hasBorder: false)
          ]),
        ));
  }
}
