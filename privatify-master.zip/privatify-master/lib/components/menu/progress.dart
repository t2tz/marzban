import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'dart:math' as Math;

class DayProgress extends StatefulWidget {
  const DayProgress({super.key, this.value = 0});

  final double value;

  @override
  State<DayProgress> createState() => _DayProgressState();
}

class _DayProgressState extends State<DayProgress> {
  @override


  //var value = .+' '+2*math.PI*72
  Widget build(BuildContext context) {
    return SvgPicture.string('''

 
    <svg xmlns="http://www.w3.org/2000/svg" width="201" height="201" viewBox="0 0 201 201" >
      <defs>
        <filter id="ufk9xr992a" width="201" height="201" x="0" y="0" filterUnits="userSpaceOnUse">
          <feOffset />
          <feGaussianBlur result="blur" stdDeviation="8" />
          <feFlood flood-color="#0ef62c" flood-opacity=".639" />
          <feComposite in2="blur" operator="in" />
          <feComposite in="SourceGraphic" />
        </filter>
      </defs>
      <g>
        <g fill="none" stroke="#54566b" stroke-width="3px" transform="translate(-80 -140) translate(108 168)">
          <circle cx="72" cy="72" r="72" stroke="none" />
          <circle cx="72" cy="72" r="70.5" />
        </g>
        <g filter="url(#ufk9xr992a)" transform="translate(-80 -140) translate(80 140)">
          <circle cx="72" cy="72" r="72" fill="none" stroke="#0ef62c" stroke-dasharray="${widget.value * 2 * Math.pi * 72 } ${2 * Math.pi * 72}" stroke-linecap="round" stroke-width="9px"   transform="translate(28.5 28.5)" />
        </g>
      </g>
    </svg>


''');
  }
}
