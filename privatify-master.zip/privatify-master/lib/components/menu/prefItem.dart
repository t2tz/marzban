import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';

class PrefItem extends StatelessWidget {
  const PrefItem(
      {Key? key,
      required this.title,
      required this.description,
      required this.icon,
      required this.url,
      this.hasBorder = true,
      this.isClickable = false,
      this.onItem,
      this.rightSide,
      this.leftSide,
      this.locked = false})
      : super(key: key);

  final String title;
  final String description;
  final String icon;
  final String url;
  final bool hasBorder;
  final bool isClickable;
  final VoidCallback? onItem;
  final Widget? rightSide;
  final Widget? leftSide;
  final bool locked;

  Widget HandleWidget(bool clickable, Widget child) {
    if (clickable && !locked) {
      return MouseRegion(
        cursor: SystemMouseCursors.click,
        child: InkWell(
          onTap: () => onItem != null ? onItem!() : log("Hello"),
          child: child,
        ),
      );
    } else {
      return Container(
        child: child,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
        child: HandleWidget(
            isClickable,
            Stack(
              children: [
                Positioned(
                  top: 25,
                  left: 20,
                  child: leftSide ??
                      (icon.isNotEmpty
                          ? Image.asset(
                              icon,
                              width: 32,
                            )
                          : Container()),
                ),
                Padding(
                  padding: EdgeInsets.only(left: icon.isNotEmpty || leftSide != null ? 75: 25),
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                            padding: const EdgeInsets.only(left: 10),
                            decoration: BoxDecoration(
                              border: hasBorder == true
                                  ? const Border(
                                      bottom:
                                          BorderSide(color: Color(0xff5a5d78)))
                                  : null,
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              children: [
                                Container(
                                 
                                  padding:
                                       EdgeInsets.only(top: 10, bottom: 10, right: (leftSide != null ? 0: 40) ),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        title,
                                        
                                        style: GoogleFonts.baloo2(
                                            fontSize: 20,
                                            fontWeight: FontWeight.bold,
                                            color: Colors.white),
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                      Text(
                                        description,
                                        style: Theme.of(context)
                                            .textTheme
                                            .titleSmall,

                                         overflow: leftSide != null ? TextOverflow.visible : TextOverflow.ellipsis,
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            )),
                      ]),
                ),
           
                isClickable
                    ? Positioned(
                        top: rightSide != null ? 10 : 30,
                        right: rightSide != null ? 10 : 30,
                        child: rightSide ??
                            Image.asset(
                              'assets/arrow.png',
                              width: 32,
                            ),
                      )
                    : Container(),
              ],
            )));
  }
}
