import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';

class Option extends StatelessWidget {
  const Option(
      {Key? key,
      required this.title,
      required this.description,
      required this.icon,
      this.hasBorder = true,
      this.toPath})
      : super(key: key);

  final String title;
  final String description;
  final String icon;
  final VoidCallback? toPath;
  final bool hasBorder;

  @override
  Widget build(BuildContext context) {
    return Container(
        width: double.infinity,
        child: MouseRegion(
            cursor: SystemMouseCursors.click,
            child: InkWell(
                onTap: toPath,
                child: Stack(
                  children: [
                    Positioned(
                      top: 25,
                      left: 10,
                      child: Image.asset(
                        icon,
                        width: 32,
                      ),
                    ),
                    Padding( padding: const EdgeInsets.only(
                                  left: 60), child:
                    Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(vertical: 15),
                            decoration:  BoxDecoration(
                              border: hasBorder == true ? const Border(bottom: BorderSide(color:  Color(0xff5a5d78))) : null,
                              
                            ),
                              
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    title,
                                      style: GoogleFonts.baloo2(
                                            fontSize: 20,
                                            fontWeight: FontWeight.bold,
                                            color: Colors.white),
                                  ),
                                  Text(
                                    description,
                                    style: Theme.of(context).textTheme.titleSmall
                                  ),

                                
                                ],

                              ))
                        ])),
                  ],
                ))));
  }
}
