import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:get/get.dart';

class HeaderMenu extends StatelessWidget {
  const HeaderMenu({super.key, this.title = "", this.right = false});

  final String title;
  final bool right;

   logout() async {
    final storage = new FlutterSecureStorage();
    await storage.delete(key: "jwt-token");
    Get.toNamed('/welcome');
  }

  @override
  Widget build(BuildContext context) {
    return Container(

      padding: const EdgeInsets.only(left: 25, right: 25),
      
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
      Container(
        child: InkWell(child: Image.asset('assets/back.png', width: 48,), onTap: () => Navigator.of(context).pop(),)
      ),
      Container(
        child: Text(title, style: Theme.of(context).textTheme.titleSmall, overflow: TextOverflow.ellipsis),
      ),
      Container(
        child: right ? InkWell(onTap: () => logout(), child: Row(children: [Padding(padding: const EdgeInsets.symmetric(horizontal: 5), child: Text("Sign out", style: Theme.of(context).textTheme.titleSmall,)), Image.asset("assets/logout.png", width: 48,),],),) : null
      )

    ],),);
  }
}