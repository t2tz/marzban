import 'package:flutter/material.dart';
import 'package:rive/rive.dart';

class Loading extends StatelessWidget {
  late RiveAnimationController loadingController;

  @override
  Widget build(BuildContext context) {
    loadingController = SimpleAnimation("Animation 1", autoplay: true);

    return SizedBox(
      width: 88,
      child: RiveAnimation.asset(
        "assets/dots.riv",
        controllers: [loadingController],
        fit: BoxFit.contain,
      ),
    );
  }
}
